package com.base.thirdlibs;

/**
 * base class libs
 * integrate simple class such as utils class and others
 * */
public class Note {
}
