package com.juying.mjreader.data.entities;

public class NovelChapter {
    //章节地址
    private String url;
    //章节标题
    private String title;
    //章节序号
    private Integer index;
    //章节起始位置
    private static Long start;
    //章节终止位置
    private Long end;
    //EPUB书籍当前章节的fragmentId
    private String startFragmentId;
    //EPUB书籍下一章章节的fragmentId
    private String endFragmentId;
    //变量
    private String variable;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public static Long getStart() {
        return start;
    }

    public void setStart(Long start) {
        this.start = start;
    }

    public Long getEnd() {
        return end;
    }

    public void setEnd(Long end) {
        this.end = end;
    }

    public String getStartFragmentId() {
        return startFragmentId;
    }

    public void setStartFragmentId(String startFragmentId) {
        this.startFragmentId = startFragmentId;
    }

    public String getEndFragmentId() {
        return endFragmentId;
    }

    public void setEndFragmentId(String endFragmentId) {
        this.endFragmentId = endFragmentId;
    }

    public String getVariable() {
        return variable;
    }

    public void setVariable(String variable) {
        this.variable = variable;
    }

    public NovelChapter(String url, String title, Integer index, Long start, Long end, String startFragmentId, String endFragmentId, String variable) {
        this.url = url;
        this.title = title;
        this.index = index;
        this.start = start;
        this.end = end;
        this.startFragmentId = startFragmentId;
        this.endFragmentId = endFragmentId;
        this.variable = variable;
    }

    @Override
    public String toString() {
        return "NovelChapter{" +
                "url='" + url + '\'' +
                ", title='" + title + '\'' +
                ", index=" + index +
                ", start=" + start +
                ", end=" + end +
                ", startFragmentId='" + startFragmentId + '\'' +
                ", endFragmentId='" + endFragmentId + '\'' +
                ", variable='" + variable + '\'' +
                '}';
    }
}
