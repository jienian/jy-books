package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class LoginPhoneReq(val phone: String, val password: String): BaseReq()
