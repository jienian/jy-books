package com.juying.mjreader.view;

import android.content.Context;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogLoadingBinding;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogLoading extends BaseDialog {
    private DialogLoadingBinding vBinding;

    public DialogLoading(@NonNull Context context) {
        super(context, R.style.DialogTheme);
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
//        View view = View.inflate(context, R.layout.dialog_book_input, null);
        vBinding = DialogLoadingBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);

        //区域外点击不关闭dialog
        setCanceledOnTouchOutside(false);
    }
}
