package com.juying.mjreader.network.models

data class RegisterAccountRes(val phone: String, val password: String): BaseReq()
