package com.juying.mjreader.network.converter

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.TypeAdapter
import com.google.gson.reflect.TypeToken
import com.juying.mjreader.network.models.Res
import com.juying.mjreader.network.util.DecryptUtils

import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okhttp3.ResponseBody
import okio.Buffer
import retrofit2.Converter
import retrofit2.Retrofit
import java.io.OutputStreamWriter
import java.io.Writer
import java.lang.reflect.Type
import java.nio.charset.Charset
/**
 * @author Nimyears
 */

class DecryptionConverterFactory(private val gson: Gson) : Converter.Factory() {
    private val mediaType = "application/json; charset=UTF-8".toMediaTypeOrNull()
    private val utf8 = Charset.forName("UTF-8")

    companion object {
        fun create(): DecryptionConverterFactory {
            return DecryptionConverterFactory(Gson())
        }
    }

    inner class DecryptionResponseBodyConverter<T>(
        private val gson: Gson,
        private val adapter: TypeAdapter<T>
    ) : Converter<ResponseBody, T> {
        override fun convert(value: ResponseBody): T {
            val res = value.string()
            return try {
                decryptData(res)
            } catch (e: Exception) {
                Log.d("decryptData", e.toString())
                adapter.fromJson(res)
            } finally {
                value.close()
            }
        }

        private fun decryptData(json: String): T {
            val res = gson.fromJson(json, Res::class.java)
            val data = DecryptUtils.decryptResp(
                res.safety!!,
                res.safetyData!!
            )
            val jsonElement = gson.fromJson(json, JsonElement::class.java)
            val jsonObject = jsonElement.asJsonObject
            jsonObject.remove("safety")
            jsonObject.remove("safetyData")
            jsonObject.add("data", gson.fromJson(data, JsonElement::class.java))
            return adapter.fromJson(jsonObject.toString())
        }
    }

    inner class DecryptionRequestBodyConverter<T>(
        private val gson: Gson,
        private val adapter: TypeAdapter<T>
    ) : Converter<T, RequestBody> {
        override fun convert(value: T): RequestBody {
            val buffer = Buffer()
            val writer: Writer = OutputStreamWriter(buffer.outputStream(), utf8)
            val jsonWriter = gson.newJsonWriter(writer)
            adapter.write(jsonWriter, value)
            jsonWriter.close()
            return RequestBody.create(mediaType, buffer.readByteString())
        }
    }

    override fun responseBodyConverter(
        type: Type,
        annotations: Array<out Annotation>,
        retrofit: Retrofit
    ): Converter<ResponseBody, *> {
        val adapter: TypeAdapter<*> = gson.getAdapter(TypeToken.get(type))
        return DecryptionResponseBodyConverter(gson, adapter)
    }

    override fun requestBodyConverter(
        type: Type,
        parameterAnnotations: Array<out Annotation>,
        methodAnnotations: Array<out Annotation>,
        retrofit: Retrofit
    ): Converter<*, RequestBody> {
        val adapter: TypeAdapter<*> = gson.getAdapter(TypeToken.get(type))
        return DecryptionRequestBodyConverter(gson, adapter)
    }
}