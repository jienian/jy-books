package com.juying.mjreader.view;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogGroupingEdit extends Dialog {
    public DialogGroupingEdit(@NonNull Context context, int themeResId, DialogGroupingEditListener listener) {
        super(context, themeResId);
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
        View view = View.inflate(context, R.layout.dialog_grouping_edit, null);
        setContentView(view);
        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.6f);
        //设置弹出位置
        window.setGravity(Gravity.TOP);

        //区域外点击不关闭dialog
//        setCanceledOnTouchOutside(false);

        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

//FLAG_WATCH_OUTSIDE_TOUCH作用：如果点击事件发生在window之外，就会收到一个特殊的MotionEvent，为ACTION_OUTSIDE
//        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);


        view.findViewById(R.id.ll1).setOnClickListener(view1 -> {
            dismiss();
            listener.onClickEdit();
        });
        view.findViewById(R.id.ll2).setOnClickListener(view1 -> {
            dismiss();
            listener.onClickChangeName();
        });
        view.findViewById(R.id.ll3).setOnClickListener(view1 -> {
            dismiss();
            listener.onClickDel();
        });
    }

    public interface DialogGroupingEditListener {

        void onClickDel();

        void onClickEdit();

        void onClickChangeName();

    }


}
