package com.juying.mjreader;

import android.app.Activity;

import com.juying.mjreader.utils.CurrentActivityUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 16:32
 */
public class ActivityManager {
    private static ActivityManager aManager;
    private List<Activity> list;

    private ActivityManager() {
        if (list == null) {
            list = new ArrayList<>();
        }
    }

    public static ActivityManager getActivityManager() {
        if (aManager == null) {
            aManager = new ActivityManager();
        }
        return aManager;
    }

    public void addA(Activity activity) {
        list.add(activity);
    }

    public void delA(Activity activity) {
        list.remove(activity);
    }

    public Activity getTopA() {
        if (list != null) {
            return list.get(list.size() == 0 ? 0 : list.size() - 1);
        }
        return null;
    }

//    public static Activity getCurrentActivity(Context context) {
//        @SuppressLint("ServiceCast") android.app.ActivityManager activityManager = (android.app.ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//        Activity currentActivity = null;
//        if (activityManager != null) {
//            currentActivity = activityManager.getRunningTasks(1).get(0).topActivity.;
//            context.getCA
//        }
//        return currentActivity;
//    }


    public static Activity getCurrentActivity() {
        return CurrentActivityUtil.getCurrentActivity();
    }



}
