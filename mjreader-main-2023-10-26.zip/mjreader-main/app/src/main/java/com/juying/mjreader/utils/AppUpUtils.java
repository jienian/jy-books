package com.juying.mjreader.utils;


import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import java.io.File;

/**
 * Created by ycc
 * on 2019/4/8
 */
public class AppUpUtils {


    /**
     * 下载Apk
     */
    public static String downloadApk(Context context, String saveSdDirectory, String apkName, String downloadUrl, DownloadListener downloadListener) {
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));

        String saveApkName = apkName + ".apk";
        //保存到SDk的本应用内置目录
        request.setDestinationInExternalFilesDir(context, saveSdDirectory, saveApkName);
        //保存到sd卡的任意地方
//        request.setDestinationInExternalPublicDir(saveSdDirectory, saveApkNmae);

        //下载的目录
        File filePath = Environment.getExternalStoragePublicDirectory(saveSdDirectory);
        if (!filePath.exists()) {
            filePath.mkdirs();
        }
        if (!filePath.isDirectory()) {
            filePath.mkdirs();
        }
        String apkSavePath = context.getExternalFilesDir(saveSdDirectory).getAbsolutePath() + "/" + saveApkName;
        LogUtil.d("TAG","APk下载路径："+apkSavePath);
        //如果已存在一定要删除重新下载
        File apkFile = new File(apkSavePath);
        if (apkFile.exists()) {
            apkFile.delete();
        }
        request.setTitle(apkName);
//        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
        request.setDescription("正在下载...");
        //表示下载中和下载完成都显示通知
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        //网络下载的类型，默认什么网络都可以下载
        // request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
        //下载完成后，点击以什么方式打开
        request.setMimeType("application/vnd.android.package-archive");
        long downloadId = downloadManager.enqueue(request);//正式开始下载
        progressListener(downloadManager,downloadId,downloadListener);//监听
        //下载完成有一个广播发出
        return apkSavePath;
    }





    public static void   progressListener(DownloadManager downloadManager, long downloadId, DownloadListener downloadListener) {
        Handler mHandler=new Handler(Looper.myLooper());
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                boolean isFinish = false;
                DownloadManager.Query down_query = new DownloadManager.Query(); // 创建一个下载查询对象，按照下载编号过滤
                down_query.setFilterById(downloadId); // 设置下载查询对象的编号过滤器
                // 向下载管理器查询下载任务，并返回查询结果集的游标
                Cursor cursor = downloadManager.query(down_query);
                while (cursor.moveToNext()) {
                    int uriIdx = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);
                    int mediaIdx = cursor.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE);
                    int totalIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
                    int nowIdx = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                    int statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
//                    if (cursor.getString(uriIdx) == null) {
//                        break;
//                    }
                    // 根据总大小和已下载大小，计算当前的下载进度
                    int progress = (int) (100 * cursor.getLong(nowIdx) / cursor.getLong(totalIdx));
                    downloadListener.progressUp(progress); // 设置文本进度圈的当前进度
                    if (progress == 100) { // 下载完毕
                        isFinish = true;
                    }
                }
                cursor.close(); // 关闭数据库游标
                if (!isFinish) { // 下载未完成，则继续刷新
                    mHandler.postDelayed(this, 50); // 延迟50毫秒后再次启动刷新任务
                } else { // 下载已完成，停止轮询
                    mHandler.removeCallbacks(this);
                }
            }
        };
        mHandler.post(runnable);
    }

    // 定义一个下载进度的监听
    public interface DownloadListener {
        void progressUp(int progress);
    }

    /**
     * 安装Apk
     *
     * @param uri 注意7.0
     */
    public static void installApk(Context context, Uri uri) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //解決7.0安裝錯誤 Permission Denial: opening provider android.support.v4.content.FileProvider from ProcessRecord
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        context.startActivity(intent);
    }
}
