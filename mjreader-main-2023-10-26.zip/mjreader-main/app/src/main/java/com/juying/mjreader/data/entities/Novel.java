package com.juying.mjreader.data.entities;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class Novel {
    //目录页URL
    private String novelUrl;
    //小说名
    private String novelName;
    //小说作者
    private String author;
    //最新章节标题
    private String latestChapterTitle;
    //最新章节标题更新时间
    private String latestChapterTime;
    //小说目录总数
    private String totalChapterNum;
    //当前章节索引
    private String  durChapterIndex;
    //当前章节题目
    private String durChapterTitle;
    // 当前阅读的进度(首行字符的索引位置)
    private String  durChapterPos;
    //最近一次阅读书籍的时间（打开正文的时间）
    private String durChapterTime;
    // 自定义字符集名称-本地书籍
    private String charset;

    private String originName;

    public Novel() {

    }

    public void setOriginName(String originName) {
        this.originName = originName;
    }

    public String getNovelUrl() {
        return novelUrl;
    }

    public void setNovelUrl(String novelUrl) {
        this.novelUrl = novelUrl;
    }

    public String getNovelName() {
        return novelName;
    }

    public void setNovelName(String novelName) {
        this.novelName = novelName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getLatestChapterTitle() {
        return latestChapterTitle;
    }

    public void setLatestChapterTitle(String latestChapterTitle) {
        this.latestChapterTitle = latestChapterTitle;
    }

    public String getLatestChapterTime() {
        return latestChapterTime;
    }

    public void setLatestChapterTime(String latestChapterTime) {
        this.latestChapterTime = latestChapterTime;
    }

    public String getTotalChapterNum() {
        return totalChapterNum;
    }

    public void setTotalChapterNum(String totalChapterNum) {
        this.totalChapterNum = totalChapterNum;
    }

    public String getDurChapterIndex() {
        return durChapterIndex;
    }

    public void setDurChapterIndex(String durChapterIndex) {
        this.durChapterIndex = durChapterIndex;
    }

    public String getDurChapterTitle() {
        return durChapterTitle;
    }

    public void setDurChapterTitle(String durChapterTitle) {
        this.durChapterTitle = durChapterTitle;
    }

    public String getDurChapterPos() {
        return durChapterPos;
    }

    @Override
    public String toString() {
        return "Novel{" +
                "charset='" + charset + '\'' +
                '}';
    }

    public void setDurChapterPos(String durChapterPos) {
        this.durChapterPos = durChapterPos;
    }

    public String getDurChapterTime() {
        return durChapterTime;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public void setDurChapterTime(String durChapterTime) {
        this.durChapterTime = durChapterTime;
    }


    public Novel(String novelUrl, String novelName, String author, String latestChapterTitle, String latestChapterTime, String totalChapterNum, String durChapterIndex, String durChapterTitle, String durChapterPos, String durChapterTime, String charset, String originName) {
        this.novelUrl = novelUrl;
        this.novelName = novelName;
        this.author = author;
        this.latestChapterTitle = latestChapterTitle;
        this.latestChapterTime = latestChapterTime;
        this.totalChapterNum = totalChapterNum;
        this.durChapterIndex = durChapterIndex;
        this.durChapterTitle = durChapterTitle;
        this.durChapterPos = durChapterPos;
        this.durChapterTime = durChapterTime;
        this.charset = charset;
        this.originName = originName;
    }


    private static Charset charset() {
        return StandardCharsets.UTF_8;
    }

    public Charset fileCharset() {
        return charset();
    }

    public String getCharset() {
        return charset;
    }


    public String getOriginName() {
        return originName;
    }


}
