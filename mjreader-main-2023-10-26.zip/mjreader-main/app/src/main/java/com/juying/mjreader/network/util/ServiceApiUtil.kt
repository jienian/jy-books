package com.juying.mjreader.network.util

import android.util.Log
import android.widget.Toast
import com.juying.mjreader.MjApplication
import com.juying.mjreader.network.converter.DecryptionConverterFactory
import com.juying.mjreader.network.interceptor.LoggingInterceptor
import com.juying.mjreader.network.models.Res



import okhttp3.OkHttpClient
import retrofit2.Retrofit

object ServiceApiUtil {
    fun createRetrofit(baseUrl: String): Retrofit {
        val builder = OkHttpClient.Builder()
        builder.addInterceptor(LoggingInterceptor())
        val okHttpClient = builder.build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(DecryptionConverterFactory.create())
            .build()
    }

    suspend fun <T> query(showErrorToast: Boolean = false, block: suspend () -> Res<T>): Res<T>? {
        return try {
            val res = block()
            if (res.status == 1) {
                Log.d("ServiceApiUtil", "res ${res.data}")
                res
            } else {
                Log.d("ServiceApiUtil errorCode", "${res.errorCode}")
                if (showErrorToast) {
                    Toast.makeText(MjApplication.CONTEXT, "服务器繁忙！", Toast.LENGTH_SHORT).show()
                }
                null
            }
        } catch (e: Exception) {
            Log.d("ServiceApiUtil Exception", e.toString())
            if (showErrorToast) {
                Toast.makeText(MjApplication.CONTEXT, "请求失败！请检查网络", Toast.LENGTH_SHORT)
                    .show()
            }
            null
        }
    }
}