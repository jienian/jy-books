package com.juying.mjreader.utils;

import android.widget.ImageView;

import com.juying.mjreader.R;

/**
 * @Author Ycc
 * @Date 19:51
 */
public class WifiFragmentMode {
    /**
     * 设置搜索引擎图标
     *
     * @param imageView
     * @param searchEngine
     */
    public static void setImageView(ImageView imageView, String searchEngine) {
        imageView.setImageResource(getRes(searchEngine));
    }


    public static int getRes(String searchEngine) {
        int res = R.mipmap.logo_transparent;
        if (searchEngine.equals("百度")) {
            res = R.drawable.baidu;
        } else if (searchEngine.equals("搜狗")) {
            res = R.drawable.sogou;
        } else if (searchEngine.equals("必应")) {
            res = R.drawable.biying;
        } else if (searchEngine.equals("360")) {
            res = R.drawable.qihu360;
        }
        return res;
    }


    public static String resToSearchEngine(int res) {
        String searchEngine = "必应";
        if (res == R.drawable.baidu) {
            searchEngine = "百度";
        } else if (res == R.drawable.sogou) {
            searchEngine = "搜狗";
        } else if (res == R.drawable.biying) {
            searchEngine = "必应";
        } else if (res == R.drawable.qihu360) {
            searchEngine = "360";
        }
        return searchEngine;
    }


    public static String searchEngineToSearchUrl(String searchEngine) {
        String url = "https://m.baidu.com/s?word=";
        if ("百度".equals(searchEngine)) {
            url = "https://m.baidu.com/s?word=";
        } else if ("搜狗".equals(searchEngine)) {
            url = "https://m.sogou.com/web/searchList.jsp?keyword=";
        } else if ("必应".equals(searchEngine)) {
            url = "https://www.bing.com/search?q=";
        } else if ("360".equals(searchEngine)) {
            url = "https://m.so.com/s?q=";
        }
        return url;
    }

    public static String searchUrlToSearchEngine(String url) {
        String searchEngine = "";
        if (url.contains("baidu.com/")) {
            searchEngine = "百度";
        } else if (url.contains("sogou.com/")) {
            searchEngine = "搜狗";
        } else if (url.contains("bing.com/")) {
            searchEngine = "必应";
        } else if (url.contains("so.com/")) {
            searchEngine = "360";
        }
        return searchEngine;
    }


    public static int searchUrlToRes(String url) {
        int res = -1;
        if (url.contains("baidu.com/")) {
            res = R.drawable.baidu;
        } else if (url.contains("sogou.com/")) {
            res = R.drawable.sogou;
        } else if (url.contains("bing.com/")) {
            res = R.drawable.biying;
        } else if (url.contains("so.com/")) {
            res = R.drawable.qihu360;
        }
        return res;
    }

    //                if (searchEngine.equals("百度")) {
//                    //都可
////                    initWebView("https://www.baidu.com/", "index-kw", "index-bn", query, 1);
//                    WebViewUtil.initWebView(WifiFragment.this, vBinding.webView, listener, "https://www.baidu.com/", false,
//                            WebViewUtil.getJsFormIdToViewFillValue("index-kw", query),
//                            WebViewUtil.getJsFormIdToViewClick("index-bn"));
//                } else if (searchEngine.equals("搜狗")) {
//                    //不可  获取不到搜索按钮控件
////                    initWebView("https://www.sogou.com/", "keyword", "header_submit_btn", query, 1);
//                    WebViewUtil.initWebView(WifiFragment.this, vBinding.webView, listener, "https://www.sogou.com/", false,
//                            WebViewUtil.getJsFormIdToViewFillValue("keyword", query),
//                            WebViewUtil.getJsFormNameToViewClick("header_submit_btn"));
//                } else if (searchEngine.equals("必应")) {
//                    //都可
////                    initWebView("https://cn.bing.com/", "sb_form_q", "sb_form_go", query, 1);
//                    WebViewUtil.initWebView(WifiFragment.this, vBinding.webView, listener, "https://cn.bing.com/", false,
//                            WebViewUtil.getJsFormIdToViewFillValue("sb_form_q", query),
//                            WebViewUtil.getJsFormIdToViewClick("search_icon"));
//
//                } else if (searchEngine.equals("360")) {
//                    //可1 获取不到搜索按钮控件
////                    initWebView("https://m.so.com/", "q", "search-button", query, 1);
//                    String js = "javascript:document.getElementById('" + "hd" + "').getElementByClassName('" + "search-btn" + "').click();";
//                    WebViewUtil.initWebView(WifiFragment.this, vBinding.webView, listener, "https://m.so.com/", false,
//                            WebViewUtil.getJsFormIdToViewFillValue("q", query),
//                            js);
//                } else if (searchEngine.equals("谷歌")) {
//                    //不可 加载不了谷歌首页
////                    initWebView("https://www.google.com/", "q", "header_submit_btn", query, 2);
////                    initWebView("https://www.google.com.hk/", "q", "header_submit_btn", query, 1);
//                    WebViewUtil.initWebView(WifiFragment.this, vBinding.webView, listener, "https://www.google.com/", false,
//                            WebViewUtil.getJsFormIdToViewFillValue("XSqSsc", query),
//                            WebViewUtil.getJsFormIdToViewClick("search_icon"));
//                }
}
