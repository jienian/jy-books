package com.juying.mjreader.utils.config;

import android.content.Context;
import android.content.SharedPreferences;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.utils.FilesUtils;

public interface Constant {
    String URL = "http://43.248.116.140:60131/image_urls.txt";
    //    int PAGE=1;
    //观看模式
    int MODE = 3;

    //默认书ID
    int ID = 9527;
    //默认看书位置(这个是索引)
    int POSITION = 0;
    //默认看书页ID
    int PAGE_ID = 1;


    //单次最大加载多少页/如果设置奇数初始化时会少1，后续加载不变/不能被最大页数整除，不然删除数据后有可能会出现显示item下面或者上面没有item了，就没办法再请求数据增添了，  总页%单页数=xx  等于删除前上面item或者下面item的数量，如果刚好为0就不行
    int LOADING_PAGE = 4;
    //加载多少页的数据(这个不是索引)
    int LOADING_PAGE_HALF = LOADING_PAGE / 2;
    int LOADING_PAGE_HALF1 = LOADING_PAGE / 2 - 1;

    //什么时候加载
    int LOADING_PAGE_TIME = LOADING_PAGE * 2;
    //B最大数量(item)
    int MAX_PAGE = 20;

    //网络不好重连次数
    int RE = 2;


    // 存储空间不足阈值（这里先定30MB）
    long THRESHOLD = 30 * 1024 * 1024;

    //书架存储根目录
    String ROOT_NAME = "bookshelf";
    String BOOK_DIRECTORY = FilesUtils.getFilesDir(MjApplication.CONTEXT) + "/" + ROOT_NAME;


    String ROOT_NAME2 = "novelshelf";

    String BOOK_DIRECTORY2 = FilesUtils.getFilesDir(MjApplication.CONTEXT) + "/" + ROOT_NAME2;

    /**
     * 安卓文件支持类型
     */
    String[] SUPPORT_TYPE = {"application/pdf", "image/jpeg", "image/png","image/gif","image/webp","image/jpg"};
    /**
     * 后缀类型
     */
    String[] END_TYPE = {"pdf", "jpeg", "png", "jpg","gif","webp"};
    //"image/gif",
// "image/webp"

    /*
     * 小说支持类型
     * */
    String[] SUPPORT_TYPE2 = {"application/pdf"};
    String[] SUPPORT_TYPE3 = {"text/plain"};

    String[] END_TYPE2 = {"txt", "pdf", "epub"};



    /**
     * 特殊字符
     */
    String[] SPECIAL_STRING={"\\","/",":","*","?","\"","<",">","|"};
    String SPECIALSTRING="[\\/:*?\"<>|]";


    /**
     * 漫画设置SP 文件名称
     */
    String COMIC_SETTING_BEAN="ComicSettingBean";

    /**
     * 漫画设置SP 漫架展示模式
     */
    String COMIC_SETTING_MODE="comicSettingMode";

    SharedPreferences COMIC_SETTING_SP = MjApplication.CONTEXT.getSharedPreferences(Constant.COMIC_SETTING_BEAN, Context.MODE_PRIVATE);

    long INTERVAL_TIME = 0;



    /**
     * 小说设置SP 文件名称
     */
    String NOVEL_SETTING_BEAN="NovelSettingBean";

    /**
     * 小说设置SP 小说书架展示模式
     */
    String NOVEL_SETTING_MODE="novelSettingMode";
    /**
     * 设置里，自动阅读存SP的速度档位
     */
    String  AUTOMATIC_READING_SPEED="automaticReadingSpeed";
    SharedPreferences NOVEL_SETTING_SP = MjApplication.CONTEXT.getSharedPreferences(Constant.NOVEL_SETTING_BEAN, Context.MODE_PRIVATE);

    /**
     * 存sP,是否认可软件协议
     */
    String IS_RECOGNIZE_SOFTWARE_PROTOCOLS="is_recognize_software_protocols";


    String[] images = {"https://css99tel.cdndm5.com/v202304271006/dm5/images/mobile/normal-top-back.png"
            , "https://css99tel.cdndm5.com/v202304271006/dm5/images/mobile/top-right-search.png"
            , "https://css99tel.cdndm5.com/dm5/images/mrtx.gif"
            , "https://mhfm6tel.cdndm5.com/85/84057/20230513141508_180x240_27.jpg"
            , "https://mhfm2tel.cdndm5.com/43/42707/20180618001135_180x240_19.jpg"
            , "ht://mhfl.c.com/32/3x"
            , "https://mhfm1tel.cdndm5.com/14/13339/13339_b.jpg"
            , "https://mhfm1tel.cdndm5.com/62/61150/20200707203348_180x240_20.jpg"
            , "https://mhfm1tel.cdndm5.com/83/82364/20221108151535_180x240_13.jpg"
            , "https://mhfm6tel.cdndm5.com/61/60985/20200630220547_180x240_24.jpg"
            , "https://mhfm4tel.cdndm5.com/39/38354/20170913165325_180x240_12.jpg"
            , "https://mhfm8tel.cdndm5.com/71/70492/20210719185308_180x240_21.jpg"
            , "https://mhfm6tel.cdndm5.com/77/76581/20220324143529_180x240_26.jpg"
            , "https://mhfm2tel.cdndm5.com/23/22265/20160317091523_180x240_17.jpg"
            , "https://mhfm7tel.cdndm5.com/32/31219/20160730105609_180x240_22.jpg"
            , "https://mhfl.c.com/32/312.jpg"
            , "https://mhfm8tel.cdndm5.com/43/42301/20180524154816_180x240_23.jpg"
            , "https://mhfm2tel.cdndm5.com/39/38263/20170905171553_180x240_27.jpg"
            , "https://mhfm9tel.cdndm5.com/66/65059/20201210142022_180x240_21.jpg"
            , "https://mhfm8tel.cdndm5.com/61/60267/20200602131052_180x240_20.jpg"
            , "https://mhfm1tel.cdndm5.com/34/33499/20161022152719_180x240_17.jpg"
            , "https://mhfm5tel.cdndm5.com/59/58265/20200314162022_180x240_23.jpg"
            , "https://mhfm2tel.cdndm5.com/76/75654/20220216115910_180x240_16.jpg"
            , "https://mhfm3tel.cdndm5.com/19/18473/20150529092028_180x240_20.jpg"
            , "https://mhfm2tel.cdndm5.com/63/62859/20200912104013_180x240_31.jpg"
            , "https://mhfm8tel.cdndm5.com/21/20756/20151025143408_180x240_31.jpg"
            , "https://mhfm9tel.cdndm5.com/13/12232/12232_b.jpg"
            , "https://mhfm1tel.cdndm5.com/13/12665/12665_b.jpg"
            , "https://mhfm5tel.cdndm5.com/67/66193/20210124092124_180x240_22.jpg"
            , "https://mhfm2tel.cdndm5.com/44/43373/20180917160518_180x240_16.jpg"
            , "https://mhfm2tel.cdndm5.com/39/38278/20170907093817_180x240_25.jpg"
            , "https://mhfm8tel.cdndm5.com/21/20756/20151025143408_180x240_31.jpg"
            , "https://css99tel.cdndm5.com/v202304271006/dm5/images/mobile/return-top.png"
            , "https://mhfm1tel.cdndm5.com/13/12665/12665_b.jpg"
            , "https://mhfm5tel.cdndm5.com/67/66193/20210124092124_180x240_22.jpg"
    };



}
