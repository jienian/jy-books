package com.juying.mjreader.fragment

import android.content.Intent
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import com.blankj.utilcode.util.LogUtils
import com.juying.mjreader.R
import com.juying.mjreader.activity.SettingActivity
import com.juying.mjreader.activity.SimpleWebViewActivity
import com.juying.mjreader.activity.login.LoginActivity
import com.juying.mjreader.bean.LoadingBean
import com.juying.mjreader.databinding.FragmentMyBinding
import com.juying.mjreader.manager.UserManager
import com.juying.mjreader.network.service.UserApiService
import com.juying.mjreader.utils.AppInfo
import com.juying.mjreader.utils.StringUtils
import com.juying.mjreader.view.DialogNotice
import com.juying.mjreader.view.DialogNotice.InsideBean
import kotlinx.coroutines.launch

/**
 * @author nimyears
 *
 */
class MyFragment2 : BaseFragment() {
    private var vBinding: FragmentMyBinding? = null
    var myDialog: DialogNotice? = null

    private var dialogNotice: DialogNotice? = null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        vBinding = FragmentMyBinding.inflate(inflater, null, false)

        initListener()
        return vBinding!!.root
    }

    private fun initListener() {

    }

    override fun onResume() {
        super.onResume()
            getUserInfo()
    }

    fun doOnClick(v: View) {
        if (v === vBinding!!.ll1) {
            if (!UserManager.isLogin) {
                startActivity(Intent(activity, LoginActivity::class.java))
            }
        } else if (v === vBinding!!.tvOpen) {
            to("去开通", false)
        } else if (v === vBinding!!.ll2) {
            to("一键传输", false)
        } else if (v === vBinding!!.ll3) {
            to("自定义文件封面", false)
        } else if (v === vBinding!!.ll4) {
            jumpWebView(
                getString(R.string.serviceAgreement),
                getString(R.string.serviceAgreement_URL)
            )
        } else if (v === vBinding!!.ll5) {
            jumpWebView(getString(R.string.privacyPolicy), getString(R.string.privacyPolicy_URL))
        } else if (v === vBinding!!.ll6) {

            var content: String =
                AppInfo.getAppName(context) + "  " + AppInfo.getAppVersionName(context) + "\n     感谢各位长期以来的支持与鼓励，为保证可以更好地与大家进行交流与沟通，可通过《服务协议》、《隐私政策》里的联系方式与我们进行联系，其他非官方联系方式请勿轻信，以免上当受骗。"
            context?.let {
                var builder = StringUtils.textHighlight(content, it.getColor(R.color.spFFFE605F), View.OnClickListener {
                        if (it.tag.equals(getString(R.string.privacyPolicy))) {
                            jumpWebView( getString(R.string.privacyPolicy), getString(R.string.privacyPolicy_URL))
                        } else if (it.tag.equals(getString(R.string.serviceAgreement))) {
                            jumpWebView(getString(R.string.serviceAgreement), getString(R.string.serviceAgreement_URL))
                        }
                    },
                    getString(R.string.privacyPolicy),
                    getString(R.string.serviceAgreement)
                )
                toDialog("关于我们", builder)
            }
        } else if (v === vBinding!!.ll7) {
            MyFragment.appUp(activity);
        } else if (v === vBinding!!.ll8) {
            startActivity(Intent(context, SettingActivity::class.java))
        }
        //showLoginDialog();
    }

    fun jumpWebView(title: String, url: String) {
        val intent = Intent(activity, SimpleWebViewActivity::class.java)
        val bean = LoadingBean(title, url)
        intent.putExtra(SimpleWebViewActivity.LOADING_BEAN_KEY, bean)
        startActivity(intent)
    }


    private fun getUserInfo() {
        if (UserManager.isLogin) {
            vBinding?.ivDbg?.setImageResource(R.drawable.ilogo)
            lifecycleScope.launch {
                try {
                    val bean = UserApiService.getInfo()?.data
                    bean?.let {
                        val name = it.nickname
                        vBinding?.tvName?.text = name
                    }
                } catch (e: Exception) {
                    LogUtils.e("Exception...")
                }
            }
        } else {
            vBinding?.ivDbg?.setImageResource(R.drawable.dbg)
            vBinding?.tvName?.text = "未登录账号"
        }

    }

    fun toDialog(title: String, content: SpannableStringBuilder) {


        context?.let {
            if (myDialog == null) {
                myDialog = DialogNotice(it, InsideBean(title, ""), null)
                myDialog?.vBinding?.tvCancel?.visibility = View.GONE
                myDialog?.vBinding?.tvStart?.visibility = View.GONE
                myDialog?.vBinding?.tvContent?.text = content
                myDialog?.vBinding?.tvContent?.movementMethod = LinkMovementMethod.getInstance();
                //区域外点击不关闭dialog
//                setCanceledOnTouchOutside(false);
                myDialog!!.setCanceledOnTouchOutside(true)
            }

            myDialog!!.show()
        }
    }

    /* private void showLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("手机号登录");

        // 添加自定义布局（这里假设布局文件名为dialog_login.xml）
        View customLayout = getLayoutInflater().inflate(R.layout.dialog_login, null);
        builder.setView(customLayout);

        builder.setPositiveButton("一键登录", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 这里添加一键登录的代码
            }
        });
        builder.setNegativeButton("切换手机号", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 这里添加切换手机号的代码
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }*/

}


