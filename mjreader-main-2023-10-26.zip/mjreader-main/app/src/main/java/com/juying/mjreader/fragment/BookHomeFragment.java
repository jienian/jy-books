package com.juying.mjreader.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;

import com.juying.mjreader.R;
import com.juying.mjreader.adapter.BookHomeAdapter;
import com.juying.mjreader.databinding.FragmentBookHomeBinding;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 16:23
 */
public class BookHomeFragment extends BaseFragment {

    private FragmentBookHomeBinding vBinding;
    private List<BookHomeAdapter.InsideBean> listBean;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        iniData();
    }

    private void iniData() {
         listBean = new ArrayList<>();
        listBean.add(new BookHomeAdapter.InsideBean("本地", R.drawable.comic_book));
        listBean.add(new BookHomeAdapter.InsideBean("FTP服务器", R.drawable.comic_book));
        listBean.add(new BookHomeAdapter.InsideBean("SMB服务器", R.drawable.comic_book));
        listBean.add(new BookHomeAdapter.InsideBean("WEBDVA服务器", R.drawable.comic_book));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

//        View view = inflater.inflate(R.layout.fragment1, container,false);
//        return view;


        vBinding = FragmentBookHomeBinding.inflate(inflater, null, false);
        iniUi();
        return vBinding.getRoot();
    }

    private void iniUi() {
        initRv();
    }

    private void initRv() {
        vBinding.rv.setLayoutManager(new GridLayoutManager(getContext(), 3));
        vBinding.rv.setAdapter(new BookHomeAdapter(getContext(), listBean));
    }


}
