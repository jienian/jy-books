package com.juying.mjreader.model;

import com.juying.mjreader.data.entities.Novel;
import com.juying.mjreader.data.entities.NovelChapter;

import java.io.InputStream;
import java.util.ArrayList;

/**
 * Ahuthor Nimyears
 *
 * 基础的本地书籍解析功能的接口。
 */
public interface BaseLocalNovelParse {

    /*用于更新给定书籍的信息，暂时不需要。*/
    void upNovelInfo(Novel novel);

    /*获取章节列表*/
    ArrayList<NovelChapter> getChapterList(Novel  novel);

    //获取特定章节的内容
    String getContent(Novel  novel, NovelChapter chapter);
    //籍中获取图片,暂时不需要
    InputStream getImage(Novel  novel, String href);
}
