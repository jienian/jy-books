package com.juying.mjreader.bean;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.utils.ComicMode;

/**
 * @Author Ycc
 * @Date 10:35
 * 漫画浏览页Bean
 */
public class ComicSeeBean implements Parcelable {


    /**
     * 可能是网络http:  也可能是本地File
     */
    private String url;
    /**
     * 名称
     */
    private String fileName;
    /**
     * 文件类型
     */
    private String fileType;
    /**
     * 封面资源，根据文件类型变化
     */
    private int fileCover;


    /**
     * 是否是当前显示Bean
     */
    private boolean isCurrentShow;
    /**
     * 当前显示位置百分比%【如果是PDF,这里就是标签页位置，如果是其他媒体类型这里就是单文件长图的偏移量，记得存SP】
     */
    private int currentShowPosition;
    /**
     * 当前显示页数【只有在PDF时有用】索引
     */
    private int currentShowIndex;

    /**
     * 是否是PDF
     */
    private boolean isPDF;
    /**
     * PDF总页数
     */
    private int pdfCountPage;
    /**
     * 是否是网络数据【还可能是本地】
     */
    private boolean isWifi;
    /**
     * 是否选中 【用于网络批量下载】
     */
    private boolean isEditSelect;

    /**
     * 内存占用大小
     * @return
     */
    private  long memoryUsageSize;
    //标记Bean
    private FlagBean flagBean;

    public FlagBean getFlagBean() {
        return flagBean;
    }

    public void setFlagBean(FlagBean flagBean) {
        this.flagBean = flagBean;
    }

    public void setMemoryUsageSize(long memoryUsageSize) {
        this.memoryUsageSize = memoryUsageSize;
    }

    public boolean isEditSelect() {
        return isEditSelect;
    }

    public void setEditSelect(boolean editSelect) {
        isEditSelect = editSelect;
    }

    public int getPdfCountPage() {
        return pdfCountPage;
    }

    public void setPdfCountPage(int pdfCountPage) {
        this.pdfCountPage = pdfCountPage;
    }

    public boolean isWifi() {
//        if (!TextUtils.isEmpty(url) && (url.startsWith("http://") || url.startsWith("https://"))) {
//            isWifi = true;
//        }
        return isWifi;
    }

    public void setWifi(boolean wifi) {
        isWifi = wifi;
    }

    private int id;

    //imag,应该加载的宽高
    private int width;
    private int height;

    private int originaHeight;





    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getOriginaHeight() {
        return originaHeight;
    }

    public String getFileType() {
        return fileType;
    }

    public int getCurrentShowPosition() {

        return currentShowPosition;
    }

    public void setCurrentShowPosition(int currentShowPosition) {
        this.currentShowPosition = currentShowPosition;
        upSP();
    }

    public int getCurrentShowIndex() {
        return currentShowIndex;
    }


    public void setCurrentShowIndex(int currentShowIndex) {
        this.currentShowIndex = currentShowIndex;
        upSP();
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }





    //填补数据在B的索引  用着网络不好时，重新获取未加载成功的数据进行重新局部更新
    private int fillPosition;
    //图片是否加载失败
    private boolean isImageLoadFail;



    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean isImageLoadFail() {
        return isImageLoadFail;
    }



    public void setImageLoadFail(boolean imageLoadFail) {
        isImageLoadFail = imageLoadFail;
    }



    public String getUrl() {
        return url;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public void setUrl(String url) {
        this.url = url;
    }


    public void setOriginaHeight(int originaHeight) {
        this.originaHeight = originaHeight;
    }



    public ComicSeeBean(String url, String fileName, String fileType, boolean isCurrentShow, int currentShowPosition, boolean isWifi) {
        this.url = url;
        this.fileName = fileName;
        this.fileType = fileType;
        this.isCurrentShow = isCurrentShow;
        this.currentShowPosition = currentShowPosition;
        this.isWifi = isWifi;
        initSP();
    }


    @Override
    public String toString() {
        return "PageBean{" +
                "url='" + url + '\'' +

                ", id=" + id +
                '}';
    }





    SharedPreferences.Editor editor;

    /**
     * 更新物理sp
     */
    public void upSP() {
        if (editor == null) {
            editor = MjApplication.CONTEXT.getSharedPreferences(ComicMode.filePathToSpName(url, false), Context.MODE_PRIVATE).edit();
        }
        editor.putInt("readPosition", currentShowPosition);
        editor.putInt("readIndex", currentShowIndex);
        editor.apply();
    }

    SharedPreferences sp;

    private void initSP() {
        if (sp == null) {
            sp = MjApplication.CONTEXT.getSharedPreferences(ComicMode.filePathToSpName(url, false), Context.MODE_PRIVATE);
        }
        currentShowPosition = (sp.getInt("readPosition", 0));
        currentShowIndex = (sp.getInt("readIndex", 0));
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.url);
        dest.writeString(this.fileName);
        dest.writeString(this.fileType);
        dest.writeInt(this.fileCover);
        dest.writeByte(this.isCurrentShow ? (byte) 1 : (byte) 0);
        dest.writeInt(this.currentShowPosition);
        dest.writeInt(this.currentShowIndex);
        dest.writeByte(this.isPDF ? (byte) 1 : (byte) 0);
        dest.writeInt(this.pdfCountPage);
        dest.writeByte(this.isWifi ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEditSelect ? (byte) 1 : (byte) 0);
        dest.writeLong(this.memoryUsageSize);
        dest.writeParcelable(this.flagBean, flags);
        dest.writeInt(this.id);
        dest.writeInt(this.width);
        dest.writeInt(this.height);
        dest.writeInt(this.originaHeight);
        dest.writeInt(this.fillPosition);
        dest.writeByte(this.isImageLoadFail ? (byte) 1 : (byte) 0);

    }

    public void readFromParcel(Parcel source) {
        this.url = source.readString();
        this.fileName = source.readString();
        this.fileType = source.readString();
        this.fileCover = source.readInt();
        this.isCurrentShow = source.readByte() != 0;
        this.currentShowPosition = source.readInt();
        this.currentShowIndex = source.readInt();
        this.isPDF = source.readByte() != 0;
        this.pdfCountPage = source.readInt();
        this.isWifi = source.readByte() != 0;
        this.isEditSelect = source.readByte() != 0;
        this.memoryUsageSize = source.readLong();
        this.flagBean = source.readParcelable(FlagBean.class.getClassLoader());
        this.id = source.readInt();
        this.width = source.readInt();
        this.height = source.readInt();
        this.originaHeight = source.readInt();
        this.fillPosition = source.readInt();
        this.isImageLoadFail = source.readByte() != 0;
    }

    protected ComicSeeBean(Parcel in) {
        this.url = in.readString();
        this.fileName = in.readString();
        this.fileType = in.readString();
        this.fileCover = in.readInt();
        this.isCurrentShow = in.readByte() != 0;
        this.currentShowPosition = in.readInt();
        this.currentShowIndex = in.readInt();
        this.isPDF = in.readByte() != 0;
        this.pdfCountPage = in.readInt();
        this.isWifi = in.readByte() != 0;
        this.isEditSelect = in.readByte() != 0;
        this.memoryUsageSize = in.readLong();
        this.flagBean = in.readParcelable(FlagBean.class.getClassLoader());
        this.id = in.readInt();
        this.width = in.readInt();
        this.height = in.readInt();
        this.originaHeight = in.readInt();
        this.fillPosition = in.readInt();
        this.isImageLoadFail = in.readByte() != 0;
    }

    public static final Parcelable.Creator<ComicSeeBean> CREATOR = new Parcelable.Creator<ComicSeeBean>() {
        @Override
        public ComicSeeBean createFromParcel(Parcel source) {
            return new ComicSeeBean(source);
        }

        @Override
        public ComicSeeBean[] newArray(int size) {
            return new ComicSeeBean[size];
        }
    };
}
