package com.juying.mjreader.view;

import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogEngineBinding;
import com.juying.mjreader.databinding.DialogFlagDirectoryBinding;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogEngine extends BaseDialog {
    private DialogEngineBinding vBinding;
    private DialogEngineListener listener;
    private Activity context;


    String[] engineName = {"百度", "搜狗", "必应", "360", "谷歌"};

    public DialogEngine(@NonNull Activity context, int themeResId, String initEngineName, DialogEngineListener listener) {
        super(context, themeResId);
        this.context = context;
        this.listener = listener;
        vBinding = DialogEngineBinding.inflate(context.getLayoutInflater());
        setContentView(vBinding.getRoot());
//        initRecyclerView(bookBean);
        Window window = getWindow();

        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.7f);
        //设置弹出位置
        window.setGravity(Gravity.BOTTOM);
        initUi(initEngineName);
        initListener();
    }

    private void initUi(String initEngineName) {

        for (int i = 0; i < engineName.length; i++) {
            String engine = engineName[i];
            if (initEngineName.equals(engine)) {
                upUi(i+1);
            }
        }
    }

    private void initListener() {

        vBinding.ll1.setOnClickListener(v -> {
            //更新UI
            upUi(1);
            dismiss();
            //跳转
            listener.onClick("百度");
        });
        vBinding.ll2.setOnClickListener(v -> {
            //更新UI
            upUi(2);
            dismiss();
            //跳转
            listener.onClick("搜狗");
        });
        vBinding.ll3.setOnClickListener(v -> {
            //更新UI
            upUi(3);
            dismiss();
            //跳转
            listener.onClick("必应");
        });
        vBinding.ll4.setOnClickListener(v -> {
            //更新UI
            upUi(4);
            dismiss();
            //跳转
            listener.onClick("360");
        });
        vBinding.ll5.setOnClickListener(v -> {
            //更新UI
            upUi(5);
            dismiss();
            //跳转
            listener.onClick("谷歌");
        });
        vBinding.ivOff.setOnClickListener(v -> {
            dismiss();
        });
    }

    private void upUi(int type) {
        if (type == 1) {
            setSelected(vBinding.ll1, vBinding.tv1, vBinding.iv1, true);
            setSelected(vBinding.ll2, vBinding.tv2, vBinding.iv2, false);
            setSelected(vBinding.ll3, vBinding.tv3, vBinding.iv3, false);
            setSelected(vBinding.ll4, vBinding.tv4, vBinding.iv4, false);
            setSelected(vBinding.ll5, vBinding.tv5, vBinding.iv5, false);
        } else if (type == 2) {
            setSelected(vBinding.ll1, vBinding.tv1, vBinding.iv1, false);
            setSelected(vBinding.ll2, vBinding.tv2, vBinding.iv2, true);
            setSelected(vBinding.ll3, vBinding.tv3, vBinding.iv3, false);
            setSelected(vBinding.ll4, vBinding.tv4, vBinding.iv4, false);
            setSelected(vBinding.ll5, vBinding.tv5, vBinding.iv5, false);
        } else if (type == 3) {
            setSelected(vBinding.ll1, vBinding.tv1, vBinding.iv1, false);
            setSelected(vBinding.ll2, vBinding.tv2, vBinding.iv2, false);
            setSelected(vBinding.ll3, vBinding.tv3, vBinding.iv3, true);
            setSelected(vBinding.ll4, vBinding.tv4, vBinding.iv4, false);
            setSelected(vBinding.ll5, vBinding.tv5, vBinding.iv5, false);
        } else if (type == 4) {
            setSelected(vBinding.ll1, vBinding.tv1, vBinding.iv1, false);
            setSelected(vBinding.ll2, vBinding.tv2, vBinding.iv2, false);
            setSelected(vBinding.ll3, vBinding.tv3, vBinding.iv3, false);
            setSelected(vBinding.ll4, vBinding.tv4, vBinding.iv4, true);
            setSelected(vBinding.ll5, vBinding.tv5, vBinding.iv5, false);
        } else if (type == 5) {
            setSelected(vBinding.ll1, vBinding.tv1, vBinding.iv1, false);
            setSelected(vBinding.ll2, vBinding.tv2, vBinding.iv2, false);
            setSelected(vBinding.ll3, vBinding.tv3, vBinding.iv3, false);
            setSelected(vBinding.ll4, vBinding.tv4, vBinding.iv4, false);
            setSelected(vBinding.ll5, vBinding.tv5, vBinding.iv5, true);
        }
    }

    private void setSelected(LinearLayout linearLayout, TextView textView, ImageView imageView, boolean isSelected) {
        if (isSelected) {
            linearLayout.setBackground(context.getDrawable(R.color.spFFFE605F));
            linearLayout.getBackground().mutate().setAlpha(15);
            textView.setTextColor(context.getColor(R.color.spFFFE605F));
            imageView.setVisibility(View.VISIBLE);
        } else {
            linearLayout.setBackground(context.getDrawable(R.color.white));
            linearLayout.getBackground().mutate().setAlpha(255);
            textView.setTextColor(context.getColor(R.color.spFF624243));
            imageView.setVisibility(View.GONE);
        }
    }


    public interface DialogEngineListener {
        //搜索引擎名称
        void onClick(String engineName);
    }


}
