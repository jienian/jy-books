package com.juying.mjreader.bean;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.List;

/**
 * @Author Nimyears
 *
 * 笔记
 */
public class Note  implements Parcelable {

    private String section;
    private List<String> noteList;

    public Note(){}

    protected Note(Parcel in) {
        section = in.readString();
        noteList = in.createStringArrayList();
    }

    public static final Creator<Note> CREATOR = new Creator<Note>() {
        @Override
        public Note createFromParcel(Parcel in) {
            return new Note(in);
        }

        @Override
        public Note[] newArray(int size) {
            return new Note[size];
        }
    };

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public List<String> getNoteList() {
        return noteList;
    }


    public void setNoteList(List<String> noteList) {
        this.noteList = noteList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(section);
        dest.writeStringList(noteList);
    }
}
