package com.juying.mjreader.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.smbj.share.DiskShare;
import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogBookInputSmbBinding;
import com.juying.mjreader.utils.StringUtils;
import com.thegrizzlylabs.sardineandroid.Sardine;

import java.io.InputStream;
import java.net.URI;
import java.util.List;
import java.util.concurrent.Executors;

import me.jingbin.smb.BySMB;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogBookInputSMB extends BaseDialog {
    private DialogBookInputSmbBinding vBinding;
    private DialogLoading loadomg;
    Handler handler;

    public DialogBookInputSMB(@NonNull Context context, DialogBrowseEditListener listener) {
        super(context, R.style.DialogTheme);
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
//        View view = View.inflate(context, R.layout.dialog_book_input, null);
        vBinding = DialogBookInputSmbBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);

        handler = new Handler(Looper.myLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case 1:
                        log("通知更新：" + msg.obj);
                        if (msg.obj instanceof TextView) {
                            vBinding.llMode.addView((TextView) msg.obj);
                        } else if (msg.obj instanceof Bitmap) {
                            Glide.with(getContext())
                                    .asBitmap()
                                    .load((Bitmap) msg.obj)
//                                        .override(500, 500)
                                    .into(vBinding.iv);
                        } else if (msg.obj instanceof InputStream) {
                            vBinding.pdf.fromStream((InputStream) msg.obj).load();
                        } else if (msg.obj instanceof String) {
                            Glide.with(getContext())
                                    .asBitmap()
                                    .load((String) msg.obj)
//                                        .override(500, 500)
                                    .into(vBinding.iv);


                        } else if (msg.obj instanceof URI) {
                            Glide.with(getContext())
                                    .load((URI) msg.obj)
//                                        .override(500, 500)
                                    .into(vBinding.iv);
                        }
//                        vBinding.iv.setImageBitmap((Bitmap) msg.obj);


                        break;
                    case 2:
                        to("链接失败", false);
                        break;
                    case 3:
                        vBinding.llMode.removeAllViews();
                        break;
                    default:
                }


            }
        };
        initView();
        initListener();


    }

    private void initView() {

    }


    private void initListener() {

        vBinding.tvCancel.setOnClickListener(v -> {
            dismiss();
        });
        vBinding.tvOk.setOnClickListener(v -> {
            FormData formData = getForm();
            if (StringUtils.isEmpty(formData.getServer(), formData.getPort(), formData.getUserName(), formData.getPassword())) {
                to("服务器/端口/用户名/密码必须填写", false);
//                return;
            }
            if (loadomg == null) {
                loadomg = new DialogLoading(getContext());
            }
            loadomg.show();

            BySMB.Companion.Builder bu = BySMB.Companion.with().setConfig(
                    formData.getHost(),  // ip
                    formData.getUserName(),// 用户名
                    formData.getPassword(),// 密码
                    formData.getServer()// 共享文件夹名
            );
            BySMB bySMB = new BySMB(bu);


            showView(bySMB, formData);


        });
    }

    private void showView(BySMB bySMB, FormData formData) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                bySMB.init();
                DiskShare ds = bySMB.getConnectShare();
                List<FileIdBothDirectoryInformation> list = ds.list("");
                for (FileIdBothDirectoryInformation s : list) {
                    log("smb服务器文件：" + s.getFileName());
                    String fileName = s.getFileName();
                    TextView tv = new TextView(getContext());
                    tv.setText(fileName);
                    Message mes = new Message();
                    mes.what = 1;
                    mes.obj = tv;
                    tv.setOnClickListener(v -> {
//                        if (s.getFileName().endsWith("jpg")) {
                            //                        String url = "\\\\" + formData.getHost() + "\\" + formData.getServer() + "\\" + s.getFileName();
//                        String url1 = "//" + formData.getHost() + "/" + formData.getServer() + "/" + s.getFileName();
//                        String url2 = "\\" +  formData.getServer() + "\\" + s.getFileName();
//                        String url3 = "/" +  formData.getServer() + "/" + s.getFileName();
//                            boolean fileExists = ds.fileExists(fileName);
//                        }
                    });
                    handler.sendMessage(mes);
                }
                // 读取根目录下的所有文件，重载方法("", "*.txt", callback)
                loadomg.dismiss();
            } catch (Exception e) {
                loadomg.dismiss();
                handler.sendEmptyMessage(2);
                throw new RuntimeException(e);
            }
        });

    }

    private String setData(Sardine sardine, FormData formData, boolean isReal) {
        String url = "";
        if (isReal) {
//            url = formData.getProtocol() + "://" + formData.getServer();
            sardine.setCredentials(formData.getUserName(), formData.getPassword());
        } else {
            url = "http://17.tcp.cpolar.top:13420/";
            sardine.setCredentials("JUYINGTECH", "654321");
        }
        return url;
    }


    private FormData getForm() {
        String host = getString(vBinding.etHost);
        String rort = getString(vBinding.etPort);
        boolean isAnonymous = vBinding.cbAnonymous.isChecked();
        String name = getString(vBinding.etName);
        String password = getString(vBinding.etPassword);
        String rename = getString(vBinding.etRename);
//        FormData formData = new FormData(host, rort, name, password, isAnonymous, rename);
        FormData formData = new FormData("192.168.51.76", "smb_ycc", "JUYINGTECH", "654321", isAnonymous, rename);
        log("表单Bean:" + formData);
        return formData;
    }


    private String getString(EditText et) {
        String string = "";
        try {
            string = et.getText().toString();
        } catch (Exception ignored) {
        }
        return string;
    }

    public interface DialogBrowseEditListener {
        void onClickEdit();
    }

    private class FormData {
        //域名
        private String host;
        //服务器 示例：192.168.100/共享文档
        private String server;
        //端口
        private String port;
        //用户名
        private String userName;
        private String password;
        //匿名
        private boolean isAnonymous;
        //重命名
        private String rename;


        public FormData(String port, String server, String userName, String password, boolean isAnonymous, String rename) {
            this.host = port;
            this.server = server;
            this.port = port;
            this.userName = userName;
            this.password = password;
            this.rename = rename;
            this.isAnonymous = isAnonymous;
        }


        public String getHost() {
            return host;
        }

        public void setServer(String server) {
            this.server = server;
        }

        @Override
        public String toString() {
            return "FormData{" +
                    "server='" + server + '\'' +
                    ", port='" + port + '\'' +
                    ", userName='" + userName + '\'' +
                    ", password='" + password + '\'' +
                    ", rename='" + rename + '\'' +
                    '}';
        }

        public String getServer() {
            return server;
        }

        public String getPort() {
            return port;
        }

        public String getUserName() {
            return userName;
        }

        public String getPassword() {
            return password;
        }


        public String getRename() {
            return rename;
        }
    }

}
