package com.juying.mjreader.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.juying.mjreader.bean.WifiHistBean;
import com.juying.mjreader.fragment.WifiFragment;
import com.juying.mjreader.utils.sqlite.DBDao;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 10:01
 */
public class WebViewUtil {


    /**
     * @param webView
     * @param listener
     * @param wifiUrl
     * @param isDirectLoading 是否直接加载，如果直接加载就不做填充搜索框的处理
     * @param js
     */
    @SuppressLint({"JavascriptInterface", "SetJavaScriptEnabled"})
    public static void initWebView(WifiFragment context, WebView webView, WebViewListener listener, String wifiUrl, boolean isDirectLoading, String... js) {
        // 启用javascript
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        webView.loadUrl(wifiUrl);
        context.showMenu(true);//隐藏菜单
//        contentWebView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);//加载html数据
        // 添加js交互接口类，并起别名 imageListner
//        webView.addJavascriptInterface(new JavascriptInterface2(context), "imageListener");
//        webSettings.setJavaScriptEnabled(true);//暂时不需要交互
//        webSettings.setDomStorageEnabled(true);// 打开本地存供JS调用至关重要
//        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);//设置缓存模式为默认
//        webSettings.AppCacheMaxSize(1024 * 1024 * 8);//实现8后经存
        webSettings.setAllowFileAccess(true);//文件访问
//        webSettings.setAppCacheEnabled(true);
//        String appCachePath = MjApplication.CONTEXT.getCacheDir().getAbsolutePath();
//        webSettings.setAppCachePath(appCachePath);
        webSettings.setDatabaseEnabled(true);
//        webSettings.setGeolocationEnabled(true);//定位

        Log.d("TAG", "WebView开始加载Url：" + wifiUrl);
        webView.setWebViewClient(new WebViewClient() {

            //DOM加载结束，图片可能不一定加载完全了
            @Override
            public void onPageFinished(WebView view, String url) {
                Log.d("TAG", "onPageFinished,加载结束: " + url + ";标题:" + view.getTitle() + ";图标：" + view.getFavicon());
//                saveUrlInfo(view, "user", url, context.comicSettingBean.getSearchEngine(), false);//存浏览记录
                listener.onPageFinished(view, url);
                addImageClickListner(view);

                if (isDirectLoading) {
                    return;
                }
                if (!wifiUrl.equals(url)) {
                    //非第一次加载的时候，就不执行下面的模拟搜索点击动作
                    return;
                }
                Log.d("TAG", "WebView开始填充搜索框JS：" + js[0]);
                view.evaluateJavascript(js[0], s -> {
                    Log.d("TAG", "填充搜索框成功：" + s);
                    if (!TextUtils.isEmpty(s)) {
                        Log.d("TAG", "WebView开始模拟点击搜索：" + js[1]);
                        view.evaluateJavascript(js[1], value -> Log.d("TAG", "模拟点击完成：" + value));
                    }
                });
                super.onPageFinished(view, url);
            }

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                Log.d("TAG", "onPageStarted执行: " + url);
                super.onPageStarted(view, url, favicon);
            }

            //WebView发起的WEB请求因为网络原因失败时回调
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                int errorCode = error.getErrorCode();
                String errorMessage = error.getDescription().toString();
                Log.i("TAG", "onReceivedError,加载错误:网络原因——errorCode : " + errorCode + " errorMessage : " + errorMessage);
            }

            //WebView发起的WEB请求收到服务器的错误消息时回调
            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                Log.i("TAG", "onReceivedHttpError，加载错误:服务器返回错误消息——  errorCode : " + errorResponse.getStatusCode() + ";Encoding : " + errorResponse.getEncoding());
            }


//            @SuppressWarnings("deprecation")
//            @Override
//            public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
//
//                WebView.HitTestResult hit = view.getHitTestResult();
//                //hit.getExtra()为null或者hit.getType() == 0都表示即将加载的URL会发生重定向，需要做拦截处理
//                if (TextUtils.isEmpty(hit.getExtra()) || hit.getType() == 0) {
//                    //通过判断开头协议就可解决大部分重定向问题了，有另外的需求可以在此判断下操作
////                    Log.e("重定向", "重定向: " + hit.getType() + " && EXTRA（）" + hit.getExtra() + "------");
////                    Log.e("重定向", "GetURL: " + view.getUrl() + "\n" + "getOriginalUrl()" + view.getOriginalUrl());
////                    Log.d("重定向", "URL: " + url);
//                }
//
//                if (url.startsWith("http://") || url.startsWith("https://")) { //加载的url是http/https协议地址
//                    view.loadUrl(url);
//                    return false; //返回false表示此url默认由系统处理,url未加载完成，会继续往下走
//
//                } else { //加载的url是自定义协议地址
//                    try {
//                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
//                        context.startActivity(intent);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    return true;
//                }
//
//            }


            //解决重定向造成的 -10 errorMessage : net::ERR_UNKNOWN_URL_SCHEME 问题
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                WebView.HitTestResult hit = view.getHitTestResult();
                //hit.getExtra()为null或者hit.getType() == 0都表示即将加载的URL会发生重定向，需要做拦截处理
                if (TextUtils.isEmpty(hit.getExtra()) || hit.getType() == 0) {
                    //通过判断开头协议就可解决大部分重定向问题，有另外的需求可以在此判断下操作
//                    Log.e("重定向", "重定向: " + hit.getType() + " && EXTRA（）" + hit.getExtra() + "------");
//                    Log.e("重定向", "GetURL: " + view.getUrl() + "\n" + "getOriginalUrl()" + view.getOriginalUrl());
                    Log.d("重定向", "URL: " + url);

                    if (context.isClickBack()) {
//                        view.goBack();
                        return true; //不往下走
                    }
                }
                context.setClickBack(false);
                if (url.startsWith("http://") || url.startsWith("https://")) { //加载的url是http/https协议地址
                    view.loadUrl(url);
                    return false; //返回false表示此url默认由系统处理,url未加载完成，会继续往下走
                } else { //加载的url是自定义协议地址
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        @SuppressLint("WrongConstant") ActivityInfo activityInfo = intent.resolveActivityInfo(context.getActivity().getPackageManager(), intent.getFlags());
                        if (activityInfo.exported) {
                            context.startActivity(intent);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return true;
                }
            }


            @Override
            public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                //每次访问网页，webview都会记录访问的地址，保存了一个堆栈中，也就是浏览历史记录。网页进行加载时，都会调用；
                //网页加载过程中本方法只会调用一次，网页前进后退并不会回调这个函数。
//                Log.d("TAG", "doUpdateVisitedHistory;webView标题：" + view.getTitle() + "；webView图标：" + view.getFavicon() + ";是否是重新加载：" + isReload + ": 当前加载url:" + url);
//                WebBackForwardList xxxx = view.copyBackForwardList();
//                WebHistoryItem xxx = xxxx.getCurrentItem();
//                Log.d("TAG", "doUpdateVisitedHistory: 历史记录标题：" + xxx.getTitle() + ";图标：" + xxx.getFavicon() + ";url：" + xxx.getUrl() + ";源url：" + xxx.getOriginalUrl());
                ;
//                        doUpdateVisitedHistory
                super.doUpdateVisitedHistory(view, url, isReload);
            }
        });


        webView.setWebChromeClient(new WebChromeClient() {
            //WebView加载任意网络请求时回调，包括html、网络图片
            //此回调虽然在单次页面请求时不只被回调一次，但是需要对页面所有请求做监控时，是个好选择
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                Log.d("TAG", "onProgressChanged加载进度: " + newProgress);
                if (newProgress == 100) {
                    //加载完成
                }
            }

            //在WebView载入<head></head>标签结束时回调
            @Override
            public void onReceivedTitle(WebView view, String title) {
                Log.d("TAG", "onReceivedTitle，WebView载入<head></head>标签结束：标题: " + title);
                listener.onReceivedTitle(view, title);
            }
        });
    }

    public static List<String> noTedirectUrlList = new ArrayList<>();

    /**
     * 历史记录的新增与更新
     */
//    public static void saveUrlInfo(WebView webView, String userId, String url, String browserName, boolean isCollection) {
    public static WifiHistBean inputOrUp(WifiHistBean wifiHistBean) {

        DBDao dbDao = DBDao.getInstance();
        //先查
        List<WifiHistBean> listBean = dbDao.query(wifiHistBean, 3);
        if (listBean == null || listBean.size() == 0) {
            //没有数据，直接增添
            dbDao.insert(wifiHistBean);
            return wifiHistBean;
        } else {
            //有数据，更新时间
            WifiHistBean wifiHistBean1 = listBean.get(0);
            wifiHistBean1.setSaveTime(System.currentTimeMillis());
            dbDao.upBean(wifiHistBean1, 2);
            return wifiHistBean1;
        }
        //更新远程
    }


    //通过ID获取控件赋值
    public static String getJsFormIdToViewFillValue(String id, String value) {
        return "javascript:document.getElementById('" + id + "').value = '" + value + "';";
    }

    //通过Name获取控件赋值
    public static String getJsFormNameToViewFillValue(String name, String value) {
        return "javascript:document.getElementByName('" + name + "').value = '" + value + "';";
    }

    //通过ID获取控件点击JS
    public static String getJsFormIdToViewClick(String id) {
        return "javascript:document.getElementById('" + id + "').click();";
    }

    //通过Name获取控件点击JS
    public static String getJsFormNameToViewClick(String name) {
        return "javascript:document.getElementByName('" + name + "').click();";
    }


    // 注入js函数监听

    /**
     * 获取图片Js并注入
     *
     * @param webView
     */
    public static void addImageClickListner(WebView webView) {
        //网页加载完成 走JS代码
        String js = "javascript:(function(){" +
                "var objs = document.getElementsByTagName(\"img\"); " +
                "var imgUrl = \"\";" +
                "var filter = [\"img//EventHead.png\",\"img//kong.png\",\"hdtz//button.png\"];" +
                "var isShow = true;" +
                "for(var i=0;i<objs.length;i++){" +
                "for(var j=0;j<filter.length;j++){" +
                "if(objs[i].src.indexOf(filter[j])>=0) {" +
                "isShow = false; break;}}" +
                "if(isShow && objs[i].width>1){" +
                "imgUrl += objs[i].src + ',';isShow = true;" +
                "    objs[i].οnclick=function()  " +
                "    {  "
                + "        window.imageListener.openImage(imgUrl,this.src);" +
//                + "        window.imageListener."+callbackMethodName+"(imgUrl,this.src);" +
                "    }" +
                "}" +
                "}" +
                "})()";
        String js1 = "Javascript:(function(){ " + "var objs = document.getElementsByTagName(\"img\");"
                + " var array=new Array(); " + " for(var j=0;j +array[j]=objs[j].src;" + " } "
                + "window.imageListner.getImage(array); })()";

        String js2 = "function getImages() {\n" +
                "\tvar imgs = document.getElementsByTagName('img');\n" +
                "\tvar imgScr = '';\n" +
                "\tfor (var i = 0; i < imgs.length; i++) {\n" +
                "\t\tif (i == 0) {\n" +
                "\t\t\timgScr = imgs[i].src;\n" +
                "\t\t} else {\n" +
                "\t\t\timgScr = imgScr + '---' + imgs[i].src;\n" +
                "\t\t}\n" +
                "\t};\n" +
                "\treturn imgScr;\n" +
                "};";
//        webView.loadUrl(js);
        webView.evaluateJavascript(js2, null);
//        webView.evaluateJavascript("javascript:getImages()", new ValueCallback<String>() {
//            @Override
//            public void onReceiveValue(String value) {
//                if (value != null && !value.equals("") && !value.equals("null")) {
//                    value = value.replace("\"", "");
//                    String[] dataSource = value.split("---");
//                    List<String> imageDataSource = Arrays.asList(dataSource);
//                    Log.d("TAG", "已获取到图片, 总共 " + imageDataSource.size() + " 张图片" + "\n图片地址：" + imageDataSource);
//                    if (imageDataSource.size()== 0) {
//                        Toast.makeText(context, "主人,没有可观看的图片！", Toast.LENGTH_SHORT).show();
//                    }else {
//                        Intent intent = new Intent(context, SeeImageActivity.class);
//                        intent.putExtra("images", (CharSequence) imageDataSource);
//                        context.startActivity(intent);
//                    }
//                }
//            }
//        });
    }


    // js通信接口
    public static class JavascriptInterface2 {

        private Context context;

        public JavascriptInterface2(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void openImage(String imageUrl, String img) {
            Log.d("TAG", "网页JS注入成功，回调所有图片Url: " + imageUrl + "\n当前观看URL：" + img);
            int position = 0;//当前观看位置
            String[] imgs = imageUrl.split(",");
            ArrayList<String> imgUrlList = new ArrayList<>();
            for (String s : imgs) {
                imgUrlList.add(s);
            }
            for (int i = 0; i < imgUrlList.size(); i++) {
                if (img.equals(imgUrlList.get(i))) {
                    position = i;
                }
            }
            Log.d("TAG", "解析回调图片Url成功：" + imgUrlList + "\n当前观看位置：" + position);
//            Intent intent = new Intent(MainActivity.this, ImageActivity.class);
//            intent.putExtra("number",position);
//            intent.putExtra("list",(Serializable) imgUrlList);
//            startActivity(intent);
        }

//        @android.webkit.JavascriptInterface
//        public void openImage(String imageUrl) {
//            Log.d("TAG", "网页JS注入成功，回调所有图片Url: "+imageUrl);
//        }

//        @JavascriptInterface
//        public void getImage(String[] urls) {
//            Log.d("TAG", "网页JS注入成功，回调所有图片Url: "+ Arrays.toString(urls));
//        }
    }


    public interface WebViewListener {
        void onReceivedTitle(WebView view, String title);

        /**
         * 加载完成
         *
         * @param view
         * @param url
         */
        void onPageFinished(WebView view, String url);


    }


}
