package com.juying.mjreader.fragment;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.juying.mjreader.R;
import com.juying.mjreader.adapter.novel.SectionAdapter;
import com.juying.mjreader.adapter.novel.ViewPageAdaper;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.Note;
import com.juying.mjreader.databinding.ActivityNovelDetailBinding;
import com.juying.mjreader.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Nimyears
 * <p>
 * section:目录
 * note:笔记
 * tvAll:全部
 * tvBookmark:书签
 * tvTag:标红
 */


public class NovelDetailDialogFragment extends DialogFragment implements View.OnClickListener {
    private ActivityNovelDetailBinding vBinding;
    private List<Fragment> fragmentList;
    private List<String> titles;
    private BookBean book;
    protected View rootView;

    private int mNowPos = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Window window = getDialog().getWindow();

        if (rootView == null) {
            getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);

            vBinding = ActivityNovelDetailBinding.inflate(getLayoutInflater(), container, false);
            rootView = vBinding.getRoot();

            window.setWindowAnimations(R.style.main_menu_animStyle);
        }
        getDialog().setCancelable(true);
        getDialog().setCanceledOnTouchOutside(true);

        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        /*作用是从传递给当前Fragment或Activity的参数中获取名为 "bean" 的Parcelable对象*/
        book = getArguments().getParcelable("bean");

        List<Note> noteList = new ArrayList<>();

        Note note = new Note();
        List<String> stringList = new ArrayList<>();
        note.setNoteList(stringList);

        noteList.add(note);


        book.setNotes(noteList);

        initView();
        initListener();
    }


/*    private void readStream(InputStream inputStream, BookBean bookBean) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bufferedInputStream));

        try {
            String line;
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }

//            Log.e(TAG, "readStream: " + stringBuilder);
            List<BookInfo> sections = new ArrayList<>();
            Pattern p = Pattern.compile("===.*?===?");
            Matcher m = p.matcher(stringBuilder.toString());


            while (m.find()) {
                String group = m.group();
//                filterSections.add(group);
                BookInfo bookInfo = new BookInfo();
                bookInfo.setSection(group);
//                bookInfo.setContent(group);
                sections.add(bookInfo);

            }

            bookBean.setSections1(sections);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }*/

    @Override
    public void onStart() {
        super.onStart();

        Window window = getDialog().getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//注意此处

            WindowManager.LayoutParams layoutParams = window.getAttributes();
            layoutParams.width = (int) (ScreenUtils.getScreenWidth(getActivity()));
            layoutParams.height = ScreenUtils.getScreenHeight(getActivity()) * 9 / 10;
            window.setAttributes(layoutParams);
            window.setGravity(Gravity.BOTTOM);
        }

    }

    /*初始化组件*/
    private void initView() {
        fragmentList = new ArrayList<>();
        SectionFragment sectionFragment = new SectionFragment();
        Bundle bundle = new Bundle();
//        bundle.putStringArrayList("sections1", (ArrayList<String>) book.getSections1());
        bundle.putParcelableArrayList("sections1", (ArrayList<? extends Parcelable>) book.getSections1());
        bundle.putParcelable("uri", book.getUri());
        sectionFragment.setArguments(bundle);
        sectionFragment.getSectionAdapter().setChapter(mNowPos);

        sectionFragment.setOnItemClickListener((start, end) -> {
            if(onItemClickListener != null){
                onItemClickListener.onItemClick(start, end);
                dismiss();
            }

        });

        NoteFragment noteFragment = new NoteFragment();
        Bundle bundle1 = new Bundle();
        bundle1.putParcelableArrayList("notes", (ArrayList<? extends Parcelable>) book.getNotes());
        noteFragment.setArguments(bundle1);

        fragmentList.add(sectionFragment);
        fragmentList.add(noteFragment);
        titles = new ArrayList<>();
        titles.add("目录");
        titles.add("笔记");

        ViewPageAdaper pageAdaper = new ViewPageAdaper(getChildFragmentManager(), fragmentList, titles);
        vBinding.viewPager.setAdapter(pageAdaper);
        vBinding.tabLayout.setupWithViewPager(vBinding.viewPager);
        vBinding.tvAll.setSelected(true);

        vBinding.tvTitle.setText(book.getFileName());
        vBinding.bookBriefTvAuthor.setText(String.format(getString(R.string.all_section), book.getSections1().size()));
    }

    @SuppressLint("ClickA")  //忽略警告
    public void initListener() {
        vBinding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            /*被查看的页面发生改变时被调用*/
            @Override
            public void onPageSelected(int position) {
                if (position == 1) {
                    vBinding.llNote.setVisibility(View.VISIBLE);
                } else {
                    vBinding.llNote.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        vBinding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position == 1) {
                    vBinding.llNote.setVisibility(View.VISIBLE);
                } else {
                    vBinding.llNote.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        vBinding.tvAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (vBinding.tvAll.isSelected()) return;
                vBinding.tvAll.setSelected(true);
                vBinding.tvBookmark.setSelected(false);
                vBinding.tvTag.setSelected(false);
            }
        });
        vBinding.tvBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (vBinding.tvBookmark.isSelected()) return;
                vBinding.tvBookmark.setSelected(true);
                vBinding.tvAll.setSelected(false);
                vBinding.tvTag.setSelected(false);
            }
        });
        vBinding.tvTag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (vBinding.tvTag.isSelected()) return;
                vBinding.tvTag.setSelected(true);
                vBinding.tvAll.setSelected(false);
                vBinding.tvBookmark.setSelected(false);

            }
        });
    }

    /*属性动画纵向平移*/
    private void startPopsAnimTrans1(View view, float... xy) {
        ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(view, "translationY", xy);
        objectAnimatorX.setDuration(350);
        objectAnimatorX.start();
    }

    @Override
    public void onClick(View v) {
    }




    /*通常用于在用户点击某个元素或视图时执行特定操作*/
    public interface OnItemClickListener {
        void onItemClick(String start, String end);
    }

    private OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setNowPos(int pos){
        mNowPos = pos;
    }
}
