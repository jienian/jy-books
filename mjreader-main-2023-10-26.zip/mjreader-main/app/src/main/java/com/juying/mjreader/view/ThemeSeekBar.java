package com.juying.mjreader.view;

import static com.bumptech.glide.Glide.init;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatSeekBar;

public class ThemeSeekBar extends AppCompatSeekBar {
    public ThemeSeekBar(@NonNull Context context) {
        super(context);
        init(context);
    }

    public ThemeSeekBar(Context context, AttributeSet attrs){
        super(context, attrs);
        init(context);
    }

    public void init(Context context){
        if(isInEditMode()){
            //applyTint(context.getAccentColor());
        }
    }
    private void applyTint(int color) {
        // 这里添加applyTint方法的具体实现
    }

}
