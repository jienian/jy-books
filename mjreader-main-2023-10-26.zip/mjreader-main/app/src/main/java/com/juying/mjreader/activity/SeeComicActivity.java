package com.juying.mjreader.activity;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnRenderListener;
import com.github.barteksc.pdfviewer.util.FitPolicy;
import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.R;
import com.juying.mjreader.adapter.SeeComicAdapter;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.bean.ComicSettingBean;
import com.juying.mjreader.bean.FlagBean;
import com.juying.mjreader.bean.TreeNodeData;
import com.juying.mjreader.databinding.ActivitySeeComicBinding;
import com.juying.mjreader.utils.DeviceInfo;
import com.juying.mjreader.utils.DialogUtils;
import com.juying.mjreader.utils.PDFUtil;
import com.juying.mjreader.utils.RecyclerViewUtil;
import com.juying.mjreader.utils.RomUtil;
import com.juying.mjreader.utils.SeeComicMode;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.utils.sqlite.FlagBDDao;
import com.juying.mjreader.view.DialogBrowseEdit;
import com.juying.mjreader.view.DialogFlagDirectory;
import com.juying.mjreader.view.DialogMask;

import java.io.File;
import java.util.List;

import me.jessyan.autosize.AutoSizeConfig;

/**
 * @Author Ycc
 * @Date 16:09
 */
public class SeeComicActivity extends BaseActivity {

    public ComicSettingBean comicSettingBean;
//    public BookBean comicBean;//文档页传过来的目录Bean

    //    public BookBean currentBean;//文档页目录Bean点击的子Bean,也就是当前展示的Bean,【一定是文件】
    private ComicSeeSumBean comicSeeSumBean;
    /**
     * 当前显示seeBean
     */
    private ComicSeeBean currentSeeBean;
    private ActivitySeeComicBinding vBinding;
    boolean isAnimationHave = false;
    boolean titleSwitch = true;
    private SeeComicAdapter seeComicAdapter;
    private LinearLayoutManager layoutManager;
    private PagerSnapHelper linearSnapHelper;

    private DialogFlagDirectory dialogFlagDirectory;

    /**
     * 是否是用户在拖动SeekBar
     */
    private boolean isFromUserClickSeekBar = false;
    /**
     * 目前是不是自动阅读模式
     */
    private boolean isAuto = false;
    private double windowW;
    private DialogBrowseEdit dialogBrowseEdit;
    private DialogMask dialogMask;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivitySeeComicBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        DeviceInfo deviceInfo = DeviceInfo.getDeviceInfo(this);
        windowW = DeviceInfo.getDeviceInfo(this).getWindowW();
        log("是否pad1=" + deviceInfo.isPad());
        initBean();
        initUi(comicSeeSumBean, comicSettingBean);
        initListener();
        //TODO  加载中loding
    }


    private void initBean() {
        Intent intent = getIntent();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            comicSeeSumBean = intent.getParcelableExtra("comicSeeSumBean", ComicSeeSumBean.class);
            comicSettingBean = intent.getParcelableExtra("settingBean", ComicSettingBean.class);
        } else {
            comicSeeSumBean = intent.getParcelableExtra("comicSeeSumBean");
            comicSettingBean = intent.getParcelableExtra("settingBean");
        }
        currentSeeBean = comicSeeSumBean.getSeeBeanList().get(comicSeeSumBean.getCurrentShowPosition());

        //Rv的标签信息就在这里统一查，PDF在翻页的时候单独查
        if (!comicSeeSumBean.isPDFMode()) {
            FlagBDDao flagBDDao = FlagBDDao.getInstance();
            List<ComicSeeBean> cBean = comicSeeSumBean.getSeeBeanList();
            for (int i = 0; i < cBean.size(); i++) {
                ComicSeeBean bean = cBean.get(i);
                List<FlagBean> list = flagBDDao.query(new FlagBean(bean.getUrl(), 0), 1);
                if (list != null && list.size() > 0) {
                    bean.setFlagBean(list.get(0));
                }
            }
        }
        //增添ComicSeeBean数据
//        log("传递设置数据=" + comicSettingBean.toString());
//        log("传递数据=" + comicSeeSumBean.toString());
        log("传递数据数据总量=" + comicSeeSumBean.getSeeBeanList().size());
        setUrlWH(comicSeeSumBean);
    }


    //设置资源宽高
    private void setUrlWH(ComicSeeSumBean comicSeeSumBean) {
        if (!isDataNull(comicSeeSumBean)) {
            for (int i = 0; i < comicSeeSumBean.getSeeBeanList().size(); i++) {
                ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(i);
                Bitmap bitmap = null;
                if (!comicSeeBean.isWifi()) {
                    bitmap = BitmapFactory.decodeFile(comicSeeBean.getUrl());
                }

                if (bitmap != null) {
                    int w = bitmap.getWidth();
                    int h = bitmap.getHeight();
                    double newH = windowW / w * h;
                    //扩大了多少，有可能是负数，说明缩小了
                    comicSeeBean.setWidth((int) windowW);
                    comicSeeBean.setHeight((int) newH);
                }
            }
        }
    }

    private void initUi(ComicSeeSumBean comicSeeSumBean, ComicSettingBean comicSettingBean) {
        vBinding.cbSetting.getBackground().mutate().setAlpha(26);

        if (comicSeeSumBean.isPDFMode()) {
            vBinding.rv.setVisibility(View.GONE);
            vBinding.flPdf.setVisibility(View.VISIBLE);
            flag_mode = comicSettingBean.getModeComicSee();//这个标识符很重要，影响PDF的观看模式，位置要在initPDFview()之前
            vBinding.sb.setProgress(currentSeeBean.getCurrentShowIndex());
            initPDFview(currentSeeBean);
        } else {
            vBinding.rv.setVisibility(View.VISIBLE);
            vBinding.flPdf.setVisibility(View.GONE);
            initRV();
            vBinding.sb.setMax(comicSeeSumBean.getSeeBeanList().size() - 1);
//            vBinding.sb.setProgress(comicSeeSumBean.getCurrentShowPosition());
        }
        SeeComicMode.setTitleTxt(vBinding, currentSeeBean.getFileName(), false);
        setSetingUi(comicSettingBean);

//        //由于初始化sb的时候会矫正RV,所以解决方法：先在xml初始化的时候用的INVISIBLE，这里用GONE
//        vBinding.llSchedule.setVisibility(View.GONE);
    }


    private void setSetingUi(ComicSettingBean comicSettingBean) {
        vBinding.sb1.setProgress((int) (comicSettingBean.getViewingBrightness() * 100));
        int modeComicSee = comicSettingBean.getModeComicSee();
        if (modeComicSee == 1) {
            readModeChecked(vBinding.rb1, 1);
            vBinding.rb1.setChecked(true);
        } else if (modeComicSee == 2) {
            readModeChecked(vBinding.rb2, 2);
            vBinding.rb2.setChecked(true);
        } else if (modeComicSee == 3) {
            vBinding.rb3.setChecked(true);
            readModeChecked(vBinding.rb3, 3);
        }
        int modeHorizontalOrVertical = comicSettingBean.getModeHorizontalOrVertical();
        modeHorizontalOrVertical = 2;
        if (modeHorizontalOrVertical == 1) {
//            vBinding.rb4.setChecked(true);
        } else if (modeHorizontalOrVertical == 2) {
            vBinding.rb5.setChecked(true);
//           setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//竖屏
        } else if (modeHorizontalOrVertical == 3) {
//            vBinding.rb6.setChecked(true);
//            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//横屏
        }
        vBinding.switch1.setChecked(comicSettingBean.isVolumeKeysPages());
        vBinding.switch2.setChecked(comicSettingBean.isReadShowStatusBar());
        vBinding.cbDay.setChecked(comicSettingBean.isModeNight());
        vBinding.cbDay.setText(comicSettingBean.isModeNight() ? "日间" : "夜间");
        vBinding.cbDay.setCompoundDrawablesWithIntrinsicBounds(null, comicSettingBean.isModeNight() ? getDrawable(R.drawable.day1) : getDrawable(R.drawable.night), null, null);
    }


    private PDFView.Configurator configurator;

    //标识符，更改模式之前的模式，默认3
    private int flag_mode;

    private void initPDFview(ComicSeeBean showBean) {

        int modeComicSee = comicSettingBean.getModeComicSee();
        boolean isHorizontal = false;//是否横版
        boolean isReverse = false;//是否倒序

        if (modeComicSee == 1) {
            isHorizontal = true;
            isReverse = false;
        } else if (modeComicSee == 2) {
            isHorizontal = true;
            isReverse = true;
        } else if (modeComicSee == 3) {
            isHorizontal = false;
            isReverse = false;
        }
        String url = showBean.getUrl();
        int[] pageByte = null;
        int defaultPage = 0;
        if (showBean.isWifi()) {
            configurator = vBinding.pdfView.fromUri(Uri.parse(url));
        } else {
            File pdfFile = new File(url);
            configurator = vBinding.pdfView.fromFile(pdfFile);
            int countPages = PDFUtil.getPdfCountPages(pdfFile);
            showBean.setPdfCountPage(countPages);
            pageByte = new int[countPages];
            for (int i = 0; i < countPages; i++) {
                if (isReverse) {
                    pageByte[i] = countPages - 1 - i;
                } else {
                    pageByte[i] = i;
                }
            }
//            log("倒序后：" + Arrays.toString(pageByte));
            defaultPage = showBean.getCurrentShowIndex();
            if (isReverse) {
                if (flag_mode == 2) {
                    //初始化的时候就用之前存的数据
                } else {
                    defaultPage = countPages - 1 - defaultPage;
                }
            } else {
                if (flag_mode == 2) {
                    defaultPage = countPages - 1 - defaultPage;
                }
            }
            log("倒序起始位置：" + defaultPage + ",之前模式：" + flag_mode);
        }


        if (pageByte != null) {
            configurator.pages(pageByte);
        }

        configurator
//                .password(null)//密码
                .defaultPage(defaultPage)//默认显示第几页
                .enableSwipe(true)//滑动
                .swipeHorizontal(isHorizontal)//是否水平展示
                .pageFling(isHorizontal)
                .autoSpacing(isHorizontal)
                .pageSnap(isHorizontal)
                .pageFitPolicy(FitPolicy.WIDTH)//页面适应测量
                .enableAnnotationRendering(false)
                .scrollHandle(null)//滚轮
//                .enableDoubletap(false)//双击放大缩小
//                .onTap(e -> {
//                    //只在点击时执行一下
//                    LogUtil.d("TAG", "onTap执行,动作：" + e.getAction());
//                    return false;
//                })
                .onPageScroll((page, positionOffset) -> {
//                    log("onPageScroll: 执行=page=" + page + ";positionOffset=" + positionOffset);
                })
                .onPageChange((page, pageCount) -> {
                    // 页面切换时的回调函数，存读取进度
                    log("onPageChange: 执行=page=" + page + ";pageCount=" + pageCount);
//                        SeeComicMode.setTitleTxt(vBinding,);
                    showBean.setCurrentShowIndex(page);
                    double position = ((double) page) / (pageCount - 1) * 100;
                    showBean.setCurrentShowPosition((int) position);
                    int num = page;
                    if (comicSettingBean.getModeComicSee() == 2) {
                        num = flip(num, pageCount - 1);
                    }
                    vBinding.sb.setProgress(num);
                    //查标签信息
                    FlagBDDao flagBDDao = FlagBDDao.getInstance();
                    List<FlagBean> flagBeans = flagBDDao.query(new FlagBean(showBean.getUrl(), num), 1);
                    if (flagBeans != null && flagBeans.size() > 0) {
                        vBinding.mcv.setVisibility(View.VISIBLE);
                        FlagBean flagBean = flagBeans.get(0);
                        vBinding.mcv.setTag(flagBean);
                        showBean.setFlagBean(flagBean);
                    } else {
                        vBinding.mcv.setVisibility(View.GONE);
                        vBinding.tvContent.setVisibility(View.GONE);
                        vBinding.mcv.setTag(null);
                        showBean.setFlagBean(null);
                    }
                })
                .onLoad(nbPages -> {
                    log("成功加载PDF,onLoad: 执行=nbPages=" + nbPages);
                    vBinding.sb.setMax(nbPages - 1);
//                    vBinding.sb.setProgress(showBean.getCurrentShowIndex());
                    //TODO 获得文档书签信息,没有有书签的PDF,先用模拟书签数据
//                    iniTreeNodeData();
//                    catelogues = SeeComicMode.bookmarkToCatelogues(catelogues, 50, 1);
                    //加载完成后设定标识符；
                    flag_mode = modeComicSee;
                })
                .onRender(new OnRenderListener() {
                    @Override
                    public void onInitiallyRendered(int nbPages) {
                        log("成功加载PDF,onRender: 执行=nbPages=" + nbPages);
                    }
                })
                .load();
    }


    private boolean isDataNull(ComicSeeSumBean comicSeeSumBean) {
        return comicSeeSumBean == null || comicSeeSumBean.getSeeBeanList() == null || comicSeeSumBean.getSeeBeanList().size() == 0;
    }


    private void setAutoSwitch(int type) {
        //点击外层开启自动阅读
        if (type == 1) {
            clickCentre();
            vBinding.llAuto.setVisibility(View.VISIBLE);
            vBinding.llAutoSetting.setVisibility(View.GONE);
            isAuto = true;
            //点击自动阅读的设置
        } else if (type == 2) {
            vBinding.llAuto.setVisibility(View.GONE);
            vBinding.llAutoSetting.setVisibility(View.VISIBLE);
            //点击退出自动阅读
        } else if (type == 3) {
            vBinding.llAuto.setVisibility(View.GONE);
            vBinding.llAutoSetting.setVisibility(View.GONE);
            isAuto = false;
        }
    }


    private void clickRaeShowState(boolean isChecked) {
        fullscreen(isChecked);
        if (isChecked) {
            vBinding.view2.setVisibility(View.VISIBLE);
        } else {
            if (RomUtil.isMiui()) {
                vBinding.view2.setVisibility(View.GONE);
            } else {
                vBinding.view2.setVisibility(View.VISIBLE);
            }
        }

    }

    @SuppressLint({"ClickableViewAccessibility", "WrongConstant"})
    private void initListener() {
        vBinding.ivBack.setOnClickListener(v -> finish());
        vBinding.llSetting.setOnClickListener(v -> {
                    //拦截点击事件
                }
        );
        vBinding.tvAuto.setOnClickListener(v -> {
            if (comicSettingBean.getModeComicSee() != 3) {
                to("卷轴模式下可自动阅读", false);
                return;
            }
            int speed = getSpeed();
            //自动开跑
            if (vBinding.rv.getVisibility() == View.VISIBLE) {
                vBinding.rv.startPlay();
                vBinding.rv.setSpeed(speed);
            } else if (vBinding.pdfView.getVisibility() == View.VISIBLE) {
//                autoScrollHandle.startPlay();
                vBinding.pdfView.startPlay();
            }
            //更新UI
            setAutoSwitch(1);
            if (speed == 1) {
                vBinding.rbAotu1.setChecked(true);
            } else if (speed == 2) {
                vBinding.rbAotu2.setChecked(true);
            } else if (speed == 3) {
                vBinding.rbAotu3.setChecked(true);
            } else if (speed == 4) {
                vBinding.rbAotu4.setChecked(true);
            } else if (speed == 5) {
                vBinding.rbAotu5.setChecked(true);
            }
        });
        vBinding.tvBackAuto.setOnClickListener(v -> {
            //更新UI
            setAutoSwitch(1);
        });
        vBinding.tvAutoSetting.setOnClickListener(v -> setAutoSwitch(2));
        vBinding.ivSetting.setOnClickListener(v -> setAutoSwitch(2));
        vBinding.tvOff.setOnClickListener(v -> {
            //停止自动
            vBinding.rv.stopPlay();
            vBinding.pdfView.stopPlay();
            //更新UI
            setAutoSwitch(3);
        });
        vBinding.ivEdit.setOnClickListener(v -> {
            if (dialogBrowseEdit == null) {
                dialogBrowseEdit = new DialogBrowseEdit(this, () -> {
                    DialogUtils.windowDialogView(this, R.layout.dialog_new_group, "增添标记", "请输入文字内容", text -> {
                        ComicSeeBean currentBean;
                        int page = 0;
                        if (comicSeeSumBean.isPDFMode()) {
                            currentBean = comicSeeSumBean.getSeeBeanList().get(0);
                            page = vBinding.sb.getProgress();//直接以进度条为准，无论普通还是日翻，进度条已经处理好了索引
//                            .
                        } else {
                            //如果是Rv就可以用当前Bean
                            currentBean = currentSeeBean;
//                            log("当前显示索引："+comicSeeSumBean.getCurrentShowPosition());
//                            log("当前显示Bean："+currentSeeBean.toString());
                        }
                        String filePath = currentBean.getUrl();
                        String coverUrl = currentBean.getFileType();
                        String fileName = currentBean.getFileName();
                        FlagBean flagBean = new FlagBean(MjApplication.getUserId(), System.currentTimeMillis(), text, filePath, currentBean.getFileType(), coverUrl, fileName, page, 0);
                        //保存SQ书签
                        FlagBDDao.getInstance().insert(flagBean);
                        //保存内存更新ui
                        currentBean.setFlagBean(flagBean);
                        upFlagUi();
                    });
                });
            }
            dialogBrowseEdit.show();
        });

        vBinding.rgAotuSetting.setOnCheckedChangeListener((group, checkedId) -> {
            int type = 3;
            if (checkedId == vBinding.rbAotu1.getId()) {
                type = 1;
            } else if (checkedId == vBinding.rbAotu2.getId()) {
                type = 2;
            } else if (checkedId == vBinding.rbAotu3.getId()) {
                type = 3;
            } else if (checkedId == vBinding.rbAotu4.getId()) {
                type = 4;
            } else if (checkedId == vBinding.rbAotu5.getId()) {
                type = 5;
            }
            saveSpeed(type);
            if (vBinding.rv.getVisibility() == View.VISIBLE) {
                vBinding.rv.setSpeed(type);
            } else if (vBinding.pdfView.getVisibility() == View.VISIBLE) {
                vBinding.pdfView.setSpeed(type);
            }
        });


        vBinding.cbSetting.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                vBinding.llMore.setVisibility(View.VISIBLE);
            } else {
                vBinding.llMore.setVisibility(View.GONE);
            }
        });
        vBinding.switch1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            comicSettingBean.setVolumeKeysPages(isChecked);
        });
        vBinding.switch2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            comicSettingBean.setReadShowStatusBar(isChecked);
            clickRaeShowState(isChecked);
        });
        vBinding.rgType.setOnCheckedChangeListener((group, checkedId) -> {
            //阅读模式改变
            if (checkedId == vBinding.rb1.getId()) {
                comicSettingBean.setModeComicSee(1);
                readModeChecked(vBinding.rb1, 1);
            } else if (checkedId == vBinding.rb2.getId()) {
                comicSettingBean.setModeComicSee(2);
                readModeChecked(vBinding.rb2, 2);
            } else if (checkedId == vBinding.rb3.getId()) {
                comicSettingBean.setModeComicSee(3);
                readModeChecked(vBinding.rb3, 3);
            }
        });


        vBinding.rgWindow.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == vBinding.rb4.getId()) {
                comicSettingBean.setModeHorizontalOrVertical(1);
//                readModeChecked(vBinding.rb4, 4);
            } else if (checkedId == vBinding.rb5.getId()) {
                AutoSizeConfig.getInstance().setDesignWidthInDp(375);
                AutoSizeConfig.getInstance().setDesignHeightInDp(812);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//竖屏
                comicSettingBean.setModeHorizontalOrVertical(2);
//                readModeChecked(vBinding.rb5, 5);
            } else if (checkedId == vBinding.rb6.getId()) {
                comicSettingBean.setModeHorizontalOrVertical(3);
                AutoSizeConfig.getInstance().setDesignWidthInDp(812);
                AutoSizeConfig.getInstance().setDesignHeightInDp(375);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//横屏
//                readModeChecked(vBinding.rb6, 6);
            }


        });


        vBinding.sb1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                log("滑动开始");
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                SeeComicMode.setBrightness(SeeComicActivity.this, ((float) progress) / 100);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                log("滑动结束");
                float p = ((float) seekBar.getProgress()) / 100;
                comicSettingBean.setViewingBrightness(p);
            }
        });

        vBinding.listeningView.setRecyclerViewClickListener((v, direction) -> {


            if (titleSwitch) {
                clickCentre();
                return;
            }

            switch (direction) {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    jumpPage(comicSeeSumBean, getJumpPostion(true));
                    break;
                case 4:
                    jumpPage(comicSeeSumBean, getJumpPostion(false));
                    break;
                case 5:
                    clickCentre();
                    break;
                default:
            }
        });

        vBinding.textView1.setOnClickListener(v -> {
//            log("点击目录");
            List<TreeNodeData> treeNodeDataList;
            int currentPage;
            if (comicSeeSumBean.isPDFMode()) {
                treeNodeDataList = PDFUtil.iniTreeNodeData(vBinding.pdfView);
//                if (comicSettingBean.getModeComicSee() == 2) {
//                    Collections.reverse(treeNodeDataList);
//                }
                //pdf当前page
                int pdfCurrentPage = vBinding.pdfView.getCurrentPage();
                if (comicSettingBean.getModeComicSee() == 2) {
                    pdfCurrentPage = vBinding.pdfView.getPageCount() - 1 - pdfCurrentPage;
                }
                //转化成rv标签页的当前页【也就是pdf当前page属于标签页的那一页，因为一个标签页可能包含很多pdf page】
                currentPage = PDFUtil.pdfPageBelongTag(pdfCurrentPage, treeNodeDataList);


            } else {
                List<Integer> list = RecyclerViewUtil.getVisibleItmePosition(vBinding.rv, layoutManager);
                if (list.size() == 0) {
                    currentPage = layoutManager.findFirstVisibleItemPosition();
                } else {
                    currentPage = list.get(0);
                }
                treeNodeDataList = SeeComicMode.getRvTreeNodeData(comicSeeSumBean);
            }


            if (dialogFlagDirectory == null) {
                dialogFlagDirectory = new DialogFlagDirectory(this, R.style.DialogTheme, comicSeeSumBean, treeNodeDataList, currentPage, new DialogFlagDirectory.DialogFlagDirectoryListener() {

                    @Override
                    public void onClickPosition(int clickPosition) {
                        if (comicSeeSumBean.isPDFMode()) {
                            String pdfName = treeNodeDataList.get(clickPosition).getName();
                            int pdfPageNum = treeNodeDataList.get(clickPosition).getPageNum();
                            log("Rv的itme索引：" + clickPosition + ";标签名称：" + pdfName + ";对应索引e：" + pdfPageNum);
                            if (comicSettingBean.getModeComicSee() == 2) {
                                pdfPageNum = vBinding.pdfView.getPageCount() - 1 - pdfPageNum;
                            }
                            jumpPage(comicSeeSumBean, pdfPageNum);
                        } else {
                            vBinding.rv.scrollToPosition(clickPosition);
                        }
                        dialogFlagDirectory.dismiss();
                    }

                    @Override
                    public void onClickAdd() {

                    }
                });
            } else {
                if (comicSeeSumBean.isPDFMode()) {
                    dialogFlagDirectory.initFlagListBean();
                    dialogFlagDirectory.upFlagUi();
                    dialogFlagDirectory.upAdaper2();
                } else {
                    dialogFlagDirectory.upDirectoryUi(currentPage);
                }
            }
            dialogFlagDirectory.show();
        });


        vBinding.textView2.setOnClickListener(v -> {
                    setSwitch(vBinding.llSchedule, true);
                }
        );
        vBinding.cbDay.setOnCheckedChangeListener((group, checkedId) -> {
            requestDrawOverLays(checkedId);//夜间/日间模式
        });

        vBinding.tvTop.setOnClickListener(v -> {
            int position = getJumpPostion(true);
            jumpPage(comicSeeSumBean, position);
        });
        vBinding.tvBelow.setOnClickListener(v -> {
            int position = getJumpPostion(false);
            jumpPage(comicSeeSumBean, position);
        });

        vBinding.sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // 拖动开始时调用
                log("拖动开始当前值：" + seekBar.getProgress());
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // 拖动中; 这里只有progress发生变化才会调用，fromUser 是用户拖动为true   代码设置为false
                if (isFromUserClickSeekBar = fromUser) {

                    if (comicSettingBean.getModeComicSee() == 2) {
                        progress = vBinding.pdfView.getPageCount() - 1 - progress;
                    }
                    log("onProgressChanged执行：progress：" + progress);

                    jumpPage(comicSeeSumBean, progress);
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // 拖动停止时调用
                isFromUserClickSeekBar = false;
            }
        });


        vBinding.textView4.setOnClickListener(v -> {
            setSwitch(vBinding.llSetting, true);
        });

        vBinding.rb4.setOnClickListener(v -> {
            to("暂不支持", false);
        });
        vBinding.rb6.setOnClickListener(v -> {
            to("暂不支持", false);
        });

        vBinding.mcv.setOnClickListener(v -> {
            Object tag = v.getTag();
            if (tag != null) {
                FlagBean flagBean = (FlagBean) tag;
                if (vBinding.tvContent.getVisibility() == View.GONE && !TextUtils.isEmpty(flagBean.getContent())) {
                    vBinding.tvContent.setVisibility(View.VISIBLE);
                    vBinding.tvContent.setText(flagBean.getContent());
//                    vBinding.tvContent.post(new Runnable() {
//                        @Override
//                        public void run() {
////                            int height = tvContent.getHeight();
////                            float xxx = tvContent.getY();
////                            float xxx1 = tvContent.getRotationY();
//                            float pivotY = vBinding.tvContent.getPivotY();
////                            float xxx3 = tvContent.getScaleY();
////                            float xxx4 = tvContent.getScrollY();
//                            ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(vBinding.tvContent, "translationY", pivotY);
//                            objectAnimatorX.setDuration(1);
//                            objectAnimatorX.start();
//                            tvContent.post(() -> tvContent.setVisibility(View.VISIBLE));
//                        }
//                    });
                } else {
                    vBinding.tvContent.setVisibility(View.GONE);
                }
            }
        });
    }

    public void requestDrawOverLays(boolean checkedId) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请授予权限", Toast.LENGTH_SHORT).show();
            //跳转到相应软件的设置页面
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, -9);
        } else {
            // 授权成功之后执行的方法
            checkedSet(checkedId);
        }
    }

//    @SuppressLint("MissingSuperCall")
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == -9) {
//            if (!Settings.canDrawOverlays(this)) {
//                log("悬浮窗授权失败");
//            } else {
//                log("悬浮窗授权成功");
//                checkedSet(true);
//            }
//        }
//    }


    private void checkedSet(boolean checkedId) {
        DialogMask dialogMask = DialogMask.example(MjApplication.CONTEXT);
        if (checkedId) {
            dialogMask.show();
        } else {
            dialogMask.dismiss();
        }
        comicSettingBean.setModeNight(checkedId);
        vBinding.cbDay.setText(checkedId ? "日间" : "夜间");
        vBinding.cbDay.setCompoundDrawablesWithIntrinsicBounds(null, getDrawable(R.drawable.select_day_night), null, null);
    }


    //保存速度档位到SP
    private void saveSpeed(int type) {
        SharedPreferences.Editor edit = Constant.NOVEL_SETTING_SP.edit();
        edit.putInt(Constant.AUTOMATIC_READING_SPEED, type);
        edit.apply();
    }

    //获取sp速度档位
    private int getSpeed() {
        SharedPreferences sp = Constant.NOVEL_SETTING_SP;
        int speed = sp.getInt(Constant.AUTOMATIC_READING_SPEED, 3);
        comicSettingBean.setAutomaticReadingSpeed(speed);
        return speed;
    }

    private void upFlagUi() {
        if (comicSeeSumBean.isPDFMode()) {
            FlagBean flagBean = getCurrentShowFlagBean();
            if (flagBean != null && !TextUtils.isEmpty(flagBean.getContent())) {
                vBinding.mcv.setVisibility(View.VISIBLE);
                vBinding.mcv.setTag(flagBean);
            } else {
                vBinding.mcv.setVisibility(View.GONE);
                vBinding.mcv.setTag(null);
            }
        } else {
            seeComicAdapter.notifyItemChanged(comicSeeSumBean.getCurrentShowPosition(), vBinding.mcv);
        }
    }

    private FlagBean getCurrentShowFlagBean() {
        FlagBean flagBean;
        if (comicSeeSumBean.isPDFMode()) {
            flagBean = comicSeeSumBean.getSeeBeanList().get(0).getFlagBean();
        } else {
            flagBean = comicSeeSumBean.getSeeBeanList().get(comicSeeSumBean.getCurrentShowPosition()).getFlagBean();
        }
        return flagBean;
    }


    @SuppressLint("NotifyDataSetChanged")
    private void readModeChecked(RadioButton radioButton, int i) {
        log("阅读模式或横竖屏模式：" + i);
        radioButton.setChecked(true);
        switch (i) {
            case 1:
                if (comicSeeSumBean.isPDFMode()) {
                    initPDFview(comicSeeSumBean.getSeeBeanList().get(0));
                } else {
                    linearSnapHelper.attachToRecyclerView(vBinding.rv);//控制单Itme能否有偏移
                    layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);//横向
                    layoutManager.setReverseLayout(false);//是否倒序
                    seeComicAdapter.notifyDataSetChanged();
                }
                break;
            case 2:
                if (comicSeeSumBean.isPDFMode()) {
                    initPDFview(comicSeeSumBean.getSeeBeanList().get(0));
                } else {
                    linearSnapHelper.attachToRecyclerView(vBinding.rv);
                    layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                    layoutManager.setReverseLayout(true);
                    seeComicAdapter.notifyDataSetChanged();
                }
                break;
            case 3:
                if (comicSeeSumBean.isPDFMode()) {
                    initPDFview(comicSeeSumBean.getSeeBeanList().get(0));
                } else {
                    linearSnapHelper.attachToRecyclerView(null);
                    layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                    layoutManager.setReverseLayout(false);
                    seeComicAdapter.notifyDataSetChanged();
                }
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
        }
    }

    private int getJumpPostion(boolean isTop) {
        int position;
        if (isTop) {
            int toPosition;
            if (comicSeeSumBean.isPDFMode()) {
                if (comicSettingBean.getModeComicSee() == 2) {
                    //日漫模式
                    toPosition = vBinding.pdfView.getCurrentPage() + 1;
                } else {
                    //其他模式模式
                    toPosition = vBinding.pdfView.getCurrentPage() - 1;
                }
            } else {
                /**
                 *    TODO 因为RV采用的是吸附顶部，所以如果滑动最底后有两个及以上可见itme,那么用最后的值减1调整Rv是不会触发滚定监听的，所以这种情况要单独处理
                 * 但是，横向rv的时候要注意看看有没有问题
                 */
                List<Integer> list = RecyclerViewUtil.getVisibleItmePosition(vBinding.rv, layoutManager);
                if (list.size() != 0 && list.get(list.size() - 1) == layoutManager.getItemCount() - 1) {
                    //如果没有完全可见的，上翻页的时候就以最后一个可见为基准，这样翻页的时候就加载上一个未完整显示的
                    toPosition = list.get(0) - 1;
                } else {
                    toPosition = vBinding.sb.getProgress() - 1;
                }
            }
            position = toPosition < 0 ? 0 : toPosition;
        } else {
            int toPosition;
            int size;
            if (comicSeeSumBean.isPDFMode()) {
                size = vBinding.pdfView.getPageCount() - 1;
//                toPosition = comicSeeSumBean.getSeeBeanList().get(0).getCurrentShowIndex() + 1;
                if (comicSettingBean.getModeComicSee() == 2) {
                    //日漫模式
                    toPosition = vBinding.pdfView.getCurrentPage() - 1;
                } else {
                    //其他模式模式
                    toPosition = vBinding.pdfView.getCurrentPage() + 1;
                }

            } else {
//                size = comicSeeSumBean.getSeeBeanList().size() - 1;
//                toPosition = comicSeeSumBean.getCurrentShowPosition() + 1;
                size = vBinding.sb.getMax();
                toPosition = vBinding.sb.getProgress() + 1;
            }
            position = toPosition > size ? size : toPosition;
        }
        return position;
    }

    /**
     * 调整到指定页
     *
     * @param comicSeeSumBean
     * @param position        索引
     */
    private void jumpPage(ComicSeeSumBean comicSeeSumBean, int position) {
        if (position < 0) {
            return;
        }
        if (comicSeeSumBean.isPDFMode()) {
            vBinding.pdfView.jumpTo(position);
        } else {
            layoutManager.scrollToPosition(position);
        }
    }

    private int getProgress(int position) {
        if (position == 0) {
            position = 1;
        } else {
            position += 1;
        }
        return position;
    }

    private void setSwitch(View v, boolean isShow) {
        if (isShow) {
            v.setVisibility(View.VISIBLE);
            vBinding.llBottom.setVisibility(View.GONE);
            startPopsAnimTrans1(v, 0);
        } else {
            vBinding.llBottom.setVisibility(View.VISIBLE);
            startPopsAnimTrans1(v, v.getHeight());
        }
    }

    //单击标记item
    public void clickFlag(FlagBean flagBean) {
        int position = queryPosition(flagBean);
        jumpPage(comicSeeSumBean, position);
    }


    //查标记所在list的索引
    public int queryPosition(FlagBean flagBean) {
        int position = -1;
        if (comicSeeSumBean.isPDFMode()) {
            for (int i = 0; i < vBinding.pdfView.getPageCount(); i++) {
                if (flagBean.getPageNumber() == i) {
                    position = i;
                    if (comicSettingBean.getModeComicSee() == 2) {
                        //翻转
                        position = flip(i, vBinding.pdfView.getPageCount() - 1);
                    }
                    break;
                }
            }
        } else {
            for (int i = 0; i < comicSeeSumBean.getSeeBeanList().size(); i++) {
                if (flagBean.getFilePath().equals(comicSeeSumBean.getSeeBeanList().get(i).getUrl())) {
                    position = i;
                    break;
                }
            }

        }
        return position;
    }


    //翻转位置 【如果position是索引，记得传进来count总数减1】
    private int flip(int position, int count) {
        return count - position;
    }

    public void delFlag(FlagBean flagBean) {
        if (comicSeeSumBean.isPDFMode()) {
            vBinding.mcv.setVisibility(View.GONE);
        } else {
//            int sssd = queryPosition(flagBean);
            int progress = vBinding.sb.getProgress();
            comicSeeSumBean.getSeeBeanList().get(progress).setFlagBean(null);
            seeComicAdapter.notifyItemChanged(progress, R.id.mcv);
//            .
//            log("当前删除索引：sssd="+sssd+";progress:"+progress);
        }
    }


    public class SmoothScroller extends LinearSmoothScroller {
        public SmoothScroller(Context context) {
            super(context);
        }

        @Override
        public int getVerticalSnapPreference() {
            // 这里改成滚动停止时吸附到列表头部  三种值头、中、底
            return SNAP_TO_START;
        }
    }

    ViewTreeObserver.OnGlobalLayoutListener globalLayoutListener;

    private void initRV() {
        seeComicAdapter = new SeeComicAdapter(this, comicSeeSumBean);
        // 使用前首先实例化SmoothScroller
        SmoothScroller scroller = new SmoothScroller(this);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false) {
            @Override
            public void scrollToPosition(int position) {
                scroller.setTargetPosition(position);
                startSmoothScroll(scroller);

            }

            @Override
            public void smoothScrollToPosition(RecyclerView recyclerView, RecyclerView.State state, int position) {
                scroller.setTargetPosition(position);
                startSmoothScroll(scroller);
            }

        };


        globalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            Thread thread;

            @Override
            public void onGlobalLayout() {
                log("onGlobalLayout，加载itme:" + comicSeeSumBean.getCurrentShowPosition() + "加载完成");
                vBinding.rv.scrollToPosition(comicSeeSumBean.getCurrentShowPosition());
                //执行完按需求，移除监听，不然会多次回调，
                if (thread == null) {
                    thread = new Thread(() -> {
                        try {
                            Thread.sleep(3000);
                            vBinding.rv.getViewTreeObserver().removeOnGlobalLayoutListener(globalLayoutListener);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    });
                    thread.start();
                }

            }
        };
        vBinding.rv.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);

//        ((SimpleItemAnimator) vBinding.rv.getItemAnimator()).setSupportsChangeAnimations(false);//禁止动画
//        RecyclerView.ItemAnimator animator = vBinding.rv.getItemAnimator();
//        assert animator != null;
//        animator.setChangeDuration(0);
//        if (animator instanceof SimpleItemAnimator) {
//            ((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);//禁止动画
//        }
//        rv1.setHasFixedSize(true);//itme大小固定时，提到性能
//        rv1.setItemViewCacheSize(20);//
//        rv1.setPreserveFocusAfterLayout(true);//在布局变化后是否保持焦点
//        pageAdapter.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid

//        linearSnapHelper = new LinearSnapHelper();//用作横向滑动时，不保持偏移量，可多页滑动连续滑动
        linearSnapHelper = new PagerSnapHelper();//用作横向滑动时，不保持偏移量，只能一页一页滑动
        vBinding.rv.setLayoutManager(layoutManager);
        vBinding.rv.setAdapter(seeComicAdapter);

        log("rvItem初始化索引：" + comicSeeSumBean.getCurrentShowPosition());
        vBinding.rv.addOnScrollListener(new RecyclerView.OnScrollListener() {

            int position = 0;
            boolean isProgress = false;//是否RV滑动判断进行中
            int firstPosition; //第一个可见itme索引
            int lastPosition;//最后一个可见itme索引

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dx == 0 && dy == 0) {
                    return;
                }
                if (isProgress || recyclerView.getChildCount() <= 0 || layoutManager.findLastVisibleItemPosition() < 0) {
//                    LogUtil.d(TAG, "拦截1");
                    return;
                }
//                log("rv滑动变化:" + dx + ":" + dy);

                isProgress = true;
                RecyclerView.LayoutParams rl;
                try {
                    rl = (RecyclerView.LayoutParams) recyclerView.getChildAt(0).getLayoutParams();
                } catch (Exception e) {
                    isProgress = false;
                    return;
                }
                int p = rl.getAbsoluteAdapterPosition();

//                View xxx = layoutManager.findViewByPosition(p);

//                View xxx = layoutManager.findViewByPosition(layoutManager.findFirstVisibleItemPosition());
//                View view2 = layoutManager.findViewByPosition(layoutManager.findLastVisibleItemPosition());
//                float X = xxx.getX();
//                float Y = xxx.getY();
//                float Height = xxx.getHeight();
//
//                float RotationY = xxx.getRotationY();
//                float PivotY = xxx.getPivotY();
//                float ScaleY = xxx.getScaleY();
//                float TranslationY = xxx.getTranslationY();
//                log("Item：" + p + ";X=" + X + "；Y=" + Y + "；Height=" + Height + "；RotationY=" + RotationY + "；PivotY=" + PivotY + "；ScaleY=" + ScaleY + "；TranslationY=" + TranslationY);
//                float X1 = vBinding.rv.getX();
//                float Y1 = vBinding.rv.getY();
//                float Height1 = vBinding.rv.getHeight();
//                float RotationY1 = vBinding.rv.getRotationY();
//                float PivotY1 = vBinding.rv.getPivotY();
//                float ScaleY1 = vBinding.rv.getScaleY();
//                float TranslationY1 = vBinding.rv.getTranslationY();
//                log("RV;X=" + X1 + "；Y=" + Y1 + "；Height=" + Height1 + "；RotationY=" + RotationY1 + "；PivotY=" + PivotY1 + "；ScaleY=" + ScaleY1 + "；TranslationY=" + TranslationY1);
                //如果不是用户拖动的情况下才代码更新Progress
                if (!isFromUserClickSeekBar) {
                    //完整可见itme
                    List<Integer> list = RecyclerViewUtil.getVisibleItmePosition(vBinding.rv, layoutManager);
                    int position;
//                if (dy < 0) {
//                    //上翻页
                    if (list.size() == 0) {
                        //如果没有完全可见的，上翻页的时候就以最后一个可见为基准，这样翻页的时候就加载上一个未完整显示的
                        position = layoutManager.findFirstVisibleItemPosition();
                    } else {
                        if (list.get(list.size() - 1) == layoutManager.getItemCount() - 1) {
                            position = layoutManager.getItemCount() - 1;//索引
                        } else {
                            position = list.get(0);//索引
                        }

                    }
                    vBinding.sb.setProgress(position);
                    currentSeeBean = comicSeeSumBean.getSeeBeanList().get(position);
                    comicSeeSumBean.setCurrentShowPosition(position);
                }

//
//                } else if (dy > 0) {
//                    //下翻页
//                    if (list.size() == 0) {
//                        //如果没有完全可见的，下翻页的时候就以最后一个可见为基准，这样翻页的时候就加载下一个未完整显示的
//                        vBinding.sb.setProgress(layoutManager.findFirstVisibleItemPosition());
//                    } else {
//                        int index = list.get((list.size() - 1 <= 0) ? 0 : list.size() - 1);
//                        //更新上一页下一页进度条
//                        vBinding.sb.setProgress(index);//索引
//                    }
//                    //更新上一页下一页所需的位置
//                }


//                int p = rl.getViewLayoutPosition();
//                int fp = layoutManager.findFirstVisibleItemPosition();
//                LogUtil.d(TAG, "fp=" + fp + ";fp1=" + fp1 + ";fp2=" + fp2 + ";fp3=" + fp3 + ";fp4=" + fp4 + ";fp5=" + fp5 + ";fp6=" + fp6 + ";fp7=" + fp7 + ";p=" + p + ";p2=" + p2 + ";p3=" + p3);
                //优化——item没变化不做后续操作
                int fPosition = layoutManager.findFirstVisibleItemPosition();//第一个可见itme索引
                int lPosition = layoutManager.findLastVisibleItemPosition();//最后一个可见itme索引
                if (firstPosition == fPosition && lastPosition == lPosition) {
//                    log("Itme没有发生变化，首个可见Item：" + fPosition + ";最后可见Item：" + lPosition);
                    isProgress = false;
                    return;
                }
//                log("Itme变化，首个可见Item：" + fPosition + ";最后可见Item：" + lPosition);
                firstPosition = fPosition;
                lastPosition = lPosition;
                if (!comicSeeSumBean.getSeeBeanList().get(0).isWifi()) {
                    for (int i = firstPosition; i <= lastPosition; i++) {
                        ComicSeeBean bean = comicSeeSumBean.getSeeBeanList().get(i);
                        //更新已读状态：图片只要出现，就是已读100%
                        bean.setCurrentShowPosition(100);
//                    currentSeeBean.setCurrentShowPosition(RecyclerViewUtil.firstItemVisiblePercent(layoutManager, vBinding.rv, i));
                    }
                }
                SeeComicMode.setTitleTxt(vBinding, comicSeeSumBean.getSeeBeanList().get(p).getFileName(), false);
                isProgress = false;
            }

            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
//                if (newState == 0) {
//                    //屏幕已停止。屏幕停止滚动时为
////                    Glide.with(ComicActivity1.this).resumeRequests();
//                    log("rv滑动停止");
//                } else if (newState == 1) {
//                    //正在滚动。当屏幕滚动且用户使用的触碰或手指还在屏幕上时为
//                    log("rv滑动中");
//                } else if (newState == 2) {
//                    log("rv做抛动作");
//                    //手指做了抛的动作（手指离开屏幕前，用力滑了一下，屏幕产生惯性滑动）
////                    Glide.with(ComicActivity1.this).pauseRequests();
//                }
            }
        });
    }


    /**
     * RecyclerView 移动到当前位置，
     *
     * @param manager       设置RecyclerView对应的manager
     * @param mRecyclerView 当前的RecyclerView
     * @param n             要跳转的位置
     */
    public static void MoveToPosition(LinearLayoutManager manager, RecyclerView mRecyclerView,
                                      int n) {
        int firstItem = manager.findFirstVisibleItemPosition();
        int lastItem = manager.findLastVisibleItemPosition();
        if (n <= firstItem) {
            mRecyclerView.scrollToPosition(n);
        } else if (n <= lastItem) {
            int top = mRecyclerView.getChildAt(n - firstItem).getTop();
            mRecyclerView.scrollBy(0, top);
        } else {
            mRecyclerView.scrollToPosition(n);
        }
    }


    private void clickCentre() {
        if (isAuto) {
            return;
        }
        if (!isAnimationHave) {
            isAnimationHave = true;
            if (titleSwitch) {
                startPopsAnimTrans1(vBinding.ll1, -(vBinding.ll1.getHeight()));
                startPopsAnimTrans1(vBinding.llBottom, vBinding.llBottom.getHeight());
                if (vBinding.llSetting.getVisibility() == View.VISIBLE) {
//                    startPopsAnimTrans1(vBinding.llSetting, vBinding.llSetting.getHeight());
                    setSwitch(vBinding.llSetting, false);
                }
                if (vBinding.llSchedule.getVisibility() == View.VISIBLE) {
//                    startPopsAnimTrans1(vBinding.llSchedule, vBinding.llSchedule.getHeight());
                    setSwitch(vBinding.llSchedule, false);
                }
                titleSwitch = false;
            } else {
                startPopsAnimTrans1(vBinding.ll1, 0);
                startPopsAnimTrans1(vBinding.llBottom, 0);
                titleSwitch = true;
            }
            isAnimationHave = false;
        }
    }

    // 属性动画-纵向平移
    private void startPopsAnimTrans1(View view, float... xy) {
        ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(view, "translationY", xy);
        objectAnimatorX.setDuration(350);
        objectAnimatorX.start();
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                //音量键up
                if (comicSettingBean.isVolumeKeysPages()) {
                    int position = getJumpPostion(true);
                    jumpPage(comicSeeSumBean, position);
                }
                return false;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                //音量键down
                if (comicSettingBean.isVolumeKeysPages()) {
                    int position = getJumpPostion(false);
                    jumpPage(comicSeeSumBean, position);
                }
                return false;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (vBinding.llSetting.getVisibility() == View.VISIBLE) {
//            clickCentre();
            vBinding.llSetting.setVisibility(View.GONE);
            vBinding.llBottom.setVisibility(View.VISIBLE);
        } else if (titleSwitch) {
            clickCentre();
        } else {
            finish();
        }
    }



    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        //每次获取焦点的时候都更新一下状态栏状态，TODO 在这更新状态栏是因为当用户下拉列表时 状态栏会恢复默认状态，所以这里要重新走一遍更新状态栏逻辑
        if (hasFocus) {
            clickRaeShowState(comicSettingBean.isReadShowStatusBar());
        }

    }
}
