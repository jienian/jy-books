package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class LoginEmailReq(val email: String, val password: String): BaseReq()
