package com.juying.mjreader.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.FileUtils
import android.view.View
import com.blankj.utilcode.util.SPUtils
import com.juying.mjreader.BaseActivity
import com.juying.mjreader.databinding.ActivitySettingBinding
import com.juying.mjreader.fragment.JumpPermissionManagement
import com.juying.mjreader.manager.SpManager
import com.juying.mjreader.utils.DialogUtils
import com.juying.mjreader.utils.FilesUtils
import com.juying.mjreader.utils.LoginUtil
import com.juying.mjreader.utils.ScreenUtils
import com.juying.mjreader.utils.SpUtil
import java.io.File

class SettingActivity : BaseActivity(), View.OnClickListener {

    private var vBinding: ActivitySettingBinding? = null


    @SuppressLint("SdCardPath")
    override fun onCreate(saveInstanceState: Bundle?) {
        super.onCreate(saveInstanceState)
        vBinding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(vBinding?.root)
        if (LoginUtil.isLogin()) {
            vBinding!!.btLogout.visibility = View.VISIBLE
        } else {
            vBinding!!.btLogout.visibility = View.GONE
        }

        vBinding?.root?.setPadding(0, ScreenUtils.getStatusBarHeight(), 0, 0)

        // 返回键
        vBinding?.btnBack?.setOnClickListener { finish() }

        // 允许通知
        val notific = SPUtils.getInstance().getBoolean("notific", false)
        // vBinding.switchNotification.isChecked = notific
        /*
        vBinding.switchNotification.setOnCheckedChangeListener { buttonView, isChecked ->
            SPUtils.getInstance().put("notific", isChecked)
        }
        */

        // 允许震动
        /*
        val vibrate = SPUtils.getInstance().getBoolean("vibrate", false)
        vBinding.switchVibrate.isChecked = vibrate
        vBinding.switchVibrate.setOnCheckedChangeListener { buttonView, isChecked ->
            SPUtils.getInstance().put("vibrate", isChecked)
        }
        */

        // 清除缓存

        vBinding!!.stvClearCache.setOnClickListener {
            DialogUtils.delDialog(
                this,
                "清除缓存",
                "您确定清除缓存"
            ) { isOk ->
                if (isOk) {
                    val file = File("/data/data/$packageName/app_webview")
                    FilesUtils.delFiles(file);
                    to("清理完毕",false)
                }
            }
        }


        // 应用权限
        vBinding?.stvPrivacy?.setOnClickListener { JumpPermissionManagement.GoToSetting(this) }

        // 退出登录
        vBinding?.btLogout?.setOnClickListener {
//             dialog.show(supportFragmentManager, "退出登录")
            DialogUtils.delDialog(
                this,
                "退出登录",
                "您确定退出登录吗？",
                DialogUtils.OkDialogListener {
                    if (it) {
                        val file = SpUtil.fileNameToSpFile(this, SpManager.SP_NAME)
                        FilesUtils.delFiles(file)
                        LoginUtil.userEmpty()
                        finish()
                    }
                })
        }
    }


    override fun onClick(v: View?) {
        TODO("Not yet implemented")
    }

    companion object {
        @JvmStatic
        fun Companion(Context: Context) {
            val starter = Intent(Context, SettingActivity::class.java)
            Context.startActivity(starter)
        }
    }
}
