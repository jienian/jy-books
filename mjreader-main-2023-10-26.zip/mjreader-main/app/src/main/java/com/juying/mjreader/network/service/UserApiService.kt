package com.juying.mjreader.network.service

import com.juying.mjreader.network.UserApi
import com.juying.mjreader.network.models.ChangeUserinfoReq
import com.juying.mjreader.network.models.CheckEmailReq
import com.juying.mjreader.network.models.CheckPhoneReq
import com.juying.mjreader.network.models.CheckUsernameRes
import com.juying.mjreader.network.models.LoginByUuidReq
import com.juying.mjreader.network.models.LoginEmailReq
import com.juying.mjreader.network.models.LoginPhoneReq
import com.juying.mjreader.network.models.RegisterAccountReq
import com.juying.mjreader.network.models.Res
import com.juying.mjreader.network.models.UserInfo
import com.juying.mjreader.network.util.ServiceApiUtil.createRetrofit
import com.juying.mjreader.network.util.ServiceApiUtil.query
import okhttp3.MultipartBody
import retrofit2.await
/**
 * @author Nimyears
 */
object UserApiService {
    const val BASE_URL = "http://43.248.116.140:20351"



    private val service by lazy {
        createRetrofit("$BASE_URL/").create(UserApi::class.java)
    }


    suspend fun loginByUuid(sex: Int): Res<UserInfo>? = query {
        val req = LoginByUuidReq(sex)
        service.loginByUuid(req).await()
    }

    suspend fun getInfo(): Res<UserInfo>? = query {
        service.getInfo().await()
    }

    suspend fun changeUserinfo(nickname: String, avatarUrl: String, sex: Int): Res<Any>? = query(true) {
        val req = ChangeUserinfoReq(nickname, avatarUrl, sex)
        service.changeUserinfo(req).await()
    }

    suspend fun registerAccount(email: String, phone: String, password: String, sex: Int): Res<UserInfo>? = query(true) {
        val req = RegisterAccountReq(email, phone, password, sex)
        service.registerAccount(req).await()
    }

    suspend fun checkPhone(phone: String): Res<CheckUsernameRes>? = query(true) {
        val req = CheckPhoneReq(phone)
        service.checkPhone(req).await()
    }

    suspend fun checkEmail(email: String): Res<CheckUsernameRes>? = query(true) {
        val req = CheckEmailReq(email)
        service.checkEmail(req).await()
    }

    suspend fun loginEmail(email: String, password: String): Res<UserInfo>? = query(true) {
        val req = LoginEmailReq(email, password)
        service.loginEmail(req).await()
    }

    suspend fun loginPhone(phone: String, password: String): Res<UserInfo>? = query(true) {
        val req = LoginPhoneReq(phone, password)
        service.loginPhone(req).await()
    }
}