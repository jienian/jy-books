package com.juying.mjreader.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.juying.mjreader.databinding.FragmentSectionBinding;

import java.util.List;

/**
 * @Author Nimyears
 *
 */
public class NoteFragment extends BaseFragment{
    private FragmentSectionBinding binding;



}
