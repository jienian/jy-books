package com.juying.mjreader.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.juying.mjreader.utils.LogUtil;

/**
 * 支持上下左右中的点击监听View
 *
 * @Author Ycc
 * @Date 17:38
 */
public class ListeningView extends FrameLayout {

    RecyclerViewClickListener recyclerViewClickListener;
    int width;
    int height;
    public ListeningView(@NonNull Context context) {
        super(context);
        width = getWidth();
        height = getHeight();
    }

    public ListeningView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        width = getWidth();
        height = getHeight();
    }

    public ListeningView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        width = getWidth();
        height = getHeight();
    }

    public ListeningView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    float downX;
    float downY;

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        float x = e.getX();
        float y = e.getY();
//        LogUtil.d("TAG", "onInterceptTouchEvent执行:" + e.getAction() + ";坐标：" + x + ":" + y);

        if (e.getAction() == MotionEvent.ACTION_UP) {
            //松手时触发，【注意：如果是按下-移动-再松手；这个UP就不会触发，符合本次使用场景】
//            LogUtil.d("TAG", "ACTION_UP");
            if ((x < downX + 10 && x > downX - 10) && (y < downY + 10 && y > downY - 10)) {
                handlerEvent(e);
            }
        } else if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
        }
//        else if (e.getAction() == MotionEvent.ACTION_MOVE ) {
//            //按下后移动触发
//            LogUtil.d("TAG", "ACTION_MOVE");
//        }

        return super.onInterceptTouchEvent(e);
        //true就是拦截  false  就是不拦截，拦截的意思是事件不会继续往下分发，如果当前View，处理这个点击事件,则事件到此终止，如果不处理这次事件，则事件会继续往上传递，不会往下分发了
//        return false;
    }


    //
    private void handlerEvent(MotionEvent e) {
        if (recyclerViewClickListener == null) {
            return;
        }
        float x = e.getX();
        float y = e.getY();
        width = getWidth();
        height = getHeight();

//        int oneX = width / 2;
//        int h = height / 7;
//        int oneY = h * 3;
//        int oneY1 = h * 4;
//        LogUtil.i("TAG", "x:" + x + ";Y:" + y + ";X1:" + x1 + ";Y1:" + y1 + ";X2:" + x2 + ";Y2:" + y2 + ";width=" + width + ";height:" + height);

//        if (y < oneY && x < oneX) {
//            recyclerViewClickListener.click(this, 1);
//            LogUtil.d("TAG", "点击Rv上左");//左上
//        } else if (y < oneY && x > oneX) {
//            recyclerViewClickListener.click(this, 2);
//            LogUtil.d("TAG", "点击Rv上右");
//        } else if (y > oneY1 && x < oneX) {
//            recyclerViewClickListener.click(this, 3);
//            LogUtil.d("TAG", "点击Rv下左");
//        } else if (y > oneY1 && x > oneX) {
//            recyclerViewClickListener.click(this, 4);
//            LogUtil.d("TAG", "点击Rv下右");
//        } else {
//            recyclerViewClickListener.click(this, 5);
//            LogUtil.d("TAG", "点击Rv中间");
//        }



        if (y < height/12*2 && x < width/7*2) {
            recyclerViewClickListener.click(this, 1);
            LogUtil.d("TAG", "点击Rv上左");//左上
        } else if (y < height/12*2 && x > width/7*5) {
            recyclerViewClickListener.click(this, 2);
            LogUtil.d("TAG", "点击Rv上右");
        } else if (y > height/12*10 && x < width/7*2) {
            recyclerViewClickListener.click(this, 3);
            LogUtil.d("TAG", "点击Rv下左");
        } else if (y > height/12*10 && x > width/7*5) {
            recyclerViewClickListener.click(this, 4);
            LogUtil.d("TAG", "点击Rv下右");
        } else if (y > height/12*5 && y < height/12*7){
            recyclerViewClickListener.click(this, 5);
            LogUtil.d("TAG", "点击Rv中间");
        }else  {
            recyclerViewClickListener.click(this, 6);
            LogUtil.d("TAG", "点击其他空白处");
        }
    }


    public void setRecyclerViewClickListener(RecyclerViewClickListener listener) {
        this.recyclerViewClickListener = listener;
    }

    public interface RecyclerViewClickListener {
        void click(View v, int direction);
    }


}
