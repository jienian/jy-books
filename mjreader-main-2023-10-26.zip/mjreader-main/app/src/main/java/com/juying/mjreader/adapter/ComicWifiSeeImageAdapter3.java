package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.ImageViewTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeImageActivity;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.databinding.ItemWifiSeeIamge3Binding;
import com.juying.mjreader.databinding.ItmeMoveGroupingBinding;
import com.juying.mjreader.databinding.ItmeWifiHistBinding;

import java.util.ArrayList;


public class ComicWifiSeeImageAdapter3 extends BaseAdapter<ComicWifiSeeImageAdapter3.ViewHolder> {
    private final ComicSeeSumBean comicSeeSumBean;
    private final SeeImageActivity context;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;

    public ComicWifiSeeImageAdapter3(SeeImageActivity context, ComicSeeSumBean comicSeeSumBean) {

        this.context = context;
        this.comicSeeSumBean = comicSeeSumBean;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        @NonNull ItemWifiSeeIamge3Binding vBinding = ItemWifiSeeIamge3Binding.inflate(LayoutInflater.from(parent.getContext()), null, false);
        return new ViewHolder(vBinding);
    }


    @Override
    public void onBindViewHolder(@NonNull ComicWifiSeeImageAdapter3.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(position);
        holder.vBinding.cb.setChecked(comicSeeBean.isEditSelect());
        setImage(holder, comicSeeBean);
        holder.vBinding.getRoot().getRootView().setTag(position);
    }

    private void setImage(ComicWifiSeeImageAdapter3.ViewHolder viewHolder, ComicSeeBean comicSeeBean) {
        Glide.with(context)
//                .asDrawable()//比bitmap要省
//                    .load(bean.isWifiData()?comicSeeBean.getImges():comicSeeBean.getUrl())
                .load(comicSeeBean.getUrl())
//                    .override(comicSeeBean.getWidth(), comicSeeBean.getHeight())
                .override(500, 500)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
//                        log("网络访问失败，请检查是否开始网络或者增加http的访问许可");
                        viewHolder.vBinding.tvError.setText("网络异常");
                        viewHolder.vBinding.cb.setEnabled(false);
                        comicSeeBean.setImageLoadFail(true);
                        loadType(2, viewHolder.vBinding.pb, viewHolder.vBinding.tvError, viewHolder.vBinding.tvError, viewHolder
                                .vBinding.fl);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
//                        log("网络访问成功，可以显示图片");
                        return false;
                    }
                })
                .into(new ImageViewTarget<Drawable>(viewHolder.vBinding.iv) {
                    //图片开始加载
                    @Override
                    public void onLoadStarted(Drawable placeholder) {
                        super.onLoadStarted(placeholder);
//                        log("图片开始加载");
                        loadType(1, viewHolder.vBinding.pb, viewHolder.vBinding.tvError, viewHolder.vBinding.tvError, viewHolder
                                .vBinding.fl);
                    }

                    @Override
                    public void onLoadFailed(Drawable errorDrawable) {
                        super.onLoadFailed(errorDrawable);
//                        log("图片加载失败");
                        viewHolder.vBinding.tvError.setText("资源损坏");
                        comicSeeBean.setImageLoadFail(true);
                        viewHolder.vBinding.cb.setEnabled(false);
                        loadType(3, viewHolder.vBinding.pb, viewHolder.vBinding.tvError, viewHolder.vBinding.tvError, viewHolder
                                .vBinding.fl);
                    }

                    //图片加载完成
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, Transition<? super Drawable> transition) {
                        super.onResourceReady(resource, transition);
//                        log("图片加载完成");
                        // 图片加载完成
                        viewHolder.vBinding.iv.setImageDrawable(resource);
                        loadType(4, viewHolder.vBinding.pb, viewHolder.vBinding.tvError, viewHolder.vBinding.tvError, viewHolder
                                .vBinding.fl);
                        comicSeeBean.setImageLoadFail(false);
                        viewHolder.vBinding.cb.setEnabled(true);
                    }

                    @Override
                    protected void setResource(Drawable resource) {
//                        log("设置资源");
                    }
                });
    }


    @Override
    public int getItemCount() {

//        return getShowSize(bookBean);
        return comicSeeSumBean == null || comicSeeSumBean.getSeeBeanList() == null ? 0 : comicSeeSumBean.getSeeBeanList().size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private final ItemWifiSeeIamge3Binding vBinding;

        public ViewHolder(@NonNull ItemWifiSeeIamge3Binding vBinding) {
            super(vBinding.getRoot());
            this.vBinding = vBinding;
            vBinding.getRoot().setOnClickListener(v -> setCb(vBinding, false));
            vBinding.cb.setOnClickListener(v -> setCb(vBinding, true));
        }
    }

    private void setCb(ItemWifiSeeIamge3Binding vBinding, boolean isCbClick) {
        int position = (int) vBinding.getRoot().getTag();
        ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(position);
        if (comicSeeBean.isImageLoadFail()) {
            return;
        }
        if (!isCbClick) {
            vBinding.cb.setChecked(!vBinding.cb.isChecked());
        }
        comicSeeBean.setEditSelect(vBinding.cb.isChecked());
        context.upTvNum();
    }
}
