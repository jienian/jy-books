package com.juying.mjreader.adapter.novel;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeNovelActivity;
import com.juying.mjreader.adapter.BaseAdapter;
import com.juying.mjreader.bean.BookBean;

import java.util.ArrayList;

/**
 * 用于管理和显示书籍的章节或标志信息
 *
 */
public class NovelFlagAdapter extends BaseAdapter<NovelFlagAdapter.ViewHolder> {
    private SeeNovelActivity context;

    private BookBean bookBean;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;

    public NovelFlagAdapter(SeeNovelActivity context,BookBean bookBean){
        this.bookBean = bookBean;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_comic_page, null);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itme_flag, null, false);
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position){
        if(bookBean == null ) return;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            
        }
    }
}
