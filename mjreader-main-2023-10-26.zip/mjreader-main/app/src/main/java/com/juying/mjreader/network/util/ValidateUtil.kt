package com.juying.mjreader.network.util
/**
 * @author Nimyears
 */
object ValidateUtil {
    @JvmStatic
    fun isEmail(email: String): Boolean {
        val emailRegex = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
        return emailRegex.matches(email)
    }
    @JvmStatic
    fun isPhoneNumber(phoneNumber: String): Boolean {
        val phoneRegex = Regex("^1[3456789]\\d{9}$")
        return phoneRegex.matches(phoneNumber)
    }
}