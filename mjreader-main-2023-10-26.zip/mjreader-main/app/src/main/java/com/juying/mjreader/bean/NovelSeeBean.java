package com.juying.mjreader.bean;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.utils.ComicMode;
import com.juying.mjreader.utils.NovelMode;

public class NovelSeeBean  implements Parcelable {

    /**
     * 可能是网络http:  也可能是本地File
     */
    private String url;
    /**
     * 名称
     */
    private String fileName;
    /**
     * 文件类型
     */
    private String fileType;
    /**
     * 是否是当前显示Bean
     */
    private boolean isCurrentShow;
    /**
     * 当前显示位置百分比%【如果是PDF,这里就是标签页位置，如果是其他媒体类型这里就是单文件长图的偏移量，记得存SP】
     */
    private int currentShowPosition;
    /**
     * 当前显示页数【只有在PDF时有用】索引
     */
    private int currentShowIndex;




    public NovelSeeBean(Parcel in) {
    }
    public NovelSeeBean(String url, String fileName, String fileType, boolean isCurrentShow, int currentShowPosition, boolean isWifi) {
        this.url = url;
        this.fileName = fileName;
        this.fileType = fileType;
        this.isCurrentShow = isCurrentShow;
        this.currentShowPosition = currentShowPosition;
        initSP();
    }
    public static final Creator<NovelSeeBean> CREATOR = new Creator<NovelSeeBean>() {
        @Override
        public NovelSeeBean createFromParcel(Parcel in) {
            return new NovelSeeBean(in);
        }

        @Override
        public NovelSeeBean[] newArray(int size) {
            return new NovelSeeBean[size];
        }
    };

    public NovelSeeBean(String filePath) {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel( Parcel dest, int flags) {
        dest.writeInt(this.currentShowPosition);
    }
    SharedPreferences sp;

    private void initSP() {
        if (sp == null) {
            sp = MjApplication.CONTEXT.getSharedPreferences(NovelMode.filePathToSpName(url, false), Context.MODE_PRIVATE);
        }
        currentShowPosition = (sp.getInt("readPosition", 0));
        currentShowIndex = (sp.getInt("readIndex", 0));
    }

    public void setCurrentShowPosition(int currentShowPosition) {
        this.currentShowPosition = currentShowPosition;
        upSP();
    }

    SharedPreferences.Editor editor;
    public void upSP() {
        if (editor == null) {
            editor = MjApplication.CONTEXT.getSharedPreferences(NovelMode.filePathToSpName(url, false), Context.MODE_PRIVATE).edit();
        }
        editor.putInt("readPosition", currentShowPosition);
        editor.putInt("readIndex", currentShowIndex);
        editor.apply();
    }


}
