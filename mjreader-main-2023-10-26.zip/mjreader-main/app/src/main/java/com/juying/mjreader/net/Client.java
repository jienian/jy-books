package com.juying.mjreader.net;


import android.annotation.SuppressLint;

import com.google.gson.Gson;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.manager.UserManager;
import com.juying.mjreader.net.bean.RequestSubmitUserDataBean;
import com.juying.mjreader.network.converter.DecryptionConverterFactory;

import retrofit2.Retrofit;

/**
 * Created by ycc
 * on 2019/4/8
 */
public class Client {


    private static NetApi api;

    public static NetApi getNetApi() {
        if (api == null) {
            api = Client.getRetrofit(
                            MjApplication.isDebug ? NetApi.BASE_URL_DEBUG : NetApi.BASE_URL_FORMAL)
                    .create(NetApi.class);
        }
        return api;
    }


    @SuppressLint("DefaultLocale")
    private static Retrofit getRetrofit(String host) {
//        OkHttpClient.Builder builder = new OkHttpClient.Builder();
//        builder.readTimeout(10, TimeUnit.SECONDS);
//        builder.addInterceptor(new LoggingInterceptor());
//        builder.connectTimeout(9, TimeUnit.SECONDS);
        //拦截器，拦截响应头和log
//        builder.addInterceptor(new MyInterceptor());


        //创建retrofit对象
        return new Retrofit.Builder()
                //使用自定义的mGsonConverterFactory
//                .addConverterFactory()
                .baseUrl(host)
//                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(DecryptionConverterFactory.Companion.create())//解密配置
//                .client(builder.build())//打印日志
                .build();
    }


    public static RequestSubmitUserDataBean getRsBean(String type,String dataId,Object contentObject){
        RequestSubmitUserDataBean b = new RequestSubmitUserDataBean(type
                , UserManager.INSTANCE.createDataId(type, dataId)
                ,new Gson().toJson(contentObject), UserManager.INSTANCE.createTopUserId());
        return b;
    }




}
