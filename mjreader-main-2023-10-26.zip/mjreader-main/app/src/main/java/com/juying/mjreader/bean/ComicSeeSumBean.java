package com.juying.mjreader.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

/**
 * 漫画观看页根Bean
 *
 * @Author Ycc
 * @Date 10:32
 */
public class ComicSeeSumBean implements Parcelable {


    /**
     * 当前显示位置，【初始化的时候有用】索引
     */
    private int currentShowPosition;


    /**
     * 是否PDF显示模式
     */
    private boolean isPDFMode;

    private List<ComicSeeBean> seeBeanList;

    public ComicSeeSumBean(int currentShowPosition, boolean isPDFMode, List<ComicSeeBean> seeBeanList) {
        this.currentShowPosition = currentShowPosition;
        this.isPDFMode = isPDFMode;
        this.seeBeanList = seeBeanList;
    }

    public boolean isPDFMode() {
        return isPDFMode;
    }

    public void setPDFMode(boolean PDFMode) {
        isPDFMode = PDFMode;
    }

    public List<ComicSeeBean> getSeeBeanList() {
        return seeBeanList;
    }

    public void setSeeBeanList(List<ComicSeeBean> seeBeanList) {
        this.seeBeanList = seeBeanList;
    }

    public int getCurrentShowPosition() {
        return currentShowPosition;
    }

    public void setCurrentShowPosition(int currentShowPosition) {
        this.currentShowPosition = currentShowPosition;
    }


    @Override
    public String toString() {
        return "ComicSeeSumBean{" +
                "currentShowPosition=" + currentShowPosition +
                ", isPDFMode=" + isPDFMode +
                ", seeBeanList=" + seeBeanList +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.currentShowPosition);
        dest.writeByte(this.isPDFMode ? (byte) 1 : (byte) 0);
        dest.writeTypedList(this.seeBeanList);
    }

    public void readFromParcel(Parcel source) {
        this.currentShowPosition = source.readInt();
        this.isPDFMode = source.readByte() != 0;
        this.seeBeanList = source.createTypedArrayList(ComicSeeBean.CREATOR);
    }

    protected ComicSeeSumBean(Parcel in) {
        this.currentShowPosition = in.readInt();
        this.isPDFMode = in.readByte() != 0;
        this.seeBeanList = in.createTypedArrayList(ComicSeeBean.CREATOR);
    }

    public static final Parcelable.Creator<ComicSeeSumBean> CREATOR = new Parcelable.Creator<ComicSeeSumBean>() {
        @Override
        public ComicSeeSumBean createFromParcel(Parcel source) {
            return new ComicSeeSumBean(source);
        }

        @Override
        public ComicSeeSumBean[] newArray(int size) {
            return new ComicSeeSumBean[size];
        }
    };


    /**
     * 取消所有编辑选中
     */
    public boolean cancelAllSelect() {
        boolean isExistSelect = false;
        if (seeBeanList != null && seeBeanList.size() > 0) {
            for (int i = 0; i < seeBeanList.size(); i++) {
                ComicSeeBean comicSeeBean = seeBeanList.get(i);
                if (comicSeeBean.isEditSelect()) {
                    comicSeeBean.setEditSelect(false);
                    isExistSelect = true;
                }

            }
        }
        return isExistSelect;
    }

    /**
     * 选中所有未失败
     */
    public int startAllSelect() {
        int selectNum=0;
        if (seeBeanList != null && seeBeanList.size() > 0) {
            for (ComicSeeBean comicSeeBean : seeBeanList) {
                if (!comicSeeBean.isImageLoadFail()) {
                    comicSeeBean.setEditSelect(true);
                    selectNum++;
                }
            }
        }
        return selectNum;
    }

    /**
     * 当前没有失败并选中的Bean
     */
    public List<ComicSeeBean> getSelectListBean() {
        List<ComicSeeBean> list=new ArrayList<>();
        if (seeBeanList != null && seeBeanList.size() > 0) {
            for (ComicSeeBean comicSeeBean : seeBeanList) {
                if (comicSeeBean.isEditSelect() && !comicSeeBean.isImageLoadFail()) {
                    list.add(comicSeeBean);
                }
            }
        }
        return list;
    }


    /**
     * 当前所有加载失败的Bean
     */
    public List<ComicSeeBean> getNoLoadedOK() {
        List<ComicSeeBean> list=new ArrayList<>();
        if (seeBeanList != null && seeBeanList.size() > 0) {
            for (ComicSeeBean comicSeeBean : seeBeanList) {
                if (comicSeeBean.isImageLoadFail()) {
                    list.add(comicSeeBean);
                }
            }
        }
        return list;
    }


    /**
     * 获得当前浏览Bean
     */
    public ComicSeeBean getCurrentShowBean() {

        return seeBeanList.get(currentShowPosition);
    }
}
