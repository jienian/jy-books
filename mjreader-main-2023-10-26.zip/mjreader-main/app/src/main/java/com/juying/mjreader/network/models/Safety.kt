package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class Safety(val type: String, val token: ArrayList<String>)
