package com.juying.mjreader.utils

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import com.juying.mjreader.extemsions.getPackageInfoCompat
import com.juying.mjreader.network.converter.DecryptionConverterFactory
import com.juying.mjreader.network.interceptor.LoggingInterceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.security.MessageDigest
/**
 * @author Nimyears
 */

object AppUtil {
    fun createRetrofit(baseUrl: String): Retrofit {
        val builder = OkHttpClient.Builder()
        builder.addInterceptor(LoggingInterceptor())
        val okHttpClient = builder.build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(DecryptionConverterFactory.create())
            .build()
    }

    private var appName: String? = null
    fun getAppName(context: Context): String {
        if (appName != null) return appName!!
        val packageInfo = getPackageInfo(context, 0)
        val labelRes = packageInfo.applicationInfo.labelRes
        return context.resources.getString(labelRes)
    }

    private var versionName: String? = null
    fun getVersionName(context: Context): String {
        if (versionName != null) return versionName!!
        val packageInfo = getPackageInfo(context, 0)
        return packageInfo.versionName
    }

    private var versionCode: Int? = null
    fun getVersionCode(context: Context): Int {
        if (versionCode != null) return versionCode!!
        val packageInfo = getPackageInfo(context, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode.toInt()
        } else {
            @Suppress("DEPRECATION") packageInfo.versionCode
        }
    }

    private var packageName: String? = null
    fun getPackageName(context: Context): String {
        if (packageName != null) return packageName!!
        val packageInfo = getPackageInfo(context, 0)
        return packageInfo.packageName
    }

    // 获取应用的包签名
    fun getSignature(context: Context): String {
        try {
            val packageName = context.packageName
            val packageManager = context.packageManager
            val signatures: Array<Signature?>? =
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                    val packageInfo = getPackageInfo(context, PackageManager.GET_SIGNING_CERTIFICATES)
                    val signingInfo = packageInfo.signingInfo
                    signingInfo.apkContentsSigners
                } else {
                    val packageInfo: PackageInfo =
                        packageManager.getPackageInfoCompat(packageName, 0)
                    @Suppress("DEPRECATION") packageInfo.signatures
                }

            // 获取第一个签名信息
            val signature = signatures!![0]!!.toByteArray()

            // 计算签名的 SHA-1 值
            val md = MessageDigest.getInstance("SHA-1")
            val sha1Fingerprint = md.digest(signature)

            val hexFingerprint = StringBuilder()
            for (byte in sha1Fingerprint) {
                hexFingerprint.append(String.format("%02x", byte))
            }

            return hexFingerprint.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }

    private fun getPackageInfo(context: Context, flags: Int): PackageInfo {
        val packageManager = context.packageManager
        return packageManager.getPackageInfoCompat(
            context.packageName, flags
        )
    }
}