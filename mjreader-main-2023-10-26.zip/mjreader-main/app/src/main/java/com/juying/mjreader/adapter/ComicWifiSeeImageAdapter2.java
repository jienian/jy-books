package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.ImageViewTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.card.MaterialCardView;
import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeImageActivity;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;

import java.util.ArrayList;


public class ComicWifiSeeImageAdapter2 extends BaseAdapter<ComicWifiSeeImageAdapter2.ViewHolder> {
    private final ComicSeeSumBean comicSeeSumBean;
    private SeeImageActivity context;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;

    public ComicWifiSeeImageAdapter2(SeeImageActivity context, ComicSeeSumBean comicSeeSumBean) {
        this.context = context;
        this.comicSeeSumBean = comicSeeSumBean;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_comic_page, null);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wifi_see_iamge2, parent, false);
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(position);
        setImage(holder, comicSeeBean);
        if (comicSeeSumBean.getCurrentShowPosition() == position) {
            holder.itemView.setStrokeColor(context.getResources().getColor(R.color.spFFFE605F, null));
        } else {
//            holder.mcv.setStrokeWidth(3);
            holder.itemView.setStrokeColor(context.getResources().getColor(R.color.sp00000000, null));
        }

        holder.itemView.setTag(position);


    }

    private void setImage(ViewHolder viewHolder, ComicSeeBean comicSeeBean) {
        Glide.with(context)
//                .asDrawable()//比bitmap要省
//                    .load(bean.isWifiData()?comicSeeBean.getImges():comicSeeBean.getUrl())
                .load(comicSeeBean.getUrl())
//                    .override(comicSeeBean.getWidth(), comicSeeBean.getHeight())
                .override(500, 500)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
//                        log("网络访问失败，请检查是否开始网络或者增加http的访问许可");
                        viewHolder.tvEror.setText("网络异常");
                        comicSeeBean.setImageLoadFail(true);
                        loadType(2, viewHolder.pb, viewHolder.tvEror, viewHolder.tvEror, viewHolder.mcv);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
//                        log("网络访问成功，可以显示图片");
                        return false;
                    }
                })
                .into(new ImageViewTarget<Drawable>(viewHolder.iv) {
                    //图片开始加载
                    @Override
                    public void onLoadStarted(Drawable placeholder) {
                        super.onLoadStarted(placeholder);
//                        log("图片开始加载");
                        loadType(1, viewHolder.pb, viewHolder.tvEror, viewHolder.tvEror, viewHolder.mcv);
                    }

                    @Override
                    public void onLoadFailed(Drawable errorDrawable) {
                        super.onLoadFailed(errorDrawable);
//                        log("图片加载失败");
                        viewHolder.tvEror.setText("资源损坏");
                        comicSeeBean.setImageLoadFail(true);
                        loadType(3, viewHolder.pb, viewHolder.tvEror, viewHolder.tvEror, viewHolder.mcv);

                    }

                    //图片加载完成
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, Transition<? super Drawable> transition) {
                        super.onResourceReady(resource, transition);
//                        log("图片加载完成");
                        // 图片加载完成
                        viewHolder.iv.setImageDrawable(resource);
                        loadType(4, viewHolder.pb, viewHolder.tvEror, viewHolder.tvEror, viewHolder.mcv);
                        comicSeeBean.setImageLoadFail(false);
                    }

                    @Override
                    protected void setResource(Drawable resource) {
//                        log("设置资源");
                    }
                });
    }




    @Override
    public int getItemCount() {
//        return getShowSize(bookBean);
        return comicSeeSumBean == null || comicSeeSumBean.getSeeBeanList() == null ? 0 : comicSeeSumBean.getSeeBeanList().size();
    }


    private int getShowSize(BookBean bookBean) {
        if (bookBean == null || bookBean.getBookBeanList() == null || bookBean.getBookBeanList().size() == 0 || bookBean.getTreeNodeData() == null) {
            return 0;
        }
        showPosition = new ArrayList<>();
        for (int i = 0; i < bookBean.getBookBeanList().size(); i++) {
            BookBean bean = bookBean.getBookBeanList().get(i);
            if (bean.getMaxSize() > bean.getImputSchedule() || bean.isDirectory() || bean.getFileType().contains("pdf")) {
                //如果是未导入完成、目录、pdf就不在Rv里显示
            } else {
                showPosition.add(i);
            }
        }
        return showPosition.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private final MaterialCardView mcv;
        private final CheckBox cb;
        private final ImageView iv;
        private final TextView tvEror;
        private final ProgressBar pb;
        private final MaterialCardView itemView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mcv = itemView.findViewById(R.id.mcv);
            cb = itemView.findViewById(R.id.cb);
            iv = itemView.findViewById(R.id.iv);
            tvEror = itemView.findViewById(R.id.tv_eror);
            pb = itemView.findViewById(R.id.pb);
            this.itemView = (MaterialCardView) itemView;

            itemView.setOnClickListener(v -> {
                int position = (int) v.getTag();
//                if (comicSeeSumBean.getSeeBeanList().get(position).isImageLoadFail()) {
//                    log("加载异常，不可点击");
//                    return;
//                }
                comicSeeSumBean.setCurrentShowPosition(position);
                context.upRv1(position);
                context.upTitle(position);
                notifyDataSetChanged();
            });
        }
    }



}
