package com.juying.mjreader.widget

import android.content.Context
import android.util.AttributeSet
/**
 * @author Nimyears
 */
class YaButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet, defStyleAttr: Int = 0
) : androidx.appcompat.widget.AppCompatButton(context, attrs, defStyleAttr) {

    init {
        gravity = android.view.Gravity.CENTER
    }

    /*字体自定义*/
/*    @Override
    override fun setTypeface(tf: Typeface?, style: Int) {
        if (style == Typeface.BOLD) {
         //   super.setTypeface(FontManager.yab, style)
        } else {
      //      super.setTypeface(FontManager.yam, style)
        }
    }*/
}