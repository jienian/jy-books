package com.juying.mjreader.activity;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.R;
import com.juying.mjreader.adapter.novel.ViewPageAdaper;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.databinding.ActivityNovelDetailBinding;
import com.juying.mjreader.fragment.NoteFragment;
import com.juying.mjreader.fragment.SectionFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Nimyears
 *
 * section:目录
 * note:笔记
 * tvAll:全部
 * tvBookmark:书签
 * tvTag:标红
 */


public class NovelDetailActivity extends BaseActivity implements View.OnClickListener {
    private ActivityNovelDetailBinding vBinding;
    private List<Fragment> fragmentList;
    private List<String> titles;
    private BookBean book;
    private BookBean novelBean;
    @Override
    protected void onCreate(@Nullable Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        vBinding = ActivityNovelDetailBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        book = getIntent().getParcelableExtra("book");
        initView();
        initListener();

    }

    /*初始化组件*/
    private void initView() {
        fragmentList = new ArrayList<>();
        SectionFragment sectionFragment = new SectionFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("sections1", (ArrayList<? extends Parcelable>) book.getSections1());
        bundle.putParcelable("uri" , book.getUri());
        sectionFragment.setArguments(bundle);

        NoteFragment noteFragment = new NoteFragment();
        Bundle bundle1 = new Bundle();
        bundle1.putParcelableArrayList("notes", (ArrayList<? extends Parcelable>) book.getNotes());
        noteFragment.setArguments(bundle1);

        fragmentList.add(sectionFragment);
        fragmentList.add(noteFragment);
        titles = new ArrayList<>();
        titles.add("目录");
        titles.add("笔记");

        ViewPageAdaper pageAdaper = new ViewPageAdaper(getSupportFragmentManager(), fragmentList,titles);
        vBinding.viewPager.setAdapter(pageAdaper);
        vBinding.tabLayout.setupWithViewPager(vBinding.viewPager);
        vBinding.tvAll.setSelected(true);

        vBinding.tvAll.setText(book.getFileName());
        vBinding.bookBriefTvAuthor.setText(String.format(getString(R.string.all_section), book.getSections1().size()));
        String fileName = novelBean.getFileName();
        vBinding.tvTitle.setText(fileName.split("\\.")[0].replace("《", "").replace("》", ""));
    }

    @SuppressLint("ClickA")  //忽略警告
    public void initListener(){
        vBinding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            /*被查看的页面发生改变时被调用*/
            @Override
            public void onPageSelected(int position) {
                if(position == 1){
                    vBinding.llNote.setVisibility(View.VISIBLE);
                }else {
                    vBinding.llNote.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        vBinding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if(position == 1) {
                    vBinding.llNote.setVisibility(View.VISIBLE);
                }else {
                    vBinding.llNote.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        vBinding.tvAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vBinding.tvAll.isSelected()) return;
                vBinding.tvAll.setSelected(true);
                vBinding.tvBookmark.setSelected(false);
                vBinding.tvTag.setSelected(false);
            }
        });
        vBinding.tvBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vBinding.tvBookmark.isSelected()) return;
                vBinding.tvBookmark.setSelected(true);
                vBinding.tvAll.setSelected(false);
                vBinding.tvTag.setSelected(false);
            }
        });
        vBinding.tvTag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (vBinding.tvTag.isSelected()) return;
                vBinding.tvTag.setSelected(true);
                vBinding.tvAll.setSelected(false);
                vBinding.tvBookmark.setSelected(false);

            }
        });
    }

    /*属性动画纵向平移*/
    private void startPopsAnimTrans1(View view, float... xy){
        ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(view, "translationY", xy);
        objectAnimatorX.setDuration(350);
        objectAnimatorX.start();
    }

    @Override
    public void onClick(View v) {

    }
}
