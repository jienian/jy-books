package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class LoginByUuidReq(val sex: Int): BaseReq()
