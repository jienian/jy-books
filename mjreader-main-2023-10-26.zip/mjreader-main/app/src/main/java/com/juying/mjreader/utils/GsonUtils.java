package com.juying.mjreader.utils;

import android.net.Uri;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

public final class GsonUtils {

    private static final class Holder {
        private static final Gson mInstance = new GsonBuilder()
                .registerTypeAdapter(Uri.class, new UriAdapter())
                .create();
    }

    public static Gson getInstance() {
        return Holder.mInstance;
    }

    private static final class UriAdapter extends TypeAdapter<Uri> {
        @Override
        public void write(JsonWriter out, Uri uri) throws IOException {
            out.value(uri == null ? "" : uri.toString());
        }

        @Override
        public Uri read(JsonReader in) throws IOException {
            return Uri.parse(in == null ? "" : in.nextString());
        }
    }
}