package com.juying.mjreader.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @Author Ycc
 * @Date 17:00
 */
public class AutoRecyclerView extends RecyclerView {

    private static final int delayTime = 10;
    //自动滚动速度，默认15 标准
    int speed = 15;
    private boolean running = false; //标示是否正在自动轮询
    private boolean canRun = true;//标示是否可以自动轮询,可在不需要的是否置false
    private RvListener rvListener;

    public AutoRecyclerView(@NonNull Context context) {
        super(context);
    }

    public AutoRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public AutoRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    private final Runnable mTask = new Runnable() {
        @Override
        public void run() {
            if (running && canRun) {
//                if (canScrollVertically(-1)) {
//                    //如果到底了，就自动停止,并通知外层
//                    stopPlay();
//                    if (rvListener != null) {
//                        rvListener.moveBottomComplete();
//                    }
//                } else {
                    scrollBy(0, speed);
                    postDelayed(mTask, delayTime);
//                }

            }
        }
    };

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopPlay();
    }

    public void stopPlay() {
        running = false;
        removeCallbacks(mTask);
    }

    public void startPlay() {
        canRun = true;
        running = true;
        removeCallbacks(mTask);
        // 这里没调用Handler，view里面自带postDelayed
        postDelayed(mTask, delayTime);
    }

//    @Override
//    public boolean onTouchEvent(MotionEvent e) {
//        return false;
//    }



    /**
     * 设置速度
     * @param type 1=慢 2=较慢 3=标准 4=较快 5=快
     */
    public void setSpeed(int type) {
        if (type == 1) {
            speed = 5;
        } else if (type == 2) {
            speed = 10;
        } else if (type == 3) {
            speed = 15;
        } else if (type == 4) {
            speed = 20;
        } else if (type == 5) {
            speed = 25;
        }
    }

    public void setRvListener(RvListener rvListener) {
        this.rvListener = rvListener;
    }

    private interface RvListener {
        //移动到底了
        void moveBottomComplete();
    }
}