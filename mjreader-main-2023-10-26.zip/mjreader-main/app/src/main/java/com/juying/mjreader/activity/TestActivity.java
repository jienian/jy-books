package com.juying.mjreader.activity;

import static java.security.AccessController.getContext;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.R;
import com.juying.mjreader.databinding.ActivitySeeComicBinding;
import com.juying.mjreader.databinding.ActivityTestBinding;
import com.juying.mjreader.utils.LogUtil;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class TestActivity extends BaseActivity implements EasyPermissions.PermissionCallbacks {

    private ActivityTestBinding vBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivityTestBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        initListenr();
        File file = new File("/data/user/0/com.juying.mjreader/files/bookshelf/ss01.pdf");
//        vBinding.pdfView.fromAsset("sss.pdf")
        vBinding.pdfView.fromFile(file)
//                        .password(null)
//                        .defaultPage(0)
//                        .enableSwipe(true)
//                        .swipeHorizontal(false)
//                        .enableDoubletap(true)
//                        .onPageChange(new OnPageChangeListener() {
//                            @Override
//                            public void onPageChanged(int page, int pageCount) {
//                                // 页面切换时的回调函数
//                                Log.d("TAG", "onPageChanged: 执行=page="+page+";pageCount="+pageCount);
//                            }
//                        })
//                .enableAnnotationRendering(false)
//                .onLoad(new OnLoadCompleteListener() {
//                    @Override
//                    public void loadComplete(int nbPages) {
//                        Log.d("TAG", "loadComplete: 执行=nbPages="+nbPages);
//                    }
//                })
//                .scrollHandle(null)
                .load();

    }

    private void permission() {
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(this, perms)) {
            // 已获取权限
            // ...
            Toast.makeText(this, "已获取权限", Toast.LENGTH_SHORT).show();
        } else {
            // 没有权限，现在去获取
            // ...
            Toast.makeText(this, " 没有权限，现在去获取", Toast.LENGTH_SHORT).show();

            EasyPermissions.requestPermissions(this, "申请内存权限",
                    1, perms);
        }
    }

    private void initListenr() {
        vBinding.bt10.setOnClickListener(v -> {
            openFile();
        });
        vBinding.bt11.setOnClickListener(v -> {

            permission();
        });
    }

    public void openFileSelector() {

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
//        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
//筛选文件(这里是读取音频目录)
//        intent.setType("*/*");
        intent.setType("application/pdf");
//调用系统文件选择器
        startActivityForResult(intent, 2);
    }
    private void openFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");

        // Optionally, specify a URI for the file that should appear in the
        // system file picker when it loads.
//        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri);

        startActivityForResult(intent, 2);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // 将返回结果转给EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }
    public static final String EXTRA_RESULT_SELECTION_PATH = "extra_result_selection_path";



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 2) {
            //获取Uri
            Uri uri = data.getData();
            //根据Uri查询文件名
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                cursor.moveToFirst();
                //文件名
                String fileName = cursor.getString(nameIndex);
                String size = cursor.getString(sizeIndex);
                cursor.close();

                String s3 = uri.getPath();
                String s5 = Uri.decode(uri.getEncodedPath());
//                String s4 = Uri2Path(this, uri);

                LogUtil.d(TAG, "是否存在2=" + new File(s3).exists() + "是否存在3=" + new File(s5).exists());
                vBinding.tv.setText(fileName);

                s3 = fileName.substring(fileName.length() - 4);
                if (".pdf".equals(s3)) {
                    try {
                        Bitmap btm = getBitmapFromUri(uri);
                        vBinding.iv.setImageBitmap(btm);

//
//                        ParcelFileDescriptor mFileDescriptor = ParcelFileDescriptor.open(new File(fileName), ParcelFileDescriptor.MODE_READ_ONLY);
//                        PdfRenderer mPdfRenderer = new PdfRenderer(mFileDescriptor);
//                        PdfRenderer.Page mCurrentPage = mPdfRenderer.openPage(0);
//                        //Bitmap必须是ARGB，不可以是RGB
//                        Bitmap bitmap = Bitmap.createBitmap(mCurrentPage.getWidth(), mCurrentPage.getHeight(),
//                                Bitmap.Config.ARGB_8888);
//                        /*
//                         * 调用PdfRender.Page的render方法渲染bitmap
//                         *
//                         * render的参数说明：
//                         * destination : 要渲染的bitmap对象
//                         * destClip ：传一个矩形过去 矩形的尺寸不能大于bitmap的尺寸 最后渲染的pdf会是rect的大小 可为null
//                         * transform : 一个Matrix bitmap根据该Matrix图像进行转换
//                         * renderMode ：渲染模式 可选2种 RENDER_MODE_FOR_DISPLAY 和 RENDER_MODE_FOR_PRINT
//                         */
//                        mCurrentPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
//                        vBinding.iv.setImageBitmap(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else {
                    Glide.with(this)
//                            .asDrawable()//比bitmap要省
                            .load(uri)
//                        .override(pBean.getWidth(), pBean.getHeight())
                            .into(vBinding.iv);


                }


            }
        }


    }
    private Bitmap getBitmapFromUri(Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptor =
                getContentResolver().openFileDescriptor(uri, "r");
        FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
        Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);
        parcelFileDescriptor.close();
        return image;
    }

    public Bitmap getBitmapFromUri1(Uri uri) throws IOException {
        // 通过 ContentResolver 获取输入流
        InputStream input = getContentResolver().openInputStream(uri);
        // 对输入流进行解码获取 Bitmap 对象
        Bitmap bitmap = BitmapFactory.decodeStream(input);
        // 关闭输入流
        input.close();
        // 返回 Bitmap 对象
        return bitmap;
    }


    public String Uri2Path(Context context, Uri uri) {
        if (uri == null) {
            return null;
        }

        String filePath = null;
        if (ContentResolver.SCHEME_FILE.equals(uri.getScheme())) {
             filePath=uri.getPath();
        } else if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            String authority = uri.getAuthority();

            if (authority.startsWith("com.android.externalstorage")) {
                filePath =Environment.getExternalStorageDirectory() + "/" + uri.getPath().split(":")[1];
            } else {
                String idStr = "";
                if (authority.equals("media")) {
                    idStr = uri.toString().substring(uri.toString().lastIndexOf('/') + 1);
                } else if (authority.startsWith("com.android.providers")) {
                    idStr = DocumentsContract.getDocumentId(uri).split(":")[1];
                }

                ContentResolver contentResolver = context.getContentResolver();
                Cursor cursor = contentResolver.query(MediaStore.Files.getContentUri("external"),
                        new String[]{MediaStore.Files.FileColumns.DATA},
                        "_id=?",
                        new String[]{idStr}, null);
                if (cursor != null) {
                    cursor.moveToFirst();
                    try {
                        int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);
                        filePath = cursor.getString(idx);
                    } catch (Exception e) {
                        throw e;
                    } finally {
                        cursor.close();
                    }
                }


//                if (TextUtils.isEmpty(filePath)) {
//                    filePath = getFilePathForNonMediaUri(context, uri);
//                }
            }
        }
        return filePath;
    }


    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        // 一些权限被授予
        Toast.makeText(this, "允许", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        // 一些权限被禁止
        Toast.makeText(this, "禁止", Toast.LENGTH_SHORT).show();
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            //点了拒绝且不再提醒
            new AppSettingsDialog.Builder(this).build().show();
            //弹出个对话框 可以自定义
        }
    }


    public static String getRealPathFromUri(Context context, Uri uri) {
        String filePath = "";
        String scheme = uri.getScheme();
        if (scheme == null) {
            filePath = uri.getPath();
        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            filePath = uri.getPath();
        } else if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            String[] proj = {MediaStore.Images.Media.DATA};
            String[] proj1 = {MediaStore.Files.FileColumns.DATA};
            String[] proj2 = {MediaStore.Downloads.DATA};
            String[] proj3 = {MediaStore.Video.Media.DATA};
            String[] proj4 = {MediaStore.Audio.Media.DATA};
            String[] proj5 = {MediaStore.DownloadColumns.DATA};
            Cursor cursor = context.getContentResolver().query(uri, proj5, null, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
//                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
//                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
//                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATA);
//                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.DownloadColumns.DATA);
                    filePath = cursor.getString(columnIndex);
                }
                cursor.close();
            }
            if (TextUtils.isEmpty(filePath)) {
                filePath = getFilePathForNonMediaUri(context, uri);
            }
        }
        return filePath;
    }

    //非媒体文件中查找
    private static String getFilePathForNonMediaUri(Context context, Uri uri) {
        String filePath = "";
        Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow("_data");
                filePath = cursor.getString(columnIndex);
            }
            cursor.close();
        }
        return filePath;
    }
    public String getAbsolutePathFromUri(Context context, Uri uri) {
        String absolutePath = null;
        String scheme = uri.getScheme();

        if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            ContentResolver contentResolver = context.getContentResolver();
            try {
                InputStream inputStream = contentResolver.openInputStream(uri);
                if (inputStream != null) {
                    File file = new File(context.getCacheDir(), "temp");
                    FileOutputStream outputStream = new FileOutputStream(file);
                    byte[] buffer = new byte[4 * 1024];
                    int read;
                    while ((read = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, read);
                    }
                    absolutePath = file.getAbsolutePath();
                    outputStream.flush();
                    outputStream.close();
                    inputStream.close();
                    file.delete();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            absolutePath = uri.getPath();
        }

        return absolutePath;
    }

}