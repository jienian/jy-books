package com.juying.mjreader.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;

import com.juying.mjreader.databinding.DialogBookInputBinding;

/**
 * @Author Ycc
 * @Date 15:46
 */
public class InputView extends FrameLayout {

    DialogBookInputBinding vBinding;

    public InputView(Context context) {
        super(context);
        initView(context);
    }

    public InputView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public InputView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public InputView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }


   private void initView(Context context){
       vBinding = DialogBookInputBinding.inflate(LayoutInflater.from(context));
       addView(vBinding.getRoot());
    }


}
