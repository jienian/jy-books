package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.TreeNodeData;
import com.juying.mjreader.view.DialogFlagDirectory;

import java.util.ArrayList;
import java.util.List;


public class ComicFlagDirectoryAdapter extends BaseAdapter<ComicFlagDirectoryAdapter.ViewHolder> {
    private final DialogFlagDirectory.DialogFlagDirectoryListener listener;
    private  int currentPage;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;
    private List<TreeNodeData> treeNodeDataList;

    public ComicFlagDirectoryAdapter(DialogFlagDirectory.DialogFlagDirectoryListener listener, int currentPage, List<TreeNodeData> treeNodeDataList) {
        this.listener = listener;
        this.treeNodeDataList = treeNodeDataList;
        this.currentPage = currentPage;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_comic_page, null);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itme_flag_directory, null, false);
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    //上次选中位置
    int lastInProgressShowPosition;

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        TreeNodeData treeNodeData = treeNodeDataList.get(position);
        if (currentPage==position) {
            holder.ll.setVisibility(View.VISIBLE);
            holder.tvNoSelect.setVisibility(View.GONE);
            holder.tvSelect.setText("正在阅读：" + treeNodeData.getName());
        } else {
            holder.ll.setVisibility(View.GONE);
            holder.tvNoSelect.setVisibility(View.VISIBLE);
            holder.tvNoSelect.setText(treeNodeData.getName());
        }
        holder.itemview.setTag(position);
//        BookBean bean = bookBean.getBookBeanList().get(showPosition.get(position));
//        ComicSeeBean comicSeeBean = bean.getComicSeeBean();

    }


    @Override
    public long getItemId(int position) {
//        return cpBean.getUsePageBeanList().get(position).getId();
        return super.getItemId(position);
//        return position;
    }

    @Override
    public int getItemCount() {
//        return getShowSize(bookBean);
        return treeNodeDataList == null ? 0 : treeNodeDataList.size();
    }


    private int getShowSize(BookBean bookBean) {
        if (bookBean == null || bookBean.getBookBeanList() == null || bookBean.getBookBeanList().size() == 0 || bookBean.getTreeNodeData() == null) {
            return 0;
        }
        showPosition = new ArrayList<>();
        for (int i = 0; i < bookBean.getBookBeanList().size(); i++) {
            BookBean bean = bookBean.getBookBeanList().get(i);
            if (bean.getMaxSize() > bean.getImputSchedule() || bean.isDirectory() || bean.getFileType().contains("pdf")) {
                //如果是未导入完成、目录、pdf就不在Rv里显示
            } else {
                showPosition.add(i);
            }
        }
        return showPosition.size();
    }

    public void upUi(int currentPage) {
        this.currentPage=currentPage;
        notifyDataSetChanged();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private final LinearLayout ll;
        private final View itemview;

        private final TextView tvSelect;
        private final TextView tvNoSelect;

        @SuppressLint("NotifyDataSetChanged")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemview = itemView;
            tvNoSelect = itemView.findViewById(R.id.tv_no_select);
            tvSelect = itemView.findViewById(R.id.tv_select);
            ll = itemView.findViewById(R.id.ll_select);
            itemView.setOnClickListener(v -> {

                int clickPosition = (int) v.getTag();
//                context.clickRV();
                log("目录itme点击item:" + v.getTag());
//                treeNodeDataList.get(currentPage).setInProgressShow(false);
//                treeNodeDataList.get(clickPosition).setInProgressShow(true);
                currentPage=clickPosition;
//                notifyItemChanged(lastInProgressShowPosition);
                notifyDataSetChanged();
                listener.onClickPosition(clickPosition);
            });
        }
    }


    private void viewShow(int type) {
        if (type == 1) {
//            viewHolder.iv.setVisibility(View.VISIBLE);
//            viewHolder.bt.setVisibility(View.GONE);
        } else if (type == 2) {
//            viewHolder.iv.setVisibility(View.GONE);
//            viewHolder.bt.setVisibility(View.VISIBLE);
        }
    }

}
