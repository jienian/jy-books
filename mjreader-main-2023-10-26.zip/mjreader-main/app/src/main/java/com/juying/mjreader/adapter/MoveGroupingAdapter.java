package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.databinding.ItmeMoveGroupingBinding;
import com.juying.mjreader.fragment.ComicFragment;
import com.juying.mjreader.utils.ComicMode;
import com.juying.mjreader.utils.config.Abstract;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.view.DialogGrouping;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class MoveGroupingAdapter extends RecyclerView.Adapter<MoveGroupingAdapter.ViewHolder> {

    private final DialogGrouping.DialogGroupingListener listener;
    private ComicFragment comicFragment;
    private BookBean sumBean;

    //    public MoveGroupingAdapter(Context context, ComicBean comicBean, DialogGrouping.DialogGroupingListener listener) {
//        this.context = context;
//        this.comicBean = comicBean;
//        this.listener=listener;
//    }
    public MoveGroupingAdapter(ComicFragment comicFragment, BookBean sumBean, DialogGrouping.DialogGroupingListener listener) {
        this.comicFragment = comicFragment;
        this.sumBean = sumBean;
        this.listener = listener;
    }



    @NonNull
    @Override
    public MoveGroupingAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        @NonNull ItmeMoveGroupingBinding vBinding = ItmeMoveGroupingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(vBinding);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MoveGroupingAdapter.ViewHolder viewHolder, int position) {
//        BookBean bookBean = comicBean.getComicBookBean().getBookBeanList().get(position);
        BookBean bookBean = bookBeanList.get(position);
        if (bookBean != null) {
            if (bookBean.isDirectory()) {
                if (bookBean.getFileName().equals(Constant.ROOT_NAME)) {
                    viewHolder.vBinding.rl.setVisibility(View.GONE);
                    viewHolder.vBinding.ivExit.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.tv1.setText("从分组移出至漫架");
                    viewHolder.vBinding.tv2.setVisibility(View.GONE);
                } else {
                    viewHolder.vBinding.rl.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.ivExit.setVisibility(View.GONE);

                    viewHolder.vBinding.tv1.setText(bookBean.getFileName());
                    viewHolder.vBinding.tv2.setVisibility(View.VISIBLE);
                    if (bookBean.getBookBeanList() != null) {
                        viewHolder.vBinding.tv2.setText("共" + bookBean.getBookBeanList().size() + "本");
                    } else {
                        viewHolder.vBinding.tv2.setText("共0本");
                    }
                    upIV(viewHolder, bookBean);
                }
                viewHolder.vBinding.getRoot().setTag(bookBean);

            }
        }
    }


    private void upIV(ViewHolder viewHolder, BookBean bookBean) {
        List<BookBean> child = bookBean.getBookBeanList();
        if (child == null || child.size() == 0) {
            viewHolder.vBinding.rl.setVisibility(View.GONE);
        } else {
            viewHolder.vBinding.rl.setVisibility(View.VISIBLE);
            for (int i = 0; i < child.size(); i++) {
                if (i == 0) {
                    setImage(viewHolder.vBinding.iv2, bookBean);
                    viewHolder.vBinding.iv2.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv3.setVisibility(View.INVISIBLE);
                    viewHolder.vBinding.iv4.setVisibility(View.INVISIBLE);
                    viewHolder.vBinding.iv5.setVisibility(View.INVISIBLE);
                } else if (i == 1) {
                    setImage(viewHolder.vBinding.iv3, bookBean);
                    viewHolder.vBinding.iv2.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv3.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv4.setVisibility(View.INVISIBLE);
                    viewHolder.vBinding.iv5.setVisibility(View.INVISIBLE);
                } else if (i == 2) {
                    setImage(viewHolder.vBinding.iv4, bookBean);
                    viewHolder.vBinding.iv2.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv3.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv4.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv5.setVisibility(View.INVISIBLE);
                } else if (i == 3) {
                    setImage(viewHolder.vBinding.iv5, bookBean);
                    viewHolder.vBinding.iv2.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv3.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv4.setVisibility(View.VISIBLE);
                    viewHolder.vBinding.iv5.setVisibility(View.VISIBLE);
                } else {
                    break;
                }
            }
        }
    }


    private void setImage(ImageView iv, BookBean bean) {
        iv.setImageResource(Abstract.getFileCover(bean.getFileType()));
    }

    @Override
    public int getItemCount() {
        if (sumBean == null || sumBean.getBookBeanList() == null) {
            return 0;
        }
        return getSize();
    }

    List<BookBean> bookBeanList;

    private int getSize() {
        int size = 0;
        bookBeanList = new ArrayList<>();
        for (int i = 0; i < sumBean.getBookBeanList().size(); i++) {
            BookBean bookBean = sumBean.getBookBeanList().get(i);
            if (bookBean.isDirectory()) {
                size++;
                bookBean.setDirectoryPosition(i);
                bookBeanList.add(bookBean);
            }
        }
        return size;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final ItmeMoveGroupingBinding vBinding;

        public ViewHolder(ItmeMoveGroupingBinding vBinding) {
            super(vBinding.getRoot());

            this.vBinding = vBinding;

            vBinding.getRoot().setOnClickListener(v -> {
                BookBean bookBean = (BookBean) vBinding.getRoot().getTag();
                //移动至分组，先改内存，再改文件，后更新UI,
//                List<BookBean> listBean = sumBean.getBookBeanList();
                BookBean currentShowBean = comicFragment.getCurrentShowBean();
                List<BookBean> listBean = currentShowBean.getBookBeanList();


                boolean isSelectFile = false;
                for (int i = 0; i < listBean.size(); i++) {
                    BookBean bean = listBean.get(i);
                    if (bean.isChecked()) {
                        isSelectFile = true;
                        if (bean.isDirectory() && bean.getFileName().equals(bookBean.getFileName())) {
                            //移动的目录就是自己目录，不操作
//                            Toast.makeText(context, "不支持移动到自身", Toast.LENGTH_SHORT).show();
                        } else {
                            Log.d("Adapter", "ViewHolder:把：" + bean.getFilePath() + "移动到：" + bookBean.getFilePath() + "目录里");
                            if (bean.isDirectory()) {
                                if (bean.getBookBeanList().size() == 0) {
                                    //空目录不移动
                                    comicFragment.to("空目录不支持移动", false);
                                } else {
                                    while (bean.getBookBeanList().size() > 0) {
                                        BookBean childBean = bean.getBookBeanList().get(0);
                                        //物理加减
                                        ComicMode.moveSPandFile(comicFragment.getContext(), childBean, bookBean);
                                        //内存加减
//                                        bookBean.getBookBeanList().add(childBean);
//                                        bookBean.setMaxSize(bookBean.getMaxSize() + childBean.getMaxSize());
//                                        bookBean.setImputSchedule(bookBean.getImputSchedule() + childBean.getImputSchedule());
                                        bean.getBookBeanList().remove(childBean);
                                    }


                                    //改新父sp的MaxSize，这里暂时不用存，maxSize 不变
//                                    ComicMode.saveSP(context.getContext(), bookBean);

                                    listBean.remove(bean);
                                    //删除一个之后要记得移动下标,不然位置就错乱了
                                    i--;
                                    //删除目录文件
                                    new File(bean.getFilePath()).delete();
                                    //删除目录sp
                                    new File(bean.getSpFilePath()).delete();


                                }
                            } else {
                                //物理加减
                                ComicMode.moveSPandFile(comicFragment.getContext(), bean, bookBean);

                                currentShowBean.setMaxSize(currentShowBean.getMaxSize() - bean.getMaxSize());
                                //内存加减
                                listBean.remove(bean);
                                //删除一个之后要记得移动下标,不然位置就错乱了
                                i--;
                                //改新父sp的MaxSize，这里暂时不用存，maxSize 不变
                                if (bookBean.getFileName().equals(Constant.ROOT_NAME)) {
                                    ComicMode.saveSP(comicFragment.getContext(), currentShowBean);
                                } else {
                                    ComicMode.saveSP(comicFragment.getContext(), bookBean);
                                }

                            }
                        }
                    }
                }


                if (!isSelectFile) {
                    comicFragment.to("未选择文件", false);
                } else {
                    //最后在统一更新UI
                    listener.onClickGroupingOK();
                }
            });
        }
    }


}
