package com.juying.mjreader.model;

import com.juying.mjreader.data.entities.Novel;

public class NovelExtensions {

/*    public static boolean isImage(Novel novel) {
        return novel.isType(NovelType.image);
    }

    public static boolean isLocal(Novel novel) {
        if (novel.getType() == 0) {
            return NovelType.localTag.equals(novel.getOrigin()) || novel.getOrigin().startsWith(NovelType.webDavTag);
        }
        return novel.isType(NovelType.local);
    }
    public static boolean isLocalTxt(Novel novel) {
        return novel.isLocal() && novel.getOriginName().toLowerCase().endsWith(".txt");
    }

    public static boolean isEpub(Novel novel) {
        return novel.isLocal() && novel.getOriginName().toLowerCase().endsWith(".epub");
    }


    public static boolean isPdf(Novel novel) {
        return novel.isLocal() && novel.getOriginName().toLowerCase().endsWith(".pdf");
    }

    public static boolean isOnLineTxt(Novel novel) {
        return !novel.isLocal() && novel.isType(NovelType.text);
    }*/
}
