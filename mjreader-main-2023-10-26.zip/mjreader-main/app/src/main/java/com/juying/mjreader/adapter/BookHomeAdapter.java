package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.activity.FileDrowseActivity;
import com.juying.mjreader.databinding.ItmeBookHomeSBinding;

import java.util.List;


public class BookHomeAdapter extends RecyclerView.Adapter<BookHomeAdapter.ViewHolder> {


    private Context context;
    //    private ComicBean comicBean;
    private List<InsideBean> beanList;

    private int itmeType = 0;

    public BookHomeAdapter(Context context, List<InsideBean> beanList) {
        this.context = context;
        this.beanList = beanList;
    }


    @NonNull
    @Override
    public BookHomeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        @NonNull ItmeBookHomeSBinding vBinding = ItmeBookHomeSBinding.inflate(LayoutInflater.from(parent.getContext()), null, false);
        return new ViewHolder(vBinding);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull BookHomeAdapter.ViewHolder viewHolder, int position) {
        InsideBean bean = beanList.get(position);
        viewHolder.vBinding.tv1.setText(bean.title);
        viewHolder.vBinding.iv1.setImageResource(bean.resID);
    }


    @Override
    public int getItemCount() {
        return beanList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ItmeBookHomeSBinding vBinding;

        public ViewHolder(@NonNull ItmeBookHomeSBinding vBinding) {
            super(vBinding.getRoot());
            this.vBinding = vBinding;
            vBinding.getRoot().setOnClickListener(v -> {
                context.startActivity(new Intent(context, FileDrowseActivity.class));

            });
        }
    }


    public static class InsideBean {
        String title;
        int resID;

        public InsideBean(String title, int resID) {
            this.title = title;
            this.resID = resID;
        }

    }
}
