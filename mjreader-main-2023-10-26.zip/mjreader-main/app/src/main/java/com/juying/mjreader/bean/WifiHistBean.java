package com.juying.mjreader.bean;

/**
 * @Author Ycc
 * @Date 11:15
 */
public class WifiHistBean implements Cloneable{


    //id[SQL的行，自增不唯一]
    private String id;
    //数据id，唯一键]
    private String dataId;

    //用户id
    private String userID;
    //浏览时间戳
    private long saveTime;
    //使用浏览器
    private String browserName;
    //标题
    private String title;
    //url
    private String url;
    //封面图url
    private String imageUrl;
    //是否编辑状态
    private boolean isEditState;
    //是否编辑并选中状态
    private boolean isEditSelectState;
    //是否收藏
    private boolean isCollection;
    //是否历史
    private boolean isHist;
    //保存日期【没有存SQL，后面解析的】
    private String saveDate;



    //是否有更新【上传远程依据:目前有地方变化：创建时-true、更改观看时间时-true、增添取消收藏/删除时[是否收藏和是否历史变化时]-true、上传远程-fase】
    private boolean isUpdatePresent=true;


    public String getDataId() {
        return dataId;
    }

    public void setDataId(String dataId) {
        this.dataId = dataId;
    }

    public WifiHistBean(String dataId,String userID, long saveTime, String browserName, String title, String url, String imageUrl, boolean isCollection, boolean isHist) {
        this.userID = userID;
        this.saveTime = saveTime;
        this.browserName = browserName;
        this.title = title;
        this.url = url;
        this.imageUrl = imageUrl;
        this.isCollection = isCollection;
        this.isHist=isHist;
        this.dataId=dataId;
    }

    public boolean isUpdatePresent() {
        return isUpdatePresent;
    }

    public void setUpdatePresent(boolean updatePresent) {
        isUpdatePresent = updatePresent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSaveDate() {
        return saveDate;
    }

    public void setSaveDate(String saveDate) {
        this.saveDate = saveDate;
    }

    public boolean isHist() {
        return isHist;
    }

    public void setHist(boolean hist) {
        isHist = hist;
    }

    public WifiHistBean() {
    }

    public boolean isCollection() {
        return isCollection;
    }

    public void setCollection(boolean collection) {
        isCollection = collection;
    }


    public String getBrowserName() {
        return browserName;
    }

    public void setBrowserName(String browserName) {
        this.browserName = browserName;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public long getSaveTime() {
        return saveTime;
    }

    public void setSaveTime(long saveTime) {
        this.saveTime = saveTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public boolean isEditState() {
        return isEditState;
    }

    public void setEditState(boolean editState) {
        isEditState = editState;
    }

    public boolean isEditSelectState() {
        return isEditSelectState;
    }

    public void setEditSelectState(boolean editSelectState) {
        isEditSelectState = editSelectState;
    }

    @Override
    public String toString() {
        return "WifiHistBean{" +
                "userID='" + userID + '\'' +
                ", saveTime=" + saveTime +
                ", browserName='" + browserName + '\'' +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", isEditState=" + isEditState +
                ", isEditSelectState=" + isEditSelectState +
                ", isCollection=" + isCollection +
                ", isHist=" + isHist +
                ", saveDate='" + saveDate + '\'' +
                '}';
    }

    @Override
    public WifiHistBean clone() {
        try {
            return (WifiHistBean) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return new WifiHistBean(dataId,userID,saveTime,browserName,title,url,imageUrl,isCollection,isHist);
        }
    }
}
