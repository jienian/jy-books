package com.juying.mjreader.net.bean;

/**
 * 软件更新接口返回Bean
 * @Author Ycc
 * @Date 17:11
 */
public class RetAppUpBean extends RetBaseBean {


    /**
     * appKey : com.juying.mjreader
     * channel : normal
     * upgradeType : 1
     * latestVersionName : v1.0.2
     * latestVersionCode : 15
     * upgradeTip : 有新版本了，兄弟们，冲
     * linkUrl : https://f-res.gz.bcebos.com/apk/QQ.apk
     * linkType : 1
     * updateTime : 1695718698886
     */

    private String appKey;
    private String channel;
    private int upgradeType;
    private String latestVersionName;
    private int latestVersionCode;
    private String upgradeTip;
    private String linkUrl;
    private int linkType;
    private long updateTime;

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public int getUpgradeType() {
        return upgradeType;
    }

    public void setUpgradeType(int upgradeType) {
        this.upgradeType = upgradeType;
    }

    public String getLatestVersionName() {
        return latestVersionName;
    }

    public void setLatestVersionName(String latestVersionName) {
        this.latestVersionName = latestVersionName;
    }

    public int getLatestVersionCode() {
        return latestVersionCode;
    }

    public void setLatestVersionCode(int latestVersionCode) {
        this.latestVersionCode = latestVersionCode;
    }

    public String getUpgradeTip() {
        return upgradeTip;
    }

    public void setUpgradeTip(String upgradeTip) {
        this.upgradeTip = upgradeTip;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public int getLinkType() {
        return linkType;
    }

    public void setLinkType(int linkType) {
        this.linkType = linkType;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "RetAppUpBean{" +
                "appKey='" + appKey + '\'' +
                ", channel='" + channel + '\'' +
                ", upgradeType=" + upgradeType +
                ", latestVersionName='" + latestVersionName + '\'' +
                ", latestVersionCode=" + latestVersionCode +
                ", upgradeTip='" + upgradeTip + '\'' +
                ", linkUrl='" + linkUrl + '\'' +
                ", linkType=" + linkType +
                ", updateTime=" + updateTime +
                '}';
    }
}
