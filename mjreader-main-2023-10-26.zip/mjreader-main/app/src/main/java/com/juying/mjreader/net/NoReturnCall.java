package com.juying.mjreader.net;

import com.juying.mjreader.utils.LogUtil;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * 不需要返回值的Call
 *
 * @Author Ycc
 * @Date 19:28
 */
public class NoReturnCall implements Callback<ResponseBody> {
    @Override
    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
        LogUtil.d("NoReturnCall", "访问成功状态：" + response.code());
        if (response.code() == 200) {
            if (response.body() != null) {
                try {
                    LogUtil.d("NoReturnCall", "访问成功值：" + response.body().string());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }
        }
    }

    @Override
    public void onFailure(Call<ResponseBody> call, Throwable t) {
        LogUtil.d("NoReturnCall", "访问失败：" + t.getMessage());
    }
}
