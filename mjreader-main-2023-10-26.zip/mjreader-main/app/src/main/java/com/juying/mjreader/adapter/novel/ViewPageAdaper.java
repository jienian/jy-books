package com.juying.mjreader.adapter.novel;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.List;

/**
 * @Author Nimyears
 * 存储每个页面的标题 mTitles
 * 存储显示的 fragmentList
 * 对象的总数 getCount
 * 每个页面提供的标签 getPageTitle
 */



public class ViewPageAdaper extends FragmentPagerAdapter {

    private final List<String> mTitles;
    private List<Fragment> fragmentList;
    public ViewPageAdaper(@NonNull FragmentManager fm, List<Fragment> fragments, List<String> titles) {
        super(fm);
        this.mTitles = titles;
        this.fragmentList = fragments;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }

    public CharSequence getPageTitle(int position){
        return mTitles.get(position);
    }
}
