package com.juying.mjreader.net;


import com.juying.mjreader.net.bean.DataBean;
import com.juying.mjreader.net.bean.ReqRemoveDataBean;
import com.juying.mjreader.net.bean.RequestSubmitUserDataBean;
import com.juying.mjreader.net.bean.RequestUserDataBean;
import com.juying.mjreader.net.bean.RetAppUpBean;
import com.juying.mjreader.net.bean.RetBaseBean;
import com.juying.mjreader.network.models.BaseReq;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * @Author Ycc
 * @Date 11:00
 */
public interface NetApi {

    //目前都一样
    String BASE_URL_FORMAL = "http://43.248.116.140:20351";
    String BASE_URL_DEBUG = "http://43.248.116.140:20351";

    /**
     * 拉取用户数据
     */
    @POST("/api/user/data/sync/get")
    Call<RetBaseBean<List<DataBean>>> getUserData(@Body RequestUserDataBean body);
    /**
     * 提交用户数据
     */
//    @FormUrlEncoded
    @POST("/api/user/data/sync/submit")
    Call<ResponseBody> submitUserData(@Body RequestSubmitUserDataBean body);

    /**
     * 删除用户数据
     */
//    @FormUrlEncoded
    @POST("/api/user/data/sync/remove")
    Call<ResponseBody> delUserData(@Body ReqRemoveDataBean body);

    /**
     * 软件更新
     */
    @POST("/api/config/upgrades")
    Call<RetBaseBean<RetAppUpBean>> appUpdate(@Body BaseReq baseReq);

}
