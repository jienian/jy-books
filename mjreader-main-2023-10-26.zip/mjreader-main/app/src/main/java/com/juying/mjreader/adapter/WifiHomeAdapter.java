package com.juying.mjreader.adapter;

import android.content.Context;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.databinding.ItmeWifiHomeBinding;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * @Author Ycc
 * @Date 16:06
 */
public class WifiHomeAdapter extends BaseAdapter<WifiHomeAdapter.ViewHolder> {


    private final Context context;
    private  List<WifiHomeAdapter.InsideBean> beanList;
    private ItmeWifiHomeBinding vBinding;

    public WifiHomeAdapter(Context context, List<WifiHomeAdapter.InsideBean> beanList) {
        this.context = context;
        this.beanList = beanList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        vBinding = ItmeWifiHomeBinding.inflate(LayoutInflater.from(parent.getContext()),null,false);
        return new WifiHomeAdapter.ViewHolder(vBinding);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WifiHomeAdapter.InsideBean bean = beanList.get(position);
        holder.vBinding.tv1.setText(bean.title);
        holder.vBinding.iv1.setImageResource(bean.resID);
        holder.vBinding.getRoot().setTag(bean);
    }

    @Override
    public int getItemCount() {
        return beanList.size();
    }

    public void setData(List<InsideBean> favoriteData) {
        this.beanList=favoriteData;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ItmeWifiHomeBinding vBinding;

        public ViewHolder(@NonNull ItmeWifiHomeBinding vBinding) {
            super(vBinding.getRoot());
            this.vBinding = vBinding;
            vBinding.getRoot().setOnClickListener(v -> {
                Message message = new Message();
                message.obj = vBinding.getRoot().getTag();
                EventBus.getDefault().post(message);
            });
        }
    }

    public static class InsideBean {
        String title;
        int resID;
        //url
        String url;
        public InsideBean(String title, int resID, String url) {
            this.title = title;
            this.resID = resID;
            this.url = url;
        }

        public String getUrl() {
            return url;
        }

        public String getTitle() {
            return title;
        }
    }


}
