package com.juying.mjreader.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.viewbinding.ViewBinding;

import com.github.barteksc.pdfviewer.PDFView;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.bean.ComicSettingBean;
import com.juying.mjreader.bean.TreeNodeData;
import com.juying.mjreader.databinding.ActivitySeeComicBinding;
import com.shockwave.pdfium.PdfDocument;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 14:34
 */
public class SeeComicMode {

    /**
     * 设置标题
     *
     * @param name
     * @param isHaveAfter 标题保留后缀
     */
    public static void setTitleTxt(ActivitySeeComicBinding vBinding, String name, boolean isHaveAfter) {
        if (isHaveAfter) {
            vBinding.tvTitle.setText(TextUtils.isEmpty(name)?"未知":name);
        }else {
            vBinding.tvTitle.setText(getNoAfterFileName(name));
        }
    }

    /**
     * 获得没后缀的字符name
     * @param name
     * @return
     */
    public static String getNoAfterFileName(String name) {
        if (TextUtils.isEmpty(name)) {
            return "未知";
        }
        if (name.contains(".")) {
            name = name.substring(0, name.lastIndexOf("."));
        }
        return name;
    }


    /**
     * 设置亮度
     *
     * @param brightness 0.0~1.0 的数
     */
    public static void setBrightness(Activity context, float brightness) {
        Window window = context.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        //设置系统亮度需要获取运行时权限，所以不用这个方案
//            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 200);
        lp.screenBrightness = brightness;
        window.setAttributes(lp);
    }


    /**
     * 获取Rv标签数据【简单封装一下】
     *
     * @param comicSeeSumBean
     * @return
     */
    public static List<TreeNodeData> getRvTreeNodeData(ComicSeeSumBean comicSeeSumBean) {
        //获得文档书签信息
        List<TreeNodeData> catelogues = new ArrayList<>();
        for (int i = 0; i < comicSeeSumBean.getSeeBeanList().size(); i++) {
            ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(i);
            TreeNodeData nodeData = new TreeNodeData();
            nodeData.setName(comicSeeBean.getFileName());
            nodeData.setPageNum(i);
//            if (currentShowPage == i) {
//                nodeData.setInProgressShow(true);
//            }
            nodeData.setTreeLevel(1);
            nodeData.setExpanded(false);
            catelogues.add(nodeData);
        }
        return catelogues;
    }
}
