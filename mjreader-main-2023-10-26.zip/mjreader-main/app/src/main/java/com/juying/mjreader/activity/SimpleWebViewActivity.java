package com.juying.mjreader.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.bean.LoadingBean;
import com.juying.mjreader.databinding.ActivitySimpleWebViewBinding;

/**
 * 简单的WebView页，用来加载用户协议隐私政策之类的,需要传对应的Bean过来
 */
public class SimpleWebViewActivity extends BaseActivity {

    public static String LOADING_BEAN_KEY = "loading_bean";
    private ActivitySimpleWebViewBinding vBinding;
    private LoadingBean loadingBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivitySimpleWebViewBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        initData();
        initUi();
        vBinding.ivBack.setOnClickListener(v -> finish());
    }

    private void initUi() {
        if (loadingBean == null) {
            return;
        }
        vBinding.tvTitle.setText(loadingBean.getTitle());
        setWebView(loadingBean.getUrl());
    }


    private void initData() {

        Intent intent = getIntent();
        try {
            if (intent != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    loadingBean = intent.getSerializableExtra(LOADING_BEAN_KEY, LoadingBean.class);
                } else {
                    loadingBean = (LoadingBean) intent.getSerializableExtra(LOADING_BEAN_KEY);
                }
            }
        } catch (Exception e) {
            log("加载数据错误");
            e.printStackTrace();
        }


    }


    @SuppressLint("SetJavaScriptEnabled")
    private void setWebView(String url) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        WebSettings webSettings = vBinding.webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        vBinding.webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                log("webView加载完成：" + url);
            }
        });
        vBinding.webView.loadUrl(url);
    }

}