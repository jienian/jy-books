package com.juying.mjreader.net.bean;

import com.juying.mjreader.network.models.BaseReq;

/**
 * @Author Ycc
 * @Date 19:09
 */
public class ReqRemoveDataBean extends BaseReq {

    private String type;
    private String dataId;
    private String topUserId;

    public ReqRemoveDataBean(String type, String dataId, String topUserId) {
        this.type = type;
        this.dataId = dataId;
        this.topUserId = topUserId;
    }
}
