package com.juying.mjreader.utils;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 17:53
 */
public class RecyclerViewUtil {


    /**
     * 该方法，获取屏幕内所有Item在屏幕内的显示比例，
     */
    public static void calculateItemVisiblePercent(LinearLayoutManager layoutManager, RecyclerView rv) {
        //获取第一个可见item的位置
        final int firstPosition = layoutManager.findFirstVisibleItemPosition();
        //获取最后一个可见item的位置
        final int lastPosition = layoutManager.findLastVisibleItemPosition();
        Rect rvRect = new Rect();
        //获取recyclerview可见区域相对屏幕左上角的位置坐标
        rv.getGlobalVisibleRect(rvRect);
        for (int position = firstPosition; position <= lastPosition; position++) {
            int visiblePercent;
            //根据position获得对应的view
            View itemView = layoutManager.findViewByPosition(position);
            int itemHeight = itemView.getHeight();
            Rect rowRect = new Rect();
            //获取item可见区域相对屏幕左上角的位置坐标
            itemView.getGlobalVisibleRect(rowRect);
            if (rowRect.bottom >= rvRect.bottom) { //item在recyclerview底部且有部分不可见
                int visibleHeightFirst = rvRect.bottom - rowRect.top;
                visiblePercent = (visibleHeightFirst * 100) / itemHeight;
            } else { //item在recyclerview中或顶部
                int visibleHeightFirst = rowRect.bottom - rvRect.top;
                visiblePercent = (visibleHeightFirst * 100) / itemHeight;
            }
            if (visiblePercent > 100) {
                visiblePercent = 100;
            }
            Log.d("TAG", "第position个itme展示了：" + visiblePercent + "%");
        }
    }


    /**
     * 某个Item在屏幕内的显示比例
     */
    public static int firstItemVisiblePercent(LinearLayoutManager layoutManager, RecyclerView rv, int position) {
        //获取第一个可见item的位置
//        final int firstPosition = layoutManager.findFirstVisibleItemPosition();
        //获取最后一个可见item的位置
//        final int lastPosition = layoutManager.findLastVisibleItemPosition();
        Rect rvRect = new Rect();
        //获取recyclerview可见区域相对屏幕左上角的位置坐标
        rv.getGlobalVisibleRect(rvRect);
        int visiblePercent;
        //根据position获得对应的view
        View itemView = layoutManager.findViewByPosition(position);
        if (itemView == null) {
            return 0;//初始化的时候这里获取不到
        }
        int itemHeight = itemView.getHeight();
        if (itemHeight == 0) {
            return 0;//初始化的时候这里获取不到
        }
        Rect rowRect = new Rect();
        //获取item可见区域相对屏幕左上角的位置坐标
        itemView.getGlobalVisibleRect(rowRect);
        if (rowRect.bottom >= rvRect.bottom) { //item在recyclerview底部且有部分不可见
            int visibleHeightFirst = rvRect.bottom - rowRect.top;
            visiblePercent = (visibleHeightFirst * 100) / itemHeight;
        } else { //item在recyclerview中或顶部
            int visibleHeightFirst = rowRect.bottom - rvRect.top;
            visiblePercent = (visibleHeightFirst * 100) / itemHeight;
        }
        if (visiblePercent > 100) {
            visiblePercent = 100;
        }
        Log.d("TAG", "第" + position + "索引个itme展示了：" + visiblePercent + "%");
        return visiblePercent;

    }

    /**
     * 获得完整可见itme索引
     * @return
     */
    public static List<Integer> getVisibleItmePosition(RecyclerView recyclerView,LinearLayoutManager layoutManager) {
        List<Integer> list = new ArrayList<>();
        int fPosition = layoutManager.findFirstVisibleItemPosition();//第一个可见itme索引
        int lPosition = layoutManager.findLastVisibleItemPosition();//最后一个可见itme索引
        View fPositionView = layoutManager.findViewByPosition(fPosition);
        View lPositionView = layoutManager.findViewByPosition(lPosition);


        for (int i = fPosition; i <= lPosition; i++) {
            //这里没有考虑第一个可见或者最后一个可见刚好是完整可见这种极端情况，一般只有滑动到最最最最顶或者最最最最底部才会出现这种情况,
            // 可以通过    int xxxxx = layoutManager.getInitialPrefetchItemCount();
            //            int xxxxx = layoutManager.getItemCount();来判断， 以后再优化
            if (getPositionIsCompleteShow(recyclerView, layoutManager.findViewByPosition(i))) {
                list.add(i);
            }
        }
        Log.d("TAG","完整可见itme索引:" + list.toString());

        return list;
    }
    /**
     * 判断ItmeView是否完整可见
     *
     * @param recyclerView
     * @param itmeView
     * @return
     */
    public static boolean getPositionIsCompleteShow(RecyclerView recyclerView, View itmeView) {

        float recyclerViewY = recyclerView.getY();
        int recyclerViewHeight = recyclerView.getHeight();
        float itmeY = itmeView.getY();
        int itmeHeight = itmeView.getHeight();

        //当前只有两个itme,
        if (itmeY >= recyclerViewY && itmeY + itmeHeight <= recyclerViewHeight) {
//            log("最后一个完整可见的Item:"+layoutManager.findLastVisibleItemPosition());
            return true;
        }
        return false;
    }
}
