package com.juying.mjreader.adapter.novel;

import android.view.View;
import android.view.ViewGroup;

import com.juying.mjreader.activity.NovelDetailActivity;
import com.juying.mjreader.bean.adapter.EasyAdapter;
import com.juying.mjreader.bean.adapter.IViewHolder;
import com.juying.mjreader.widget.page.TxtChapter;

/**
 * @Author:Nimyears
 * 解析章节的内容
 */

public class CategoryAdapter extends EasyAdapter<TxtChapter> {
    private int currentSelected = 0;

    @Override
    protected IViewHolder<TxtChapter> onCreateViewHolder(int viewType) {
      //  return new NovelDetailActivity();
        return null ;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        //  CategoryHolder holder = (CategoryHolder) view.getTag();


        if (position == currentSelected){
      //      holder.setSelectedChapter();
        }

        return view;
    }



    public void setChapter(int pos){
        currentSelected = pos;
        notifyDataSetChanged();
    }
}
