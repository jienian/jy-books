package com.juying.mjreader.network.models

/**
 * @author Nimyears
 *用于网络响应或某种操作的结果的数据模型(操作的状态、错误代码、时间等的信息)
 */


data class Res<T>(
    val status: Int,
    val errorCode: Int,
    val time: String,
    val statisticCache: Boolean,
    var data: T?,
    val safety: Safety?,
    val safetyData: String?
)

