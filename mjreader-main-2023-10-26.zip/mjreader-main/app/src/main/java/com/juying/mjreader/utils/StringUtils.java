package com.juying.mjreader.utils;

import android.content.Context;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

import com.juying.mjreader.utils.config.Constant;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Author Ycc
 * @Date 13:16
 */
public class StringUtils {
    private static final String TAG = "StringUtils";


    public static boolean isEmpty(String... s) {
        for (String string : s) {
            if (TextUtils.isEmpty(string)) {
                return true;
            }
        }
        return false;
    }


    //将时间转换成日期
    public static String dateConvert(long time, String pattern) {
        Date date = new Date(time);
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.format(date);
    }

    /**
     * 是否包含多种字符，有一个满足就返回
     *
     * @param string
     * @return
     */
    public static String isContain(String string) {
        if (!TextUtils.isEmpty(string)) {
            for (String s : Constant.SPECIAL_STRING) {
                if (string.contains(s)) {
                    // 包含
                    return s;
                }
            }
        }
        return "";
    }


    /**
     * 获取倒数第2个特定字符的位置
     *
     * @param s
     * @param flag
     * @return
     */
    public static int getReciprocal2(String s, String flag) {
        // 最后一个分隔符位置
        int lastIndex = s.lastIndexOf(flag);
        // 倒数第二个分隔符位置
        int secondLastIndex = s.lastIndexOf(flag, lastIndex - 1);
        return secondLastIndex;
    }

    public static String convertCC(String input, Context context) {
        return input;
        /*ConversionType currentConversionType = ConversionType.S2TWP;
        int convertType = SharedPreUtils.getInstance().getInt(SHARED_READ_CONVERT_TYPE, 0);

        if (input.length() == 0)
            return "";

        switch (convertType) {
            case 1:
                currentConversionType = ConversionType.TW2SP;
                break;
            case 2:
                currentConversionType = ConversionType.S2HK;
                break;
            case 3:
                currentConversionType = ConversionType.S2T;
                break;
            case 4:
                currentConversionType = ConversionType.S2TW;
                break;
            case 5:
                currentConversionType = ConversionType.S2TWP;
                break;
            case 6:
                currentConversionType = ConversionType.T2HK;
                break;
            case 7:
                currentConversionType = ConversionType.T2S;
                break;
            case 8:
                currentConversionType = ConversionType.T2TW;
                break;
            case 9:
                currentConversionType = ConversionType.TW2S;
                break;
            case 10:
                currentConversionType = ConversionType.HK2S;
                break;
        }

        return (convertType != 0)?ChineseConverter.convert(input, currentConversionType, context):input;*/
    }

    /**
     * 将文本中的半角字符，转换成全角字符
     *
     * @param input
     * @return
     */
    public static String halfToFull(String input) {
        char[] c = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == 32) //半角空格
            {
                c[i] = (char) 12288;
                continue;
            }
            //根据实际情况，过滤不需要转换的符号
            //if (c[i] == 46) //半角点号，不转换
            // continue;

            if (c[i] > 32 && c[i] < 127)    //其他符号都转换为全角
                c[i] = (char) (c[i] + 65248);
        }
        return new String(c);
    }


    /**
     * 去除不要的字符
     *
     * @param specialString 不要的字符集
     * @return
     */
    public static String delSpecialChar(String[] specialString, String string) {
        if (!TextUtils.isEmpty(string)) {
            for (String s : specialString) {
                if (string.contains(s)) {
                    // 包含
                    try {
                        string = string.replace(s + "", "");
                        Log.d(TAG, "delSpecialChar: " + string);
                    } catch (Exception e) {
                        Log.d(TAG, "delSpecialChar: " + e.getMessage());
                    }
                }
            }
        }
        return string;
    }


    /**
     * 文字高亮，并监听
     * View要设置  setMovementMethod(LinkMovementMethod.getInstance()); 监听才会生效
     */
    public static SpannableStringBuilder textHighlight(String allText, int highlightColor, View.OnClickListener onClickListener, String... highlightText) {
        SpannableStringBuilder builder = new SpannableStringBuilder(allText);
        for (int i = 0; i < highlightText.length; i++) {
            String highlightT = highlightText[i];
            if (allText.contains(highlightT)) {
                int startIndex = allText.lastIndexOf(highlightT);
                int endIndex = startIndex + highlightT.length();
                //设置文本点击事件
//                builder.setSpan(clickSpannable, startIndex, endIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new ClickableSpan() {
                    @Override
                    public void onClick(@NonNull View widget) {
                        widget.setTag(highlightT);
                        onClickListener.onClick(widget);
                    }
                }, startIndex, endIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                //   改文本颜色，要在点击事件之后，不然会被覆盖
                builder.setSpan(new ForegroundColorSpan(highlightColor), startIndex, endIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            }
        }
        return builder;
    }

}
