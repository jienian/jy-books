package com.juying.mjreader.adapter;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.google.android.material.card.MaterialCardView;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeComicActivity;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.bean.FlagBean;
import com.juying.mjreader.net.NetUtils;

import java.util.ArrayList;


public class SeeComicAdapter extends RecyclerView.Adapter<SeeComicAdapter.ViewHolder> {
    private SeeComicActivity context;
    private ComicSeeSumBean comicSeeSumBean;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;
    ViewGroup.LayoutParams layoutParams1 = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    ViewGroup.LayoutParams layoutParams2 = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

    public SeeComicAdapter(SeeComicActivity context, ComicSeeSumBean comicSeeSumBean) {
        this.comicSeeSumBean = comicSeeSumBean;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_comic_page, null);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comic_page, null, false);
        int type = context.comicSettingBean.getModeComicSee();
        if (type == 1 || type == 2) {
            view.setLayoutParams(layoutParams1);
        } else if (type == 3) {
            view.setLayoutParams(layoutParams2);
        }
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        super.onViewRecycled(holder);
        ImageView imageView = holder.iv;
        if (imageView != null) {
            Glide.with(context).clear(imageView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (comicSeeSumBean == null) {
            return;
        }
//        BookBean bean = bookBean.getBookBeanList().get(showPosition.get(position));
        ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(position);
        holder.tvContent.setVisibility(View.GONE);
        holder.setLL();
        ViewGroup.LayoutParams layoutParams = holder.iv.getLayoutParams();
        if (comicSeeBean == null || comicSeeBean.isImageLoadFail()) {
            holder.bt.setVisibility(View.VISIBLE);
            holder.iv.setVisibility(View.GONE);
            holder.mcv.setVisibility(View.GONE);
            holder.tvContent.setVisibility(View.GONE);
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
        } else {
            holder.bt.setVisibility(View.GONE);
            holder.iv.setVisibility(View.VISIBLE);
            FlagBean flagBean = comicSeeBean.getFlagBean();
            if (flagBean != null && !TextUtils.isEmpty(flagBean.getContent())) {
                holder.mcv.setVisibility(View.VISIBLE);
                holder.mcv.setTag(flagBean);
//                if (flagBean.isShowContent()) {
//                    holder.tvContent.setVisibility(View.VISIBLE);
//                    holder.tvContent.setText(flagBean.getContent());
//                }else {
//                    holder.tvContent.setVisibility(View.GONE);
//                }
            } else {
                holder.mcv.setVisibility(View.GONE);
            }

            layoutParams.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            Glide.with(context)
                    .asDrawable()//比bitmap要省
//                    .load(bean.isWifiData()?comicSeeBean.getImges():comicSeeBean.getUrl())
                    .load(comicSeeBean.getUrl())
                    .override(comicSeeBean.getWidth(), comicSeeBean.getHeight())
//                                        .override(500, 500)
                    .into(holder.iv);

//            if (bean.getFileType().contains("pdf")) {
//                holder.pdfView.setVisibility(View.VISIBLE);
//                holder.bt.setVisibility(View.GONE);
//                holder.iv.setVisibility(View.GONE);
//
////                File file =new File(bean.getFilePath());
////                boolean xxx = file.exists();
//                File file = new File("/data/user/0/com.juying.mjreader/files/bookshelf/ss01.pdf");
//                holder.pdfView.fromAsset("sss.pdf")
//                        .password(null)
//                        .defaultPage(0)
//                        .enableSwipe(true)
//                        .swipeHorizontal(false)
//                        .enableDoubletap(true)
//                        .onPageChange(new OnPageChangeListener() {
//                            @Override
//                            public void onPageChanged(int page, int pageCount) {
//                                // 页面切换时的回调函数
//                                Log.d("TAG", "onPageChanged: 执行=page="+page+";pageCount="+pageCount);
//                            }
//                        })
//                        .enableAnnotationRendering(false)
//                        .onLoad(new OnLoadCompleteListener() {
//                            @Override
//                            public void loadComplete(int nbPages) {
//                                Log.d("TAG", "loadComplete: 执行=nbPages="+nbPages);
//                            }
//                        })
//                        .scrollHandle(null)
//                        .load();
//            }else {

//            }

        }


    }

    public ViewHolder getViewHolder() {
        return viewHolder;
    }


    @Override
    public int getItemCount() {
        return getShowSize(comicSeeSumBean);
//        return 200;
    }


    private int getShowSize(ComicSeeSumBean bookBean) {
        if (bookBean == null || bookBean.getSeeBeanList() == null) {
            return 0;
        }
//        showPosition = new ArrayList<>();
//        for (int i = 0; i < bookBean.getSeeBeanList().size(); i++) {
//            BookBean bean = bookBean.getSeeBeanList().get(i);
//            if (bean.getMaxSize() > bean.getImputSchedule() || bean.isDirectory() || bean.getFileType().contains("pdf")) {
//                //如果是未导入完成、目录、pdf就不在Rv里显示
//            } else {
//                showPosition.add(i);
//            }
//        }
        return bookBean.getSeeBeanList().size();
    }


    public void setBean(ComicSeeSumBean comicSeeSumBean) {
        this.comicSeeSumBean = comicSeeSumBean;
    }




    public class ViewHolder extends RecyclerView.ViewHolder {
        //        private final FrameLayout fl;
        private final ImageView iv;
        private final Button bt;
        private final View ll;
        private final View itemview;
//        private final View rl;
        private final TextView tvContent;
        private final MaterialCardView mcv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemview = itemView;
            iv = itemView.findViewById(R.id.iv_comic);
            bt = itemView.findViewById(R.id.bt1);
            ll = itemView.findViewById(R.id.ll);
            mcv = itemView.findViewById(R.id.mcv);
//             rl = itemView.findViewById(R.id.rl);
            tvContent = itemView.findViewById(R.id.tv_content);

            bt.setOnClickListener(v -> {
                        if (NetUtils.isNetSystemUsable(MjApplication.CONTEXT)) {
                            viewShow(1);
//                         TODO   context.reconnect();
                            Log.d("TAG", "网络重连");
                        } else {
                            viewShow(2);
                            Toast.makeText(context, "请检查网络", Toast.LENGTH_SHORT).show();
                        }
                    }

            );

            mcv.setOnClickListener(v -> {
                FlagBean flagBean= (FlagBean) v.getTag();
                if (tvContent.getVisibility() == View.GONE&&!TextUtils.isEmpty(flagBean.getContent())) {
                    tvContent.setText(flagBean.getContent());
                    tvContent.setVisibility(View.INVISIBLE);
                    tvContent.post(new Runnable() {
                        @Override
                        public void run() {
//                            int height = tvContent.getHeight();
//                            float xxx = tvContent.getY();
//                            float xxx1 = tvContent.getRotationY();
                            float pivotY = tvContent.getPivotY();
//                            float xxx3 = tvContent.getScaleY();
//                            float xxx4 = tvContent.getScrollY();
                            ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(tvContent, "translationY", pivotY);
                            objectAnimatorX.setDuration(1);
                            objectAnimatorX.start();
                            tvContent.post(() -> tvContent.setVisibility(View.VISIBLE));
                        }
                    });
                }else {
                    tvContent.setVisibility(View.GONE);
                }
            });
        }

        public void setLL() {
            int type = context.comicSettingBean.getModeComicSee();
            ViewGroup.LayoutParams layoutParams = (ViewGroup.LayoutParams) itemview.getLayoutParams();
            if (layoutParams == null) {
                return;
            }
            if (type == 1 || type == 2) {
                layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
                itemview.setLayoutParams(layoutParams);
//                itemview.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
            } else if (type == 3) {
                layoutParams.width = ViewGroup.LayoutParams.WRAP_CONTENT;
                layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                itemview.setLayoutParams(layoutParams);
//                itemview.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.WRAP_CONTENT, RecyclerView.LayoutParams.WRAP_CONTENT));
            }

        }

    }


    private void viewShow(int type) {
        if (type == 1) {
            viewHolder.iv.setVisibility(View.VISIBLE);
            viewHolder.bt.setVisibility(View.GONE);
        } else if (type == 2) {
            viewHolder.iv.setVisibility(View.GONE);
            viewHolder.bt.setVisibility(View.VISIBLE);
        }
    }

}
