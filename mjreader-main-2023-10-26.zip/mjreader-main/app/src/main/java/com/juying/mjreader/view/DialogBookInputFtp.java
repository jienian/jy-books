package com.juying.mjreader.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogBookInputFtpBinding;
import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.StringUtils;
import com.juying.mjreader.utils.ftp.FTP;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogBookInputFtp extends BaseDialog {
    private DialogBookInputFtpBinding vBinding;
    private DialogLoading loadomg;
    Handler handler;

    public DialogBookInputFtp(@NonNull Context context, DialogBrowseEditListener listener) {
        super(context, R.style.DialogTheme);
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
//        View view = View.inflate(context, R.layout.dialog_book_input, null);
        vBinding = DialogBookInputFtpBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);

        //区域外点击不关闭dialog
//        setCanceledOnTouchOutside(false);

        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

//FLAG_WATCH_OUTSIDE_TOUCH作用：如果点击事件发生在window之外，就会收到一个特殊的MotionEvent，为ACTION_OUTSIDE
//        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);


//        view.findViewById(R.id.ll1).setOnClickListener(view1 -> {
//            dismiss();
//            listener.onClickEdit();
//        });

        handler = new Handler(Looper.myLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case 1:
                        if (msg.obj instanceof TextView) {
                            vBinding.llMode.addView((TextView) msg.obj);
                        } else if (msg.obj instanceof Bitmap) {
                            vBinding.iv.setImageBitmap((Bitmap) msg.obj);
                        }else if (msg.obj instanceof  InputStream  ) {
                            Bitmap bmp = BitmapFactory.decodeStream((BufferedInputStream) msg.obj);
                            vBinding.iv.setImageBitmap(bmp);
                        }
//                        vBinding.iv.setImageBitmap((Bitmap) msg.obj);

//                        Glide.with(getContext())
//                                .load((URL) msg.obj)
////                                        .override(500, 500)
//                                .into(vBinding.iv);
                        break;
                    case 2:
                        to("链接服务器失败", false);
                        break;
                    default:
                }


            }
        };
        initView();
        initListener();


    }

    private void initView() {
        ArrayAdapter spinnerAadapter = ArrayAdapter.createFromResource(getContext(), R.array.coding, R.layout.spiner_text_item);
        spinnerAadapter.setDropDownViewResource(R.layout.spiner_text_item);
        vBinding.spinnerCoding.setAdapter(spinnerAadapter);
    }

    private void test(){
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
//                    URL u = new URL("ftp://192.168.51.76/3.jpg");
//                    LogUtil.d(TAG, "加载Url:" + u);
//                    URLConnection c = u.openConnection();
//                    InputStream is = c.getInputStream();


                String server = "192.168.51.76";
                int port = 21;
                String user = "JUYINGTECH";
                String password = "654321";
                String remoteFilePath = "/3.jpg";

                FTPClient ftpClient = new FTPClient();
                ftpClient.connect(server, port);
                ftpClient.login(user, password);
                ftpClient.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);

                InputStream inputStream = ftpClient.retrieveFileStream(remoteFilePath);

                // 在这里对文件流进行处理，比如读取或保存到本地
                //                    BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
                Bitmap bmp = BitmapFactory.decodeStream(inputStream);
                Message mes = new Message();
                mes.what = 1;
                mes.obj = bmp;
                handler.sendMessage(mes);

                ftpClient.logout();
                ftpClient.disconnect();



            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

    }

    private void initListener() {

        vBinding.tvCancel.setOnClickListener(v -> {
            dismiss();
        });
        vBinding.tvOk.setOnClickListener(v -> {
            FormData formData = getForm();
            if (StringUtils.isEmpty(formData.getServer(), formData.getPort(), formData.getUserName(), formData.getPassword())) {
                to("服务器/端口/用户名/密码必须填写", false);
                return;
            }


            if (loadomg == null) {
                loadomg = new DialogLoading(getContext());
            }
            loadomg.show();

            Executors.newSingleThreadExecutor().execute(() -> {
                FTP ftp = new FTP(formData.getServer(), formData.getUserName(), formData.getPassword(), formData.getCoding(), formData.isActive());
                try {
                    if (ftp.openConnect()) {
                        loadomg.dismiss();

                        /**
                         * TODO ftp链接上，建一个sql远程来源表，存所有ftp源信息
                         * TODO 获取所有数据，跳转到根目录打开页
                         */
                        FtpFile ffile = new FtpFile();
                        ffile.setDirectory(true);
                        ffile.setPath("/");
                        ffile.setHost(formData.getServer());
                        ffile = getFTPFile(ftp, formData.getServer(), ffile);
                        log("识别FTP文件名：" + ffile);

                        showMode(ffile);

                    } else {
                        loadomg.dismiss();
                        handler.sendEmptyMessage(2);
                    }
                } catch (Exception e) {
                    loadomg.dismiss();
                    handler.sendEmptyMessage(2);
                    throw new RuntimeException(e);
                }
            });
        });
    }

    private void showMode(FtpFile ffile) {
        for (int i = 0; i < ffile.getFtpFiles().size(); i++) {
            FtpFile f = ffile.getFtpFiles().get(i);
            TextView tv = new TextView(getContext());
            tv.setText(f.getName());
            tv.setOnClickListener(v1 -> {

                if (!(f.getFileType().contains("jpeg")||f.getFileType().contains("png")||f.getFileType().contains("jpg"))) {
                    return;
                }


                Executors.newCachedThreadPool().execute(() -> {
                    try {
                        if (f.isImages()) {
                            URL u = new URL("ftp://" + f.getHost() + f.getPath());
//                            URL u = new URL("ftp://" + f.getHost() + "/3.jpg");
                            LogUtil.d(TAG, "加载Url:" + u);
                            URLConnection c = u.openConnection();
                            InputStream is = c.getInputStream();
                            BufferedInputStream bufferedInputStream = new BufferedInputStream(is);
                            Bitmap bmp = BitmapFactory.decodeStream(bufferedInputStream);


//                            InputStream is = u.openStream();
//                            BufferedInputStream bufferedInputStream = new BufferedInputStream(is);


                            is.close();
                            bufferedInputStream.close();
                            Message mes = new Message();
                            mes.what = 1;
                            mes.obj = bmp;
                            handler.sendMessage(mes);
                        }
                    } catch (IOException e) {
                    }
                });
            });
            Message mes = new Message();
            mes.what = 1;
            mes.obj = tv;
            handler.sendMessage(mes);
        }
    }


    private FtpFile getFTPFile(FTP ftp, String host, FtpFile file) throws IOException {
        List<FTPFile> listFiles = ftp.listFiles(file.path);

        for (int i = 0; i < listFiles.size(); i++) {
            FTPFile ftpFile = listFiles.get(i);
//                            String url="ftp:\\\\"+formData.getServer()+"\\"+ftpFile.getName();
            FtpFile childFile = new FtpFile();
            childFile.setDirectory(ftpFile.isDirectory());
            if (file.path.equals("/")) {//根目录
                childFile.setPath(file.path + ftpFile.getName());
            } else {
                childFile.setPath(file.path + "/" + ftpFile.getName());
            }
            childFile.setHost(file.getHost());
            childFile.setName(ftpFile.getName());

            if (ftpFile.isDirectory()) {
                childFile.setFileType("");
                getFTPFile(ftp, host, childFile);
            } else {
                URL u = new URL("ftp://" + host + childFile.getPath());
                URLConnection c = u.openConnection();
                String fileType = c.getContentType();
                childFile.setFileType(fileType);
            }
            file.getFtpFiles().add(childFile);
        }
        return file;
    }


    private class FtpFile {
        private List<FtpFile> ftpFiles = new ArrayList<>();
        private boolean isDirectory;
        private String host;

        //父路径
        private String parent_path;
        //本路径
        private String path;
        private String name;
        //文件类型，如果是目录则为""
        private String fileType;

        @Override
        public String toString() {
            return "FtpFile{" +
                    "ftpFiles=" + ftpFiles +
                    ", isDirectory=" + isDirectory +
                    ", parent_path='" + parent_path + '\'' +
                    ", path='" + path + '\'' +
                    ", name='" + name + '\'' +
                    ", fileType='" + fileType + '\'' +
                    '}';
        }

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public String getFileType() {
            return fileType;
        }

        public void setFileType(String fileType) {
            this.fileType = fileType;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<FtpFile> getFtpFiles() {
            return ftpFiles;
        }

        public void setFtpFiles(List<FtpFile> ftpFiles) {
            this.ftpFiles = ftpFiles;
        }

        public boolean isImages() {
            if (!TextUtils.isEmpty(fileType) && (fileType.contains("jpg") || fileType.contains("jpeg") || fileType.contains("webp") || fileType.contains("png") || fileType.contains("gif"))) {
                return true;
            }
            return false;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getParent_path() {
            return parent_path;
        }

        public void setParent_path(String parent_path) {
            this.parent_path = parent_path;
        }


        public boolean isDirectory() {
            return isDirectory;
        }

        public void setDirectory(boolean rootDirectory) {
            isDirectory = rootDirectory;
        }
    }


    private FormData getForm() {
        String host = getString(vBinding.etHost);
        String rort = getString(vBinding.etPort);
        boolean isActive = vBinding.rbActive.isChecked();
        String name = getString(vBinding.etName);
        String password = getString(vBinding.etPassword);
        boolean isAnonymous = vBinding.cbAnonymous.isChecked();
        String coding = vBinding.spinnerCoding.getSelectedItem().toString();
        String rename = getString(vBinding.etRename);
        FormData formData = new FormData(host, rort, isActive, name, password, isAnonymous, coding, rename);
//        FormData formData = new FormData("192.168.51.76", rort, isActive, "JUYINGTECH", "654321", isAnonymous, "GBK", rename);
        log("表单Bean:" + formData);
        return formData;
    }


    private String getString(EditText et) {
        String string = "";
        try {
            string = et.getText().toString();
        } catch (Exception ignored) {
        }
        return string;
    }

    public interface DialogBrowseEditListener {
        void onClickEdit();
    }

    private class FormData {
        //服务器
        String server;
        //端口
        String port;
        //模式
        boolean isActive;
        //用户名
        String userName;
        String password;
        //是否匿名
        boolean isAnonymous;
        //编码
        String coding;
        //重命名
        String rename;

        public FormData(String server, String port, boolean isActive, String userName, String password, boolean isAnonymous, String coding, String rename) {
            this.server = server;
            this.port = port;
            this.isActive = isActive;
            this.userName = userName;
            this.password = password;
            this.isAnonymous = isAnonymous;
            this.coding = coding;
            this.rename = rename;
        }

        @Override
        public String toString() {
            return "FormData{" +
                    "server='" + server + '\'' +
                    ", port='" + port + '\'' +
                    ", isActive=" + isActive +
                    ", userName='" + userName + '\'' +
                    ", password='" + password + '\'' +
                    ", isAnonymous=" + isAnonymous +
                    ", coding='" + coding + '\'' +
                    ", rename='" + rename + '\'' +
                    '}';
        }

        public String getServer() {
            return server;
        }

        public String getPort() {
            return port;
        }

        public boolean isActive() {
            return isActive;
        }

        public String getUserName() {
            return userName;
        }

        public String getPassword() {
            return password;
        }

        public boolean isAnonymous() {
            return isAnonymous;
        }

        public String getCoding() {
            return coding;
        }

        public String getRename() {
            return rename;
        }
    }

}
