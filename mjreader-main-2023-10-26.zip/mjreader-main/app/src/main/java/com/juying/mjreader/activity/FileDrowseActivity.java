package com.juying.mjreader.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.juying.mjreader.databinding.ActivityFileDrowseBinding;

public class FileDrowseActivity extends AppCompatActivity {

    private ActivityFileDrowseBinding vBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding=ActivityFileDrowseBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
    }
}