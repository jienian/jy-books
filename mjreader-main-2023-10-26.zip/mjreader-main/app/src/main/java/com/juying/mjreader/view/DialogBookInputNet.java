package com.juying.mjreader.view;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogBookInputNetBinding;

/**
 *
 * @Author Ycc
 * @Date 15:34
 */
public class DialogBookInputNet extends Dialog {
  private   DialogBookInputNetBinding vBinding;
    public DialogBookInputNet(@NonNull Context context, DialogBrowseEditListener listener) {
        super(context, R.style.DialogTheme);
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
//        View view = View.inflate(context, R.layout.dialog_book_input, null);
        vBinding= DialogBookInputNetBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);

        //区域外点击不关闭dialog
//        setCanceledOnTouchOutside(false);

        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

//FLAG_WATCH_OUTSIDE_TOUCH作用：如果点击事件发生在window之外，就会收到一个特殊的MotionEvent，为ACTION_OUTSIDE
//        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);


//        view.findViewById(R.id.ll1).setOnClickListener(view1 -> {
//            dismiss();
//            listener.onClickEdit();
//        });
        initListener();
    }

    private void initListener() {
        vBinding.ll1.setOnClickListener(v -> {
            dismiss();
            new DialogBookInputFtp(getContext(),null).show();
        });
        vBinding.ll2.setOnClickListener(v -> {
            dismiss();
            new DialogBookInputSMB(getContext(),null).show();
        });
        vBinding.ll3.setOnClickListener(v -> {
            dismiss();
            new DialogBookInputWebdav(getContext(),null).show();
        });
    }

    public interface DialogBrowseEditListener {
        void onClickEdit();
    }


}
