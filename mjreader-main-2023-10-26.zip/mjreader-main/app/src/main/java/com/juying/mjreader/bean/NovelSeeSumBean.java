package com.juying.mjreader.bean;

import static java.lang.System.in;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.juying.mjreader.data.entities.Novel;

import java.util.List;

public class NovelSeeSumBean implements Parcelable {

    /**
     * 当前显示位置，【初始化的时候有用】
     */
    private int currentShowPosition;

    /**
     * 是否PDF显示模式
     */
    private boolean isPDFMode;

    private List<NovelSeeBean> seeBeanList;
    public List<NovelSeeBean> getSeeBeanList() {
        return seeBeanList;
    }


    public NovelSeeSumBean(int currentShowPosition, boolean isPDFMode, List<NovelSeeBean> seeBeanList){
        this.currentShowPosition = currentShowPosition;
        this.isPDFMode = isPDFMode;
        this.seeBeanList = seeBeanList;

    }




    public boolean isPDFMode(){
        return isPDFMode;
    }

    public void setPDFMode(boolean PDFMode){
        isPDFMode = PDFMode;
    }


    public void setSeeBeanList(List<NovelSeeBean> seeBeanList){
        this.seeBeanList = seeBeanList;
    }
    public int getCurrentShowPosition() {
        return currentShowPosition;
    }

    public void setCurrentShowPosition(int currentShowPosition) {
        this.currentShowPosition = currentShowPosition;
    }
    @Override
    public String toString() {
        return "NovelSeeSumBean{" +
                "currentShowPosition=" + currentShowPosition +
                ", isPDFMode=" + isPDFMode +
                ", seeBeanList=" + seeBeanList +
                '}';
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeInt(this.currentShowPosition);
        dest.writeByte(this.isPDFMode ? (byte) 1 : (byte) 0) ;
        dest.writeTypedList(this.seeBeanList);
    }

    public void readFromParcel(Parcel source) {
        this.currentShowPosition = source.readInt();
        this.isPDFMode = source.readByte() != 0;
        this.seeBeanList = source.createTypedArrayList(NovelSeeBean.CREATOR);
    }
    protected NovelSeeSumBean(Parcel in) {
        this.currentShowPosition = in.readInt();
        this.isPDFMode = in.readByte() != 0;
        this.seeBeanList = in.createTypedArrayList(NovelSeeBean.CREATOR);
    }

    public static final Parcelable.Creator<NovelSeeSumBean> CREATOR = new Parcelable.Creator<NovelSeeSumBean>() {

        @Override
        public  NovelSeeSumBean createFromParcel(Parcel source) {
            return new NovelSeeSumBean(source);
        }

        @Override
        public NovelSeeSumBean[] newArray(int size) {
            return new NovelSeeSumBean[size];
        }
    };
}
