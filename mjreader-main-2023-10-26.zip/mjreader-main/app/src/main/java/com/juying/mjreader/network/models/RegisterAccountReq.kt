package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class RegisterAccountReq(
    val email: String,
    val phone: String,
    val password: String,
    val sex: Int
) : BaseReq()