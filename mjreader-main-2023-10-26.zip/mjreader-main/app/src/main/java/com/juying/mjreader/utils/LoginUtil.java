package com.juying.mjreader.utils;

import android.text.TextUtils;

import com.juying.mjreader.manager.SpManager;
import com.juying.mjreader.network.models.UserInfo;

/**
 * @Author Ycc
 * @Date 14:22
 */
public class LoginUtil {

    //清空User
    public static boolean isLogin() {
//        UserInfo userInfo = UserManager.INSTANCE.getUserInfo();
        UserInfo userInfo = SpManager.INSTANCE.getUserInfo();
        if (userInfo != null && !TextUtils.isEmpty(userInfo.getUserId())) {
            return true;
        }
        return false;
    }

    //清空User
    public static void userEmpty() {
        SpManager.INSTANCE.setUserInfo(null);
//        UserManager.INSTANCE.isLogin().setUserInfo(null);
    }
}
