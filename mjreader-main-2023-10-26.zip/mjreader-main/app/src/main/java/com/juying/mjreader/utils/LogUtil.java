package com.juying.mjreader.utils;

import android.util.Log;

public class LogUtil {
    private static int VERBOSE = 1;
    private static int DEBUG = 2;
    private static int INFO = 3;
    private static int WARN = 4;
    private static int ERROR = 5;
    private static int level = DEBUG;

    public static void v(String tag, String msg) {
        if (level <= VERBOSE) {
            Log.v(tag, msg + getThreadName());
        }
    }

    public static void d(String tag, String msg) {
        if (level <= DEBUG) {
            Log.d(tag, msg + getThreadName());
        }
    }

    public static void i(String tag, String msg) {
        if (level <= INFO) {
            Log.i(tag, msg + getThreadName());
        }
    }

    public static void w(String tag, String msg) {
        if (level <= WARN) {
            Log.w(tag, msg + getThreadName());
        }
    }

    public static void e(String tag, String msg) {
        if (level <= ERROR) {
            Log.e(tag, msg + getThreadName());
        }
    }


    private static String getThreadName() {
        return "；当前线程：" + Thread.currentThread().getName();
    }
}
