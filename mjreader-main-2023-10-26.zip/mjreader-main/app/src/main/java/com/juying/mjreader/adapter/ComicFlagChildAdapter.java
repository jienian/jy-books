package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeComicActivity;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.utils.DialogUtils;

import java.util.ArrayList;


public class ComicFlagChildAdapter extends BaseAdapter<ComicFlagChildAdapter.ViewHolder> {
    private SeeComicActivity context;
    private ComicSeeSumBean comicSeeSumBean;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;

    public ComicFlagChildAdapter(SeeComicActivity context, ComicSeeSumBean comicSeeSumBean) {
        this.comicSeeSumBean = comicSeeSumBean;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_comic_page, parent);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itme_flag_child, null, false);
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

//        BookBean bean = bookBean.getBookBeanList().get(showPosition.get(position));
//        ComicSeeBean comicSeeBean = bean.getComicSeeBean();

    }


    @Override
    public long getItemId(int position) {
//        return cpBean.getUsePageBeanList().get(position).getId();
        return super.getItemId(position);
//        return position;
    }

    @Override
    public int getItemCount() {

//        return getShowSize(bookBean);
        return 20;
    }


    private int getShowSize(BookBean bookBean) {
        if (bookBean == null || bookBean.getBookBeanList() == null || bookBean.getBookBeanList().size() == 0 || bookBean.getTreeNodeData() == null) {
            return 0;
        }
        showPosition = new ArrayList<>();
        for (int i = 0; i < bookBean.getBookBeanList().size(); i++) {
            BookBean bean = bookBean.getBookBeanList().get(i);
            if (bean.getMaxSize() > bean.getImputSchedule() || bean.isDirectory() || bean.getFileType().contains("pdf")) {
                //如果是未导入完成、目录、pdf就不在Rv里显示
            } else {
                showPosition.add(i);
            }
        }
        return showPosition.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private final LinearLayout ll;
        private final View itemview;

        private final TextView tvSelect;
        private final TextView tvNoSelect;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemview = itemView;
            tvNoSelect = itemView.findViewById(R.id.tv_no_select);
            tvSelect = itemView.findViewById(R.id.tv_select);
            ll = itemView.findViewById(R.id.ll_select);

//            itemView.setOnClickListener(v -> {
////                context.clickRV();
//                Log.d("TAG", "itme点击");
//            });
            itemView.setOnLongClickListener(v -> {
                log("itme长按");
                DialogUtils.longEnDialogView(context, new Runnable() {
                    @Override
                    public void run() {
                        to("删除", true);
                    }
                });
                return false;
            });
        }
    }




}
