package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class CheckEmailReq(val email: String): BaseReq()
