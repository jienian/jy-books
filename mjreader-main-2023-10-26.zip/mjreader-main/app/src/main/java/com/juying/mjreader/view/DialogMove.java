package com.juying.mjreader.view;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogMoreBinding;
import com.juying.mjreader.fragment.WifiFragment;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogMove extends BaseDialog {
    private boolean isSeeMode;
    public boolean isCurrentColl;
    private DialogMoreBinding vBinding;
    private DialogMoreListener listener;
    private WifiFragment context;
    private boolean isAd;


    public DialogMove(@NonNull WifiFragment context, int themeResId,boolean isAd, boolean isCurrentColl, boolean isSeeModee, DialogMoreListener listener) {
        super(context.getContext(), themeResId);
        this.isCurrentColl = isCurrentColl;
        this.isSeeMode = isSeeModee;
        this.context = context;
        this.listener = listener;
        vBinding = DialogMoreBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
//        initRecyclerView(bookBean);
        Window window = getWindow();

        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //区域外点击不关闭dialog
        setCanceledOnTouchOutside(false);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.7f);
        //设置弹出位置
        window.setGravity(Gravity.BOTTOM);
        initUi(isAd,isCurrentColl, isSeeModee);
        initListener();
    }


    public void initUi(boolean isAd,boolean currentIsColl, boolean isSeeModee) {
       this.isCurrentColl=currentIsColl;
       this.isAd=isAd;
        showIv1(currentIsColl);
        showIv2(isSeeModee);
        changeAd(isAd);
    }

    public void showIv2(boolean isSeeModee) {
        if (isSeeModee) {
            vBinding.iv2.setImageResource(R.drawable.reading_mode);
            vBinding.iv3.setImageResource(R.drawable.view_mode_red);
            setColor(false, vBinding.tv2);
            setColor(true, vBinding.tv3);
        } else {
            vBinding.iv2.setImageResource(R.drawable.reading_mode_red);
            vBinding.iv3.setImageResource(R.drawable.view_mode);
            setColor(true, vBinding.tv2);
            setColor(false, vBinding.tv3);
        }
    }

    private void setColor(boolean isSele, TextView tv) {
        if (isSele) {
            tv.setTextColor(context.getContext().getColor(R.color.spFFFE605F));
        } else {
            tv.setTextColor(context.getContext().getColor(R.color.spFF624243));
        }
    }


    public void showIv1(boolean currentIsColl) {
        if (currentIsColl) {
            vBinding.iv1.setImageResource(R.drawable.favorite_ok);
            vBinding.tv1.setText("已收藏");
        } else {
            vBinding.iv1.setImageResource(R.drawable.add_favorite);
            vBinding.tv1.setText("增添收藏");
        }
        setColor(currentIsColl, vBinding.tv1);
    }

    private void initListener() {

        vBinding.llHistory.setOnClickListener(v -> {
            listener.onClick(1, isCurrentColl);
        });
        vBinding.llAddHistory.setOnClickListener(v -> {
//            showIv1(isCurrentColl = !isCurrentColl);
            listener.onClick(2,isCurrentColl);
        });
        vBinding.llRead.setOnClickListener(v -> {
            showIv2(false);
            listener.onClick(3, isCurrentColl);
        });
        vBinding.llSee.setOnClickListener(v -> {
            if (WifiFragment.vBinding.webView.getVisibility()!= View.GONE) {
                showIv2(true);
            }
            listener.onClick(4, isCurrentColl);
        });

        vBinding.llAdvertisement.setOnClickListener(v -> {
            changeAd(isAd=!isAd);
            listener.onClick(5, isAd);
        });



        vBinding.ivOff.setOnClickListener(v -> dismiss());



    }

    private void changeAd(boolean isShieldAd) {
        if (isShieldAd) {
//            vBinding.tv6.setText("开启广告");
            vBinding.tv6.setTextColor(getContext().getColor(R.color.spFFFE605F));
            vBinding.iv6.setImageResource(R.drawable.block_ad_red);

        }else {
//            vBinding.tv6.setText("屏蔽广告");
            vBinding.tv6.setTextColor(getContext().getColor(R.color.spFF624243));
            vBinding.iv6.setImageResource(R.drawable.block_ad_ash);

        }
    }


    public interface DialogMoreListener {
        /**
         * @param type   1=历史  2=增添收藏  3=阅读模式  4=看图模式
         * @param isColl 是否收藏
         */
        void onClick(int type, boolean isColl);
    }


}
