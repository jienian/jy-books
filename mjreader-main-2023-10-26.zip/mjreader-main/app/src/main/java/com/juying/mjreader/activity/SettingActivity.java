/*
package com.juying.mjreader.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;

import androidx.appcompat.app.AppCompatActivity;

import com.blankj.utilcode.util.ConvertUtils;
import com.blankj.utilcode.util.FileUtils;
import com.blankj.utilcode.util.SPUtils;
import com.juying.mjreader.databinding.ActivitySettingBinding;
import com.juying.mjreader.fragment.JumpPermissionManagement;
import com.juying.mjreader.manager.UserManager;
import com.juying.mjreader.network.models.UserInfo;
import com.juying.mjreader.utils.ScreenUtils;

public class SettingActivity  extends AppCompatActivity {
    private ActivitySettingBinding vBinding;
    private UserManager userManager;

    public static void start(Context context) {
        Intent starter = new Intent(context, SettingActivity.class);
        context.startActivity(starter);
    }

    @Override
    protected  void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        vBinding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        vBinding.getRoot().setPadding(0, ScreenUtils.getStatusBarHeight(), 0 , 0 );

        //返回键
        vBinding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //允许通知
        boolean notific = SPUtils.getInstance().getBoolean("notific", false);

//        vBinding.switchNotification.setChecked(notific);

   */
/*     vBinding.switchNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SPUtils.getInstance().put("notific", isChecked);
            }
        });*//*



        //允许震动
      */
/*  boolean vibrate = SPUtils.getInstance().getBoolean("vibrate", false);
        vBinding.switchVibrate.setChecked(vibrate);
        vBinding.switchVibrate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SPUtils.getInstance().put("vibrate", isChecked);
            }
        });*//*



       */
/* //清除缓存
        long size = FileUtils.getLength(getCacheDir()) + FileUtils.getLength(getExternalCacheDir());
        vBinding.stvClearCache.setRightString(ConvertUtils.byte2FitMemorySize(size, 2));
        vBinding.stvClearCache.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileUtils.delete(getCacheDir());
                FileUtils.delete(getExternalCacheDir());
                vBinding.stvClearCache.setRightString("0.00B");
            }
        });
*//*

        //应用权限
        vBinding.stvPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JumpPermissionManagement.GoToSetting(SettingActivity.this);
            }
        });


        //退出登录
        vBinding.btLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   dialog.show(getSupportFragmentManager(), "退出登录");


            }
        });

    }

*/
/*
    private void logout() {
        if (loading) {
            return;
        }
        showLoading();
        LifecycleScope.launch(new Runnable() {
            @Override
            public void run() {
                UserInfo userinfo = UserManager.logout();
                if (userinfo != null) {
                    setResult(Activity.RESULT_OK);
                    finish();
                }
                hideLoading();
            }
        });
    }
*//*



}
*/
