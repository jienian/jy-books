package com.juying.mjreader.fragment

import android.location.GnssAntennaInfo.Listener
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.juying.mjreader.databinding.DialogFragmentUserAgreementBinding
import android.os.Process

/**
 * @author Nimyears
 *
 */
class UserAgreementDialogFragment : BaseFragment(){
    private var vBinding: DialogFragmentUserAgreementBinding? = null

    private var listener: Listener? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        vBinding = DialogFragmentUserAgreementBinding.inflate(inflater, null,false);

        initListener()

        return vBinding!!.root
    }

    private fun initListener(){

//        vBinding?.btAgree?.setOnClickListener {
//            listener?.onConfirm()
//        }
//
//        vBinding?.btDisagree?.setOnClickListener {
//            exitApp()
//        }
    }

    fun setListener(listener: Listener){
        this.listener = listener
    }

    private fun exitApp(){
        requireActivity().finish()
        Process.killProcess(Process.myPid())
    }
    interface Listener{
        fun onConfirm()
    }

    companion object{
        @JvmStatic
        fun newInstance() =
            UserAgreementDialogFragment
    }

}
