package com.juying.mjreader.view;

import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;

import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.juying.mjreader.R;
import com.juying.mjreader.fragment.ComicFragment;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogBookInput extends BaseDialog {
    private com.juying.mjreader.databinding.DialogBookInputBinding vBinding;

    ComicFragment comicFragment;

    public DialogBookInput(@NonNull ComicFragment comicFragment, DialogBrowseEditListener listener) {
        super(comicFragment.getContext(), R.style.DialogTheme);
        this.comicFragment = comicFragment;
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
//        View view = View.inflate(context, R.layout.dialog_book_input, null);
        vBinding = com.juying.mjreader.databinding.DialogBookInputBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);

        //区域外点击不关闭dialog
//        setCanceledOnTouchOutside(false);

        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

//FLAG_WATCH_OUTSIDE_TOUCH作用：如果点击事件发生在window之外，就会收到一个特殊的MotionEvent，为ACTION_OUTSIDE
//        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);


//        view.findViewById(R.id.ll1).setOnClickListener(view1 -> {
//            dismiss();
//            listener.onClickEdit();
//        });

        initListener();
    }

    private void initListener() {
        vBinding.view.setOnClickListener(v -> dismiss());
        vBinding.ll1.setOnClickListener(v -> {
//            comicFragment.exeImpurt(1);
            comicFragment.getPermission(1);
            dismiss();
        });
        vBinding.ll2.setOnClickListener(v -> {
//            comicFragment.exeImpurt(2);
            comicFragment.getPermission(2);
            dismiss();
        });
        vBinding.ll3.setOnClickListener(v -> {
            comicFragment.exeImpurt(3);
            dismiss();
        });
        vBinding.ll4.setOnClickListener(v -> {
            new DialogBookInputNet(getContext(), null).show();
            dismiss();
        });
        vBinding.ll5.setOnClickListener(v -> {
            to("开发中", false);
        });
        vBinding.ll6.setOnClickListener(v -> {
            to("开发中", false);
        });
        vBinding.famMenu.setOnFloatingActionsMenuUpdateListener(new FloatingActionsMenu.OnFloatingActionsMenuUpdateListener() {
            @Override
            public void onMenuExpanded() {

            }

            @Override
            public void onMenuCollapsed() {
                dismiss();
            }
        });

    }

    public interface DialogBrowseEditListener {
        void onClickEdit();
    }

    @Override
    public void show() {
        super.show();
        vBinding.famMenu.expand();
    }
}
