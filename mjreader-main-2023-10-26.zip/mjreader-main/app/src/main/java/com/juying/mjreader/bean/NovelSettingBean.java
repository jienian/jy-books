package com.juying.mjreader.bean;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.juying.mjreader.utils.config.Constant;


public class NovelSettingBean  implements Parcelable {

    /**
     * 小说展示模式【true 为竖屏=宫格，false 未横屏】默认宫格
     */
    boolean novelSettingMode = true;
    /**
     * 观看亮度 0f~1f
     */
    float viewingBrightness;
    /**
     *字号
     *
     */
    float textSize;
    /**
     * 是否夜间模式
     */
    boolean isModeNight;

    /**
     * 背景模式有5种颜色
     */
    int bgNovelSee = 5;

    /**
     * 翻页模式有4种动画
     */
    int pageTurning = 5;

    /**
     * 行距有四种
     */
    int space;
    /**
     * 锁屏有四种
     *
     */
    int lockScreen;

    /**
     * 是否音量键翻页
     */
    boolean isVolumeKeysPages;
    /**
     * 是否阅读时显示状态栏
     */
    boolean isReadShowStatusBar;



    public int getBgNovelSee() {
        return bgNovelSee;
    }

    public void setBgNovelSee(int bgNovelSee) {
        this.bgNovelSee = bgNovelSee;
        upSP();
    }

    public float getTextSize() {
        return textSize;
    }

    public void setTextSize(float textSize) {
        this.textSize = textSize;
        upSP();
    }

    public boolean getNovelSettingMode(){
        return novelSettingMode;
    }

    public boolean isNovelSettingMode() {
        return novelSettingMode;
    }

    public void setNovelSettingMode(boolean novelSettingMode) {
        this.novelSettingMode = novelSettingMode;
    }

    public int getPageTurning() {
        return pageTurning;
    }

    public void setPageTurning(int pageTurning) {
        this.pageTurning = pageTurning;
        upSP();
    }



    public int getSpace() {
        return space;
    }

    public void setSpace(int space) {
        this.space = space;
        upSP();
    }

    public int getLockScreen() {
        return lockScreen;
    }

    public void setLockScreen(int lockScreen) {
        this.lockScreen = lockScreen;
        upSP();
    }

    public static final Parcelable.Creator<NovelSettingBean> CREATOR = new Parcelable.Creator<NovelSettingBean>() {
        @Override
        public NovelSettingBean createFromParcel(Parcel source) {
            return new NovelSettingBean(source);
        }

        @Override
        public NovelSettingBean[] newArray(int size) {
            return new NovelSettingBean[size];
        }
    };

    /**
     * tips:切换列表时反序列解决闪退
     */
    @Expose
    private transient SharedPreferences.Editor spEdit;


    /**
     * 更新物理sp
     */
    public void upSP() {
        if (spEdit == null) {
            spEdit= Constant.NOVEL_SETTING_SP.edit();
        }
        spEdit.putBoolean(Constant.NOVEL_SETTING_MODE,novelSettingMode);
        spEdit.putBoolean("isModeNight", isModeNight);
        spEdit.putFloat("viewingBrightness", viewingBrightness);
        //     spEdit.putInt("modeNovelSee", modeNovelSee);
        spEdit.putBoolean("isVolumeKeysPages",isVolumeKeysPages);
        spEdit.putBoolean("isReadShowStatusBar", isReadShowStatusBar);
        spEdit.putInt("pageTurning",pageTurning);
        spEdit.putInt("bgNovelSee", bgNovelSee);
        spEdit.putFloat("textSize", textSize);
        spEdit.putInt("space", space);
        spEdit.putInt("lockScreen", lockScreen);

        spEdit.apply();
    }

    private void initSP() {
        novelSettingMode=(Constant.NOVEL_SETTING_SP.getBoolean(Constant.NOVEL_SETTING_MODE, true));
        isModeNight = (Constant.NOVEL_SETTING_SP.getBoolean("isModeNight", false));
        viewingBrightness = (Constant.NOVEL_SETTING_SP.getFloat("viewingBrightness", 0.5f));
        textSize = Constant.NOVEL_SETTING_SP.getFloat("textSize", 1f);
        bgNovelSee = (Constant.NOVEL_SETTING_SP.getInt("bgNovelSee", 5));
        isVolumeKeysPages = Constant.NOVEL_SETTING_SP.getBoolean("isVolumeKeysPages",false);
        isReadShowStatusBar = (Constant.NOVEL_SETTING_SP.getBoolean("isReadShowStatusBar", false));
        pageTurning = Constant.NOVEL_SETTING_SP.getInt("pageTurning",5);
        space = (Constant.NOVEL_SETTING_SP.getInt("space", 4));
        lockScreen =(Constant.NOVEL_SETTING_SP.getInt("space", 4));
    }

    public  NovelSettingBean(){
        initSP();
    }

    @Override
    public void writeToParcel( Parcel dest, int flags) {
        dest.writeByte(this.isModeNight ? (byte) 1 : (byte) 0);
        dest.writeFloat(this.viewingBrightness);
        dest.writeInt(this.bgNovelSee);
        dest.writeByte(this.isVolumeKeysPages ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isReadShowStatusBar ? (byte) 1 : (byte) 0);
        dest.writeInt(this.pageTurning);
        dest.writeFloat(this.textSize);

        dest.writeInt(this.space);
        dest.writeInt(this.lockScreen);
    }


    public void readFromParcel(Parcel source) {
        this.isModeNight = source.readByte() != 0;
        this.viewingBrightness = source.readFloat();
        this.bgNovelSee = source.readInt();
        this.isVolumeKeysPages = source.readByte() != 0;
        this.isReadShowStatusBar = source.readByte() != 0;
        this.pageTurning = source.readInt();
        this.textSize = source.readFloat();
        this.space = source.readInt();
        this.lockScreen = source.readInt();
    }


    protected NovelSettingBean(Parcel in) {
        this.isModeNight = in.readByte() != 0;
        this.bgNovelSee = in.readInt();
        this.isVolumeKeysPages = in.readByte() != 0;
        this.isReadShowStatusBar = in.readByte() != 0;
        this.pageTurning = in.readInt();
        this.textSize = in.readFloat();
        this.space = in.readInt();
        this.lockScreen = in.readInt();
//        this.spEdit = in.readParcelable(SharedPreferences.Editor.class.getClassLoader());

    }



    @Override
    public int describeContents() {
        return 0;
    }


    public float getViewingBrightness() {
        return viewingBrightness;
    }

    public void setViewingBrightness(float viewingBrightness) {
        this.viewingBrightness = viewingBrightness;
        upSP();
    }


    public boolean isModeNight() {
        return isModeNight;
    }

    public void setModeNight(boolean modeNight) {
        isModeNight = modeNight;
    }

    public boolean isVolumeKeysPages() {
        return isVolumeKeysPages;
    }


    public void setVolumeKeysPages(boolean volumeKeysPages) {
        isVolumeKeysPages = volumeKeysPages;
        upSP();
    }

    public boolean isReadShowStatusBar() {
        return isReadShowStatusBar;
    }

    public void setReadShowStatusBar(boolean readShowStatusBar) {
        isReadShowStatusBar = readShowStatusBar;
        upSP();
    }


    @Override
    public String toString() {
        return "NovelSettingBean{"  +
                "novelSettingMode=" + novelSettingMode +
                ", isModeNight=" + isModeNight +
                ", viewingBrightness=" + viewingBrightness +
                ", bgNovelSee=" + bgNovelSee +
                ", isVolumeKeysPages=" + isVolumeKeysPages +
                ", isReadShowStatusBar=" + isReadShowStatusBar +
                ", pageTurning=" + pageTurning +
                ", textSize=" + textSize +
                ", space=" + space +
                ", lockScreen=" + lockScreen +
                '}';
    }
}
