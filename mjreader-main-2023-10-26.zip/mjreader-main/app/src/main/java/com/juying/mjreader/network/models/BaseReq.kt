package com.juying.mjreader.network.models

import android.os.Build
import com.juying.mjreader.MjApplication
import com.github.gzuliyujiang.oaid.DeviceIdentifier
import com.juying.mjreader.manager.SpManager
import com.juying.mjreader.network.util.NetworkUtils
import com.juying.mjreader.utils.AppUtil

/**
 * @author Nimyears
 */
@Suppress("unused") //忽悠警告
open class BaseReq {

  val userId = SpManager.userInfo?.userId ?: ""
  val sign = ""
  val clientTime = System.currentTimeMillis()
  val deviceType: String = Build.MODEL
  val deviceBrand: String = Build.MANUFACTURER
  val uuid: String = DeviceIdentifier.getClientId()
  val platform = 0
  val netType = NetworkUtils.getNetworkType(MjApplication.CONTEXT)
  val appVersion = AppUtil.getVersionName(MjApplication.CONTEXT)
  val versionCode = AppUtil.getVersionCode(MjApplication.CONTEXT)
  val appKey = AppUtil.getPackageName(MjApplication.CONTEXT)
 // val appChannel = Config.channel
  val ipAddr = NetworkUtils.getLocalIp()
  val systemVersion: String = Build.VERSION.RELEASE


/* //   val userId = SpManager.userInfo?.userId ?: ""

    val sign = ""
    val clientTime = System.currentTimeMillis()
  //  val uuid: String = DeviceIdentifier
    //客户端平台
    val platform = 0
    val deviceType: String = Build.MODEL
    val deviceBrand: String = Build.MANUFACTURER
    val netType = NetworkUtils.getNetworkType(MjApplication.CONTEXT)
    val appVersion = AppUtil.getVersionName(MjApplication.CONTEXT)
    val versionCode = AppUtil.getVersionCode(MjApplication.CONTEXT)
    val appKey = AppUtil.getPackageName(MjApplication.CONTEXT)
  // val appChannel = Config()
    val ipAddr = NetworkUtils.getLocalIp()
    val systemVersion: String = Build.VERSION.RELEASE*/
}
