package com.juying.mjreader.manager

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.juying.mjreader.MjApplication
import com.juying.mjreader.network.models.UserInfo

/**
 * @author Nimyears
 */
object SpManager {

    val SP_NAME = "SpManager"
    private val sp: SharedPreferences by lazy {
        MjApplication.CONTEXT.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
    }

    //是否同意隐私政策
    private const val IS_AGREE_PRIVACY_KEY = "isAgreePrivacyPolicy"

    private const val USER_INFO_KEY = "userInfo"
     var userInfo: UserInfo?
        get() {
            val json = sp.getString(USER_INFO_KEY, null)
            return Gson().fromJson(json, UserInfo::class.java)
        }
        set(value) {
            if (value == null) {
                sp.edit().remove(USER_INFO_KEY).commit()
            } else {
                sp.edit().putString(USER_INFO_KEY, Gson().toJson(value)).commit()
            }
        }

}