package com.juying.mjreader.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

import com.github.barteksc.pdfviewer.PDFView;


/**
 * @Author Ycc
 * @Date 17:00
 */
public class AutoPDFView extends PDFView {


    private int delayTime = 2500;
    //自动滚动速度，默认15 标准

    private boolean running = false; //标示是否正在自动轮询
    private boolean canRun = true;//标示是否可以自动轮询,可在不需要的是否置false
    private RvListener rvListener;

//    public AutoPDFView(@NonNull Context context) {
//        super(context);
//    }
//
//    public AutoPDFView(@NonNull Context context, @Nullable AttributeSet attrs) {
//        super(context, attrs);
//    }
//
//    public AutoPDFView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyle) {
//        super(context, attrs, defStyle);
//    }

    /**
     * Construct the initial view
     *
     * @param context
     * @param set
     */
    public AutoPDFView(Context context, AttributeSet set) {
        super(context, set);
    }


    private final Runnable mTask = new Runnable() {
        @Override
        public void run() {
            if (running && canRun) {
//                if (canScrollVertically(-1)) {
//                    //如果到底了，就自动停止,并通知外层
//                    stopPlay();
//                    if (rvListener != null) {
//                        rvListener.moveBottomComplete();
//                    }
//                } else {


//                ValueAnimator animation = ValueAnimator.ofFloat(getCurrentYOffset(),getCurrentYOffset()+(((float) speed)/100));
//                animation.setInterpolator(new DecelerateInterpolator());
//                animation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
//                    @Override
//                    public void onAnimationUpdate(@NonNull ValueAnimator animation) {
//                        //获取当前值
//                        //重新绘制布局，实现显示效果的改变,本例并不需要调用requestLayout()
//                        jumpTo(getCurrentPage()+1);
//                        performPageSnap();
//
//                    }
//                });
////                animation.addListener(yAnimation);
//                animation.setDuration(delayTime);
//                //开始延时时长
//                animation.setStartDelay(0);
//                animation.setRepeatCount(5);
//                animation.start();
                if (getCurrentPage() == getPageCount() - 1) {
                    //最后一页,不处理
                } else {
                    jumpTo(getCurrentPage() + 1, true);
                }
//                scrollBy(0, (int) speed);
                int page = getCurrentPage();
//                moveRelativeTo(0,-speed);
                float currentYOffset = getCurrentYOffset();
//                setMouseClick(0, (int) (getCurrentYOffset()-250));
              Log.d("TAG", "当前页：" + page + ";当前Y:" + currentYOffset);

//                ValueAnimator animation = ValueAnimator.ofFloat(0, speed);
//                AnimationManager.YAnimation yAnimation = new AnimationManager.YAnimation();

//                animation.setInterpolator(new DecelerateInterpolator());
//                animation.addUpdateListener(yAnimation);
//                animation.addListener(yAnimation);
//                animation.setDuration(delayTime);
//                animation.start();

//                setMouseClick(0,500);
                float xxx = getX();
                float xxxY = getY();
//                simulateClick(AutoScrollHandle.this,xxx,xxxY);
//                setMouseClick((int)xxx, (int) xxxY+5);

                postDelayed(mTask, delayTime);

//                page = determineValidPageNumberFrom(getCurrentPage());
//                float offset = page == 0 ? 0 : -pdfFile.getPageOffset(page, zoom);

//                moveTo(getCurrentXOffset(),getCurrentYOffset()-speed);

//                performPageSnap();
//               scrollTo(0, speed+=speed);
//                scrollBy(0, (int) getCurrentYOffset());
//                }


            }
        }
    };

    @Override
    public void jumpTo(int page, boolean withAnimation) {
        super.jumpTo(page, withAnimation);

    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopPlay();
    }

    public void stopPlay() {
        running = false;
        removeCallbacks(mTask);
    }

    public void startPlay() {
        canRun = true;
        running = true;
        removeCallbacks(mTask);
        // 这里没调用Handler，view里面自带postDelayed
        postDelayed(mTask, delayTime);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.d("TAG", "onTouchEvent: " + event.getY());
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Log.d("TAG", "onInterceptTouchEvent: " + ev.getY());
        return super.onInterceptTouchEvent(ev);
    }

    /**
     * 设置速度
     *
     * @param type 1=慢 2=较慢 3=标准 4=较快 5=快
     */
    public void setSpeed(int type) {
        if (type == 1) {
            delayTime = 3500;
        } else if (type == 2) {
            delayTime = 3000;
        } else if (type == 3) {
            delayTime = 2500;
        } else if (type == 4) {
            delayTime = 2000;
        } else if (type == 5) {
            delayTime = 1500;
        }
    }

    public void setRvListener(RvListener rvListener) {
        this.rvListener = rvListener;
    }


    private interface RvListener {
        //移动到底了
        void moveBottomComplete();
    }

    public void setMouseClick(int x, int y) {
        MotionEvent evenDownt = MotionEvent.obtain(System.currentTimeMillis(),
                System.currentTimeMillis() + 100, MotionEvent.ACTION_DOWN, x, y, 0);
        dispatchTouchEvent(evenDownt);
        MotionEvent eventUp = MotionEvent.obtain(System.currentTimeMillis(),
                System.currentTimeMillis() + 100, MotionEvent.ACTION_UP, x, y, 0);
        dispatchTouchEvent(eventUp);
        evenDownt.recycle();
        eventUp.recycle();
    }
}