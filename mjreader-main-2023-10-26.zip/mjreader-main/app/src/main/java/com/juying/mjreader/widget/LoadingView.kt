package com.juying.mjreader.widget

import com.airbnb.lottie.LottieAnimationView
/**
 * @author Nimyears
 */
interface LoadingView {
    var loading: Boolean
    var loadingView: LottieAnimationView?

    fun showLoading()
    fun hideLoading()

}
