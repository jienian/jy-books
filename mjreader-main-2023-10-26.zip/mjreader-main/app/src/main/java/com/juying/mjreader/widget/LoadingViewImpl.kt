package com.juying.mjreader.widget

import android.view.View
import com.airbnb.lottie.LottieAnimationView
/**
 * @author Nimyears
 */
open class LoadingViewImpl: LoadingView {
    override var loading = false
    override var loadingView: LottieAnimationView? = null

    override fun showLoading() {
        if(loading) return

        loading = true
        loadingView?.visibility = View.VISIBLE

    }

    override fun hideLoading(){
        if(!loading) return

        loading = false
        loadingView?.visibility = View.GONE
    }
}