package com.juying.mjreader.manager

import android.util.Log
import com.google.gson.Gson
import com.juying.mjreader.manager.SpManager
import com.juying.mjreader.network.models.UserInfo
import com.juying.mjreader.network.service.UserApiService
import com.juying.mjreader.network.util.Md5Util
import com.juying.mjreader.network.util.ValidateUtil
import kotlinx.coroutines.delay
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File
import java.net.URI

object UserManager11 {

//    val userInfo: UserInfo?
//        get() = SpManager.userInfo
//
//    val isLogin: Boolean
//        get() = userInfo?.status == 1
//
//    val sex: Int
//        get() = userInfo?.sex ?: 0
//
//    private var dataSyncUserId = ""
//
//    suspend fun loginByUuid(sex: Int): UserInfo? {
//        val res = UserApiService.loginByUuid(sex)
//        return res?.data?.let {
//            SpManager.userInfo = it
//            it
//        }
//    }
//
//    suspend fun login(username: String, password: String): UserInfo? {
//        dataSyncUserId = ""
//        val isEmail = ValidateUtil.isEmail(username)
//        val res = if (isEmail) {
//            UserApiService.loginEmail(username, password)
//        } else {
//            UserApiService.loginPhone(username, password)
//        }
//        return res?.data?.let {
//            SpManager.userInfo = it
//            it
//        }
//    }
//
//    suspend fun registerAndLogin(username: String, password: String): UserInfo? {
//        val isEmail = ValidateUtil.isEmail(username)
//        val (email, phone) = if (isEmail) Pair(username, "") else Pair("", username)
//        val res = UserApiService.registerAccount(email, phone, password, sex)
//        return res?.data?.let {
//            login(username, password)
//        }
//    }
//
//    suspend fun changeUserinfo(nickname: String, avatarUrl: String, sex: Int): Boolean {
//        val newItem = SpManager.userInfo?.copy(nickname = nickname, avatar = avatarUrl, sex = sex)
//        val res = UserApiService.changeUserinfo(nickname, avatarUrl, sex)
//        res?.let {
//            SpManager.userInfo = newItem
//            return true
//        }
//        return false
//    }
//
//    suspend fun logout(): UserInfo? {
//        return loginByUuid(sex)
//    }
//
//    suspend fun checkUsername(username: String): Boolean {
//        val isEmail = ValidateUtil.isEmail(username)
//        val res = if (isEmail) {
//            UserApiService.checkEmail(username)
//        } else {
//            UserApiService.checkPhone(username)
//        }
//        res?.data?.let {
//            return !it.isExist
//        }
//        return false
//    }
//
//    suspend fun fileUpload(filePath: String): String? {
//        val file = File(filePath)
//        if (file.exists()) {
//            val requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file)
//            val filePart = MultipartBody.Part.createFormData("file", file.name, requestFile)
//            val md5 = Md5Util.md5(file)
//            md5?.let {
//                val res = UserApiService.fileUpload(filePart, md5)
//                res?.let {
//                    it.data?.accessUrl?.let { url ->
//                        return URI(url).path
//                    }
//                }
//            }
//        }
//        return null
//    }
//
//    suspend fun startDataSync() {
//        while (true) {
//            if (NetworkUtils.isNetworkDisconnected(MyApplication.context)) {
//                delay(5000)
//                continue
//            }
//
//            if (!isLogin) {
//                delay(2000)
//                continue
//            }
//
//            if (!SpManager.dataSync) {
//                delay(2000)
//                continue
//            }
//
//            syncLocalData()
//            delay(20 * 1000)
//        }
//    }
//
//    private suspend fun syncLocalData() {
//        val recordList = RecordService.loadSync()
//        recordList.forEach {
//            if (it.deleted == 0) {
//                it.syncTimestamp = System.currentTimeMillis()
//                val isSuccess = dataSyncSubmit(DataSyncType.RECORD, it.id.toString(), it)
//                if (isSuccess) {
//                    it.syncTimestamp += 1000
//                    RecordService.update(it)
//                }
//            } else {
//                val isSuccess = dataSyncRemove(DataSyncType.RECORD, it.id.toString())
//                if (isSuccess) {
//                    it.syncTimestamp = 0L
//                    RecordService.delete(it)
//                }
//            }
//        }
//
//        val accountList = AccountService.loadSync()
//        accountList.forEach {
//            if (it.deleted == 0) {
//                it.syncTimestamp = System.currentTimeMillis()
//                val isSuccess = dataSyncSubmit(DataSyncType.ACCOUNT, it.id.toString(), it)
//                if (isSuccess) {
//                    it.syncTimestamp += 1000
//                    AccountService.update(it)
//                }
//            } else {
//                val isSuccess =  dataSyncRemove(DataSyncType.ACCOUNT, it.id.toString())
//                if (isSuccess) {
//                    it.syncTimestamp = 0L
//                    AccountService.delete(it)
//                }
//            }
//        }
//
//        val propertyList = PropertyService.loadSync()
//        propertyList.forEach {
//            if (it.deleted == 0) {
//                it.syncTimestamp = System.currentTimeMillis()
//                val isSuccess = dataSyncSubmit(DataSyncType.PROPERTY, it.id.toString(), it)
//                if (isSuccess) {
//                    it.syncTimestamp += 1000
//                    PropertyService.update(it)
//                }
//            } else {
//                val isSuccess = dataSyncRemove(DataSyncType.PROPERTY, it.id.toString())
//                if (isSuccess) {
//                    it.syncTimestamp += 1000
//                    PropertyService.update(it)
//                }
//            }
//        }
//
//        val assetList = AssetService.loadSync()
//        assetList.forEach {
//            it.syncTimestamp = System.currentTimeMillis()
//            val isSuccess = dataSyncSubmit(DataSyncType.ASSET, it.date, it)
//            if (isSuccess) {
//                it.syncTimestamp += 1000
//                AssetService.update(it)
//            }
//        }
//
//        val periodList = PeriodService.loadSync()
//        periodList.forEach {
//            if (it.deleted == 0) {
//                it.syncTimestamp = System.currentTimeMillis()
//                val isSuccess = dataSyncSubmit(DataSyncType.PERIOD, it.id.toString(), it)
//                if (isSuccess) {
//                    it.syncTimestamp += 1000
//                    PeriodService.update(it)
//                }
//            } else {
//                val isSuccess =dataSyncRemove(DataSyncType.PERIOD, it.id.toString())
//                if (isSuccess) {
//                    it.syncTimestamp = 0L
//                    PeriodService.delete(it)
//                }
//            }
//        }
//
//
//        Log.d("dataSync Local", "数据同步完成")
//    }
//
//    suspend fun syncRemoteData() {
//        val assetList = dataSyncGet<AssetEntity>(DataSyncType.ASSET, 0)
//        assetList?.let {
//            AssetService.insertAll(it)
//        }
//
//        val accountList = dataSyncGet<AccountEntity>(DataSyncType.ACCOUNT, 0)
//        accountList?.let {
//            AccountService.insertAll(it)
//        }
//
//        val propertyList = dataSyncGet<PropertyEntity>(DataSyncType.PROPERTY, 0)
//        propertyList?.let {
//            PropertyService.insertAll(it)
//        }
//
//        val periodList = dataSyncGet<PeriodEntity>(DataSyncType.PERIOD, 0)
//        periodList?.let {
//            PeriodService.insertAll(it)
//        }
//
//        val recordList = dataSyncGet<RecordEntity>(DataSyncType.RECORD, 0)
//        recordList?.let {
//            RecordService.insertAll(it)
//        }
//
//        Log.d("dataSync Remote", "---")
//    }
//
//    private suspend inline fun <reified T> dataSyncGet(type: DataSyncType, size: Int): List<T>? {
//        val res = UserApiService.dataSyncGet(createTopUserId(), type.value, size)
//        return res?.data?.let {list ->
//            list.map {
//                Gson().fromJson(it.content, T::class.java)
//            }
//        }
//    }
//
//    private suspend fun dataSyncRemove(type: DataSyncType, dataId: String): Boolean {
//        val res =
//            UserApiService.dataSyncRemove(createTopUserId(), type.value, createDataId(type, dataId))
//        return res != null
//    }
//
//    private suspend fun dataSyncSubmit(type: DataSyncType, dataId: String, content: Any): Boolean {
//        val res = UserApiService.dataSyncSubmit(
//            createTopUserId(),
//            type.value,
//            createDataId(type, dataId),
//            Gson().toJson(content)
//        )
//        Log.d("dataSync Submit", "${type.value} ${Gson().toJson(content)}")
//        return res != null
//    }
//
//    private fun createTopUserId(): String {
//        if (dataSyncUserId.isNotEmpty()) return dataSyncUserId
//
//        userInfo?.let {
//            val key = AppUtil.getPackageName(MyApplication.context) + it.userId
//            dataSyncUserId = Md5Util.md5(key)
//        }
//        return dataSyncUserId
//    }
//
//    private fun createDataId(type: DataSyncType, dataId: String): String {
//        val key = type.value + dataId + userInfo?.userId
//        return Md5Util.md5(key)
//    }

}