package com.juying.mjreader.adapter.novel;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.bean.BookInfo;
import com.juying.mjreader.databinding.ActivityNovelDetailBinding;

import java.util.Collections;
import java.util.List;

/**
 * @Athuor Nmyears
 * SectionAdapter 用于适配目录展示
 */
public class SectionAdapter extends RecyclerView.Adapter<SectionAdapter.ViewHolder> {
    private ActivityNovelDetailBinding vBinding;


    private List<BookInfo> sectionList;
    private Context mContext;
    private int currentSelected = 0;

    private boolean isReversed = false;

    public void setBookBeanList(List<BookInfo> bookBeanList) {
        this.sectionList = bookBeanList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.section_item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        BookInfo section;
        String sectionNum = "";
        if (!isReversed) {
            section = sectionList.get(position);
        //    sectionNum = "第" + (position + 1) + "章 ";
        }
        else {
            section = sectionList.get(sectionList.size() - 1 - position);
     //       sectionNum = "第" + (sectionList.size() - position - 1) + "章 ";
        }

        holder.tvTitle.setText(sectionNum + section.getSection().replaceAll("===", ""));

        if (position == currentSelected) {
            holder.tvRead.setVisibility(View.VISIBLE);
            holder.tvRead.setTextColor(Color.parseColor("#ff0000")); //红色
            holder.tvTitle.setTextColor(Color.parseColor("#ff0000"));
        } else {
            holder.tvRead.setVisibility(View.GONE);
            holder.tvRead.setTextColor(ContextCompat.getColor(mContext, R.color.black_11));
            holder.tvTitle.setTextColor(ContextCompat.getColor(mContext, R.color.black_11));
        }


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(section, position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return sectionList != null ? sectionList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        TextView tvRead;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvRead = itemView.findViewById(R.id.tvRead);
        }
    }

    /**
     * 当列表项被点击时会调用此方法
     * section 被点击的列表项
     * position 被点击的列表项的索引
     */
    public interface OnItemClickListener {
        //接口的方法
        void onItemClick(BookInfo section, int position);
    }

    private OnItemClickListener onItemClickListener;

    public OnItemClickListener getOnItemClickListener() {
        return onItemClickListener;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setChapter(int pos) {
        currentSelected = pos;
        notifyDataSetChanged();
    }

    public void reversed() {
        isReversed = !isReversed;
        currentSelected = Math.abs(sectionList.size() - currentSelected);
        notifyDataSetChanged();
    }


    /*    private void  initListener () {
     */

}
