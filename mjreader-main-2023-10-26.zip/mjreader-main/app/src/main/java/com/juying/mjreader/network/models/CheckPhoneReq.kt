package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class CheckPhoneReq(val phone: String): BaseReq()
