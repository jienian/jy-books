package com.juying.mjreader.activity;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.github.barteksc.pdfviewer.BuildConfig;
import com.github.barteksc.pdfviewer.listener.OnPageScrollListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.google.gson.Gson;
import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.R;
import com.juying.mjreader.adapter.novel.SectionAdapter;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.BookInfo;
import com.juying.mjreader.bean.ComicSettingBean;
import com.juying.mjreader.bean.NovelSeeBean;
import com.juying.mjreader.bean.NovelSeeSumBean;
import com.juying.mjreader.bean.NovelSettingBean;
import com.juying.mjreader.databinding.ActivitySeeNovelBinding;
import com.juying.mjreader.fragment.NovelDetailDialogFragment;
import com.juying.mjreader.manager.NovelSettingManager;
import com.juying.mjreader.utils.DeviceInfo;
import com.juying.mjreader.utils.GsonUtils;
import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.NovelMode;
import com.juying.mjreader.utils.ScreenUtils;
import com.juying.mjreader.utils.SeeNovelMode;
import com.juying.mjreader.utils.SystemBarUtils;
import com.juying.mjreader.view.DialogBrowseEdit;
import com.juying.mjreader.view.DialogMask;
import com.juying.mjreader.widget.page.PageLoader;
import com.juying.mjreader.widget.page.PageMode;
import com.juying.mjreader.widget.page.PageStyle;
import com.juying.mjreader.widget.page.PageView;
import com.juying.mjreader.widget.page.TxtChapter;
import com.shockwave.pdfium.PdfDocument;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Nimyears
 */
public class SeeNovelActivity extends BaseActivity {
    public static final String EXTRA_COLL_BOOK = "extra_coll_book";
    public static final String EXTRA_IS_COLLECTED = "extra_is_collected";
    private static final int WHAT_CATEGORY = 1;
    private static final int WHAT_CHAPTER = 2;
    private static final int WHAT_PROGRESS_UPDATE = 3;
    public NovelSettingBean novelSettingBean;
    public BookBean currentBean;//文档页目录Bean点击的子Bean,也就是当前展示的Bean,【一定是文件】
    boolean isAnimationHave = false;
    boolean titleSwitch = true;
    /*activity_see_novel*/
    private ActivitySeeNovelBinding vBinding;
    private NovelSeeSumBean novelSeeSumBean;
    private BookBean novelBean;
    /**
     * 当前显示seeBean
     */
    private SeeNovelMode seeNovelMode;
    private LinearLayoutManager layoutManager;
    private int seePosition = 0;//当前观看位于文件夹里的位置
    private boolean isPDFShowMode;
    private boolean isFullScreen;
    private SectionAdapter mSectionAdapter;

    /**
     * 目前是不是自动阅读模式
     */
    private boolean isAuto = false;
    private BookBean bookBean;
    /*****************view******************/
    private NovelSettingManager mNovelSettingManager;
    private PageLoader mPageLoader;
    private Animation mTopInAnim;
    private Animation mTopOutAnim;
    private Animation mBottomInAnim;
    private Animation mBottomOutAnim;
    private SectionAdapter mCategoryAdapter;
    private boolean isPDFMode;
    private String[] pdfType = new String[]{"pdf", "application/pdf"};

    /***************params*****************/
    private PageMode mPageMode;
    private boolean isCollected = false;
    private boolean isNightMode = false;
    private boolean isRegistered = false;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable lockScreenRunnable;

    private ComicSettingBean comicSettingBean;
    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case WHAT_CATEGORY:
                    //          vBinding.novelDirectory.setSelection(mPageLoader.getChapterPos());
                    break;
                case WHAT_CHAPTER:
                    mPageLoader.openChapter();
                    break;
                case WHAT_PROGRESS_UPDATE:
                    int curCount = msg.arg1;
                    int totalCount = msg.arg2;
                    // todo 调用函数存储进度
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivitySeeNovelBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        DeviceInfo deviceInfo = DeviceInfo.getDeviceInfo(this);
        Log.d(TAG, "is pad1.." + deviceInfo.isPad());
        initBean();

        initUi(novelSeeSumBean, novelSettingBean);
        initView();
        initWidget();
        initListener();
    }

    private void initBean() {
        comicSettingBean = new ComicSettingBean();
        Intent intent = getIntent();
        String bookBeanJson = intent.getStringExtra("bean");
        Gson gson = GsonUtils.getInstance();
        novelBean = gson.fromJson(bookBeanJson, BookBean.class);
        String settingBeanJson = intent.getStringExtra("settingBean");
        novelSettingBean = gson.fromJson(settingBeanJson, NovelSettingBean.class);
        seePosition = intent.getIntExtra("seePosition", 0);
        if (!isDataNull(novelBean)) {
            log("传递数据=" + novelBean.toString());
            log("传递数据数据总量=" + novelBean.getBookBeanList().size());
            for (int i = 0; i < novelBean.getBookBeanList().size(); i++) {
                BookBean bookBean = novelBean.getBookBeanList().get(i);
                novelBean.getBookBeanList().get(i).setNovelSeeBean(new NovelSeeBean(bookBean.getFilePath()));
            }
            currentBean = novelBean.getShowChildBean();
            isPDFShowMode = currentBean.getFileType().contains("pdf");

        }
        String filepath = novelBean.getFilePath();
        isPDFShowMode = Arrays.asList(pdfType).contains(novelBean.getFileType());
        if (isPDFShowMode) {
            vBinding.pdfView.setVisibility(VISIBLE);
            // vBinding.ViewPager.setVisibility(View.GONE);
            initPDFview(filepath);
            toggleMenu(true);
        } else {
            try {
                InputStream inputStream = new FileInputStream(filepath);
                readStream(inputStream, novelBean);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        bookBean = getIntent().getParcelableExtra(EXTRA_COLL_BOOK);
        isCollected = getIntent().getBooleanExtra(EXTRA_IS_COLLECTED, false);
        //  isNightMode = NovelSettingManager.getInstance().isNightMode();
        //  mPageMode = NovelSettingManager.getInstance().getPageMode();
    }

    private void initWidget() {
        // 如果 API < 18 取消硬件加速
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR2
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            vBinding.PageView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        //隐藏StatusBar
        vBinding.PageView.post(() -> hideSystemBar());

        //获取页面加载器
        mPageLoader = vBinding.PageView.getPageLoader(novelBean.convertToCollBookBean());
        mPageLoader.refreshChapterList();

        initBottomMenu();

//        toggleNightMode();

    }

    private void initPDFview(String filePath) {

        vBinding.pdfView.fromFile(new File(filePath))

                .defaultPage(0)//默认显示第几页
                .enableSwipe(true)
                .enableAntialiasing(true)
                .swipeHorizontal(false)//是否水平展示
//                .enableDoubletap(false)//双击放大缩小
                .onTap(e -> {
                    //只在点击时执行一下
                    LogUtil.d("TAG", "onTap执行,动作：" + e.getAction());
                    return false;
                })
                .onPageScroll(new OnPageScrollListener() {
                    @Override
                    public void onPageScrolled(int page, float positionOffset) {
                        Log.d("TAG", "onPageScrolled: 执行=page=" + page + ";positionOffset=" + positionOffset);
                    }
                })
                .onPageChange((page, pageCount) -> {
                    // 计算进度
                    novelBean.setReadPosition(page * 100 / pageCount);
                    NovelMode.saveSP(SeeNovelActivity.this, novelBean);
                    // 页面切换时的回调函数，存读取进度
                    Log.d("TAG", "onPageChanged: 执行=page=" + page + ";pageCount=" + pageCount);
                    mHandler.removeMessages(WHAT_PROGRESS_UPDATE);
                    Message msg = mHandler.obtainMessage(WHAT_PROGRESS_UPDATE);
                    msg.arg1 = page;
                    msg.arg2 = pageCount;
                    // 延迟500ms，方式反复io影响阅读流畅性
                    mHandler.sendMessageDelayed(msg, 500);
                })
                .enableAnnotationRendering(false)
                .onLoad(nbPages -> {
                    log("成功加载PDF,loadComplete: 执行=nbPages=" + nbPages);
                    //TODO 获得文档书签信息,没有有书签的PDF,先用模拟书签数据
//                    iniTreeNodeData();
                    com.shockwave.pdfium.PdfDocument.Meta meta = vBinding.pdfView.getDocumentMeta();
                    Log.e(TAG, "title = " + meta.getTitle());
                    Log.e(TAG, "author = " + meta.getAuthor());
                    Log.e(TAG, "subject = " + meta.getSubject());
                    Log.e(TAG, "keywords = " + meta.getKeywords());
                    Log.e(TAG, "creator = " + meta.getCreator());
                    Log.e(TAG, "producer = " + meta.getProducer());
                    Log.e(TAG, "creationDate = " + meta.getCreationDate());
                    Log.e(TAG, "modDate = " + meta.getModDate());

                    printBookmarksTree(vBinding.pdfView.getTableOfContents(), "-");
                })
                .scrollHandle(new DefaultScrollHandle(SeeNovelActivity.this))
                .enableAntialiasing(true)
                .fitEachPage(false)
                .load();
    }

    public void printBookmarksTree(List<PdfDocument.Bookmark> tree, String sep) {
        for (PdfDocument.Bookmark b : tree) {

            Log.e(TAG, String.format("%s %s, p %d", sep, b.getTitle(), b.getPageIdx()));

            if (b.hasChildren()) {
                printBookmarksTree(b.getChildren(), sep + "-");
            }
        }
    }

    private void readStream(InputStream inputStream, BookBean bookBean) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bufferedInputStream));

        try {
            String line;
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line).append("\r\n");
            }

            List<String> sections = new ArrayList<>();
            List<BookInfo> bookInfos = new ArrayList<>();
            Pattern p = Pattern.compile("===.*?===?");

            Matcher m = p.matcher(stringBuilder.toString());

            while (m.find()) {
                String group = m.group();
                sections.add(group);

                BookInfo bookInfo = new BookInfo();

                bookInfo.setSection(group);
                bookInfos.add(bookInfo);
            }

            bookBean.setSections(sections);
            bookBean.setSections1(bookInfos);
            if (!sections.isEmpty()) {
                readStream(stringBuilder.toString(), sections.get(0), sections.get(1));
            } else {
                //      mPageLoader.skipToChapter();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readStream(InputStream inputStream, String start, String end) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bufferedInputStream));

        try {
            String line;
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line).append("\r\n");
            }

            int startIndex = stringBuilder.toString().indexOf(start);
            int endIndex = stringBuilder.toString().indexOf(end);
            if (startIndex != -1 && endIndex != -1) {
                try {
                    String result = stringBuilder.substring(startIndex + start.length(), endIndex);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readStream(String allContent, String start, String end) {

        int startIndex = allContent.indexOf(start);
        int endIndex = allContent.indexOf(end);
        if (startIndex != -1 && endIndex != -1) {
            try {
                String result = allContent.substring(startIndex + start.length(), endIndex);
                Log.e(TAG, "readStream: " + result);

                //   mPageLoader.skipToChapter( );
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void initUi(NovelSeeSumBean novelSeeSumBean, NovelSettingBean novelSettingBean) {
        /*cbSetting视图的背景透明度设置为 26*/
        vBinding.cbSetting.getBackground().mutate().setAlpha(26);
        setSettingUi(novelSettingBean);
    }

    private void setSettingUi(NovelSettingBean novelSettingBean) {
        vBinding.sb1.setProgress((int) (novelSettingBean.getViewingBrightness() * 100));

        vBinding.sbs.setProgress((int) (novelSettingBean.getTextSize() * 40));

        vBinding.switch1.setChecked(novelSettingBean.isVolumeKeysPages());
        vBinding.switch2.setChecked(novelSettingBean.isReadShowStatusBar());

        vBinding.cbDay.setChecked(comicSettingBean.isModeNight());
        vBinding.cbDay.setText(comicSettingBean.isModeNight() ? "日间" : "夜间");
        vBinding.cbDay.setCompoundDrawablesWithIntrinsicBounds(null, comicSettingBean.isModeNight() ? getDrawable(R.drawable.day1) : getDrawable(R.drawable.night), null, null);

        clickRaeShowState(novelSettingBean.isReadShowStatusBar());

        fullscreen(novelSettingBean.isReadShowStatusBar());

    /*    if (novelSettingBean.isReadShowStatusBar()) {
            vBinding.view2.setVisibility(View.GONE);
        } else {
            vBinding.view2.setVisibility(View.VISIBLE);
        }*/
    }

    public void requestDrawOverLays(boolean checkedId) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请授予权限", Toast.LENGTH_SHORT).show();
            //跳转到相应软件的设置页面
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, -9);
        } else {
            // 授权成功之后执行的方法
            checkedSet(checkedId);
        }
    }

//    @SuppressLint("MissingSuperCall")
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == -9) {
//            if (!Settings.canDrawOverlays(this)) {
//                log("悬浮窗授权失败");
//            } else {
//                log("悬浮窗授权成功");
//                checkedSet(true);
//            }
//        }
//    }


    private void checkedSet(boolean checkedId) {
        DialogMask dialogMask = DialogMask.example(MjApplication.CONTEXT);
        if (checkedId) {
            dialogMask.show();
        } else {
            dialogMask.dismiss();
        }
        comicSettingBean.setModeNight(checkedId);
        vBinding.cbDay.setText(checkedId ? "日间" : "夜间");
        vBinding.cbDay.setCompoundDrawablesWithIntrinsicBounds(null, getDrawable(R.drawable.select_day_night), null, null);
    }


    private void initBottomMenu() {
        //判断是否全屏
        if (NovelSettingManager.getInstance().isFullScreen()) {
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) vBinding.llBottom.getLayoutParams();
            params.bottomMargin = ScreenUtils.getNavigationBarHeight();
            vBinding.llBottom.setLayoutParams(params);
        } else {
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) vBinding.llBottom.getLayoutParams();
            params.bottomMargin = 0;
            vBinding.llBottom.setLayoutParams(params);
        }
    }

    private boolean isDataNull(BookBean bookBean) {
        return bookBean == null || bookBean.getBookBeanList() == null || bookBean.getBookBeanList().size() == 0;
    }

    private void initView() {
        String fileName = novelBean.getFileName();
        vBinding.tvTitle.setText(fileName.split("\\.")[0].replace("《", "").replace("》", ""));

    }

    private void clickRaeShowState(boolean isChecked) {
        fullscreen(isChecked);
        if (isChecked) {
            vBinding.view2.setVisibility(View.VISIBLE);
        } else {
            vBinding.view2.setVisibility(View.GONE);
        }

    }

    private DialogBrowseEdit dialogBrowseEdit;

    /*触摸、长按、滑动事件*/
    @SuppressLint("ClickableViewAccessibility")
    private void initListener() {
        /******************PageView**********************************************/
        vBinding.PageView.setTouchListener(new PageView.TouchListener() {
            @Override
            public boolean onTouch() {
                return !hideReadMenu();
            }

            @Override
            public void center() {
                toggleMenu(true);
            }

            @Override
            public void prePage() {
            }

            @Override
            public void nextPage() {
            }

            @Override
            public void cancel() {
            }
        });

        /******************mPageLoader**********************************************/
        if (mPageLoader != null) {
            mPageLoader.setOnPageChangeListener(
                    new PageLoader.OnPageChangeListener() {
                        @Override
                        public void onChapterChange(int pos) {
                        }

                        @Override
                        public void requestChapters(List<TxtChapter> requestChapters) {
                            //   mPresenter.loadChapter(mBookId, requestChapters);
                            mHandler.sendEmptyMessage(WHAT_CATEGORY);
                            //隐藏提示
                            //  vBinding.readTvPageTip.setVisibility(GONE);
                        }

                        @Override
                        public void onCategoryFinish(List<TxtChapter> chapters) {
                            for (TxtChapter chapter : chapters) {
                                chapter.setTitle(chapter.getTitle().replace("===", ""));
                            }
                            //       mCategoryAdapter.refreshItems(chapters);
                            mHandler.sendEmptyMessage(WHAT_CHAPTER);
                        }

                        @Override
                        public void onPageCountChange(int count) {
                            vBinding.sb.setMax(Math.max(0, count - 1));
                            vBinding.sb.setProgress(0);
                            // 如果处于错误状态，那么就冻结使用
                            if (mPageLoader.getPageStatus() == PageLoader.STATUS_LOADING
                                    || mPageLoader.getPageStatus() == PageLoader.STATUS_ERROR) {
                                vBinding.sb.setEnabled(false);
                            } else {
                                vBinding.sb.setEnabled(true);
                            }
                        }


                        @Override
                        public void onPageChange(int pos) {
                            vBinding.sb.post(() -> vBinding.sb.setProgress(pos));
                            //setCurrentShowPosition是阅读位置的方法

                          /*  NovelSeeBean noelSeeBean = novelBean.getNovelSeeBean();
                          novelSeeBean.setCurrentShowPosition(mPageLoader.getChapterPos() * 100 /(novelBean.getSections().size() - 1));
*/
                            novelBean.setReadPosition(mPageLoader.getChapterPos() * 100 / (novelBean.getSections().size() - 1));
                            NovelMode.saveSP(SeeNovelActivity.this, novelBean);
                        }
                    }
            );
        }

        vBinding.ivBack.setOnClickListener(v -> {
                    Intent intent = new Intent();
                    intent.putExtra("readPosition", novelBean.getReadPosition());
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                }
        );

/*        vBinding.ivEdit.setOnClickListener(v -> {
            if (dialogBrowseEdit == null) {
                dialogBrowseEdit = new DialogBrowseEdit(this, new DialogBrowseEdit.Callback() {
                    @Override
                    public void onActionSelected() {
                        DialogUtils.windowDialogView(SectionFragment.this, R.layout.dialog_new_group, "添加书签", new DialogUtils.Callback() {
                            @Override
                            public void onConfirm() {
                                // 在此处处理确认点击事件
                            }

                            @Override
                            public void onCancel() {
                                // 在此处处理取消点击事件
                            }
                        });
                    }
                });
            }
            dialogBrowseEdit.show();  // 显示DialogBrowseEdit
        });*/


        vBinding.novelDirectory.setOnClickListener(v -> {
            log("点击目录");

            if (isPDFShowMode) {
                Toast.makeText(this, "没有章节", Toast.LENGTH_SHORT).show();
            } else {
                NovelDetailDialogFragment dialogFragment = new NovelDetailDialogFragment();
                dialogFragment.setNowPos(mPageLoader.getChapterPos() - 1);
                Bundle bundle = new Bundle();

                bundle.putParcelable("bean", novelBean);
                dialogFragment.setArguments(bundle);

                dialogFragment.setOnItemClickListener((start, end) -> {
                    //跳转章节方法
                    try {
                        String filePath = novelBean.getFilePath();
                        InputStream inputStream = new FileInputStream(filePath);
                        int pos = novelBean.getSections().indexOf(start);
                        if (pos != -1) mPageLoader.skipToChapter(pos + 1);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                });
                dialogFragment.show(getSupportFragmentManager(), "");
            }
        });

        vBinding.novelSchedule.setOnClickListener(v -> {
            setSwitch(vBinding.llSchedule, true);
        });
        /*进度*/
        vBinding.tvTop.setOnClickListener(v -> {
            if (mPageLoader.skipPreChapter() && mCategoryAdapter != null) {
                mCategoryAdapter.setChapter(mPageLoader.getChapterPos());
            }
        });

        vBinding.tvBelow.setOnClickListener(v -> {
            if (mPageLoader.skipNextChapter() && mCategoryAdapter != null) {
                mCategoryAdapter.setChapter(mPageLoader.getChapterPos());
            }
        });

        vBinding.sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (vBinding.llBottom.getVisibility() == VISIBLE) {

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                log("拖动开始当前值：" + seekBar.getProgress());
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int pagePos = vBinding.sb.getProgress();
                if (pagePos != mPageLoader.getPagePos()) {
                    mPageLoader.skipToPage(pagePos);
                }
            }
        });


        vBinding.textView4.setOnClickListener(v -> {
            setSwitch(vBinding.llSetting, true);
        });

        vBinding.cbSetting.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                vBinding.llMore.setVisibility(VISIBLE);
            } else {
                vBinding.llMore.setVisibility(View.GONE);
            }
        });

        /*音量键翻页*/
        vBinding.switch1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            novelSettingBean.setVolumeKeysPages(isChecked);
        });
        /*阅读显示状态栏*/
        vBinding.switch2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            novelSettingBean.setReadShowStatusBar(isChecked);
            clickRaeShowState(isChecked);
        });

        // 夜间模式
//        vBinding.cbDay.setOnClickListener(v -> {
//            if (isNightMode) {
//                isNightMode = false;
//            } else {
//                isNightMode = true;
//            }
//            if (mPageLoader != null) {
//                mPageLoader.setNightMode(isNightMode);
//            }
//            toggleNightMode();
//        });

        vBinding.cbDay.setOnCheckedChangeListener((buttonView, isChecked) -> {
            requestDrawOverLays(isChecked);
        });



        /*亮度模式*/
        vBinding.sb1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                SeeNovelMode.setBrightness(SeeNovelActivity.this, ((float) progress) / 100);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                float p = ((float) seekBar.getProgress()) / 100;
                novelSettingBean.setViewingBrightness(p);
            }
        });

        /*字体大小模式*/
        vBinding.sbs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float size = (float) progress / seekBar.getMax();
                mPageLoader.setTextSize(progress + 40);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                log("滑动开始");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                log("滑动结束");
                float s = ((float) seekBar.getProgress()) / 40;
                novelSettingBean.setTextSize(s);
            }
        });

        /*翻页*/
        vBinding.rgPage.setOnCheckedChangeListener((group, checkedId) -> {
            PageMode pageMode = PageMode.SIMULATION;
            if (checkedId == vBinding.seeSettingCover.getId()) {
                pageMode = PageMode.COVER;
                novelSettingBean.setPageTurning(1);
            } else if (checkedId == vBinding.seeSettingScroll.getId()) {
                pageMode = PageMode.SCROLL;
                novelSettingBean.setPageTurning(2);
            } else if (checkedId == vBinding.seeSettingSimulation.getId()) {
                pageMode = PageMode.SIMULATION;
                novelSettingBean.setPageTurning(3);
            } else if (checkedId == vBinding.seeSettingSlide.getId()) {
                pageMode = PageMode.SLIDE;
                novelSettingBean.setPageTurning(4);
            }
            mPageLoader.setPageMode(pageMode);
        });

        vBinding.tvAuto.setOnClickListener(v -> {
            setAutoSwitch(1);
        });
        vBinding.tvAutoSetting.setOnClickListener(v -> {
            setAutoSwitch(2);
        });
        vBinding.ivSetting.setOnClickListener(v -> {
            setAutoSwitch(2);
        });
        vBinding.tvOff.setOnClickListener(v -> {
            setAutoSwitch(3);
        });

        vBinding.rgSpace.setOnCheckedChangeListener((group, checkedId) -> {

            if (checkedId == vBinding.spaceSmall.getId()) {
                novelSettingBean.setSpace(1);
                applySpaceSetting(1);

            } else if (checkedId == vBinding.spaceLess.getId()) {
                novelSettingBean.setSpace(2);
                applySpaceSetting(2);

            } else if (checkedId == vBinding.spaceStandard.getId()) {
                novelSettingBean.setSpace(3);
                applySpaceSetting(3);

            } else if (checkedId == vBinding.spaceBig.getId()) {
                novelSettingBean.setSpace(4);
                applySpaceSetting(4);
            }
        });

        vBinding.rgBg.setOnCheckedChangeListener((group, checkedId) -> {
            int bg = 0;
            int more = 0;
            int ll = 0;
            int di = 0;
            if (checkedId == vBinding.seeSettingBg1.getId()) {
                bg = 1;

            } else if (checkedId == vBinding.seeSettingBg2.getId()) {
                bg = 2;

            } else if (checkedId == vBinding.seeSettingBg3.getId()) {
                bg = 3;

            } else if (checkedId == vBinding.seeSettingBg4.getId()) {
                bg = 4;

            } else if (checkedId == vBinding.seeSettingBg5.getId()) {
                bg = 5;
            }

            novelSettingBean.setBgNovelSee(bg);
            setBackground(bg, more, ll, di);
        });

        //锁屏
        vBinding.settingLock.setOnCheckedChangeListener((group, checkedId) -> {

            requestWriteSettingsPermission();

            int lock = 0;
            if (checkedId == vBinding.seeSettingLockSystem.getId()) {
                lock = 1;
                // 阻止屏幕自动锁屏
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, getSysScreenOffTime(this));

            } else if (checkedId == vBinding.seeSettingLockMinutes5.getId()) {
                lock = 2;
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 1000 * 60 * 5);

            } else if (checkedId == vBinding.seeSettingLockMinutes15.getId()) {
                lock = 3;
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 1000 * 60 * 15);

            } else if (checkedId == vBinding.seeSettingLockMinutes30.getId()) {
                log("minutes30..." + lock);
                lock = 4;
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 1000 * 60 * 30);

            }
            novelSettingBean.setLockScreen(lock);
        });
    }

    //动态权限
    private void requestWriteSettingsPermission() {
        if (!Settings.System.canWrite(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    public static int getSysScreenOffTime(Context context) {
        int screenOffTimeout = 0;
        try {
            screenOffTimeout = Settings.System.getInt(context.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT);
        } catch (Settings.SettingNotFoundException e) {
            if (BuildConfig.DEBUG) {
                Log.e("ScreenSettings", "Setting not found", e);
            }
        }
        return screenOffTimeout;
    }

    /*行距设置*/
    public void applySpaceSetting(int spaceMode) {
        int actualSpace = 10;
        switch (spaceMode) {
            case 1:
                actualSpace = 10;//1.0f;
                break;
            case 2:
                actualSpace = 30;//1.25f;
                break;
            case 3:
                actualSpace = 50;//1.5f;
                break;
            case 4:
                actualSpace = 80;//2.0f;
                break;
        }
        mPageLoader.setTextInterval(actualSpace);
    }

    public void setBackground(int bg, int more, int ll, int di) {
        PageStyle bgStyle = null;
        switch (bg) {
            case 1:
                bgStyle = PageStyle.BG_0;
                bg = getResources().getColor(R.color.bg1);
                more = getResources().getColor(R.color.bg1);
                ll = getResources().getColor(R.color.bg1);
                di = getResources().getColor(R.color.bg1);
                break;
            case 2:
                di = getResources().getColor(R.color.bg2);
                bgStyle = PageStyle.BG_1;
                bg = getResources().getColor(R.color.bg2);
                more = getResources().getColor(R.color.bg2);
                ll = getResources().getColor(R.color.bg2);
                break;
            case 3:
                di = getResources().getColor(R.color.bg3);
                bg = getResources().getColor(R.color.bg3);
                more = getResources().getColor(R.color.bg3);
                ll = getResources().getColor(R.color.bg3);
                bgStyle = PageStyle.BG_2;
                break;
            case 4:
                di = getResources().getColor(R.color.bg4);
                bgStyle = PageStyle.BG_3;
                bg = getResources().getColor(R.color.bg4);
                more = getResources().getColor(R.color.bg4);
                ll = getResources().getColor(R.color.bg4);
                break;
            case 5:
                di = getResources().getColor(R.color.bg5);
                bgStyle = PageStyle.BG_4;
                bg = getResources().getColor(R.color.bg5);
                more = getResources().getColor(R.color.bg5);
                ll = getResources().getColor(R.color.bg5);
                break;
            default:
                di = getResources().getColor(R.color.bg1);
                bgStyle = PageStyle.BG_1;
                bg = getResources().getColor(R.color.bg1);
                more = getResources().getColor(R.color.bg1);
                ll = getResources().getColor(R.color.bg1);
                break;
        }

        //    vBinding.view2.setBackgroundColor(di);
        vBinding.ll11.setBackgroundColor(bg);
        vBinding.llSetting.setBackgroundColor(more);
        vBinding.llBottom.setBackgroundColor(ll);
        vBinding.PageView.setBgColor(bgStyle);
    }

    private void setAutoSwitch(int type) {
        //点击外层开启自动阅读
        if (type == 1) {
            clickCentre();
            vBinding.llAuto.setVisibility(View.VISIBLE);
            vBinding.llAutoSetting.setVisibility(View.GONE);
            isAuto = true;
            //点击自动阅读的设置
        } else if (type == 2) {
            vBinding.llAuto.setVisibility(View.GONE);
            vBinding.llAutoSetting.setVisibility(View.VISIBLE);
            //点击退出自动阅读
        } else if (type == 3) {
            vBinding.llAuto.setVisibility(View.GONE);
            vBinding.llAutoSetting.setVisibility(View.GONE);
            isAuto = false;
        }
    }

    private void clickCentre() {

        if (isAuto) return;
        ;

        if (!isAnimationHave) {
            isAnimationHave = true;

            if (titleSwitch) {

                startPopsAnimTrans1(vBinding.ll1, -(vBinding.ll1.getHeight()));
                startPopsAnimTrans1(vBinding.llSchedule, (vBinding.llSchedule.getHeight()));
                startPopsAnimTrans1(vBinding.llBottom, (vBinding.llBottom.getHeight()));
                startPopsAnimTrans1(vBinding.llSetting, (vBinding.llSetting.getHeight()));

                if (vBinding.llSetting.getVisibility() == View.VISIBLE) {
                    setSwitch(vBinding.llSetting, false);
                }

                if (vBinding.llSchedule.getVisibility() == View.VISIBLE) {
                    setSwitch(vBinding.llSchedule, false);
                }

                titleSwitch = false;
            } else {
                startPopsAnimTrans1(vBinding.ll1, 0);
                startPopsAnimTrans1(vBinding.llSchedule, 0);
                startPopsAnimTrans1(vBinding.llBottom, 0);
                startPopsAnimTrans1(vBinding.llSetting, 0);
                titleSwitch = true;
            }
            isAnimationHave = false;
        }
    }

    private void hideSystemBar() {
        SystemBarUtils.hideStableStatusBar(this);
        if (isFullScreen) {
            SystemBarUtils.hideStableNavBar(this);
        }
    }

    private void setSwitch(View v, boolean isShow) {
        if (isShow) {
            v.setVisibility(View.VISIBLE);
            vBinding.llBottom.setVisibility(View.GONE);
            startPopsAnimTrans1(v, 0);
        } else {
            vBinding.llBottom.setVisibility(View.VISIBLE);
            startPopsAnimTrans1(v, v.getHeight());
        }
    }

    private void showSystemBar() {
        //显示
        SystemBarUtils.showUnStableStatusBar(this);
        if (isFullScreen) {
            SystemBarUtils.showUnStableNavBar(this);
        }
    }

    /**
     * 切换菜单栏的可视状态
     * 默认是隐藏的
     */
    private void toggleMenu(boolean hideStatusBar) {
        initMenuAnim();
        if (isPDFShowMode) {
            // 关闭底部菜单
            vBinding.ll1.setVisibility(View.GONE);
            vBinding.llSchedule.setVisibility(GONE);
            vBinding.llBottom.setVisibility(View.GONE);

            hideSystemBar();
        } else if (vBinding.ll1.getVisibility() == View.VISIBLE) {
            // 关闭顶部和底部菜单
            vBinding.ll1.startAnimation(mTopOutAnim);
            vBinding.llSchedule.startAnimation(mBottomOutAnim);
            vBinding.llBottom.startAnimation(mBottomOutAnim);

            vBinding.ll1.setVisibility(View.GONE);
            vBinding.llSchedule.setVisibility(GONE);
            vBinding.llBottom.setVisibility(View.GONE);

            hideSystemBar();

        } else {
            // 显示顶部和底部菜单
            vBinding.ll1.setVisibility(View.VISIBLE);
            vBinding.llBottom.setVisibility(View.VISIBLE);

            vBinding.ll1.startAnimation(mTopInAnim);

            vBinding.llBottom.startAnimation(mBottomInAnim);

            // 显示系统状态栏
            showSystemBar();

            setSwitch(vBinding.llSetting, false);
        }
    }

    /**
     * 隐藏阅读界面的菜单显示
     */
    private boolean hideReadMenu() {
        if (vBinding.ll1.getVisibility() == VISIBLE || vBinding.llBottom.getVisibility() == VISIBLE) {
            // 如果顶部或底部菜单是可见的，隐藏它们
            toggleMenu(true);
            hideSystemBar();  // 隐藏系统状态栏
            return true;
        }
        return false;
    }

    /* @Override
     public void onBackPressed() {
         if (vBinding.ll1.getVisibility() == View.VISIBLE) {
             // 非全屏收缩，全屏下直接退出
             if (!NovelSettingManager.getInstance().isFullScreen()) {
                 toggleMenu(true);
                 return;
             } else {
                 finish();
             }
         }
     }*/
    @Override
    public void onBackPressed() {
        if (vBinding.llSetting.getVisibility() == View.VISIBLE) {
//            clickCentre();
            vBinding.llSetting.setVisibility(View.GONE);
            vBinding.llBottom.setVisibility(View.VISIBLE);
        } else if (vBinding.ll1.getVisibility()==VISIBLE) {
//            clickCentre();
            toggleMenu(true);
        } else {
            Intent intent = new Intent();
            intent.putExtra("readPosition", novelBean.getReadPosition());
            setResult(Activity.RESULT_OK, intent);
            finish();
        }

    }


    //初始化菜单动画
    private void initMenuAnim() {
        if (mTopInAnim != null) return;

        mTopInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_top_in);
        mTopOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_top_out);
        mBottomInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_bottom_in);
        mBottomOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_bottom_out);
        //设置速度
        mTopOutAnim.setDuration(200);
        mBottomOutAnim.setDuration(200);
    }

    /*动画纵移*/
    private void startPopsAnimTrans1(View view, float... xy) {
        ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(view, "translationY", xy);
        objectAnimatorX.setDuration(350);
        objectAnimatorX.start();
    }

    private void toggleNightMode() {

        if (isNightMode) {

            vBinding.cbDay.setText("日光");
            Drawable drawable = ContextCompat.getDrawable(this, R.drawable.day);
            vBinding.cbDay.setCompoundDrawablesWithIntrinsicBounds(null, drawable, null, null);

        } else {

            vBinding.cbDay.setText("夜间");

            Drawable drawable = ContextCompat.getDrawable(this, R.drawable.night);

            vBinding.cbDay.setCompoundDrawablesWithIntrinsicBounds(null, drawable, null, null);

        }
    }
}