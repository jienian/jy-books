package com.juying.mjreader.activity;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.adapter.ComicWifiSeeImageAdapter1;
import com.juying.mjreader.adapter.ComicWifiSeeImageAdapter2;
import com.juying.mjreader.adapter.ComicWifiSeeImageAdapter3;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.databinding.ActivitySeeImageBinding;
import com.juying.mjreader.utils.ComicMode;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.utils.DeviceInfo;
import com.juying.mjreader.utils.FilesUtils;
import com.juying.mjreader.utils.RecyclerViewUtil;
import com.juying.mjreader.utils.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;

/**
 * 网络看图模式页
 */
public class SeeImageActivity extends BaseActivity {

    private ActivitySeeImageBinding vBinding;
    private ComicSeeSumBean comicSeeSumBean;
    private LinearLayoutManager linearLayoutManager1;

    private PagerSnapHelper pagerSnapHelper1;

    //是否是连看模式，用做Adapter里设置控件属性
    public boolean isContinuitySeeMode = false;
    private ComicWifiSeeImageAdapter1 comicWifiSeeImageAdapter1;
    private ComicWifiSeeImageAdapter2 comicWifiSeeImageAdapter2;
    private ComicWifiSeeImageAdapter3 comicWifiSeeImageAdapter3;

    private double windowW;
    //webView过来的标题
    private String webViewTitle;
    //所有已加载图片所占内存大小
    private long allMemoryOccupied;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivitySeeImageBinding.inflate(getLayoutInflater());
        windowW = DeviceInfo.getDeviceInfo(this).getWindowW();
        setContentView(vBinding.getRoot());

        boolean isInitOk = initBean();
        if (isInitOk) {
            iniUi();
            initLister();
        }
    }

    private void iniUi() {
        initRv2();
        upTitle(0);
    }

    public void upTvNum() {
        vBinding.tvNum.setText(comicSeeSumBean.getSelectListBean().size() + "");
    }

    /**
     * 头部章节更新
     *
     * @param currentPosition 当前位置
     */
    @SuppressLint("SetTextI18n")
    public void upTitle(int currentPosition) {
        int size = comicSeeSumBean.getSeeBeanList().size();
        if (size == 0) {
            vBinding.tvTitle.setText("0");
        }
        vBinding.tvTitle.setText(size + "/" + (currentPosition + 1));
    }

    private void initRv2() {
        if (comicWifiSeeImageAdapter2 == null) {
            LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
            comicWifiSeeImageAdapter2 = new ComicWifiSeeImageAdapter2(this, comicSeeSumBean);
//            PagerSnapHelper pagerSnapHelper2 = new PagerSnapHelper();//不用一页一页的翻
//            pagerSnapHelper2.attachToRecyclerView(vBinding.rv2);
            linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
            vBinding.rv2.setLayoutManager(linearLayoutManager2);
            vBinding.rv2.setAdapter(comicWifiSeeImageAdapter2);
        }
    }

    private void initRv1() {
        if (linearLayoutManager1 == null) {
            linearLayoutManager1 = new LinearLayoutManager(this);
            linearLayoutManager1.setOrientation(LinearLayoutManager.HORIZONTAL);
            pagerSnapHelper1 = new PagerSnapHelper();
            pagerSnapHelper1.attachToRecyclerView(vBinding.rv1);
            comicWifiSeeImageAdapter1 = new ComicWifiSeeImageAdapter1(this, comicSeeSumBean);
            vBinding.rv1.setLayoutManager(linearLayoutManager1);
            vBinding.rv1.setAdapter(comicWifiSeeImageAdapter1);
        }
    }


    private void initRv3() {
        if (comicWifiSeeImageAdapter3 == null) {
            GridLayoutManager GridLayoutManager = new GridLayoutManager(this, 3);
            comicWifiSeeImageAdapter3 = new ComicWifiSeeImageAdapter3(this, comicSeeSumBean);
            vBinding.rv3.setLayoutManager(GridLayoutManager);
            vBinding.rv3.setAdapter(comicWifiSeeImageAdapter3);
        }
    }


    private boolean initBean() {
        Intent intent = getIntent();
        String[] imageArrays = {};
        if (intent != null) {
//            ArrayList<String> imageList = intent.getStringArrayListExtra("images");
            imageArrays = intent.getStringArrayExtra("images");
            webViewTitle = intent.getStringExtra("webView_title");
            List<String> imageDataSource = Arrays.asList(imageArrays);
            //TODO 获得到的URL不一定全部都能加载正确，除了要在Rv里做UI处理，还根据需要要不要提前做后缀判断
//        还要处理标题，如果有特殊符号，要去除
//            webViewTitle = "12#3*151.15#*@#.154#9\\64/125/64.jpg";
            log("接收到网页标题：" + webViewTitle + ";\nUrl：" + imageDataSource);
            webViewTitle = StringUtils.delSpecialChar(Constant.SPECIAL_STRING, webViewTitle);
            log("矫正后标题网页标题：" + webViewTitle + ";\nUrl：" + imageDataSource);
        }
        if (imageArrays.length == 0) {
            return false;
        }

        List<ComicSeeBean> list = new ArrayList<>();
        comicSeeSumBean = new ComicSeeSumBean(0, false, list);
//        for (int i = 0; i < Constant.images.length; i++) {
        for (int i = 0; i < imageArrays.length; i++) {
            ComicSeeBean childBean = new ComicSeeBean(imageArrays[i], null, null, false, 0, true);
            list.add(childBean);
        }
//        webViewTitle = "张三";
        getDatasync(list, () -> {
            //最后一个获取完了之后再更新UI
            log("当前线程：" + Thread.currentThread().getName());
            runOnUiThread(() -> initRv1());
        });

        return true;
    }


    public void getDatasync(List<ComicSeeBean> list, Runnable runnable) {
        List<Integer> listInt = new ArrayList<>();//计数
        for (int i = 0; i < list.size(); i++) {
            int finalI = i;
            getExecutorService(2).execute(() -> {
                ComicSeeBean comicSeeBean = list.get(finalI);
//    public void getDatasync(ComicSeeBean comicSeeBean,int position) {
                try {
                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder()
                            .url(comicSeeBean.getUrl())//请求接口，如果需要传参拼接到接口后面
                            .build(); //创建Request对象
                    okhttp3.Response response = client.newCall(request).execute();//得到Response对象
                    if (response.isSuccessful() && response.code() == 200) {
                        Bitmap bitmap;
                        ResponseBody responseBody = response.body();
                        byte[] bytes = responseBody.bytes();
//                            bitmap=BitmapFactory.decodeStream(response.body().byteStream());
                        bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        if (bitmap == null) {
                            log("加载失败：" + comicSeeBean.getUrl());
                            comicSeeBean.setImageLoadFail(true);
                        } else {
                            int w = bitmap.getWidth();
                            int h = bitmap.getHeight();
                            double newH = windowW / w * h;
                            comicSeeBean.setWidth((int) windowW);
                            comicSeeBean.setHeight((int) newH);
//                            log("加载成功：源宽高：" + w + "*" + h + ",新宽高：" + windowW + "*" + newH + ";当前线程：" + Thread.currentThread().getId());
                            comicSeeBean.setMemoryUsageSize(bitmap.getByteCount());
                        }
                    } else {
                        comicSeeBean.setImageLoadFail(true);
                    }  //此时的代码执行在子线程，修改UI的操作使用handler跳转到UI进程
                } catch (Exception e) {
                    log("加载失败：" + comicSeeBean.getUrl() + ";信息:" + e.getMessage());
                    comicSeeBean.setImageLoadFail(true);
                }
                listInt.add(finalI);
                if (listInt.size() == list.size()) {
                    runnable.run();
                }
            });

        }

    }


    private void initLister() {
        vBinding.cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            //从WebView过来默认都是单图模式，选中是连看模式，显示标题：单图模式；
            log("当前观看索引：" + comicSeeSumBean.getCurrentShowPosition());
            if (isChecked) {
                vBinding.cb.setText("单图模式");
                isContinuitySeeMode = true;
                linearLayoutManager1.setOrientation(LinearLayoutManager.VERTICAL);
                pagerSnapHelper1.attachToRecyclerView(null);
                vBinding.rv2.setVisibility(View.GONE);
            } else {
                vBinding.cb.setText("连看模式");
                linearLayoutManager1.setOrientation(LinearLayoutManager.HORIZONTAL);
                pagerSnapHelper1.attachToRecyclerView(vBinding.rv1);
                vBinding.rv2.setVisibility(View.VISIBLE);
                isContinuitySeeMode = false;
            }
            //先刷新
            comicWifiSeeImageAdapter1.notifyDataSetChanged();
            //再调整到对应位置
            vBinding.rv1.post(() -> {
                linearLayoutManager1.scrollToPosition(comicSeeSumBean.getCurrentShowPosition());
                upTitle(comicSeeSumBean.getCurrentShowPosition());
//                    comicWifiSeeImageAdapter1.notifyItemChanged(position);
            });
        });
        vBinding.lView.setRecyclerViewClickListener((v1, direction) -> {
            if (vBinding.llAllSave.getVisibility() != View.VISIBLE && direction == 5) {
                clickCentre();
            }
        });
        vBinding.rv1.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int currAbsPostion = linearLayoutManager1.findFirstVisibleItemPosition();
//                RecyclerView.LayoutParams rl;
//                try {
//                    rl = (RecyclerView.LayoutParams) recyclerView.getChildAt(0).getLayoutParams();
//                } catch (Exception e) {
//                    return;
//                }
//                 currAbsPostion = rl.getAbsoluteAdapterPosition();
                if (currAbsPostion < 0) {
                    return;
                }

                List<Integer> visibleItmePosition = RecyclerViewUtil.getVisibleItmePosition(recyclerView, linearLayoutManager1);
                int currentPosition;
                if (visibleItmePosition.size() == 0) {
                    currentPosition = currAbsPostion;
                } else {
                    currentPosition = visibleItmePosition.get(0);
                }

                if (currentPosition == comicSeeSumBean.getCurrentShowPosition()) {
                    //可见View没变
                    return;
                }
                comicSeeSumBean.setCurrentShowPosition(currentPosition);
                upRv2(currentPosition);
                comicSeeSumBean.setCurrentShowPosition(currentPosition);
                upTitle(currentPosition);
            }
        });
    }


    public void doOnClick(View v) {
        if (v == vBinding.cbAll) {
            if (comicSeeSumBean != null && comicWifiSeeImageAdapter3 != null) {
                int selectNum = comicSeeSumBean.startAllSelect();
                comicWifiSeeImageAdapter3.notifyDataSetChanged();
                vBinding.tvNum.setText(selectNum + "");
            }
        } else if (v == vBinding.ivBack) {
            finish();
        } else if (v == vBinding.tvOff) {
            if (comicSeeSumBean.cancelAllSelect()) {
                comicWifiSeeImageAdapter3.notifyDataSetChanged();
                vBinding.tvNum.setText(0 + "");
            } else {
                vBinding.rl.setVisibility(View.VISIBLE);
                vBinding.llAllSave.setVisibility(View.GONE);
            }
        } else if (v == vBinding.textView1) {
            vBinding.rl.setVisibility(View.GONE);
            vBinding.llAllSave.setVisibility(View.VISIBLE);
            initRv3();
        } else if (v == vBinding.textView2) {
            ArrayList<ComicSeeBean> list = new ArrayList<>();
            list.add(comicSeeSumBean.getCurrentShowBean());
            saveImage(list);
        } else if (v == vBinding.tvSaveImage) {
            saveImage(comicSeeSumBean.getSelectListBean());
        }

    }

    boolean isAnimationHave;
    boolean titleSwitch;

    private void clickCentre() {
        if (!isAnimationHave) {
            isAnimationHave = true;
            if (titleSwitch) {
                startPopsAnimTrans(vBinding.llTop, -(vBinding.llTop.getHeight()));
                startPopsAnimTrans(vBinding.llBottom, vBinding.llBottom.getHeight());
                titleSwitch = false;
            } else {
                startPopsAnimTrans(vBinding.llTop, 0);
                startPopsAnimTrans(vBinding.llBottom, 0);
                titleSwitch = true;
            }
            isAnimationHave = false;
        }
    }


    public void upRv1(int position) {
        log("Rv1调转索引：" + position);
        vBinding.rv1.scrollToPosition(position);
    }

    public void upRv2(int position) {
        log("Rv2调转索引：" + position);
        vBinding.rv2.scrollToPosition(position);
        comicWifiSeeImageAdapter2.notifyDataSetChanged();
    }

    /**
     * 重新获取加载失败的url资源
     */
    public void reconnect() {
        List<ComicSeeBean> comicSeeBeans = comicSeeSumBean.getNoLoadedOK();
        if (comicSeeBeans.size() == 0) {
            return;
        }
        getDatasync(comicSeeBeans, () -> {
            //最后一个获取完了之后再更新UI
            log("当前线程：" + Thread.currentThread().getName());
            runOnUiThread(() -> comicWifiSeeImageAdapter1.notifyDataSetChanged());
        });
    }


    /**
     * 保存图片
     */
    private void saveImage(List<ComicSeeBean> listBean) {
        if (listBean == null || listBean.size() == 0) {
            to("未选择图片", false);
            return;
        }
        wifiInput(listBean, () -> {
            isInputInProgress = false;
            runOnUiThread(() -> {
                to("保存完毕，可在\"漫架\"中查看", true);
                //发广播，让漫架更新UI
                Intent intent = new Intent();
                intent.setAction("download_image_complete");
                intent.setPackage(getPackageName());
                sendBroadcast(intent);
            });



        });

    }

    //是否正在导入中
    private boolean isInputInProgress;

    public void wifiInput(List<ComicSeeBean> list, Runnable runnable) {
        if (list == null || list.size() == 0) {
            return;
        }
        if (isInputInProgress) {
            to("正在保存中...", false);
            return;
        }
        isInputInProgress = true;
        to("开始保存，完毕后可在\"漫架\"查看", true);
        //开始建父文件，已网页标题命名，不判读重名【如果重名，maxSize会错乱，不会影响使用，暂时先不管】
        String fileCataloguePath = Constant.BOOK_DIRECTORY + "/" + webViewTitle;
        File directoryFile = new File(fileCataloguePath);
        if (!directoryFile.exists()) {
            directoryFile.mkdirs();
        }
        BookBean fBean = new BookBean();
        fBean.setDirectory(true);
        fBean.setFileName(TextUtils.isEmpty(webViewTitle) ? "未知文件夹" : webViewTitle);
        fBean.setFilePath(fileCataloguePath);
        fBean.setFatherName(Constant.ROOT_NAME);
//        int maxSize = 0;
//        for (ComicSeeBean comicSeeBean : list) {
//            maxSize += comicSeeBean.getMemoryUsageSize();
//        }
        fBean.setMaxSize(0);
        fBean.setImputSchedule(0);
        ComicMode.saveSP(MjApplication.CONTEXT, fBean, false);
        //开始建子文件
        List<Integer> listInt = new ArrayList<>();//计数
        for (int i = 0; i < list.size(); i++) {
            ComicSeeBean comicSeeBean = list.get(i);
            int finalI = i;
            getExecutorService(2).execute(() -> {
                try {
                    URL url = new URL(comicSeeBean.getUrl());
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    // 设置超时间为3秒
                    connection.setConnectTimeout(3 * 1000);
                    int code = connection.getResponseCode();
                    log("网络返回code码：" + code);
                    if (code == HttpURLConnection.HTTP_OK || code == HttpURLConnection.HTTP_PARTIAL) {
                        long contentLengthLong = connection.getContentLengthLong();
                        log("即将下载源文件总大小：" + contentLengthLong);
                        if (!FilesUtils.isSizeSufficient(contentLengthLong)) {
                            to("设备内存不足", true);
                        } else {
//                            String newFileName = FilesUtils.getNoDuplicateName(directoryFile, FilesUtils.getUrlFileNameFromOrigin(connection));
                            String newFileName = FilesUtils.getUrlFileNameFromOrigin(connection);//直接就做覆盖处理
                            //组Bean
                            BookBean imputBean = new BookBean();
                            imputBean.setDirectory(false);
                            imputBean.setOriginUriPath(comicSeeBean.getUrl());
                            imputBean.setFileName(newFileName);
                            imputBean.setFileType(connection.getContentType());
                            imputBean.setMaxSize(contentLengthLong);
                            //建文件
                            String newFilePath = fileCataloguePath + "/" + newFileName;
                            imputBean.setFilePath(newFilePath);
                            imputBean.setFatherName(directoryFile.getName());
                            File newFile = new File(newFilePath);
                            if (!newFile.exists()) {
                                newFile.createNewFile();
                            }
                            imputBean.setImputSchedule(newFile.length());

                            //第一次导入的时候才存
                            ComicMode.saveSP(MjApplication.CONTEXT, imputBean, false);

                            InputStream inputStream = connection.getInputStream();
                            //开始写文件
                            FileOutputStream outputStream = new FileOutputStream(newFile, true);
                            //32kb读
                            byte[] buffer = new byte[32 * 1024];
                            int read;
                            while ((read = inputStream.read(buffer)) != -1) {
                                imputBean.setImputProcess(true);
                                outputStream.write(buffer, 0, read);
                                log(newFile.getName() + "总字节大小：" + contentLengthLong + "，导入进度：" + newFile.length() + ";剩余：" + (contentLengthLong - newFile.length()));
                                imputBean.setImputSchedule(imputBean.getImputSchedule() + read);
                                imputBean.setLastModified(System.currentTimeMillis());
                                //Message发送之后就无效了，所以需要每次新建
                                if (Constant.INTERVAL_TIME > 0) {
                                    Thread.sleep(Constant.INTERVAL_TIME);
                                }
                            }
                            imputBean.setImputSchedule(contentLengthLong);
                            imputBean.setImputProcess(false);
                            //关流
                            outputStream.flush();
                            outputStream.close();
                            inputStream.close();
                        }
                        log("加载成功url：" + comicSeeBean.getUrl() + ";还剩：" + (list.size() - listInt.size() - 1) + "个资源未处理;当前线程：" + Thread.currentThread().getId());
                    }
                } catch (Exception e) {
                    log("下载失败url：" + comicSeeBean.getUrl() + ";e：" + e.getMessage() + ";还剩：" + (list.size() - listInt.size() - 1) + "个资源未处理;当前线程：" + Thread.currentThread().getId());
                }
                listInt.add(finalI);
                if (list.size() == listInt.size()) {
                    runnable.run();
                }
            });

        }
    }

    @Override
    public void onBackPressed() {
        if (vBinding.llAllSave.getVisibility() == View.VISIBLE) {
            vBinding.llAllSave.setVisibility(View.GONE);
            vBinding.rl.setVisibility(View.VISIBLE);
        } else {
            finish();
        }
    }
}