package com.juying.mjreader;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.PermissionPool;
import com.juying.mjreader.utils.RomUtil;
import com.juying.mjreader.utils.ToastUtils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import me.jessyan.autosize.AutoSize;

/**
 * @Author Ycc
 * @Date 13:15
 */
public class BaseActivity extends AppCompatActivity {
    protected String TAG = getClass().getSimpleName();


    /**
     * 初始化零件
     */

    private void initWidget() {
    }

    /**
     * 初始化点击事件
     */

    @Nullable
    @Override
    public View onCreateView(@Nullable View parent, @NonNull String name, @NonNull Context context, @NonNull AttributeSet attrs) {
        //解决使用WebView控件导致整个项目的适配失衡
        AutoSize.autoConvertDensityOfGlobal(this);
        return super.onCreateView(parent, name, context, attrs);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //状态栏黑色字体
        setTextColor(false);
        ActivityManager.getActivityManager().addA(this);
        //       initWidget();
//        fullscreen(true);
    }

    protected void to(String s, boolean isLog) {
        ToastUtils.show(this, s);
        if (isLog) {
            Log.d(TAG, s);
        }
    }

    protected void log(String s) {
        LogUtil.d(TAG, s);
    }


    //设置状态栏字体颜色
    protected void setTextColor(boolean isDarkBackground) {
        View decor = this.getWindow().getDecorView();
        if (isDarkBackground) {
            //黑暗背景字体浅色
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } else {
            //高亮背景字体深色
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            //注意要清除 FLAG_TRANSLUCENT_STATUS flag
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().setStatusBarColor(getColor(R.color.sp00000000));
        }
    }


    /**
     * 显示隐藏状态栏
     */
    protected void fullscreen(boolean show) {

        log("当前设备品牌：" + RomUtil.getName());
        if (RomUtil.isMiui()) {
            if (show) { //显示状态栏
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
                getWindow().setAttributes(lp);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            } else { //隐藏状态栏
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
                getWindow().setAttributes(lp);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            }
        } else {
            View decorView = getWindow().getDecorView();
            if (show) { //显示状态栏
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); //显示状态栏
                decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            } else { //隐藏状态栏
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); //显示状态栏
                decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LOW_PROFILE);

            }
        }


    }


    public void hideStatusBar(Activity activity) {
        if (activity == null) return;
        Window window = activity.getWindow();
        if (window == null) return;
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        WindowManager.LayoutParams lp = window.getAttributes();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        window.setAttributes(lp);
    }

    public void showStatusBar(Activity activity) {

        if (activity == null) return;
        Window window = activity.getWindow();
        if (window == null) return;
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        WindowManager.LayoutParams lp = window.getAttributes();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = 2;
        }
        window.setAttributes(lp);

    }


    private void setStatusBarVisible(boolean show) {
        if (show) {
            int uiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            uiFlags |= 0x00001000;
            getWindow().getDecorView().setSystemUiVisibility(uiFlags);
        } else {
            int uiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_FULLSCREEN;
            uiFlags |= 0x00001000;
            getWindow().getDecorView().setSystemUiVisibility(uiFlags);
        }
    }


    // 属性动画-纵向平移
    protected void startPopsAnimTrans(View view, float... xy) {
        ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(view, "translationY", xy);
        objectAnimatorX.setDuration(350);
        objectAnimatorX.start();
    }


    //单线程池
    private ExecutorService newSingleThreadExecutor;
    //多-不定长线程池
    private ExecutorService newCachedThreadPool;
    //多-定长线程池
    private ExecutorService manyExecutor;


    /**
     * 获得线程池
     *
     * @param type 1=单线程池  2=多不定长  3=定长（10条）
     * @return
     */
    protected ExecutorService getExecutorService(int type) {
        switch (type) {
            case 1://单线程池
                if (newSingleThreadExecutor == null) {
                    newSingleThreadExecutor = Executors.newSingleThreadExecutor();
                }
                return newSingleThreadExecutor;
            case 2://不定长线程池
                if (newCachedThreadPool == null) {
                    newCachedThreadPool = Executors.newCachedThreadPool();
                }
                return newCachedThreadPool;
            case 3:
                if (manyExecutor == null) {
                    /**
                     *  1：核心线程数，线程池中始终存活的线程数。
                     *
                     * 2：最大线程数，线程池中允许的最大线程数，当线程池的任务队列满了之后可以创建的最大线程数。
                     *
                     * 3：最大线程数可以存活的时间，当线程中没有任务执行时，最大线程就会销毁一部分，最终保持核心线程数量的线程。
                     *
                     *  4：unit:单位是和参数 3 存活时间配合使用的，合在一起用于设定线程的存活时间 ，参数 keepAliveTime 的时间单位有以下 7 种可选：
                     *
                     * TimeUnit.DAYS：天
                     * TimeUnit.HOURS：小时
                     * TimeUnit.MINUTES：分
                     * TimeUnit.SECONDS：秒
                     * TimeUnit.MILLISECONDS：毫秒
                     * TimeUnit.MICROSECONDS：微妙
                     * TimeUnit.NANOSECONDS：纳秒
                     * 参数 5：workQueue
                     * 一个阻塞队列，用来存储线程池等待执行的任务，均为线程安全，它包含以下 7 种类型：
                     *
                     * ArrayBlockingQueue：一个由数组结构组成的有界阻塞队列。
                     * LinkedBlockingQueue：一个由链表结构组成的有界阻塞队列。
                     * SynchronousQueue：一个不存储元素的阻塞队列，即直接提交给线程不保持它们。
                     * PriorityBlockingQueue：一个支持优先级排序的无界阻塞队列。
                     * DelayQueue：一个使用优先级队列实现的无界阻塞队列，只有在延迟期满时才能从中提取元素。
                     * LinkedTransferQueue：一个由链表结构组成的无界阻塞队列。与SynchronousQueue类似，还含有非阻塞方法。
                     * LinkedBlockingDeque：一个由链表结构组成的双向阻塞队列。
                     * 较常用的是 LinkedBlockingQueue 和 Synchronous，线程池的排队策略与 BlockingQueue 有关。
                     *
                     * 参数 6：threadFactory
                     * 线程工厂，主要用来创建线程，默认为正常优先级、非守护线程。
                     *
                     * 参数 7：handler
                     * 拒绝策略，拒绝处理任务时的策略，系统提供了 4 种可选：
                     *
                     * AbortPolicy：拒绝并抛出异常。
                     * CallerRunsPolicy：使用当前调用的线程来执行此任务。
                     * DiscardOldestPolicy：抛弃队列头部（最旧）的一个任务，并执行当前任务。
                     * DiscardPolicy：忽略并抛弃当前任务。
                     * 默认策略为 AbortPolicy。
                     */
                    manyExecutor = new ThreadPoolExecutor(3, 10, 100, TimeUnit.SECONDS, new LinkedBlockingQueue<>(10), r -> {
                        Thread thread = new Thread(r);
                        thread.setPriority(Thread.MAX_PRIORITY);
                        return thread;
                    });
                    return manyExecutor;
                }
                return manyExecutor;
            default:
        }
        return null;
    }


    PermissionPool.PermissionCallback permissionCallback;

    /**
     * android6.0权限处理
     *
     * @param code           权限标记Code
     * @param permissionName 权限名称
     */
    public void permissionDispose(@PermissionPool.PermissionCode int code, @PermissionPool.PermissionName String[] permissionName, PermissionPool.PermissionCallback callback) {
        this.permissionCallback = callback;

        boolean isApply = false;
        for (String s : permissionName) {
            if (ContextCompat.checkSelfPermission(this, s) != PackageManager.PERMISSION_GRANTED) {
                isApply = true;
            }
        }
        if (isApply) {
            //有权限没被申请,直接统一申请
            ActivityCompat.requestPermissions(this, permissionName, code);
        } else {
            callback.ok(code, permissionName);//有权限
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //授权成功
            if (permissionCallback != null) {
                permissionCallback.ok(requestCode, permissions);
            }

        } else if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
            //授权失败
            if (permissionCallback != null) {
                permissionCallback.no(requestCode, permissions);
//                if (EasyPermissions.somePermissionPermanentlyDenied(this, Arrays.asList(permissions))) {
//                    //点了拒绝且不再提醒
//                    log("权限没有被允许，且点了永不提醒");
//                    new AppSettingsDialog.Builder(this).build().show();
//                    //弹出个对话框 可以自定义
//                }
            }
        }
    }


    @Override
    protected void onDestroy() {
        log("onDestroy");
        ActivityManager.getActivityManager().delA(this);
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        log("onStart");
        super.onStart();
    }

    @Override
    protected void onResume() {
        log("onResume");
        super.onResume();
    }

    @Override
    protected void onStop() {
        log("onStop");
        super.onStop();
    }

    @Override
    protected void onPause() {
        log("onPause");
        super.onPause();
    }

    @Override
    protected void onRestart() {
        log("onRestart");
        super.onRestart();
    }
}
