package com.juying.mjreader.widget.page;
/**
 * @Author Nimyears
 * 作用：翻页动画的模式
 * 覆盖、上下、仿真、平移
 */
public enum PageMode {
    COVER, SCROLL, SIMULATION, SLIDE,NONE
}
