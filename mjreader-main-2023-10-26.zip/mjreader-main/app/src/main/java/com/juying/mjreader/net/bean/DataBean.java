package com.juying.mjreader.net.bean;

/**
 * @Author Ycc
 * @Date 15:27
 */
public class DataBean {


    /**
     * id : 1c013aed2196eb0e9358ad135bab7e56
     * dataId : 1c013aed2196eb0e9358ad135bab7e56
     * channel : normal
     * content : 收藏的书籍信息1
     * createTime : 1694787757496
     * lastUpdateTime : 1694787757496
     */

    private String id;
    private String dataId;
    private String channel;
    private String content;
    private long createTime;
    private long lastUpdateTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDataId() {
        return dataId;
    }

    public void setDataId(String dataId) {
        this.dataId = dataId;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(long lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }


    @Override
    public String toString() {
        return "DataBean{" +
                "id='" + id + '\'' +
                ", dataId='" + dataId + '\'' +
                ", channel='" + channel + '\'' +
                ", content='" + content + '\'' +
                ", createTime=" + createTime +
                ", lastUpdateTime=" + lastUpdateTime +
                '}';
    }
}
