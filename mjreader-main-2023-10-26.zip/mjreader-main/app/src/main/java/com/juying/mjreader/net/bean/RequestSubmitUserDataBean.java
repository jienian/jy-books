package com.juying.mjreader.net.bean;

import com.juying.mjreader.network.models.BaseReq;

/**
 * 请求提交数据接口参数Bean
 * @Author Ycc
 * @Date 14:06
 */
public class RequestSubmitUserDataBean extends BaseReq {
//     * @param type      数据类型，由接口调用者规划好，建议都是大写字母	BOOKSHELF, READHISTORY
//     * @param dataId    数据Id, 即键。推荐：md5(appKey,topUserId,真正的数据Id)
//     * @param content   自定义的用户数据，推荐使用json对象来存储用户的数据
//     * @param topUserId 顶级用户Id，构成： md5(appKey，userId)
    String type;
    String dataId;
    String content;
    String topUserId;

    public RequestSubmitUserDataBean(String type, String dataId, String content, String topUserId) {
        this.type = type;
        this.dataId = dataId;
        this.content = content;
        this.topUserId = topUserId;
    }
}
