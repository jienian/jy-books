package com.juying.mjreader.network

import com.juying.mjreader.network.models.BaseReq
import com.juying.mjreader.network.models.ChangeUserinfoReq
import com.juying.mjreader.network.models.CheckEmailReq
import com.juying.mjreader.network.models.CheckPhoneReq
import com.juying.mjreader.network.models.CheckUsernameRes
import retrofit2.Call
import com.juying.mjreader.network.models.LoginByUuidReq
import com.juying.mjreader.network.models.LoginEmailReq
import com.juying.mjreader.network.models.LoginPhoneReq
import com.juying.mjreader.network.models.RegisterAccountReq
import com.juying.mjreader.network.models.Res
import com.juying.mjreader.network.models.UserInfo
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST

/**
 * @author Nimyears
 */
interface UserApi {
    @Multipart

    // uuid/设备号 一键登录
    @POST("api/user/login/once/uuid")
    fun loginByUuid(@Body body: LoginByUuidReq): Call<Res<UserInfo>>

    //获取用户信息
    @POST("api/user/getinfo")
    fun getInfo(@Body body: BaseReq = BaseReq()): Call<Res<UserInfo>>


    // 修改用户信息
    @POST("api/user/change/userinfo")
    fun changeUserinfo(@Body body: ChangeUserinfoReq): Call<Res<Any>>

    //用户注册(手机、邮箱)
    @POST("api/user/register/account")
    fun registerAccount(@Body body: RegisterAccountReq): Call<Res<UserInfo>>

    // 该邮箱在本系统有没有被注册过
    @POST("api/user/check/email")
    fun checkEmail(@Body body: CheckEmailReq): Call<Res<CheckUsernameRes>>

    // 该手机号在本系统有没有被注册过
    @POST("api/user/check/phone")

    fun checkPhone(@Body body: CheckPhoneReq): Call<Res<CheckUsernameRes>>

    // 通过邮箱账号登录
    @POST("api/user/login/email")
    fun loginEmail(@Body body: LoginEmailReq): Call<Res<UserInfo>>
    // 通过手机号码登录
    @POST("api/user/login/phone")
    fun loginPhone(@Body body: LoginPhoneReq): Call<Res<UserInfo>>


}