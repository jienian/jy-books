package com.juying.mjreader.network.interceptor

import android.util.Log
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import okio.Buffer
import java.io.IOException
import java.nio.charset.Charset
/**
 * @author Nimyears
 */
class LoggingInterceptor : Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request: Request = chain.request()
        val url: HttpUrl = request.url
        Log.d("LoggingInterceptor", "Request url: $url")

        val requestBody = request.body
        if (requestBody != null) {
            val buffer = Buffer()
            requestBody.writeTo(buffer)
            val contentType = requestBody.contentType()
            val charset: Charset =
                contentType?.charset(Charset.forName("UTF-8")) ?: Charset.forName("UTF-8")
            val bodyString = buffer.readString(charset)
            Log.d("LoggingInterceptor", "Request Body: $bodyString")
        }

        val startTime = System.currentTimeMillis()
        val response = chain.proceed(request)
        Log.d("LoggingInterceptor", "duration: ${System.currentTimeMillis() - startTime}")

        return response
    }
}