package com.juying.mjreader.utils;

import static android.os.ParcelFileDescriptor.MODE_READ_ONLY;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.github.barteksc.pdfviewer.PDFView;
import com.juying.mjreader.bean.TreeNodeData;
import com.shockwave.pdfium.PdfDocument;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 10:50
 */
public class PDFUtil {

    /**
     * 获取PDF标签信息
     *
     * @param pdfView
     * @return
     */
    public static List<TreeNodeData> iniTreeNodeData(PDFView pdfView) {
        //获得文档书签信息
        List<PdfDocument.Bookmark> bookmarks = pdfView.getTableOfContents();
        List<TreeNodeData> catelogues = new ArrayList<>();
        //将bookmark转为目录数据集合
//        bookmarkToCatelogues(catelogues, bookmarks, 1,currentShowPage);
        bookmarkToCateloguesNoUngraded(catelogues, bookmarks, 1);
        return catelogues;
    }


    /**
     * 将bookmark转为目录数据集合（递归） TODO （递归）分级获取并分级排列
     *
     * @param catelogues 目录数据集合
     * @param bookmarks  书签数据
     * @param level      目录树级别（用于控制树节点位置偏移）
     */
    public static void bookmarkToCatelogues(List<TreeNodeData> catelogues, List<PdfDocument.Bookmark> bookmarks, int level, int currentShowPage) {
        for (PdfDocument.Bookmark bookmark : bookmarks) {
            TreeNodeData nodeData = new TreeNodeData();
            nodeData.setName(bookmark.getTitle());
            int pageIdx = (int) bookmark.getPageIdx();
            nodeData.setPageNum(pageIdx);
//            if (currentShowPage == pageIdx) {
//                nodeData.setInProgressShow(true);
//            }
            nodeData.setTreeLevel(level);
            nodeData.setExpanded(false);
            catelogues.add(nodeData);
            if (bookmark.getChildren() != null && bookmark.getChildren().size() > 0) {
                List<TreeNodeData> treeNodeDatas = new ArrayList<>();
                nodeData.setSubset(treeNodeDatas);
                bookmarkToCatelogues(treeNodeDatas, bookmark.getChildren(), level + 1, currentShowPage);
            }
        }
    }

    /**
     * 将bookmark转为目录数据集合（递归） TODO （递归）分级获取但不分级排列
     */
    public static void bookmarkToCateloguesNoUngraded(List<TreeNodeData> catelogues, List<PdfDocument.Bookmark> bookmarks, int level) {
        for (PdfDocument.Bookmark bookmark : bookmarks) {
            TreeNodeData nodeData = new TreeNodeData();
            nodeData.setName(bookmark.getTitle());
            int pageIdx = (int) bookmark.getPageIdx();
            nodeData.setPageNum(pageIdx);
//            if (currentShowPage == pageIdx) {
//                nodeData.setInProgressShow(true);
//            }
            nodeData.setTreeLevel(level);
            nodeData.setExpanded(false);
            catelogues.add(nodeData);
            if (bookmark.getChildren() != null && bookmark.getChildren().size() > 0) {
//                List<TreeNodeData> treeNodeDatas = new ArrayList<>();
//                nodeData.setSubset(treeNodeDatas);
                bookmarkToCateloguesNoUngraded(catelogues, bookmark.getChildren(), level + 1);
            }
        }


//        for (int i = 0; i < bookmarks.size(); i++) {
//            PdfDocument.Bookmark bookmark = bookmarks.get(i);
//            TreeNodeData nodeData = new TreeNodeData();
//            nodeData.setName(bookmark.getTitle());
//            int pageIdx = (int) bookmark.getPageIdx();
//            nodeData.setPageNum(pageIdx);
//            if (currentShowPage == pageIdx) {
//                nodeData.setInProgressShow(true);
//            }
//            nodeData.setTreeLevel(level);
//            nodeData.setExpanded(false);
//            .
//            catelogues.add(nodeData);
//
//            if (bookmark.getChildren() != null && bookmark.getChildren().size() > 0) {
////                List<TreeNodeData> treeNodeDatas = new ArrayList<>();
////                nodeData.setSubset(treeNodeDatas);
//                bookmarkToCatelogues(catelogues, bookmark.getChildren(), level + 1,currentShowPage);
//            }
//        }
    }


    /**
     * 模拟书签数据
     *
     * @param catelogues 目录数据集合
     * @param num        数据量
     * @param level      目录树级别（用于控制树节点位置偏移）
     */
    public static List<TreeNodeData> bookmarkToCatelogues(List<TreeNodeData> catelogues, int num, int level) {
        //TODO 没有有书签的PDF,先用模拟书签数据
        if (catelogues == null) {
            catelogues = new ArrayList<>();
        }
        for (int i = 0; i < num; i++) {
            TreeNodeData nodeData = new TreeNodeData();
            nodeData.setName("书签" + i);
            nodeData.setPageNum(i);
            nodeData.setTreeLevel(level);
            nodeData.setExpanded(false);
            catelogues.add(nodeData);
            for (int j = 0; j < 4; j++) {
                List<TreeNodeData> treeNodeDatas = new ArrayList<>();
                nodeData.setSubset(treeNodeDatas);
                TreeNodeData nodeData1 = new TreeNodeData();
                nodeData1.setName("子书签" + j);
                nodeData1.setPageNum(j);
                nodeData1.setTreeLevel(level + 1);
                nodeData1.setExpanded(false);
                treeNodeDatas.add(nodeData1);
            }
        }
        return catelogues;
    }

    /**
     * 提前获得PDF总页数
     *
     * @param pdfFile
     * @return
     */
    public static int getPdfCountPages(File pdfFile) {
        int countPage = 0;
        try {
            ParcelFileDescriptor parcelFileDescriptor = ParcelFileDescriptor.open(pdfFile, MODE_READ_ONLY);
            PdfRenderer pdfRenderer = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                pdfRenderer = new PdfRenderer(parcelFileDescriptor);
                countPage = pdfRenderer.getPageCount();
                pdfRenderer.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Log.d("TAG", "PDF总页数: " + countPage);
        return countPage;
    }


    /**
     * pdf页page属于标签页的哪个索引
     * 也就是pdf当前page属于标签页的那一页，因为一个标签页可能包含很多pdf page】
     *
     * @param pdfPage
     * @param treeNodeDataList
     * @return
     */
    public static int pdfPageBelongTag(int pdfPage, List<TreeNodeData> treeNodeDataList) {
        //转化成rv标签页的当前页【也就是pdf当前page属于标签页的那一页，因为一个标签页可能包含很多pdf page】
        for (int i = 0; i < treeNodeDataList.size(); i++) {
            TreeNodeData nodeData = treeNodeDataList.get(i);
            if (i == treeNodeDataList.size() - 1) {
                //最后一个标签
                if (pdfPage >= nodeData.getPageNum()) {
                    //当前pdfPage属于i标签
                    return i;
                }
            } else {
                TreeNodeData nodeData1 = treeNodeDataList.get(i + 1);
                if (pdfPage >= nodeData.getPageNum() && pdfPage < nodeData1.getPageNum()) {
                    //当前pdfPage属于i标签
                    return i;
                }
            }
        }
        return 0;
    }

    /**
     * 使用Android的默认库转PDF为图片
     *
     * @throws IOException
     */
    private void pdfToImags() throws IOException {
        ParcelFileDescriptor fileDescriptor = ParcelFileDescriptor.open(new File("pdfFilePath.pdf"), MODE_READ_ONLY);
        PdfRenderer renderer = new PdfRenderer(fileDescriptor);
        final int pageCount = renderer.getPageCount();
        for (int i = 0; i < pageCount; i++) {
            PdfRenderer.Page page = renderer.openPage(i);
            Bitmap bitmap = Bitmap.createBitmap(page.getWidth(), page.getHeight(), Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            canvas.drawBitmap(bitmap, 0, 0, null);
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            page.close();

            if (bitmap == null)
                return;

            if (bitmapIsBlankOrWhite(bitmap))
                return;

            String root = Environment.getExternalStorageDirectory().toString();
            File file = new File(root + "filename" + ".png");

            if (file.exists()) file.delete();
            try {
                FileOutputStream out = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                Log.v("Saved Image - ", file.getAbsolutePath());
                out.flush();
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 位图为空白或者白色
     *
     * @param bitmap
     * @return
     */
    private static boolean bitmapIsBlankOrWhite(Bitmap bitmap) {
        if (bitmap == null)
            return true;

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                int pixel = bitmap.getPixel(i, j);
                if (pixel != Color.WHITE) {
                    return false;
                }
            }
        }
        return true;
    }
}
