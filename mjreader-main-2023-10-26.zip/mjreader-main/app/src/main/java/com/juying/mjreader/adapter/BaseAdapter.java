package com.juying.mjreader.adapter;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.T;


import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.fragment.MyFragment;
import com.juying.mjreader.utils.LogUtil;

/**
 * @Author Ycc
 * @Date 20:02
 */
public class BaseAdapter<T extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<T>{
    protected String TAG=getClass().getSimpleName();

    @NonNull
    @Override
    public T onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull T holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }


    protected void to(String s, boolean isLog) {
        Toast.makeText(MjApplication.CONTEXT, s, Toast.LENGTH_SHORT).show();
        if (isLog) {
            Log.d(TAG, s);
        }
    }

    protected void log(String s) {
        LogUtil.d(TAG, s);
    }


    /**
     * 加载资源时的Ui变化
     * @param type 1=开始加载，2=加载失败、网络原因；3=加载失败、非网络原因 4=加载成功
     */
    protected void loadType(int type, View loadView, View faliFromWifiView, View faliNoFromWifiView, View okView) {
        switch (type) {
            case 1:
                loadView.setVisibility(View.VISIBLE);
                faliFromWifiView.setVisibility(View.GONE);
                faliNoFromWifiView.setVisibility(View.GONE);
                okView.setVisibility(View.GONE);
                break;
            case 2:
                loadView.setVisibility(View.GONE);
                faliFromWifiView.setVisibility(View.VISIBLE);
                faliNoFromWifiView.setVisibility(View.GONE);
                okView.setVisibility(View.GONE);
                break;
            case 3:
                loadView.setVisibility(View.GONE);
                faliFromWifiView.setVisibility(View.GONE);
                faliNoFromWifiView.setVisibility(View.VISIBLE);
                okView.setVisibility(View.GONE);
                break;
            case 4:
                loadView.setVisibility(View.GONE);
                faliFromWifiView.setVisibility(View.GONE);
                faliNoFromWifiView.setVisibility(View.GONE);
                okView.setVisibility(View.VISIBLE);
                break;
            default:
        }

    }

}
