package com.juying.mjreader.bean;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.juying.mjreader.utils.config.Constant;

/**
 * @Author Ycc
 * @Date 10:36
 * 漫画设置
 */
public class ComicSettingBean implements Parcelable {


    /**
     * 漫架展示模式【true 为竖屏=宫格，false 未横屏】默认宫格
     */
    boolean comicSettingMode = true;


    public boolean getComicSettingMode() {
        return comicSettingMode;
    }

    public void setComicSettingMode(boolean comicSettingMode) {
        this.comicSettingMode = comicSettingMode;
    }


    /**
     * 漫画观看模式【1=普通模式，2=日漫模式，3=卷轴】默认3
     */
    int modeComicSee = 3;
    /**
     * 横竖屏模式【1=自动，2=竖屏，3=横屏】默认2
     */
    int modeHorizontalOrVertical = 2;
    /**
     * 观看亮度 0f~1f
     */
    float viewingBrightness;
    /**
     * 是否夜间模式
     */
    boolean isModeNight;
    /**
     * 是否音量键翻页
     */
    boolean isVolumeKeysPages;
    /**
     * 是否阅读时显示状态栏
     */
    boolean isReadShowStatusBar;
    /**
     * 网络使用搜索引擎
     */
    private String searchEngine;

    /**
     * 自动阅读速度档位：1=慢，2=较慢，3=标准，4=较快，5=快
     */
    private int automaticReadingSpeed;

    public void setAutomaticReadingSpeed(int speed) {
        this.automaticReadingSpeed = speed;
    }

    public boolean isComicSettingMode() {
        return comicSettingMode;
    }

    public int getModeComicSee() {
        return modeComicSee;
    }

    public void setModeComicSee(int modeComicSee) {
        this.modeComicSee = modeComicSee;
        upSP();
    }

    public int getModeHorizontalOrVertical() {
        return modeHorizontalOrVertical;
    }

    public void setModeHorizontalOrVertical(int modeHorizontalOrVertical) {
        this.modeHorizontalOrVertical = modeHorizontalOrVertical;
        upSP();
    }

    public float getViewingBrightness() {
        return viewingBrightness;
    }

    public String getSearchEngine() {
        return searchEngine;
    }

    public void setSearchEngine(String searchEngine) {
        this.searchEngine = searchEngine;

        spEdit.putString("searchEngine", searchEngine);
        spEdit.apply();
    }

    public void setViewingBrightness(float viewingBrightness) {
        this.viewingBrightness = viewingBrightness;
        upSP();
    }

    public boolean isModeNight() {
        return isModeNight;
    }

    public void setModeNight(boolean modeNight) {
        isModeNight = modeNight;
        getSpEdit().putBoolean("isModeNight", modeNight);
        spEdit.apply();
    }

    public SharedPreferences.Editor getSpEdit() {
        if (spEdit == null) {
            spEdit = Constant.COMIC_SETTING_SP.edit();
        }
        return spEdit;
    }

    public boolean isVolumeKeysPages() {
        return isVolumeKeysPages;
    }

    public void setVolumeKeysPages(boolean volumeKeysPages) {
        isVolumeKeysPages = volumeKeysPages;
        upSP();
    }

    public boolean isReadShowStatusBar() {
        return isReadShowStatusBar;
    }

    public void setReadShowStatusBar(boolean readShowStatusBar) {
        isReadShowStatusBar = readShowStatusBar;
        upSP();
    }


    private SharedPreferences.Editor spEdit;


    /**
     * 更新物理sp
     */
    public void upSP() {
//        comicSettingMode=(Constant.COMIC_SETTING_SP.getBoolean(Constant.COMIC_SETTING_MODE, true));

        getSpEdit();
        spEdit.putBoolean("comicSettingMode", comicSettingMode);
        spEdit.putBoolean("isReadShowStatusBar", isReadShowStatusBar);
        spEdit.putBoolean("isVolumeKeysPages", isVolumeKeysPages);
        spEdit.putBoolean("isModeNight", isModeNight);
        spEdit.putFloat("viewingBrightness", viewingBrightness);
        spEdit.putInt("modeComicSee", modeComicSee);
        spEdit.putInt("modeHorizontalOrVertical", modeHorizontalOrVertical);
        spEdit.putBoolean("isBlockAd", isBlockAd);
        spEdit.apply();
    }


    private void initSP() {
        comicSettingMode = (Constant.COMIC_SETTING_SP.getBoolean("comicSettingMode", true));
        isReadShowStatusBar = (Constant.COMIC_SETTING_SP.getBoolean("isReadShowStatusBar", false));
        isVolumeKeysPages = (Constant.COMIC_SETTING_SP.getBoolean("isVolumeKeysPages", false));
        isModeNight = (Constant.COMIC_SETTING_SP.getBoolean("isModeNight", false));
        viewingBrightness = (Constant.COMIC_SETTING_SP.getFloat("viewingBrightness", 0.5f));
        modeComicSee = (Constant.COMIC_SETTING_SP.getInt("modeComicSee", 3));
        modeHorizontalOrVertical = (Constant.COMIC_SETTING_SP.getInt("modeHorizontalOrVertical", 1));
        searchEngine = (Constant.COMIC_SETTING_SP.getString("searchEngine", "百度"));
        isBlockAd = (Constant.COMIC_SETTING_SP.getBoolean("isBlockAd", true));

    }

    public ComicSettingBean() {
        initSP();
        spEdit = Constant.COMIC_SETTING_SP.edit();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte(this.comicSettingMode ? (byte) 1 : (byte) 0);
        dest.writeInt(this.modeComicSee);
        dest.writeInt(this.modeHorizontalOrVertical);
        dest.writeFloat(this.viewingBrightness);
        dest.writeByte(this.isModeNight ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isVolumeKeysPages ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isReadShowStatusBar ? (byte) 1 : (byte) 0);
    }

    public void readFromParcel(Parcel source) {
        this.comicSettingMode = source.readByte() != 0;
        this.modeComicSee = source.readInt();
        this.modeHorizontalOrVertical = source.readInt();
        this.viewingBrightness = source.readFloat();
        this.isModeNight = source.readByte() != 0;
        this.isVolumeKeysPages = source.readByte() != 0;
        this.isReadShowStatusBar = source.readByte() != 0;

    }


    protected ComicSettingBean(Parcel in) {
        this.comicSettingMode = in.readByte() != 0;
        this.modeComicSee = in.readInt();
        this.modeHorizontalOrVertical = in.readInt();
        this.viewingBrightness = in.readFloat();
        this.isModeNight = in.readByte() != 0;
        this.isVolumeKeysPages = in.readByte() != 0;
        this.isReadShowStatusBar = in.readByte() != 0;

    }

    public static final Parcelable.Creator<ComicSettingBean> CREATOR = new Parcelable.Creator<ComicSettingBean>() {
        @Override
        public ComicSettingBean createFromParcel(Parcel source) {
            return new ComicSettingBean(source);
        }

        @Override
        public ComicSettingBean[] newArray(int size) {
            return new ComicSettingBean[size];
        }


    };


    @Override
    public String toString() {
        return "ComicSettingBean{" +
                "comicSettingMode=" + comicSettingMode +
                ", modeComicSee=" + modeComicSee +
                ", modeHorizontalOrVertical=" + modeHorizontalOrVertical +
                ", viewingBrightness=" + viewingBrightness +
                ", isModeNight=" + isModeNight +
                ", isVolumeKeysPages=" + isVolumeKeysPages +
                ", isReadShowStatusBar=" + isReadShowStatusBar +
                ", searchEngine='" + searchEngine + '\'' +
                '}';
    }


    //是否屏蔽WebView广告
    private boolean isBlockAd;

    public boolean isBlockAd() {
        return isBlockAd;
    }

    public void setBlockAd(boolean blockAd) {
        isBlockAd = blockAd;
        spEdit.putBoolean("isBlockAd", isBlockAd);
        spEdit.apply();
    }
}
