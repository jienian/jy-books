package com.juying.mjreader.view;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.juying.mjreader.R;
import com.juying.mjreader.adapter.novel.NovelMoveGroupingAdapter;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.fragment.NovelFragment;

public class NovelDialogGrouping extends Dialog {


    View view;
    private NovelMoveGroupingAdapter novelmoveGroupingAdapter;
   private  NovelDialogGroupingListener listener;
    private NovelFragment context;




    public NovelDialogGrouping(@NonNull NovelFragment context, int themeResId, BookBean currentShowBean, NovelDialogGroupingListener listener) {
        super(context.getContext(), themeResId);
        this.context = context;
        this.listener = listener;

        //2、设置布局
        view = View.inflate(context.getContext(), R.layout.dialog_grouping, null);
        setContentView(view);
        initRecyclerView(currentShowBean);
        Window window = getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.7f);
        //设置弹出位置
        window.setGravity(Gravity.BOTTOM);
        view.findViewById(R.id.iv_off).setOnClickListener(view1 -> {
            dismiss();
            cancel();
        });

        view.findViewById(R.id.iv_add).setOnClickListener(view12 -> {
            listener.onClickAdd();
        });

    }
    public void addUPRV(int position) {
        novelmoveGroupingAdapter.notifyItemInserted(position);
    }

    @SuppressLint("NotifyDataSetChanged")
    public void initRecyclerView(BookBean currentShowBean) {
        RecyclerView rv=findViewById(R.id.rv);
        novelmoveGroupingAdapter = new NovelMoveGroupingAdapter(context, currentShowBean, listener);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
//        ((SimpleItemAnimator) rv1.getItemAnimator()).setSupportsChangeAnimations(false);//禁止动画
        RecyclerView.ItemAnimator animator = rv.getItemAnimator();
        assert animator != null;
        animator.setChangeDuration(0);
        if (animator instanceof SimpleItemAnimator) {
            ((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);//禁止动画
        }
//        rv1.setHasFixedSize(true);//itme大小固定时，提到性能
//        rv1.setItemViewCacheSize(20);//
//        rv1.setPreserveFocusAfterLayout(true);//在布局变化后是否保持焦点
//        pageAdapter.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid
        rv.setLayoutManager(layoutManager);
//        linearSnapHelper = new LinearSnapHelper();//用作横向滑动时，不保持偏移量，可多页滑动连续滑动
//        PagerSnapHelper linearSnapHelper1 = new PagerSnapHelper();//用作横向滑动时，不保持偏移量，只能一页一页滑动
        rv.setAdapter(novelmoveGroupingAdapter);
        novelmoveGroupingAdapter.notifyDataSetChanged();
    }

    public interface NovelDialogGroupingListener {

        void onClickGroupingOK();

        void onClickAdd();
    }

}
