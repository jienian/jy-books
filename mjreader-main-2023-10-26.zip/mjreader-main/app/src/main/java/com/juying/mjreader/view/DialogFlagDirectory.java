package com.juying.mjreader.view;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.juying.mjreader.activity.SeeComicActivity;
import com.juying.mjreader.adapter.ComicFlagAdapter;
import com.juying.mjreader.adapter.ComicFlagDirectoryAdapter;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.bean.FlagBean;
import com.juying.mjreader.bean.TreeNodeData;
import com.juying.mjreader.databinding.DialogFlagDirectoryBinding;
import com.juying.mjreader.utils.ComicMode;
import com.juying.mjreader.utils.config.Abstract;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.utils.SeeComicMode;
import com.juying.mjreader.utils.sqlite.FlagBDDao;

import java.util.List;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogFlagDirectory extends BaseDialog {
    private final List<TreeNodeData> treeNodeDataList;
    private int currentPage;
    private ComicSeeSumBean comicSeeSumBean;
    private DialogFlagDirectoryBinding vBinding;
    private DialogFlagDirectoryListener listener;
    private SeeComicActivity context;


    private TreeNodeData treeNodeData;
    private ComicFlagDirectoryAdapter comicFlagDirectoryAdapter;
    private ComicFlagAdapter comicFlagAdapter;
    private LinearLayoutManager LinearLayoutManager1;
    private LinearLayoutManager LinearLayoutManager2;

    public DialogFlagDirectory(@NonNull SeeComicActivity context, int themeResId, ComicSeeSumBean comicSeeSumBean, List<TreeNodeData> treeNodeDataList, int currentPage, DialogFlagDirectoryListener listener) {
        super(context, themeResId);
        this.context = context;
        this.listener = listener;
        this.treeNodeDataList = treeNodeDataList;
        this.comicSeeSumBean = comicSeeSumBean;
        this.currentPage = currentPage;
        vBinding = DialogFlagDirectoryBinding.inflate(getLayoutInflater());
//        vBinding = DialogEngineBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
//        initRecyclerView(bookBean);
        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.7f);
        //设置弹出位置
        window.setGravity(Gravity.BOTTOM);
        initUi();
        initListener();
    }


    @SuppressLint("NotifyDataSetChanged")
    public void upDirectoryUi(int currentPage) {
        comicFlagDirectoryAdapter.upUi(currentPage);
        vBinding.rv1.scrollToPosition(currentPage);
    }

    @SuppressLint("SetTextI18n")
    private void initUi() {
        String titleName = null;
        int count;
        int res;
        if (comicSeeSumBean.isPDFMode()) {
            count = comicSeeSumBean.getSeeBeanList().get(0).getPdfCountPage();
            titleName = SeeComicMode.getNoAfterFileName(comicSeeSumBean.getSeeBeanList().get(0).getFileName());
            res = Abstract.getFileCover(comicSeeSumBean.getSeeBeanList().get(0).getFileType());
        } else {
            count = comicSeeSumBean.getSeeBeanList().size();
            String filePath = comicSeeSumBean.getSeeBeanList().get(0).getUrl();

            titleName = ComicMode.filePathToFatherFileName(filePath);
            if (titleName.equals(Constant.ROOT_NAME)) {
                titleName = "漫架";
            }
            res = Abstract.getFileCover(Constant.ROOT_NAME);//除了PDF,其他这里就用默认，因为都没有
        }
        vBinding.tvTitle.setText(TextUtils.isEmpty(titleName) ? "未知名称" : titleName);
        vBinding.tvNum.setText("共" + count + "话");
        vBinding.iv.setImageResource(res);

        if (treeNodeDataList == null || treeNodeDataList.size() == 0) {
            isShowDirectory(3);
            vBinding.tvNoData.setText("该文件暂无目录");
        } else {
            isShowDirectory(1);
            setRv1();
        }
        //在这里初始化标题数据
        initFlagListBean();
        vBinding.rb2.setText("标记(" + (listFlagBean == null ? 0 : listFlagBean.size()) + ")");
    }

    private void initListener() {
        vBinding.rg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == vBinding.rb1.getId()) {
                log("点击目录");
                if (treeNodeDataList == null || treeNodeDataList.size() == 0) {
                    isShowDirectory(3);
                    vBinding.tvNoData.setText("暂无目录");
                } else {
                    isShowDirectory(1);
                    setRv1();
                }
            } else if (checkedId == vBinding.rb2.getId()) {
                log("点击标记");
                upFlagUi();
            }
        });
        vBinding.v.setOnClickListener(v -> dismiss());

        vBinding.iv1.setOnClickListener(v -> {
            //排序并定位
            LinearLayoutManager1.setReverseLayout(isReverse = !isReverse);
            vBinding.rv1.scrollToPosition(currentPage);
        });
        vBinding.iv2.setOnClickListener(v -> {
            vBinding.rv1.scrollToPosition(currentPage);
        });
    }

    /**
     * 是否倒序
     */
    private boolean isReverse = false;

    /**
     * @param type 1=目录，2，标记，3，没有
     */
    private void isShowDirectory(int type) {
        if (type == 1) {
            vBinding.rl.setVisibility(View.VISIBLE);
            vBinding.rv2.setVisibility(View.GONE);
            vBinding.tvNoData.setVisibility(View.GONE);
        } else if (type == 2) {
            vBinding.rl.setVisibility(View.GONE);
            vBinding.rv2.setVisibility(View.VISIBLE);
            vBinding.tvNoData.setVisibility(View.GONE);
        } else if (type == 3) {
            vBinding.rl.setVisibility(View.GONE);
            vBinding.rv2.setVisibility(View.GONE);
            vBinding.tvNoData.setVisibility(View.VISIBLE);
        }
    }


    private void setRv1() {
        if (comicFlagDirectoryAdapter == null) {
            initRV(vBinding.rv1);
            comicFlagDirectoryAdapter = new ComicFlagDirectoryAdapter(listener, currentPage, treeNodeDataList);
            LinearLayoutManager1 = new LinearLayoutManager(context);
            vBinding.rv1.setLayoutManager(LinearLayoutManager1);
            vBinding.rv1.setAdapter(comicFlagDirectoryAdapter);
            vBinding.rv1.scrollToPosition(currentPage);
        }
    }

    private void setRv2() {
        if (comicFlagAdapter == null) {
            initRV(vBinding.rv2);
            comicFlagAdapter = new ComicFlagAdapter(context, this, listFlagBean);
            vBinding.rv2.setAdapter(comicFlagAdapter);
        }
    }

    private List<FlagBean> listFlagBean;


    //初始化标记数据
    public void initFlagListBean() {
//        if (listFlagBean == null) {
            if (comicSeeSumBean.isPDFMode()) {
                //如果是PDF,就用文件路径直接插
                FlagBean flagBean = comicSeeSumBean.getSeeBeanList().get(0).getFlagBean();
                if (flagBean == null) {
                    //说明还没有翻过页，因为Activity只在翻页的时候单独查PDF的数据
                    flagBean=new FlagBean();
                    flagBean.setFilePath(comicSeeSumBean.getSeeBeanList().get(0).getUrl());
                }
                listFlagBean = FlagBDDao.getInstance().query(flagBean, 2);

            } else {
//                FlagBDDao.getInstance().query();
                //如果是rv,就用文件父路径直接查
                FlagBean flagBean = new FlagBean();
                flagBean.setFilePath(comicSeeSumBean.getSeeBeanList().get(0).getUrl());
                listFlagBean = FlagBDDao.getInstance().query(flagBean, 3);
            }
//        }
    }


    private void initRV(RecyclerView rv) {
//        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        ((SimpleItemAnimator) rv.getItemAnimator()).setSupportsChangeAnimations(false);//禁止动画
//        rv1.setHasFixedSize(true);//itme大小固定时，提到性能
//        rv1.setItemViewCacheSize(20);//
//        rv1.setPreserveFocusAfterLayout(true);//在布局变化后是否保持焦点
//        pageAdapter.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid
        rv.setLayoutManager(layoutManager);
//        linearSnapHelper = new LinearSnapHelper();//用作横向滑动时，不保持偏移量，可多页滑动连续滑动
//        PagerSnapHelper linearSnapHelper1 = new PagerSnapHelper();//用作横向滑动时，不保持偏移量，只能一页一页滑动
    }

    @SuppressLint("SetTextI18n")
    public void upFlagUi() {
        if (listFlagBean == null || listFlagBean.size() == 0) {
            isShowDirectory(3);
            vBinding.tvNoData.setText("暂无标记");
        } else {
            isShowDirectory(2);
            setRv2();
        }
        vBinding.rb2.setText("标记(" + (listFlagBean == null ? 0 : listFlagBean.size()) + ")");
    }

    public void upAdaper2(){
        if (comicFlagAdapter != null) {
            comicFlagAdapter.notifyDataSetChanged();
        }
    }



    public interface DialogFlagDirectoryListener {

        void onClickPosition(int clickPosition);

        void onClickAdd();
    }


}
