package com.juying.mjreader.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import androidx.documentfile.provider.DocumentFile;

import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.FlagBean;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.utils.sqlite.FlagBDDao;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @Author Ycc
 * @Date 15:30
 */
public class ComicMode {

//    public static BookBean sendAssembleMessage(Handler handler, int code, String fileName, String fatherName, boolean isDirectory, long imputSchedule, long maxSize, int readPosition, String fileType, int childFileNum, List<BookBean> bookBeanList) {
//        BookBean bookBean = new BookBean(fileName, fatherName, isDirectory, imputSchedule, maxSize, readPosition, fileType, bookBeanList);
//        Message mess = new Message();
//        mess.what = code;
//        mess.obj = bookBean;
//        handler.sendMessage(mess);
//        return bookBean;
//    }

    public static BookBean sendAssembleMessage(Handler handler, int code, BookBean bookBean) {
        Message mess = new Message();
        mess.what = code;
        mess.obj = bookBean;
        handler.sendMessage(mess);
        return bookBean;
    }

    /**
     * 线程递归处理导入复制文件逻辑
     *
     * @param handler 要做之后导入过程中更新UI
     * @param code
     */
    @SuppressLint("CommitPrefEdits")
    public static void writeUri(ThreadPoolExecutor threadPoolExecutor, Context context, BookBean imputFatherBookBean, Uri originUri, File newFile, int selectFileType, Handler handler, int code) {

        threadPoolExecutor.execute(() -> {
            imputFatherBookBean.setOriginUriPath(originUri.getPath());
            if (selectFileType == 1) {
                //为目录的话直接新建，空的也行
                newFile.mkdirs();
                imputFatherBookBean.setDirectory(true);
                imputFatherBookBean.setLastModified(System.currentTimeMillis());
                imputFatherBookBean.setBookBeanList(new ArrayList<>());
                /**sp存储根目录【每个文件都对应一个sp,为了UI初始化查询】
                 *创建了目录，通知更新一遍UI
                 *存目录sp,在这存是因为，这里才设置目录最大值
                 * 此时只是创建了空目录，先存一遍sp 同时更新UI
                 */
                saveSP(context, imputFatherBookBean);
                ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                // 使用DocumentFile.fromTreeUri获取指定目录下的文件
                DocumentFile documentFile = DocumentFile.fromTreeUri(context, originUri);
                if (documentFile == null) {
                    LogUtil.d("TAG", "导入空目录");
                    return;
                }
                // 获取文件列表
                DocumentFile[] listFiles = documentFile.listFiles();
                // 将DocumentFile[]数组转换成Uri集合,如果是目录就不会放进去
                if (listFiles.length == 0) {
                    LogUtil.d("TAG", "导入空目录");
                    return;
                }
                //执行到这里，那肯定是一个有子文件的目录
                for (DocumentFile docFile : listFiles) {
                    File childFile = new File(newFile.getAbsolutePath() + "/" + docFile.getName());
                    String childType = docFile.getType();
                    Uri childUri = docFile.getUri();
                    if (TextUtils.isEmpty(childType)) {
                        // 子文件为目录,递归导入————产品说子文件不能再有目录了，所以就不存了，相当于只能导入1层目录
//                        writeUri(threadPoolExecutor, context, childUri, childFile, 1, handler, code);
                    } else {
                        //子文件为文件,过滤不支持的类型
                        //先获得所有子文件大小，更新目录UI
                        for (String supportType : Constant.SUPPORT_TYPE) {
                            if (childType.equals(supportType)) {
                                //如果是目录，无法在前面流程获得真是大小，所以在这里累加
                                imputFatherBookBean.setMaxSize(imputFatherBookBean.getMaxSize() + docFile.length());
                            }
                        }
                        /**
                         * 这里更新了改目录里子文件的总大小，存一遍sp 同时更新UI
                         */
                        saveSP(context, imputFatherBookBean);
                        ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                        //再导入子文件
                        imputFatherBookBean.setImputProcess(true);
                        for (String supportType : Constant.SUPPORT_TYPE) {
                            if (childType.equals(supportType)) {
                                //支持的子文件数
                                BookBean imputChildBookBean = new BookBean();
                                imputChildBookBean.setFileType(childType.split("/")[1]);
                                imputChildBookBean.setDirectory(false);
//                                imputChildBookBean.setFileName(childFile.getName());
                                imputChildBookBean.setOriginUriPath(childUri.getPath());
//                                imputChildBookBean.setFatherName(imputFatherBookBean.getFileName());
                                imputChildBookBean.setFilePath(childFile.getAbsolutePath());
                                FilesUtils.uriWriteFile(context, childUri, childFile, imputFatherBookBean, imputChildBookBean, handler, code);
                                break;
                            }
                        }
                        imputFatherBookBean.setImputProcess(false);
                    }
                }

            } else if (selectFileType == 2) {
                imputFatherBookBean.setDirectory(false);
                String name = newFile.getName();
                String type = name.substring(name.lastIndexOf(".") + 1, name.length());
                imputFatherBookBean.setFileType(type);
                FilesUtils.uriWriteFile(context, originUri, newFile, imputFatherBookBean, null, handler, code);
            }
        });
    }


    public static BookBean saveSP(Context context, BookBean bookBean) {
        //sp只能统一存一个文件夹，所以采用父文件名+"_-_"+子文件名的方式，是为了尽可能防止重名情况
        String fileName = bookBean.getFileName();
        //存sp会自动上.xml后缀，所以这里必须去掉后缀，不然会报错
        String s;
        if (bookBean.isDirectory()) {
            s = fileName;
        } else {
//            if (fileName.contains(".")) {
                s = fileName.substring(0, fileName.lastIndexOf("."));
//            }
        }
        String spName = bookBean.getFatherName() + FLAG + s;
        SharedPreferences.Editor editor = context.getSharedPreferences(spName, Context.MODE_PRIVATE).edit();
//        bookBean.setSpFileName(spName);
        bookBean.setSpFilePath(fileNameToSpPath(context, spName));
        editor.putLong("maxSize", bookBean.getMaxSize());
        editor.putString("originUriPath", bookBean.getOriginUriPath() == null ? "" : bookBean.getOriginUriPath());
        editor.putString("fileType", bookBean.getFileType() == null ? "" : bookBean.getFileType());
        editor.putInt("readPosition", bookBean.getReadPosition());
        //sp注意apply和commit的区别,前者先改变内存值再异步存，后者先改内存值再同步存
//        editor.apply();
        editor.commit();
        return bookBean;
    }


    /**
     * 获得Sp文件名
     *
     * @param fileName   自己文件名称
     * @param fatherName 父文件名称
     * @return
     */
    public static String getSpFileName(String fileName, String fatherName) {
        //TODO 存SP，这里放弃了用判断是否是目录来存，考虑到有的文件就是没有后缀名的，这里也可以存
        String with = fileName;
        if (fileName.contains(".")) {
            with = fileName.substring(0, fileName.lastIndexOf("."));
        }
        return fatherName + ComicMode.FLAG + with;
    }

    /**
     * 获得Sp文件路径
     *
     * @param fileName   自己文件名称
     * @param fatherName 父文件名称
     * @return
     */
    public static String getSpFilePath(Context context, String fileName, String fatherName) {
        return "/data/data/" + context.getPackageName() + "/shared_prefs/" + getSpFileName(fileName, fatherName) + ".xml";
    }

    public static BookBean saveSP(Context context, BookBean bookBean, boolean isSynchronous) {
        //sp只能统一存一个文件夹，所以采用父文件名+"_-_"+子文件名的方式，是为了尽可能防止重名情况
        String spName = getSpFileName(bookBean.getFileName(), bookBean.getFatherName());
        SharedPreferences.Editor editor = context.getSharedPreferences(spName, Context.MODE_PRIVATE).edit();
        editor.putLong("maxSize", bookBean.getMaxSize());
        editor.putString("originUriPath", bookBean.getOriginUriPath() == null ? "" : bookBean.getOriginUriPath());
        editor.putString("fileType", bookBean.getFileType() == null ? "" : bookBean.getFileType());
        editor.putInt("readPosition", bookBean.getReadPosition());
        bookBean.setSpFilePath(fileNameToSpPath(context, spName));
        if (isSynchronous) {
            editor.commit();
        } else {
            editor.apply();
        }
//        //sp只能统一存一个文件夹，所以采用父文件名+"_-_"+子文件名的方式，是为了尽可能防止重名情况
//        String fileName = bookBean.getFileName();
//        //存sp会自动上.xml后缀，所以这里必须去掉后缀，不然会报错
//        String s;
//        if (bookBean.isDirectory()) {
//            s = fileName;
//        } else {
//            s = fileName.substring(0, fileName.lastIndexOf("."));
//        }
//        String spName = bookBean.getFatherName() + FLAG + s;
//        SharedPreferences.Editor editor = context.getSharedPreferences(spName, Context.MODE_PRIVATE).edit();
////        bookBean.setSpFileName(spName);
//        bookBean.setSpFilePath(fileNameToSpPath(context, spName));
//        editor.putLong("maxSize", bookBean.getMaxSize());
//        editor.putString("originUriPath", bookBean.getOriginUriPath() == null ? "" : bookBean.getOriginUriPath());
//        editor.putString("fileType", bookBean.getFileType() == null ? "" : bookBean.getFileType());
//        editor.putInt("readPosition", bookBean.getReadPosition());
//        //sp注意apply和commit的区别,前者先改变内存值再异步存，后者先改内存值再同步存
//        if (isSynchronous) {
//            editor.commit();
//        } else {
//            editor.apply();
//        }
        return bookBean;
    }


    public static BookBean saveFile(BookBean bookBean) {

        if (bookBean != null) {
            File file = new File(bookBean.getFilePath());
            if (!file.exists()) {
                file.mkdirs();
            }
        }

        return bookBean;
    }


    public static BookBean takeSP(Context context, BookBean bookBean) {
        //sp只能统一存一个文件夹，所以采用父文件名+"_-_"+子文件名的方式，是为了尽可能防止重名情况
        String filePath = bookBean.getFilePath();
        String spName = filePathToSpName(filePath, new File(filePath).isDirectory());
        SharedPreferences sp = context.getSharedPreferences(spName, Context.MODE_PRIVATE);
//        bookBean.setSpFileName(spName);
        bookBean.setSpFilePath(fileNameToSpPath(context, spName));
        bookBean.setMaxSize(sp.getLong("maxSize", 0));
        bookBean.setReadPosition(sp.getInt("readPosition", 0));
        bookBean.setOriginUriPath(sp.getString("originUriPath", ""));
        return bookBean;
    }


    public static BookBean changeSP(BookBean originBean, String newFileName) {
        //
        //改SP，存在且是目录才允许改名
        if (!TextUtils.isEmpty(originBean.getSpFilePath()) && originBean.isDirectory()) {
            File file = new File(originBean.getSpFilePath());
            if (file.exists()) {
                String newSpName = originBean.getFatherName() + FLAG + newFileName + ".xml";
                boolean isOk = file.renameTo(new File(newSpName));
                if (isOk) {
                    originBean.setSpFilePath(file.getAbsolutePath());
                }
            }
        }
        //改文件

        return originBean;

    }

    /**
     * 删除文件和sp
     *
     * @param baseBean     一定是目录：根Bean 或者 二级目录Bean
     * @param isDelOneself 是否删除[BaseBean]自身，子Bean不管是文件还是目录是一定删除的，;
     */
    public static boolean delSPandFile(BookBean baseBean, boolean isDelOneself) {
        boolean isOk = false;
        try {
            //删除SQL标记
//                currentShowBean.FlagBDDao.getInstance().delBean(,);
            List<BookBean> listBean = baseBean.getBookBeanList();
            if (listBean != null) {
                for (int i = 0; i < listBean.size(); i++) {
                    BookBean delBean = listBean.get(i);
                    //如果删除组，直接删；如果不删除组，还的判断一下子项是否选中
                    if (delBean.isChecked()) {
                        //删除文件
                        delFiles(new File(delBean.getFilePath()));
                        //删除sp
                        delFiles(new File(delBean.getSpFilePath()));
                    }
                }
            }
            if (isDelOneself) {
                //删除文件
                delFiles(new File(baseBean.getFilePath()));
                //删除sp
                delFiles(new File(baseBean.getSpFilePath()));
            }
            isOk = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isOk;
    }


    /**
     * 删除文件，或者删除文件及其子文件
     *
     * @param file
     */
    private static void delFiles(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
                for (File childFile : file.listFiles()) {
                    if (childFile.isDirectory()) {
                        delFiles(childFile);
                    } else {
                        childFile.delete();
                        delFlagSQL(childFile.getAbsolutePath());
                    }
                }
                file.delete();
                delFlagSQL(file.getAbsolutePath());
            } else {
                file.delete();
                delFlagSQL(file.getAbsolutePath());
            }
        }
    }

    private static void delFlagSQL(String url) {
        FlagBean flagBean = new FlagBean();
        flagBean.setFilePath(url);
        FlagBDDao.getInstance().delBean(flagBean, 2);
    }


    /**
     * 移动文件到目录
     *
     * @param originFileBean
     * @param newDirectoryBean
     */
    public static BookBean moveSPandFile(Context context, BookBean originFileBean, BookBean newDirectoryBean) {
        if (originFileBean.getFileName().equals(newDirectoryBean.getFileName())) {
            return originFileBean;
        }
        String originFilePath = originFileBean.getFilePath();
        String originSPPath = originFileBean.getSpFilePath();
        String newDirectoryPath = newDirectoryBean.getFilePath();
//        String newSPPath = newDirectoryBean.getSpFilePath();
        File originFile = new File(originFilePath);

        String newFilePath=newDirectoryPath + "/" + originFileBean.getFileName();

        //物理变动;文件
        File newFile = new File(newFilePath);
        originFile.renameTo(newFile);

        //变SQL标记
        upFlagBean(originFilePath,newFilePath);
        //sp
        String originFileName = originFileBean.getFileName();
        String newSPpath = fileNameToSpPath(context, newDirectoryBean.getFileName() + FLAG + originFileName.substring(0, originFileName.lastIndexOf(".")));
        File originSP = new File(originSPPath);
        originSP.renameTo(new File(newSPpath));

        //内存变动
        originFileBean.setFilePath(newFile.getAbsolutePath());
//        originFileBean.setFatherName(newDirectoryBean.getFileName());

        return originFileBean;
    }

    private static void upFlagBean(String originFilePath, String newFilePath) {
        FlagBean originFlagBean = new FlagBean();
        originFlagBean.setFilePath(originFilePath);
        FlagBean newFlagBean = new FlagBean();
        newFlagBean.setFilePath(newFilePath);
        FlagBDDao.getInstance().upBean(originFlagBean,newFlagBean,3);
    }


    /**
     * 重命名文件【先改物理再改内存，先改父再子，先改sp再改文件，否则会错乱，只要发生改变2个path2个名称都要变和1个父名称都要变】
     */
    public static BookBean renameFileAndSP(BookBean bookBean, String newName) {
        //改物理file
        File newFile = renameFile(new File(bookBean.getFilePath()), newName);
        //改物理父SP
        File newSp = renameSP(new File(bookBean.getSpFilePath()), newName, true);
        //改物理子sp,顺道改内存file和sp
        List<BookBean> listBean = bookBean.getBookBeanList();
        if (bookBean.isDirectory() && listBean != null && listBean.size() > 0) {
            for (int i = 0; i < listBean.size(); i++) {
                BookBean bean = listBean.get(i);
                File newChildSP = renameSP(new File(bean.getSpFilePath()), newName, false);
                if (newChildSP != null) {
                    bean.setSpFilePath(newChildSP.getAbsolutePath());
                    bean.setFilePath(newFile.getAbsolutePath() + "/" + bean.getFileName());
//                    bean.setFatherName(newFile.getName());
                }
            }
        }

        //改父内存sp
        if (newSp != null) {
//            bookBean.setSpFileName(newSp.getName().substring(0, newSp.getName().lastIndexOf(".")));
            bookBean.setSpFilePath(newSp.getAbsolutePath());
        }
        //改父内存file
        if (newFile != null) {
//            bookBean.setFileName(newFile.getName());
            bookBean.setFilePath(newFile.getAbsolutePath());
        }

        return bookBean;
    }

    /**
     * 重命名文件
     *
     * @param file
     * @param newName
     * @return
     */
    private static File renameFile(File file, String newName) {
        if (file.exists()) {
            String originFilePath = file.getAbsolutePath();
            String newFilePath;
            String newFilename;
            if (file.isDirectory()) {
                newFilePath = originFilePath.substring(0, originFilePath.lastIndexOf("/") + 1) + newName;
            } else {
                newFilename = newName + originFilePath.substring(originFilePath.lastIndexOf("."), originFilePath.length());
                newFilePath = originFilePath.substring(0, originFilePath.lastIndexOf("/") + 1) + newFilename;
            }
            File newFile = new File(newFilePath);
            file.renameTo(newFile);
            return newFile;
        }
        return null;
    }

    /**
     * 重命名SP
     *
     * @param spFile
     * @param newName
     * @param isDirectory 其实所有sp都是文件，这里就是告知更改前缀还是更改后缀
     * @return
     */
    private static File renameSP(File spFile, String newName, boolean isDirectory) {
        if (spFile.exists()) {
            String newFileName;
            String originSpName = spFile.getName();
            String originSpPath = spFile.getAbsolutePath();
            if (isDirectory) {
                newFileName = originSpName.split(FLAG)[0] + FLAG + newName + ".xml";
            } else {
                newFileName = newName + FLAG + originSpName.split(FLAG)[1];
            }
            String newSpPath = originSpPath.substring(0, originSpPath.lastIndexOf("/") + 1) + newFileName;
            File newSp = new File(newSpPath);
            spFile.renameTo(newSp);
            return newSp;
        }
        return null;
    }

    /**
     * 通过filePath获取spName
     *
     * @param filePath
     * @param isDirectory
     * @return
     */
    public static String filePathToSpName(String filePath, boolean isDirectory) {
        String spName = "";
        if (filePath.contains("/")) {
            if (!TextUtils.isEmpty(filePath)) {
                int index1 = filePath.lastIndexOf("/");
                String cName;
                int startIndex = filePath.lastIndexOf("/", index1 - 1) + 1;
                String fName = filePath.substring(startIndex, index1);
                if (isDirectory) {
                    cName = filePath.substring(index1 + 1, filePath.length());
                } else {

                    File file = new File(filePath);
                    boolean isWith = false;
                    if (file.getName().contains(".")) {
                        for (String type : Constant.END_TYPE) {
                            if (file.getName().endsWith(type)) {
                                isWith = true;
                                break;
                            }
                        }
                    }
                    if (isWith) {
                        int index2 = filePath.lastIndexOf(".");
                        cName = filePath.substring(index1 + 1, index2);
                    } else {
                        return "";
                    }
                }
                spName = fName + FLAG + cName;
            }
        }
        return spName;
    }

    public static String fileNameToSpPath(Context context, String fileName) {
        return "/data/data/" + context.getPackageName() + "/shared_prefs/" + fileName + ".xml";
    }

    /**
     * 通过文件路径获取父目录名
     *
     * @param filePath
     * @return
     */
    public static String filePathToFatherFileName(String filePath) {
        String spName = "";
        if (filePath.contains("/")) {
            spName = filePath.substring(StringUtils.getReciprocal2(filePath, "/") + 1, filePath.lastIndexOf("/"));
        }
        return spName;
    }

    public static String FLAG = "_-_";


    /**
     * 删除内存中选中的子bean,
     *
     * @param bookBean 根Bean
     * @return
     */
    public static BookBean delMemory(BookBean bookBean) {
        if (bookBean != null && bookBean.getBookBeanList() != null && bookBean.getBookBeanList().size() > 0) {
            List<BookBean> listBean = bookBean.getBookBeanList();
            for (int i = 0; i < listBean.size(); i++) {
                BookBean bean = listBean.get(i);
                if (bean.isChecked()) {
                    bookBean.setMaxSize(bookBean.getMaxSize() - bean.getMaxSize());
                    listBean.remove(i);
                    i--;
                }
            }
        }
        return bookBean;
    }

    /**
     * 匹配包含某字符的子bean,
     *
     * @param bookBean 根Bean
     * @return
     */
    public static BookBean huntBean(BookBean bookBean, String fileName) {
        if (bookBean != null && bookBean.getBookBeanList() != null && bookBean.getBookBeanList().size() > 0) {
            List<BookBean> listBean = bookBean.getBookBeanList();
//            BookBean bean=new BookBean(bookBean);
            for (int i = 0; i < listBean.size(); i++) {
                BookBean bean = listBean.get(i);
                if ("".equals(fileName)) {
                    bean.setFrontShow(true);
                } else {
                    bean.setFrontShow(bean.getFileName().contains(fileName));
                }
            }
        }
        return bookBean;
    }





    /**
     * 匹配包含某字符的子bean,
     *
     * @return
     */
//    public static List<BookBean> huntBean(BookBean bookBean, String fileName) {
//        List<BookBean> newListBean = new ArrayList<>();
//        if (bookBean != null && bookBean.getBookBeanList() != null && bookBean.getBookBeanList().size() > 0) {
//            List<BookBean> listBean = bookBean.getBookBeanList();
//            for (int i = 0; i < listBean.size(); i++) {
//                BookBean bean = listBean.get(i);
//                if (bean.getFileName().contains(fileName)) {
//                    newListBean.add(bean);
//                }
//
//            }
//        }
//        return newListBean;
//    }
    private void saveSettingSP() {

    }


}
