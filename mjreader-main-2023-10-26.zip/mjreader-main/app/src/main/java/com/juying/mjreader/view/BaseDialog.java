package com.juying.mjreader.view;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.ToastUtils;

/**
 * @Author Ycc
 * @Date 19:33
 */
public class BaseDialog extends Dialog {
    protected String TAG=getClass().getSimpleName();
    public BaseDialog(@NonNull Context context) {
        super(context);
    }

    public BaseDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    protected BaseDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    protected void to(String s, boolean isLog) {
//        Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
        ToastUtils.show(getContext(),s);
        if (isLog) {
            Log.d(TAG, s);
        }
    }

    protected void log(String s) {
        LogUtil.d(TAG, s);
    }
}
