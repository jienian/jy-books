package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.ImageViewTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.card.MaterialCardView;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeImageActivity;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.databinding.ItemWifiSeeIamge3Binding;
import com.juying.mjreader.net.NetUtils;
import com.juying.mjreader.utils.DeviceInfo;

import java.util.ArrayList;


public class ComicWifiSeeImageAdapter1 extends BaseAdapter<ComicWifiSeeImageAdapter1.ViewHolder> {
    private final ComicSeeSumBean comicSeeSumBean;
    private SeeImageActivity context;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;

    ViewGroup.LayoutParams layoutParams1 = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    ViewGroup.LayoutParams layoutParams2 = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

    public ComicWifiSeeImageAdapter1(SeeImageActivity context, ComicSeeSumBean comicSeeSumBean) {
        this.context = context;
        this.comicSeeSumBean = comicSeeSumBean;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_comic_page, parent);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wifi_see_iamge1, null, false);
        viewHolder = new ViewHolder(view);
        if (!context.isContinuitySeeMode) {
            view.setLayoutParams(layoutParams1);
        } else {
            view.setLayoutParams(layoutParams2);
        }
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull ComicWifiSeeImageAdapter1.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ComicSeeBean comicSeeBean = comicSeeSumBean.getSeeBeanList().get(position);
        holder.setLL();
        ViewGroup.LayoutParams layoutParams = holder.iv.getLayoutParams();
        ViewGroup.LayoutParams layoutParams3 = holder.itemView.getLayoutParams();
        if (comicSeeBean == null || comicSeeBean.isImageLoadFail()) {
            holder.mcvError.setVisibility(View.VISIBLE);
            holder.iv.setVisibility(View.GONE);
//            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
//            layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
            //加载异常的时候设置整个itemView拉大

            layoutParams3.width = ViewGroup.LayoutParams.MATCH_PARENT;
//            layoutParams3.height = ViewGroup.LayoutParams.MATCH_PARENT;

        } else {
            holder.mcvError.setVisibility(View.GONE);
            holder.iv.setVisibility(View.VISIBLE);
            layoutParams.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            Glide.with(context)
//                    .asDrawable()//比bitmap要省
                    .load(comicSeeBean.getUrl())
                    .override(comicSeeBean.getWidth(), comicSeeBean.getHeight())
//                    .override(500, 500)
                    .into(holder.iv);
        }


//        setImage(viewHolder, comicSeeBean);


    }

    private void setImage(ComicWifiSeeImageAdapter1.ViewHolder viewHolder, ComicSeeBean comicSeeBean) {
        Glide.with(context)
//                .asDrawable()//比bitmap要省
//                    .load(bean.isWifiData()?comicSeeBean.getImges():comicSeeBean.getUrl())
                .load(comicSeeBean.getUrl())
//                    .override(comicSeeBean.getWidth(), comicSeeBean.getHeight())
//                .override(viewHolder.iv.getWidth(), viewHolder.iv.getHeight())
                .override(comicSeeBean.getWidth(), comicSeeBean.getHeight())


                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        log("网络访问失败，请检查是否开始网络或者增加http的访问许可");
                        viewHolder.tvError.setText("网络异常");
                        comicSeeBean.setImageLoadFail(true);
                        loadType(2, viewHolder.pb, viewHolder.mcvError, viewHolder.mcvError, viewHolder.iv);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        log("网络访问成功，可以显示图片,资源宽：" + resource.getIntrinsicWidth() + ";资源高：" + resource.getIntrinsicHeight());
//首先设置imageView的ScaleType属性为ScaleType.FIT_XY，让图片不按比例缩放，把图片塞满整个View。

//                        if(viewHolder.iv.getScaleType() != ImageView.ScaleType.FIT_XY) {
//
//                            viewHolder.iv.setScaleType(ImageView.ScaleType.FIT_XY);
//
//                        }
//
////得到当前imageView的宽度（我设置的是屏幕宽度），获取到imageView与图片宽的比例，然后通过这个比例去设置imageView的高
//
//                        ViewGroup.LayoutParams params =viewHolder.iv.getLayoutParams();
//
//                        int vw =viewHolder.iv.getWidth() -viewHolder.iv.getPaddingLeft() -viewHolder.iv.getPaddingRight();
//
//                        float scale = (float) vw / (float) resource.getIntrinsicWidth();
//
//                        int vh = Math.round(resource.getIntrinsicHeight() * scale);
//
//                        params.height= vh +viewHolder.iv.getPaddingTop() +viewHolder.iv.getPaddingBottom();
//
//                        viewHolder.iv.setLayoutParams(params);


//                        viewHolder.iv.setImageDrawable(resource);
//                        ViewGroup.LayoutParams lp = viewHolder.iv.getLayoutParams();
//                        lp.width = windowWidth;
//                        lp.height = DensityUtil.getScreen / idth(context) * resource.getIntrinsicHeight() / resource.getIntrinsicWi
//                        dth()
//                        view.setLayoutParams(lp)


                        return false;
                    }
                })
                .placeholder(R.mipmap.ic_launcher)
//                .placeholder(errorImageId)
                .into(new ImageViewTarget<Drawable>(viewHolder.iv) {
                    //图片开始加载
                    @Override
                    public void onLoadStarted(Drawable placeholder) {
                        super.onLoadStarted(placeholder);
                        log("图片开始加载");
                        loadType(1, viewHolder.pb, viewHolder.mcvError, viewHolder.mcvError, viewHolder.iv);
                    }

                    @Override
                    public void onLoadFailed(Drawable errorDrawable) {
                        super.onLoadFailed(errorDrawable);
                        log("图片加载失败");
                        viewHolder.tvError.setText("资源损坏");
                        comicSeeBean.setImageLoadFail(true);
                        loadType(3, viewHolder.pb, viewHolder.mcvError, viewHolder.mcvError, viewHolder.iv);

                    }

                    //图片加载完成
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, Transition<? super Drawable> transition) {
                        super.onResourceReady(resource, transition);
                        log("图片加载完成");
                        // 图片加载完成
                        viewHolder.iv.setImageDrawable(resource);
                        loadType(4, viewHolder.pb, viewHolder.mcvError, viewHolder.mcvError, viewHolder.iv);
                        comicSeeBean.setImageLoadFail(false);
                    }

                    @Override
                    protected void setResource(Drawable resource) {
//                        log("设置资源");
                    }
                });
    }

    private void setImage2(ComicWifiSeeImageAdapter1.ViewHolder viewHolder, ComicSeeBean comicSeeBean) {


    }

    @Override
    public int getItemCount() {
//        return getShowSize(bookBean);
        return comicSeeSumBean == null || comicSeeSumBean.getSeeBeanList() == null ? 0 : comicSeeSumBean.getSeeBeanList().size();
    }

    private int getShowSize(BookBean bookBean) {
        if (bookBean == null || bookBean.getBookBeanList() == null || bookBean.getBookBeanList().size() == 0 || bookBean.getTreeNodeData() == null) {
            return 0;
        }
        showPosition = new ArrayList<>();
        for (int i = 0; i < bookBean.getBookBeanList().size(); i++) {
            BookBean bean = bookBean.getBookBeanList().get(i);
            if (bean.getMaxSize() > bean.getImputSchedule() || bean.isDirectory() || bean.getFileType().contains("pdf")) {
                //如果是未导入完成、目录、pdf就不在Rv里显示
            } else {
                showPosition.add(i);
            }
        }
        return showPosition.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView iv;
        private final TextView tvError;
        private final MaterialCardView mcvError;
        private final View itemView;
        private final ProgressBar pb;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemView = itemView;
            iv = itemView.findViewById(R.id.iv);
            tvError = itemView.findViewById(R.id.tv_error);
            mcvError = itemView.findViewById(R.id.mcv);
            pb = itemView.findViewById(R.id.pb);
            mcvError.setOnClickListener(v -> {
                if (NetUtils.isNetSystemUsable(MjApplication.CONTEXT)) {
//                    viewShow(1);
                    context.reconnect();
                } else {
//                    viewShow(2);
                    Toast.makeText(context, "请检查网络", Toast.LENGTH_SHORT).show();
                }

            });
        }


        public void setLL() {
            ViewGroup.LayoutParams layoutParams = (ViewGroup.LayoutParams) itemView.getLayoutParams();
            if (layoutParams == null) {
                return;
            }
            if (context.isContinuitySeeMode) {
                layoutParams.width = ViewGroup.LayoutParams.WRAP_CONTENT;
                layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                itemView.setLayoutParams(layoutParams);
//                itemview.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
            } else {
                layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
                itemView.setLayoutParams(layoutParams);
//                itemview.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.WRAP_CONTENT, RecyclerView.LayoutParams.WRAP_CONTENT));
            }

        }
    }


    private void viewShow(int type) {
        if (type == 1) {
//            viewHolder.iv.setVisibility(View.VISIBLE);
//            viewHolder.bt.setVisibility(View.GONE);
        } else if (type == 2) {
//            viewHolder.iv.setVisibility(View.GONE);
//            viewHolder.bt.setVisibility(View.VISIBLE);
        }
    }


}
