package com.juying.mjreader.utils;

import android.content.Context;

import java.io.File;

/**
 * @Author Ycc
 * @Date 13:45
 */
public class SpUtil {


    /**
     * 通过文件名,获取sp文件
     * @param context
     * @param fileName
     * @return
     */
    public static File fileNameToSpFile(Context context, String fileName) {
        return new File("/data/data/" + context.getPackageName() + "/shared_prefs/" + fileName + ".xml");
    }
}
