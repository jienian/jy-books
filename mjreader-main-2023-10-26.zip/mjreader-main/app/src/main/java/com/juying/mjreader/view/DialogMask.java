package com.juying.mjreader.view;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;

import com.juying.mjreader.ActivityManager;

/**
 * @Author Ycc
 * @Date 18:52
 * 全局遮罩Dialog
 */
public class DialogMask {

    private static DialogMask dialogMask;
    private final AlertDialog dialog;
    private final Context context;
    private Window window;

    private DialogMask(Context context) {
        this.context = context;
        dialog = new AlertDialog.Builder(context.getApplicationContext())
                .create();

    }

    public static DialogMask example(Context context) {
        if (dialogMask == null) {
            dialogMask = new DialogMask(context);
        }
        return dialogMask;
    }


    public void show() {

        if (window == null) {
            structure(dialog);
        }
        dialog.show();
    }

    //构建
    private void structure(Dialog dialog) {
        dialog.setCanceledOnTouchOutside(false);
        window = dialog.getWindow();

        window.setDimAmount(0.5f);
        //        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

        //检查版本，注意当type为TYPE_APPLICATION_OVERLAY时，铺满活动窗口，但在关键的系统窗口下面，如状态栏或IME
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        } else {
            window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        }
//        dialog.setOnKeyListener((dialog1, keyCode, event) -> true);//拦截物理返回键

        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
//                Log.d("TAG", "keyCode: " + keyCode+";event:"+event.getAction());
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 && event.getAction() == KeyEvent.ACTION_UP) {
                    Activity a = ActivityManager.getCurrentActivity();
//                    Log.d("TAG", "Activity: " + a);
                    a.onBackPressed();
                }
                return true;
            }
        });//拦截物理返回键
    }


    public void dismiss() {
        if (dialog != null) {
            dialog.dismiss();
        }
    }


    //调节遮罩亮度 0f~1.0f
    public void setBrightness(float brightness) {
        if (window != null) {
            window.setDimAmount(brightness);
        }
    }
}
