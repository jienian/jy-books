package com.juying.mjreader.utils.config;

import android.text.TextUtils;

import com.juying.mjreader.R;

/**
 * @Author Ycc
 * @Date 15:10
 */
public abstract class Abstract {


    /**
     * 根据文件类型匹配封面
     *
     * @param fileType
     * @return
     */
    public static int getFileCover(String fileType) {
        int image = R.drawable.comic_book;
        if (!TextUtils.isEmpty(fileType)) {
            if (fileType.contains("pdf")) {
                image = R.drawable.pdf;
            } else if (fileType.contains("png")) {
                image = R.drawable.png;
            } else if (fileType.contains("jpeg") || fileType.contains("jpg")) {
                image = R.drawable.jpg;
            } else if (fileType.contains("webp")) {
                image = R.drawable.webp;
            } else if (fileType.contains("gif")) {
                image = R.drawable.gif;
            }
        }
        return image;
    }


}
