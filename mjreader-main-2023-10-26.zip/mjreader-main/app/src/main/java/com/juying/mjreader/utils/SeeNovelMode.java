package com.juying.mjreader.utils;

import android.app.Activity;
import android.text.TextUtils;
import android.view.Window;
import android.view.WindowManager;

import com.juying.mjreader.databinding.ActivitySeeNovelBinding;
import com.juying.mjreader.manager.NovelSettingManager;

public class SeeNovelMode {

    private boolean isNightMode;
    private NovelSettingManager mSettingManager;

    /**
     * 设置标题
     * @param isHaveAfter 标题是否有后缀，有的话有剔除
     */

    public static void setTitle(ActivitySeeNovelBinding vBinding, String name, boolean isHaveAfter){
        if(TextUtils.isEmpty(name)) {
            return;
        }
        String text = name;
        if(isHaveAfter){
            if(isHaveAfter){
                if (name.contains(".")) {
                    text = name.substring(0, name.lastIndexOf("."));
                }
            }
            vBinding.tvTitle.setText(text);
        }

    }

    public static void setTitleTxt(ActivitySeeNovelBinding vBinding, String name, boolean isHaveAfter){
        if (TextUtils.isEmpty(name)) {
            return;
        }
        String text = name;
        if(isHaveAfter) {
            if (name.contains(".")) {
                text = name.substring(0, name.lastIndexOf("."));
            }
        }
        vBinding.tvTitle.setText(text);
    }



    /**
     * 设置亮度
     * @param context
     * @param brightness 0.0~1.0 的数
     */
    public static void setBrightness(Activity context, float brightness) {
        Window window = context.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        //设置系统亮度需要获取运行时权限，所以不用这个方案
//            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 200);
        lp.screenBrightness = brightness;
        window.setAttributes(lp);
    }



}
