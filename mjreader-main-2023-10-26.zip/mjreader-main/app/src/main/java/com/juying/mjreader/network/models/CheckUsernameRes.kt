package com.juying.mjreader.network.models
/**
 * @author Nimyears
 */
data class CheckUsernameRes(val account: String, val isExist:Boolean)
