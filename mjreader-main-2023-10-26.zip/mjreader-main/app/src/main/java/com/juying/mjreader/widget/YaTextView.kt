package com.juying.mjreader.widget

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

class YaTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr) {
  /*  @Override
    override fun setTypeface(tf: Typeface?, style: Int) {
        if (style == Typeface.BOLD) {
            super.setTypeface(FontManager.yab, style)
        } else {
            super.setTypeface(FontManager.yam, style)
        }
    }*/
}