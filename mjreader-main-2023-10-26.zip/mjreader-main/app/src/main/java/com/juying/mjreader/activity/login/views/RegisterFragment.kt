
package com.juying.mjreader.activity.login.views


import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil.setContentView
import androidx.lifecycle.lifecycleScope
import com.juying.mjreader.databinding.FragmentLoginBinding
import com.juying.mjreader.databinding.FragmentRegisterBinding
import com.juying.mjreader.fragment.BaseFragment
import com.juying.mjreader.manager.UserManager
import com.juying.mjreader.network.util.ValidateUtil
import com.juying.mjreader.utils.AppUtil
import com.juying.mjreader.widget.LoadingView
import com.juying.mjreader.widget.LoadingViewImpl

import kotlinx.coroutines.launch

/**
 * @author Nimyears
 *
 */

class RegisterFragment : BaseFragment(), LoadingView by LoadingViewImpl() {

    private val TAG = "LoginFragment"
    private lateinit var binding: FragmentRegisterBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegisterBinding.inflate(inflater, container, false)
        initView()
        initListener()
        return binding.root
    }

    fun initView() {
        loadingView = binding.loadingWrap.loadingView
    }

     fun initListener() {

        binding.btRegister.setOnClickListener {

            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val password2 = binding.etPassword2.text.toString().trim()

            if (!validate(username, password, password2)) return@setOnClickListener

            if (loading) return@setOnClickListener
            showLoading()

            lifecycleScope.launch {
                val isExist = UserManager.checkUsername(username)
                if (isExist) {
                    val data = UserManager.registerAndLogin(username, password)
                    data?.let {
                        Toast.makeText(
                            requireContext(),
                            "欢迎${AppUtil.getAppName(requireContext())}",
                            Toast.LENGTH_SHORT
                        ).show()
                        requireActivity().setResult(Activity.RESULT_OK)
                        requireActivity().finish()
                    }
                } else {
                    Toast.makeText(requireContext(), "该账号已存在，请直接登录！", Toast.LENGTH_SHORT)
                        .show()
                }

                hideLoading()
            }
        }
    }

    private fun validate(username: String, password: String, password2: String): Boolean {
        val isEmail = ValidateUtil.isEmail(username)
        val isPhone = ValidateUtil.isPhoneNumber(username)
        val isEmailOrPhone = isEmail || isPhone
        if (!isEmailOrPhone) {
            Toast.makeText(
                requireContext(),
                "请输入有效的账户格式!",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        if (password.length > 15 || password.length < 6) {
            Toast.makeText(
                requireContext(),
                "密码长度不能小于6位或大于15位",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        if (password != password2) {
            Toast.makeText(
                requireContext(),
                "两次输入的密码不一致",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        return true
    }
}