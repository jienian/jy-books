package com.juying.mjreader.utils.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.bean.FlagBean;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 18:27
 */
public class FlagBDDao extends BaseDBoperate{

    public static String TABLE_NAME = "book_flag";//表名

    private static final String ID = "id";//id自增长
    //用户id
    private static final String userID = "user_id";
    //标记时间
    private static final String saveTime = "saveTime";
    //内容
    private static final String content = "content";
    //文件路径【和外面唯一链接】
    private static final String filePath = "filePath";
    //文件父路径【批量查询用】
    private static final String fatherPath = "fatherPath";
    //文件封面
    private static final String coverUrl = "coverUrl";
    //文件类型
    private static final String fileType = "fileType";
    //文件标题
    private static final String fileName = "fileName";
    //本标记是文件的多少页【如果是图片,那么这里永远是0，如果是PDF这里就是正常页数】
    private static final String pageNumber = "pageNumber";
    //离该页上方的偏移量百分比 最大100【一页非常大的情况下，如果有多个标记的时候的显示Ui位置， 暂时用不到，先这样设计字段】
    private static final String offset = "offset";
    private DBHelper dbHelper;

    //创建表结构
    public static final String SQL_CREATE_TABLE = "create table " + TABLE_NAME + "(" +
            ID + " integer primary key autoincrement," +
            userID + " text," +
            saveTime + " integer," +//时间戳
            content + " text," +
            filePath + " text," +
            fatherPath + " text," +
            coverUrl + " text," +

            fileType + " text," +
            fileName + " text," +
            pageNumber + " integer," +
            offset + " integer" +
            ")";

    private FlagBDDao() {
        dbHelper = new DBHelper(MjApplication.getContext());
    }

    public static FlagBDDao getInstance() {
        return FlagBDDao.InnerDB.instance;
    }

    private static class InnerDB {
        private static FlagBDDao instance = new FlagBDDao();
    }


    /**
     * 数据库插入数据
     *
     * @param bean 实体类
     * @param <T>  T
     */
    public synchronized <T> void insert(T bean) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {

            if (bean != null && bean instanceof FlagBean) {
                FlagBean flagBean = (FlagBean) bean;
                ContentValues cv = new ContentValues();
                cv.put(userID, MjApplication.getUserId());
                cv.put(saveTime, flagBean.getSaveTime());
                cv.put(content, flagBean.getContent());
                cv.put(filePath, flagBean.getFilePath());
                cv.put(fatherPath, flagBean.getFatherPath());
                cv.put(coverUrl, flagBean.getCoverUrl());
                cv.put(fileType, flagBean.getFileType());
                cv.put(fileName, flagBean.getFileName());
                cv.put(pageNumber, flagBean.getPageNumber());
                cv.put(offset, flagBean.getOffset());
                db.insert(TABLE_NAME, null, cv);
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
    }


    /**
     * 无差别查询所有数据
     *
     * @return List
     */
    @SuppressLint("Range")
    public synchronized <T> List<T> queryAll() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<T> list = new ArrayList<>();
        String querySql = "select * from " + TABLE_NAME;
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(querySql, null);
            Log.d("TAG", "查询全部条数:" + cursor.getCount());
            while (cursor != null && cursor.moveToNext()) {
                list.add((T) assemble(cursor));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return list;
    }

    /**
     * @param flagBean
     * @param type     类型：
     *                 1：通过文件路径+页数，查询【目前只能查到单条】
     *                 2：根据本文件路径查询所有数据，供PDF查询多条
     *                 3：根据父文件查询所有数据，供其他多媒体格式查询多条【统一查父文件下所有子文件的标记】
     * @param <T>
     * @return
     */
    public synchronized <T> List<T> query(FlagBean flagBean, int type) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<T> list = new ArrayList<>();
        Cursor cursor = null;
        try {
            Object[] objects = getSelection(flagBean, type);
            cursor = db.query(TABLE_NAME, null, (String) objects[0], (String[]) objects[1], null, null, null);
//            cursor.moveToPrevious();
            Log.d("TAG", "查询到的数量：" + cursor.getCount());
            while (cursor.moveToNext()) {
                list.add((T) assemble(cursor));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return list;
    }


    @SuppressLint("Range")
    private FlagBean assemble(Cursor cursor) {
        FlagBean flagBean = new FlagBean();
        flagBean.setUserId(cursor.getString(cursor.getColumnIndex(userID)));
        flagBean.setSaveTime(cursor.getInt(cursor.getColumnIndex(saveTime)));
        flagBean.setContent(cursor.getString(cursor.getColumnIndex(content)));
        flagBean.setFilePath(cursor.getString(cursor.getColumnIndex(filePath)));
        flagBean.setCoverUrl(cursor.getString(cursor.getColumnIndex(coverUrl)));
        flagBean.setFileType(cursor.getString(cursor.getColumnIndex(fileType)));
        flagBean.setFileName(cursor.getString(cursor.getColumnIndex(fileName)));
        flagBean.setPageNumber(cursor.getInt(cursor.getColumnIndex(pageNumber)));
        flagBean.setOffset(cursor.getInt(cursor.getColumnIndex(offset)));
        return flagBean;
    }


    /**
     * 删除数据
     * type:和上面查询对应
     *
     * @return
     */
    public void delBean(FlagBean flagBean, int type) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            //查询 _url的数据
            Object[] obj = getSelection(flagBean, type);
            db.delete(TABLE_NAME, (String) obj[0], (String[]) obj[1]);
        } catch (Exception e) {
            Log.d("TAG", "删除标记出错: " + e.getMessage());
        }
    }

    /**
     * 查询约束
     *
     * @param flagBean
     * @param type     类型：
     *                 1：通过文件路径+页数，查询【目前只能查到单条】，供pdf删除单条
     *                 2：根据本文件路径查询所有数据，供PDF查询多条，供Rv删除单条
     *                 3：根据父文件查询所有数据，供其他多媒体格式查询多条【统一查父文件下所有子文件的标记】
     * @return
     */
    private Object[] getSelection(FlagBean flagBean, int type) {
        String selection = null;
        String[] selectionArgs = null;
        switch (type) {
            case 1:
                selection = filePath + " = ? and " + pageNumber + " = ?"+USERID;
                selectionArgs = new String[]{flagBean.getFilePath(), flagBean.getPageNumber() + "",MjApplication.getUserId()};
                break;
            case 2:
                selection = filePath + " = ?"+USERID;
                selectionArgs = new String[]{flagBean.getFilePath(),MjApplication.getUserId()};
                break;
            case 3:
                selection = fatherPath + " = ?"+USERID;
                selectionArgs = new String[]{flagBean.getFatherPath(),MjApplication.getUserId()};
                break;
            default:
        }
        return new Object[]{selection, selectionArgs};
    }

    String USERID="and "+userID+"= ?";

    /**
     * 更新
     * @param type     更新类型：
     *                 1=更新userId 在用户登录的时候迁移更新，
     *                 2=更新本路径
     *                 3=父路径(那么一定会更新本路径)
     */
    public void upBean(FlagBean originBean,FlagBean newBean, int type) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        //获取写入database对象
        ContentValues values = new ContentValues();
        if (type == 1) {
            values.put(userID, newBean.getUserId());
        } else if (type == 2) {
            values.put(filePath, newBean.getFilePath());
        } else if (type == 3) {
            values.put(filePath, newBean.getFilePath());
            values.put(fatherPath, newBean.getFatherPath());
        }
        //参数分别为：表名，写入参数对象，where语句，参数数组
        db.update(TABLE_NAME, values, filePath + " = ?"+USERID, new String[]{originBean.getFilePath(),MjApplication.getUserId()});
    }



    /**
     * 批量更新id
     */
    public  boolean upUserId(String userId) {
        if (TextUtils.isEmpty(userId)) {
            return false;
        }
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //获取写入database对象
//        db.beginTransaction();
//        for (int i = 0; i < beanLists.size(); i++) {
//            WifiHistBean bena = beanLists.get(i);
//        }
        values.put(userID, userId);
        db.update(TABLE_NAME, values, userID + "= ?", new String[]{MjApplication.DEFAULT_USER_ID});
//        db.setTransactionSuccessful();
//参数分别为：表名，写入参数对象，where语句，参数数组
//        db.update(TABLE_NAME, values, url + " = ?", new String[]{wifiHistBean.getUrl()});
        return true;
    }
}
