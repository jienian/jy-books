package com.juying.mjreader.net.bean;

import com.juying.mjreader.network.models.BaseReq;

/**
 * 请求用户数据接口参数Bean
 *
 * @Author Ycc
 * @Date 13:51
 */
public class RequestUserDataBean extends BaseReq {
    //        * @param type      数据类型	BOOKSHELF, READHISTORY【要和上传时候的类型对应】
//            * @param topUserId 顶级用户Id，构成： md5(appKey，userId)
    String type;
    String topUserId;

    public RequestUserDataBean(String type, String topUserId) {
        this.type = type;
        this.topUserId = topUserId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTopUserId() {
        return topUserId;
    }

    public void setTopUserId(String topUserId) {
        this.topUserId = topUserId;
    }
}
