package com.juying.mjreader.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogBookInputWebdavBinding;
import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.StringUtils;
import com.juying.mjreader.utils.ftp.FTP;
import com.thegrizzlylabs.sardineandroid.DavResource;
import com.thegrizzlylabs.sardineandroid.Sardine;
import com.thegrizzlylabs.sardineandroid.impl.OkHttpSardine;

import org.apache.commons.net.ftp.FTPFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogBookInputWebdav extends BaseDialog {
    private DialogBookInputWebdavBinding vBinding;
    private DialogLoading loadomg;
    Handler handler;

    public DialogBookInputWebdav(@NonNull Context context, DialogBrowseEditListener listener) {
        super(context, R.style.DialogTheme);
//        super(context);

        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
//        View view = View.inflate(context, R.layout.dialog_book_input, null);
        vBinding = DialogBookInputWebdavBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());

        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);

        handler = new Handler(Looper.myLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case 1:
                        log("通知更新："+msg.obj);
                        if (msg.obj instanceof TextView) {
                            vBinding.llMode.addView((TextView) msg.obj);
                        } else if (msg.obj instanceof Bitmap) {
                            Glide.with(getContext())
                                    .asBitmap()
                                    .load((Bitmap) msg.obj)
//                                        .override(500, 500)
                                    .into(vBinding.iv);
                        } else if (msg.obj instanceof InputStream) {
                            vBinding.pdf.fromStream((InputStream) msg.obj).load();
                        } else if (msg.obj instanceof String) {
                            Glide.with(getContext())
                                    .asBitmap()
                                    .load((String) msg.obj)
//                                        .override(500, 500)
                                    .into(vBinding.iv);
                        } else if (msg.obj instanceof URI) {
                            Glide.with(getContext())
                                    .load((URI) msg.obj)
//                                        .override(500, 500)
                                    .into(vBinding.iv);
                        }
//                        vBinding.iv.setImageBitmap((Bitmap) msg.obj);


                        break;
                    case 2:
                        to("链接失败", false);
                        break;
                    case 3:
                        vBinding.llMode.removeAllViews();
                        break;
                    default:
                }


            }
        };
        initView();
        initListener();


    }

    private void initView() {

    }


    private void initListener() {

        vBinding.tvCancel.setOnClickListener(v -> {
            dismiss();
        });
        vBinding.tvOk.setOnClickListener(v -> {
            FormData formData = getForm();
            if (StringUtils.isEmpty(formData.getServer(), formData.getPort(), formData.getUserName(), formData.getPassword())) {
                to("服务器/端口/用户名/密码必须填写", false);
                return;
            }
            if (loadomg == null) {
                loadomg = new DialogLoading(getContext());
            }
            loadomg.show();
            showView(formData);


        });
    }

    private void showView(FormData formData) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                Sardine sardine = (Sardine) new OkHttpSardine();//实例化
                String url = setData(sardine, formData, true);
                List<DavResource> resources = sardine.list(url);//后面需斜杠
                for (DavResource res : resources) {
                    //YourCode
                    String type = res.getContentType();
                    Log.d("WebDavFile:", res.toString() + ";类型：" + type);//获取webdavDir文件夹内的文件名字
                    TextView tv = new TextView(getContext());
                    tv.setText(res.toString());
                    tv.setOnClickListener(v1 -> Executors.newCachedThreadPool().execute(() -> {
                        try {
                            if (type.contains("pdf") || type.contains("jpg") || type.contains("jpeg") || type.contains("png") || type.contains("application/octet-stream") || type.contains("gif")) {
//                                    String childUrl = "http://17.tcp.cpolar.top:13420/3.jpg";
                                String childUrl = formData.getProtocol() + "://" + formData.getHost() + res;
                                InputStream is = sardine.get(childUrl);
                                BufferedInputStream bufferedInputStream = new BufferedInputStream(is);

                                Message mes = new Message();
                                mes.what = 1;
                                if (type.contains("pdf")) {
                                    mes.obj = bufferedInputStream;
                                } else {
                                    Bitmap bmp = BitmapFactory.decodeStream(bufferedInputStream);
                                    mes.obj = bmp;
                                }
                                handler.sendMessage(mes);
                            } else if (res.getContentType().endsWith("directory")) {
                                handler.sendEmptyMessage(3);
                                formData.setServer(formData.getHost() + tv.getText().toString());
                                showView(formData);
                            }
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }));
                    Message mes = new Message();
                    mes.what = 1;
                    mes.obj = tv;
                    handler.sendMessage(mes);
                }
                loadomg.dismiss();
            } catch (Exception e) {
                loadomg.dismiss();
                handler.sendEmptyMessage(2);
                throw new RuntimeException(e);
            }
        });

    }

    private String setData(Sardine sardine, FormData formData, boolean isReal) {
        String url;
        if (isReal) {
            url = formData.getProtocol() + "://" + formData.getServer();
            sardine.setCredentials(formData.getUserName(), formData.getPassword());
        } else {
            url = "http://17.tcp.cpolar.top:13420/";
            sardine.setCredentials("JUYINGTECH", "654321");
        }
        return url;
    }

    private void showMode(FtpFile ffile) {
        for (int i = 0; i < ffile.getFtpFiles().size(); i++) {
            FtpFile f = ffile.getFtpFiles().get(i);
            TextView tv = new TextView(getContext());
            tv.setText(f.getName());
            tv.setOnClickListener(v1 -> {
                Executors.newCachedThreadPool().execute(() -> {
                    try {
                        if (f.isImages()) {
//                            URL u = new URL("ftp://" + f.getHost() + f.getPath());
                            URL u = new URL("ftp://" + f.getHost() + "/3.jpg");
                            LogUtil.d(TAG, "加载Url:" + u);
                            URLConnection c = u.openConnection();
                            InputStream is = c.getInputStream();
                            BufferedInputStream bufferedInputStream = new BufferedInputStream(is);
//                            Bitmap bmp = BitmapFactory.decodeStream(bufferedInputStream);


//                            InputStream is = u.openStream();
//                            BufferedInputStream bufferedInputStream = new BufferedInputStream(is);


//                            is.close();
//                            bufferedInputStream.close();
                            Message mes = new Message();
                            mes.what = 1;
                            mes.obj = bufferedInputStream;
                            handler.sendMessage(mes);
                        }
                    } catch (IOException e) {
                    }
                });
            });
            Message mes = new Message();
            mes.what = 1;
            mes.obj = tv;
            handler.sendMessage(mes);
        }
    }


    private FtpFile getFTPFile(FTP ftp, String host, FtpFile file) throws IOException {
        List<FTPFile> listFiles = ftp.listFiles(file.path);
        for (int i = 0; i < listFiles.size(); i++) {
            FTPFile ftpFile = listFiles.get(i);
//                            String url="ftp:\\\\"+formData.getServer()+"\\"+ftpFile.getName();
            FtpFile childFile = new FtpFile();
            childFile.setDirectory(ftpFile.isDirectory());
            if (file.path.equals("/")) {//根目录
                childFile.setPath(file.path + ftpFile.getName());
            } else {
                childFile.setPath(file.path + "/" + ftpFile.getName());
            }
            childFile.setHost(file.getHost());
            childFile.setName(ftpFile.getName());

            if (ftpFile.isDirectory()) {
                childFile.setFileType("");
                getFTPFile(ftp, host, childFile);
            } else {
                URL u = new URL("ftp://" + host + childFile.getPath());
                URLConnection c = u.openConnection();
                String fileType = c.getContentType();
                childFile.setFileType(fileType);
            }
            file.getFtpFiles().add(childFile);
        }
        return file;
    }


    private class FtpFile {
        private List<FtpFile> ftpFiles = new ArrayList<>();
        private boolean isDirectory;
        private String host;

        //父路径
        private String parent_path;
        //本路径
        private String path;
        private String name;
        //文件类型，如果是目录则为""
        private String fileType;

        @Override
        public String toString() {
            return "FtpFile{" +
                    "ftpFiles=" + ftpFiles +
                    ", isDirectory=" + isDirectory +
                    ", parent_path='" + parent_path + '\'' +
                    ", path='" + path + '\'' +
                    ", name='" + name + '\'' +
                    ", fileType='" + fileType + '\'' +
                    '}';
        }

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public String getFileType() {
            return fileType;
        }

        public void setFileType(String fileType) {
            this.fileType = fileType;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<FtpFile> getFtpFiles() {
            return ftpFiles;
        }

        public void setFtpFiles(List<FtpFile> ftpFiles) {
            this.ftpFiles = ftpFiles;
        }

        public boolean isImages() {
            if (!TextUtils.isEmpty(fileType) && (fileType.contains("jpg") || fileType.contains("jpeg") || fileType.contains("webp") || fileType.contains("png") || fileType.contains("gif"))) {
                return true;
            }
            return false;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getParent_path() {
            return parent_path;
        }

        public void setParent_path(String parent_path) {
            this.parent_path = parent_path;
        }


        public boolean isDirectory() {
            return isDirectory;
        }

        public void setDirectory(boolean rootDirectory) {
            isDirectory = rootDirectory;
        }
    }


    private FormData getForm() {
        String host = getString(vBinding.etHost);
        String rort = getString(vBinding.etPort);
        boolean isHttps = vBinding.cbEncryption.isChecked();
        String name = getString(vBinding.etName);
        String password = getString(vBinding.etPassword);
        String rename = getString(vBinding.etRename);
        FormData formData = new FormData(host, rort, name, password, isHttps, rename);
//        FormData formData = new FormData("17.tcp.cpolar.top:13420", rort, "JUYINGTECH", "654321", isHttps, rename);
        log("表单Bean:" + formData);
        return formData;
    }


    private String getString(EditText et) {
        String string = "";
        try {
            string = et.getText().toString();
        } catch (Exception ignored) {
        }
        return string;
    }

    public interface DialogBrowseEditListener {
        void onClickEdit();
    }

    private class FormData {
        //服务器 不变
        private String host;
        //服务器 变
        private String server;
        //端口
        private String port;
        //用户名
        private String userName;
        private String password;

        //重命名
        private String rename;
        //重命名
        private String protocol;


        public FormData(String server, String port, String userName, String password, boolean isHttps, String rename) {
            this.server = server;
            this.host = server;
            this.port = port;
            this.userName = userName;
            this.password = password;
            this.rename = rename;


            if (isHttps) {
                protocol = "https";
            } else {
                protocol = "http";
            }
        }

        public String getProtocol() {
            return protocol;
        }

        public String getHost() {
            return host;
        }

        public void setServer(String server) {
            this.server = server;
        }

        @Override
        public String toString() {
            return "FormData{" +
                    "server='" + server + '\'' +
                    ", port='" + port + '\'' +
                    ", userName='" + userName + '\'' +
                    ", password='" + password + '\'' +
                    ", rename='" + rename + '\'' +
                    '}';
        }

        public String getServer() {
            return server;
        }

        public String getPort() {
            return port;
        }

        public String getUserName() {
            return userName;
        }

        public String getPassword() {
            return password;
        }


        public String getRename() {
            return rename;
        }
    }

}
