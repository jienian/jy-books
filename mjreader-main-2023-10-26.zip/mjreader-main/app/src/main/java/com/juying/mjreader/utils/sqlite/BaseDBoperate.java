package com.juying.mjreader.utils.sqlite;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

/**
 * @Author Ycc
 * @Date 17:46
 */
public class BaseDBoperate {


    public BaseDBoperate() {
    }


}
