package com.juying.mjreader.bean;

/**
 * @Author Ycc
 * @Date 10:13
 */
public class UploadBean {

    /**
     * type : BOOKSHELF
     * dataId : md5(appKey,topUserId,真正的数据Id)
     * content : 自定义Json数据
     * topUserId : md5(appKey,用户id)
     */
    private String type;
    private String dataId;
    private String content;
    private String topUserId;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDataId() {
        return dataId;
    }

    public void setDataId(String dataId) {
        this.dataId = dataId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTopUserId() {
        return topUserId;
    }

    public void setTopUserId(String topUserId) {
        this.topUserId = topUserId;
    }

    public UploadBean(String type, String dataId, String content, String topUserId) {
        this.type = type;
        this.dataId = dataId;
        this.content = content;
        this.topUserId = topUserId;
    }
}
