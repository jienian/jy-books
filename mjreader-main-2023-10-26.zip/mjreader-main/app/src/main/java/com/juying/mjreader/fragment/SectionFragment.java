package com.juying.mjreader.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.juying.mjreader.activity.SeeNovelActivity;
import com.juying.mjreader.adapter.novel.NovelFlagAdapter;
import com.juying.mjreader.adapter.novel.SectionAdapter;
import com.juying.mjreader.bean.BookInfo;
import com.juying.mjreader.bean.NovelSeeSumBean;
import com.juying.mjreader.databinding.FragmentSectionBinding;
import com.juying.mjreader.view.DialogFlagDirectory;

import java.util.ArrayList;

/**
 * @author Nimyears
 * <p>
 * 用于显示小说目录页
 * 从上个界面传过来目录数据(BookInfo列表)和book对应的uri
 * <p>
 * 展示目录列表,使用SectionAdapter适配器加载数据
 * <p>
 * 点击每个目录item跳转到阅读界面SeeNovelActivity
 * <p>
 * SeeNovelActivity用于单个章节阅读
 */

public class SectionFragment extends BaseFragment {
    private FragmentSectionBinding vBinding;
    private LinearLayoutManager LinearLayoutManager1;
    private LinearLayoutManager LinearLayoutManager2;
    private int currentPage;

    private SectionAdapter mSectionAdapter = new SectionAdapter();

    private DialogFlagDirectory.DialogFlagDirectoryListener listener;

    @NonNull
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle saveInstanceState) {
        vBinding = FragmentSectionBinding.inflate(inflater, container, false);
        return vBinding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle saveInstanceState) {
        super.onViewCreated(view, saveInstanceState);
        ArrayList<BookInfo> sections = getArguments().getParcelableArrayList("sections1");

        vBinding.recyclerView.setAdapter(mSectionAdapter);
        mSectionAdapter.setBookBeanList(sections);

        mSectionAdapter.setOnItemClickListener((section, position) -> {

            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(section.getSection(), sections.get(position + 1).getSection());
            }
        });

        vBinding.iv1.setOnClickListener(v -> {
        //排序
            mSectionAdapter.reversed();
        });

        //定位
        vBinding.iv2.setOnClickListener(v -> {
            vBinding.recyclerView.scrollToPosition(currentPage);
            mSectionAdapter.reversed();
        });


    }


    public interface OnItemClickListener {
        void onItemClick(String start, String end);
    }

    private OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public SectionAdapter getSectionAdapter() {
        return mSectionAdapter;
    }


}
