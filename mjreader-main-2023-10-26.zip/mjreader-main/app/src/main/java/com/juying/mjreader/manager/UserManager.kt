package com.juying.mjreader.manager


import com.juying.mjreader.MjApplication
import com.juying.mjreader.network.models.UserInfo
import com.juying.mjreader.network.service.UserApiService
import com.juying.mjreader.network.util.Md5Util
import com.juying.mjreader.network.util.ValidateUtil
import com.juying.mjreader.utils.AppUtil

/**
 * @author Nimyears
 */
object UserManager {

    val userInfo: UserInfo?
        get() = SpManager.userInfo

    val isLogin: Boolean
        get() = userInfo?.status == 1

    val sex: Int
        get() = userInfo?.sex ?: 0


    suspend fun loginByUuid(sex: Int): UserInfo? {
        val res = UserApiService.loginByUuid(sex)
        return res?.data?.let {
            SpManager.userInfo = it
            it
        }
    }

    suspend fun login(username: String, password: String): UserInfo? {
        val isEmail = ValidateUtil.isEmail(username)
        val res = if (isEmail) {
            UserApiService.loginEmail(username, password)
        } else {
            UserApiService.loginPhone(username, password)
        }
        return res?.data?.let {
            SpManager.userInfo = it
            it
        }
    }

    suspend fun registerAndLogin(username: String, password: String): UserInfo? {
        val isEmail = ValidateUtil.isEmail(username)
        val (email, phone) = if (isEmail) Pair(username, "") else Pair("", username)
        val res = UserApiService.registerAccount(email, phone, password, sex)
        return res?.data?.let {
            login(username, password)
        }
    }

    suspend fun changeUserinfo(nickname: String, avatarUrl: String, sex: Int): Boolean {
        val newItem = SpManager.userInfo?.copy(nickname = nickname, avatar = avatarUrl, sex = sex)
        val res = UserApiService.changeUserinfo(nickname, avatarUrl, sex)
        res?.let {
            if (it.status == 1) {
                SpManager.userInfo = newItem
                return true
            }
        }
        return false
    }

    suspend fun logout(): UserInfo? {
        return loginByUuid(sex)
    }

    suspend fun checkUsername(username: String): Boolean {
        val isEmail = ValidateUtil.isEmail(username)
        val res = if (isEmail) {
            UserApiService.checkEmail(username)
        } else {
            UserApiService.checkPhone(username)
        }
        res?.data?.let {
            return !it.isExist
        }
        return false
    }

    private var topUserId = ""
     fun createTopUserId(): String {
         UserManager.userInfo?.let {
             val key = AppUtil.getPackageName(MjApplication.CONTEXT) + it.userId
             topUserId= Md5Util.md5(key)
         }
        return topUserId
    }


     fun createDataId(type: String, dataId: String): String {
        val key = type + dataId + UserManager.userInfo?.userId
        return Md5Util.md5(key)
    }
}