package com.juying.mjreader.net.bean;

import com.juying.mjreader.network.models.Safety;

/**
 * 巨应接口返回BeasBean
 * @Author Ycc
 * @Date 10:55
 */
public class RetBaseBean<T> {

    /**
     * data : [{"id":"1c013aed2196eb0e9358ad135bab7e56","dataId":"1c013aed2196eb0e9358ad135bab7e56","channel":"normal","content":"收藏的书籍信息1","createTime":1694787757496,"lastUpdateTime":1694787757496},{"id":"1c013aed2196eb0e9358ad135bab7e56","dataId":"e9358ad135bab7e561c013aed2196eb0","channel":"normal","content":"收藏的书籍信息2","createTime":1694787757496,"lastUpdateTime":1694787757496}]
     * status : 1
     * errorCode : 0
     * time : 2023-09-15 22:27:35
     * elapsed : 6
     * statisticCache : false
     */

    private int status;
    private int errorCode;
    private String time;
    private int elapsed;
    private boolean statisticCache;

    private Safety safety;
    private String safetyData;

    private T data;



    public Safety getSafety() {
        return safety;
    }

    public void setSafety(Safety safety) {
        this.safety = safety;
    }

    public String getSafetyData() {
        return safetyData;
    }

    public void setSafetyData(String safetyData) {
        this.safetyData = safetyData;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getElapsed() {
        return elapsed;
    }

    public void setElapsed(int elapsed) {
        this.elapsed = elapsed;
    }

    public boolean isStatisticCache() {
        return statisticCache;
    }

    public void setStatisticCache(boolean statisticCache) {
        this.statisticCache = statisticCache;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public static class DataBean {
    }
}
