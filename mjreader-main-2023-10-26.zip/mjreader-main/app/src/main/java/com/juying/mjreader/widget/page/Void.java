package com.juying.mjreader.widget.page;

public class Void {
}
