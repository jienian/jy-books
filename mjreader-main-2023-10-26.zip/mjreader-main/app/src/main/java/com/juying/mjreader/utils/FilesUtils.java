package com.juying.mjreader.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.Log;

import androidx.documentfile.provider.DocumentFile;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.utils.config.Constant;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class FilesUtils {
    //写字符串到文件
    public static void sToFile(Context context, String fileName, String s) {
        if (context == null || s == null) {
            return;
        }
        try {
            FileOutputStream output = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output));
            writer.write(s);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //一行一行读流转字符串
    public static List<String> streamToString(InputStream inputStream) {
        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        ArrayList<String> listUrl = new ArrayList<>();
        String line;
        try {
            while (!TextUtils.isEmpty(line = br.readLine())) {
                listUrl.add(line);
            }
        } catch (Exception e) {
            Log.e("TAG", "流读取出差" + e.toString());
        }

        return listUrl;
    }


    /**
     * 根据文件判断是否为某种类型或者目录是否包含某类型
     *
     * @param file 文件
     * @param s    类型
     * @return
     */
    public static boolean isExtAppointTypeFile(File file, String[] s) {
        if (file == null && !file.exists() && s == null || s.length == 0) {
            new Exception("文件异常").printStackTrace();
            return false;
        }
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                // 对于每个文件和文件夹进行操作
                for (String string : s) {
                    if (f.getName().endsWith(string)) {
                        return true;
                    }
                }
            }
            return false;
        } else {
            for (String string : s) {
                if (file.getName().endsWith(string)) {
                    return true;
                }
            }
            return false;
        }
    }


    /**
     * 整个设备剩余可用空间(字节)
     */
    public static long getEnoughSpace() {
        // 获取存储空间信息
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long blockSize = statFs.getBlockSizeLong();
        long totalBlocks = statFs.getBlockCountLong();
        long availableBlocks = statFs.getAvailableBlocksLong();
        // 计算存储空间的总大小和可用大小
        long totalSize = blockSize * totalBlocks;
        long availableSize = blockSize * availableBlocks;
        Log.d("TAG", "空间大小totalSize=" + totalSize / 1024 / 1024 / 1024 + "G;剩余availableSize=" + availableSize / 1024 / 1024 / 1024 + "G");
        return availableSize;
    }

    /**
     * 是否空间足够
     *
     * @param threshold 当前阈值
     * @return
     */
    public static boolean isSizeSufficient(long threshold) {
        // 获取存储空间信息
        return getEnoughSpace() > threshold + Constant.THRESHOLD;
    }


    /**
     * 当SD卡存在或者SD卡不可被移除的时候，就调用getExternalCacheDir()方法来获取缓存路径，否则就调用getCacheDir()方法来获取缓存路径。前者获取到的就是 /sdcard/Android/data//cache 这个路径，后者获取到的是 /data/data//cache 这个路径。
     * 注意：这两种方式的缓存都会在卸载app的时候被系统清理到，想要不被清理的需要自己在sd卡上去建立的缓存文件夹。
     *
     * @param context
     * @return
     */
    public static String getDiskCacheDir(Context context) {
        String cachePath = null;
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())
                || !Environment.isExternalStorageRemovable()) {
            cachePath = context.getExternalCacheDir().getPath();
        } else {
            cachePath = context.getCacheDir().getPath();
        }
        return cachePath;
    }

    /**
     * 获取缓存目录
     *
     * @param context
     * @return
     */
    public static String getFilesDir(Context context) {
        return context.getFilesDir().getPath();
    }

    /**
     * 目录里某个文件名称是否已经存在
     *
     * @param directoryFile
     * @param fileName
     * @return
     */
    public static boolean isExistFile(File directoryFile, String fileName) {
        File[] listFiles = directoryFile.listFiles();
        if (listFiles != null && listFiles.length > 0) {
            for (File file : listFiles) {
                if (fileName.equals(file.getName())) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * 将Uri写入文件
     *
     * @param context
     * @param file
     * @param uri
     * @return
     */
    public static String getAbsolutePathFromUri(Context context, Handler handler, File file, Uri uri, int code) {
        String scheme = uri.getScheme();
        String absolutePath = null;
//        if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
//            uriWriteFile(context, handler, file, uri, code);
//            absolutePath = file.getAbsolutePath();
//        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
//            uriWriteFile(context, handler, file, uri, code);
//            absolutePath = uri.getPath();
//        }
        return absolutePath;
    }


    /**
     * 复制一份uri文件到新File
     *
     * @param context
     * @param handler
     * @param code    handler返回码  方便做UI更新
     */
    public static void uriWriteFile(Context context, Uri originUri, File newFile, BookBean imputFatherBookBean, BookBean imputChildBookBean, Handler handler, int code) {
        ContentResolver contentResolver = context.getContentResolver();
        LogUtil.d("TAG", "准备读取文件：" + originUri.getPath() + "；写入文件=" + newFile.getPath());
        try {
            InputStream inputStream = contentResolver.openInputStream(originUri);
//            FileInputStream inputStream = new FileInputStream(uri.getPath());
//            long fileSize = inputStream.getChannel().size();
            long uriSize = inputStream.available();//根据响应获取文件大小available方法返回int 超过2g就不行了
            writeStream(context, inputStream, uriSize, newFile, imputFatherBookBean, imputChildBookBean, handler, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 复制一份File文件到File
     *
     * @param handler
     * @param originFile
     * @param newFile
     * @param code       handler返回码  方便做UI更新
     */
    public static void fileWriteFile(Context context, File originFile, File newFile, BookBean imputFatherBookBean, BookBean imputChildBookBean, Handler handler, int code) {
        LogUtil.d("TAG", "准备读取文件：" + originFile.getPath() + "；写入文件=" + newFile.getPath());
        try {
            FileInputStream inputStream = new FileInputStream(originFile.getPath());
            long fileSize = inputStream.getChannel().size();
//            double fileSize = inputStream.available();//根据响应获取文件大小available方法返回int 超过2g就不行了
            LogUtil.d("TAG", "即将导入的文件总大小：" + fileSize);
            writeStream(context, inputStream, fileSize, newFile, imputFatherBookBean, imputChildBookBean, handler, code);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void writeStream(Context context, InputStream originInputStream, long originFileSize, File newFile, BookBean imputFatherBookBean, BookBean imputChildBookBean, Handler handler, int code) {
        try {
            if (originFileSize == 0) {
                //                throw new RuntimeException("无法获知文件大小 ");
                LogUtil.d("TAG", "文件大小为0，不操作");
                return;
            }
            if (!newFile.exists()) {
                newFile.createNewFile();
            }

            FileOutputStream outputStream = new FileOutputStream(newFile);
            if (imputChildBookBean != null) {
                imputChildBookBean.setLastModified(System.currentTimeMillis());
                imputChildBookBean.setMaxSize(originFileSize);
                imputFatherBookBean.getBookBeanList().add(imputChildBookBean);
                imputFatherBookBean.getBookBeanList().add(imputChildBookBean);
                ComicMode.saveSP(context, imputChildBookBean);
                NovelMode.saveSP(context, imputChildBookBean);
            } else {
                ComicMode.saveSP(context, imputFatherBookBean);
                NovelMode.saveSP(context, imputFatherBookBean);
            }
            //本地文件一次可以多读点，32kb读
            byte[] buffer = new byte[32 * 1024];
            int read;
            Message mess = new Message();
            mess.what = code;
            while ((read = originInputStream.read(buffer)) != -1) {
                if (imputChildBookBean != null) {
                    imputChildBookBean.setImputSchedule(newFile.length());
                    imputChildBookBean.setImputProcess(true);
                }
                imputFatherBookBean.setImputProcess(true);
                outputStream.write(buffer, 0, read);
                imputFatherBookBean.setImputSchedule(imputFatherBookBean.getImputSchedule() + read);
                mess.obj = imputFatherBookBean;
                LogUtil.v("TAG", newFile.getName() + "总字节大小：" + originFileSize + "，导入进度：" + newFile.length());
                handler.sendMessage(mess);
            }
            if (imputChildBookBean != null) {
                imputChildBookBean.setImputProcess(false);
            }
            imputFatherBookBean.setImputProcess(false);
            mess.obj = imputFatherBookBean;
            handler.sendMessage(mess);

            LogUtil.d("TAG", "成功写入文件=" + newFile.getAbsolutePath() + ";线程:" + Thread.currentThread().getName());
            outputStream.flush();
            outputStream.close();
            originInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获得文件大小  【字节】
     *
     * @param file
     * @return
     */
    public static long getFileSize(File file) {
        FileInputStream inputStream = null;
        long fileSize;
        try {
            inputStream = new FileInputStream(file.getPath());
            fileSize = inputStream.getChannel().size();
            inputStream.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return fileSize;
    }

    /**
     * 获得Uri大小  【字节】
     *
     * @param uri
     * @return
     */
    public static long getUriSize(Context context, Uri uri) {
        long uriSize = 0;
        ContentResolver contentResolver = context.getContentResolver();
        try {
            InputStream inputStream = contentResolver.openInputStream(uri);
//            FileInputStream inputStream = new FileInputStream(uri.getPath());
//            long fileSize = inputStream.getChannel().size();
            uriSize = inputStream.available();//根据响应获取文件大小available方法返回int 超过2g就不行了
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uriSize;
    }


    /**
     * 将DocumentFile[]数组转换成Uri集合
     *
     * @param listFiles DocumentFile数组
     * @return
     */
    public static List<Uri> docFilesToUriList(DocumentFile[] listFiles) {
        List<Uri> uriList = new ArrayList<>();
        for (DocumentFile docFile : listFiles) {
            if (docFile == null) {
                continue;
            }
            if (!TextUtils.isEmpty(docFile.getType())) {
                uriList.add(docFile.getUri());
            }
        }
        return uriList;
    }

    public static String getStringLast(String s) {
        return s.substring(s.lastIndexOf(".") + 1, s.length());
    }


    //获取文件夹
    public static File getFolder(String filePath) {
        File file = new File(filePath);
        //如果文件夹不存在，就创建它
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }


    public static long getDirSize(File file) {
        //判断文件是否存在
        if (file.exists()) {
            //如果是目录则递归计算其内容的总大小
            if (file.isDirectory()) {
                File[] children = file.listFiles();
                long size = 0;
                for (File f : children)
                    size += getDirSize(f);
                return size;
            } else {
                return file.length();
            }
        } else {
            return 0;
        }
    }

    //获取Cache文件夹
    public static String getCachePath() {
        if (isSdCardExist()) {
            return MjApplication.getContext()
                    .getExternalCacheDir()
                    .getAbsolutePath();
        } else {
            return MjApplication.getContext()
                    .getCacheDir()
                    .getAbsolutePath();
        }
    }

    //判断是否挂载了SD卡
    public static boolean isSdCardExist() {
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            return true;
        }
        return false;
    }
    /*获取txt文件*/

    public static List<File> getTxtFiles(String filePath, int layer) {
        List txtFiles = new ArrayList();
        File file = new File(filePath);

        //如果层级为 3，则直接返回
        if (layer == 3) {
            return txtFiles;
        }

        //获取文件夹
        File[] dirs = file.listFiles(
                pathname -> {
                    if (pathname.isDirectory() && !pathname.getName().startsWith(".")) {
                        return true;
                    }
                    //获取txt文件
                    else if (pathname.getName().endsWith(".txt")) {
                        txtFiles.add(pathname);
                        return false;
                    } else {
                        return false;
                    }
                }
        );

        //遍历文件夹
        for (File dir : dirs) {
            //递归遍历txt文件
            txtFiles.addAll(getTxtFiles(dir.getPath(), layer + 1));
        }
        return txtFiles;
    }
//    public static Single<List<File>> getSDTxtFile(){
//        //外部存储卡路径
//        String rootPath = Environment.getExternalStorageDirectory().getPath();
//        return Single.create(new SingleOnSubscribe<List<File>>() {
//            @Override
//            public void subscribe(SingleEmitter<List<File>> e) throws Exception {
//                List<File> files = getTxtFiles(rootPath,0);
//                e.onSuccess(files);
//            }
//        });
//    }

    //获取文件的编码格式
    public static Charset getCharset(String fileName) {
        BufferedInputStream bis = null;
        Charset charset = Charset.GBK;
        byte[] first3Bytes = new byte[3];
        try {
            boolean checked = false;
            bis = new BufferedInputStream(new FileInputStream(fileName));
            bis.mark(0);
            int read = bis.read(first3Bytes, 0, 3);
            if (read == -1)
                return charset;
            if (first3Bytes[0] == (byte) 0xEF
                    && first3Bytes[1] == (byte) 0xBB
                    && first3Bytes[2] == (byte) 0xBF) {
                charset = Charset.UTF8;
                checked = true;
            }
            /*
             * 不支持 UTF16LE 和 UTF16BE
            else if (first3Bytes[0] == (byte) 0xFF && first3Bytes[1] == (byte) 0xFE) {
                charset = Charset.UTF16LE;
                checked = true;
            } else if (first3Bytes[0] == (byte) 0xFE
                    && first3Bytes[1] == (byte) 0xFF) {
                charset = Charset.UTF16BE;
                checked = true;
            } else */

            bis.mark(0);
            if (!checked) {
                while ((read = bis.read()) != -1) {
                    if (read >= 0xF0)
                        break;
                    if (0x80 <= read && read <= 0xBF) // 单独出现BF以下的，也算是GBK
                        break;
                    if (0xC0 <= read && read <= 0xDF) {
                        read = bis.read();
                        if (0x80 <= read && read <= 0xBF) // 双字节 (0xC0 - 0xDF)
                            // (0x80 - 0xBF),也可能在GB编码内
                            continue;
                        else
                            break;
                    } else if (0xE0 <= read && read <= 0xEF) {// 也有可能出错，但是几率较小
                        read = bis.read();
                        if (0x80 <= read && read <= 0xBF) {
                            read = bis.read();
                            if (0x80 <= read && read <= 0xBF) {
                                charset = Charset.UTF8;
                                break;
                            } else
                                break;
                        } else
                            break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtils.close(bis);
        }
        return charset;
    }

    /**
     * 根据字节数组，输出对应的格式化字符串
     *
     * @param bytes 字节数组
     * @return 字节数组字符串
     */
    public static String printBytesByStringBuilder(byte[] bytes) {
        StringBuilder stringBuilder = new StringBuilder();

        for (byte aByte : bytes) {
            stringBuilder.append(byte2String(aByte));
        }
        return stringBuilder.toString();
    }

    public static String byte2String(byte b) {
        return String.format("%02x ", b);
    }


    public static String bytesToHexString(byte[] src) {

        StringBuilder stringBuilder = new StringBuilder();

        if (src == null || src.length <= 0) {

            return null;

        }

        for (int i = 0; i < src.length; i++) {

            int v = src[i] & 0xFF;

            String hv = Integer.toHexString(v);

            if (hv.length() < 2) {

                stringBuilder.append(0);

            }

            stringBuilder.append(hv);

        }
        return stringBuilder.toString();
    }


    /**
     * 用原生HttpURLConnection,获取文件名，已测可用
     *
     * @return
     */
    public static String getUrlFileNameFromOrigin(HttpURLConnection connection) throws UnsupportedEncodingException {
        String fileName = connection.getHeaderField("Content-Disposition");
        // 通过Content-Disposition获取文件名，这点跟服务器有关，需要灵活变通
        if (fileName == null || fileName.length() < 1) {
            // 通过截取URL来获取文件名
            URL downloadUrl = connection.getURL(); // 获得实际下载文件的URL
            fileName = downloadUrl.getFile();
            fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
        } else {
            fileName = URLDecoder.decode(fileName.substring(
                    fileName.indexOf("filename=") + 9), "UTF-8");
            // 有些文件名会被包含在""里面，所以要去掉，不然无法读取文件后缀
            fileName = fileName.replaceAll("\"", "");
        }
        return fileName;
    }


    /**
     * 用okhttp,通过url获取文件名，已测可用
     *
     * @param url
     * @return
     */
    public static String getUrlFileNameFromOkHttp(String url) {
        String fileName = null;
        if (!TextUtils.isEmpty(url)) {
            try {
                OkHttpClient client = new OkHttpClient();//创建OkHttpClient对象
                Request request = new Request.Builder()
                        .url(url)//请求接口。如果需要传参拼接到接口后面。
                        .build();//创建Request 对象
                Response response = client.newCall(request).execute();//得到Response 对象
                HttpUrl realUrl = response.request().url();
                Log.e("zmm", "real:" + realUrl);
                if (realUrl != null) {
                    String temp = realUrl.toString();
                    fileName = temp.substring(temp.lastIndexOf("/") + 1);

                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("zmm", "Get File Name:error" + e);
            }
        }
        Log.e("zmm", "fileName--->" + fileName);
        return fileName;
    }


    /**
     * 从输入流中获取字节数组
     *
     * @param inputStream
     * @return
     * @throws IOException
     */
    public static byte[] readInputStream(InputStream inputStream)
            throws IOException {
        byte[] buffer = new byte[1024];
        int len = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while ((len = inputStream.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }
        bos.close();
        return bos.toByteArray();
    }


    /**
     * 递归创建一个不重名的文件名
     *
     * @return
     */
    public static String getNoDuplicateName(File directoryFile, String originName) {
        if (FilesUtils.isExistFile(directoryFile, originName)) {
            originName = originName + "(1)";
            getNoDuplicateName(directoryFile, originName);
        } else {
            return originName;
        }
        return "";
    }


    @Deprecated(since = "效果不好，pdf识别不到，webp识别为audio/x-wav")
    public static String getFileType(File file) {
        String mimeType = "";
        try {
            FileInputStream inputFile = new FileInputStream(file);
            mimeType = URLConnection.guessContentTypeFromStream(new BufferedInputStream(inputFile));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mimeType;
    }

    /**
     * 获取文件类型【优点：识别准确且全面，缺点：慢，过时】
     * @param file
     * @return
     */
    public static String getFileTypeFromURLConnection(File file) {
        String mimeType = "";
        try {
            URLConnection connection = file.toURL().openConnection();
            mimeType = connection.getContentType();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return mimeType;
    }





    /**
     * 删除文件及其子文件
     *
     * @param file
     */
    public static void delFiles(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
                for (File childFile : file.listFiles()) {
                    if (childFile.isDirectory()) {
                        delFiles(childFile);
                    } else {
                        childFile.delete();
                    }
                }
                file.delete();
            } else {
                file.delete();
            }
        }
    }
}
