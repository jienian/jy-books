package com.juying.mjreader.activity;

import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.ActivityWebBinding;
import com.juying.mjreader.viewModel.WebViewModel;

public class WebActivity extends AppCompatActivity {

    private ActivityWebBinding vBinding;
    private WebViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivityWebBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        viewModel = new ViewModelProvider(this).get(WebViewModel.class);

        initView();
        initListener();
    }


    private void initView() {
        Resources resources = vBinding.searchView.getContext().getResources();
        int imgId = resources.getIdentifier("android:id/search_mag_icon", null, null);//获取ImageView
        int editId = resources.getIdentifier("android:id/search_src_text", null, null);//获取Edit
        EditText txtSearch = vBinding.searchView.findViewById(editId);
        txtSearch.setTextColor(getColor(R.color.black));
        txtSearch.setEllipsize(TextUtils.TruncateAt.END);
        ImageView imageView = vBinding.searchView.findViewById(imgId);
    }

    private void initListener() {

        if (vBinding == null) {

        }
    }
}