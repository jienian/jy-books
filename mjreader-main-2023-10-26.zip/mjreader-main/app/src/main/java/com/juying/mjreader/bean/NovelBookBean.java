package com.juying.mjreader.bean;

import java.io.Serializable;
import java.util.List;
/**
 * @Author Nimyears
 * 小说书架
 */
public class NovelBookBean implements Serializable {
    private List<BookBean> bookBeanList;

    public List<BookBean> getBookBeanList() {
        return bookBeanList;
    }

    public void setBookBeanList(List<BookBean> bookBeanList) {
        this.bookBeanList = bookBeanList;
    }

    @Override
    public String toString() {
        return "NovelBookBean{" +
                "bookBeanList=" + bookBeanList +
                '}';
    }
}
