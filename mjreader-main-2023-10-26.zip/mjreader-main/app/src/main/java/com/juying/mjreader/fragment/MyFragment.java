package com.juying.mjreader.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;

import com.juying.mjreader.R;
import com.juying.mjreader.activity.login.LoginActivity;
import com.juying.mjreader.databinding.DialogApkUpProcessBinding;
import com.juying.mjreader.databinding.FragmentMyBinding;
import com.juying.mjreader.net.Client;
import com.juying.mjreader.net.bean.RetAppUpBean;
import com.juying.mjreader.net.bean.RetBaseBean;
import com.juying.mjreader.network.models.BaseReq;
import com.juying.mjreader.utils.AppInfo;
import com.juying.mjreader.utils.AppUpUtils;
import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.ToastUtils;
import com.juying.mjreader.view.DialogNotice;

import java.io.File;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * @Author Ycc
 */
public class MyFragment extends BaseFragment {


    private FragmentMyBinding vBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        vBinding = FragmentMyBinding.inflate(inflater, null, false);

        initListener();
        return vBinding.getRoot();
    }

    private void initListener() {
        //    vBinding.ll1.setOnClickListener();

    }


    public void doOnClick(View v) {
        if (v == vBinding.ll1) {
            to("准备登录或者查看个人信息", false);
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        } else if (v == vBinding.tvOpen) {
            to("去开通", false);
        } else if (v == vBinding.ll2) {
            to("一键传输", false);
        } else if (v == vBinding.ll3) {
            to("自定义文件封面", false);
        } else if (v == vBinding.ll4) {
            to("服务协议", false);
        } else if (v == vBinding.ll5) {
            to("隐私政策", false);
        } else if (v == vBinding.ll6) {
            to("联系我们，1234567@qq.com", false);
        } else if (v == vBinding.ll7) {
//            to("已经是最新版本", false);

            appUp(getActivity());

        } else if (v == vBinding.ll8) {
            to("我的设置", false);
        }

        //showLoginDialog();

    }
   /* private void showLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("手机号登录");

        // 添加自定义布局（这里假设布局文件名为dialog_login.xml）
        View customLayout = getLayoutInflater().inflate(R.layout.dialog_login, null);
        builder.setView(customLayout);

        builder.setPositiveButton("一键登录", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 这里添加一键登录的代码
            }
        });
        builder.setNegativeButton("切换手机号", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 这里添加切换手机号的代码
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }*/


    public static void appUp(Activity context) {
        final DialogNotice[] dialgNotice = new DialogNotice[1];
        final String[] apkPath = new String[1];
        Client.getNetApi().appUpdate(new BaseReq()).enqueue(new Callback<RetBaseBean<RetAppUpBean>>() {
            @Override
            public void onResponse(Call<RetBaseBean<RetAppUpBean>> call, Response<RetBaseBean<RetAppUpBean>> response) {
                try {
                    LogUtil.d("NoReturnCall", "访问成功状态：" + response.code());
                    if (response.code() != 200 || response.body() == null) {
                        return;
                    }
                    RetAppUpBean retAppUpBean = response.body().getData();
                    LogUtil.d("NoReturnCall", "访问成功值：" + retAppUpBean.toString());
                    if (retAppUpBean == null) {
                        return;
                    }
                    if (retAppUpBean.getLatestVersionCode() <= AppInfo.getAppVersionCode(context)) {
                        ToastUtils.show(context, "已是最新版本");
                        return;
                    }

                    dialgNotice[0] = new DialogNotice(context, new DialogNotice.InsideBean("版本更新", retAppUpBean.getUpgradeTip()), new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (v == dialgNotice[0].vBinding.tvCancel) {
                                dialgNotice[0].cancel();
                            } else if (v == dialgNotice[0].vBinding.tvStart) {
                                //开始下载
                                Dialog dialog = new Dialog(context, R.style.DialogTheme);
                                @NonNull DialogApkUpProcessBinding vvBinding = DialogApkUpProcessBinding.inflate(context.getLayoutInflater());
                                dialog.setContentView(vvBinding.getRoot());
                                Window window = dialog.getWindow();
                                //设置对话框大小
                                window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                                window.setDimAmount(0.5f);
                                //设置弹出位置
                                window.setGravity(Gravity.CENTER);
                                if (retAppUpBean.getUpgradeType() == 1) {//强制升级
                                    dialog.setCanceledOnTouchOutside(false);
                                }
                                dialog.show();
                                dialgNotice[0].cancel();

                                //开始下载
                                apkPath[0] = AppUpUtils.downloadApk(context, "apk", retAppUpBean.getLatestVersionName(), retAppUpBean.getLinkUrl(), new AppUpUtils.DownloadListener() {
                                    @Override
                                    public void progressUp(int progress) {
                                        //加个异常捕获，有可能监听回来，dialog不在了
                                        try {
                                            vvBinding.tvP.setText(progress + "%");
                                            vvBinding.pbP.setProgress(progress);
                                            if (progress == 100) {
                                                dialog.dismiss();
                                                //安装
                                                File apkFile = new File(apkPath[0]);
                                                Uri uri = file24ToUri(context, apkFile);
                                                AppUpUtils.installApk(context, uri);
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }
                                });
                            }
                        }
                    });
                    dialgNotice[0].vBinding.tvStart.setText("开始下载");
                    if (retAppUpBean.getUpgradeType() == 1) {//强制升级
                        dialgNotice[0].vBinding.tvCancel.setVisibility(View.GONE);
                    }
                    dialgNotice[0].show();


                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public void onFailure(Call<RetBaseBean<RetAppUpBean>> call, Throwable t) {

            }
        });
    }


    /**
     * 7.0  file转Uri
     *
     * @param context
     * @param file
     * @return
     */
    public static Uri file24ToUri(Context context, File file) {
        Uri uri = null;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) { // 6.0以下
            uri = Uri.fromFile(file);
        } else {
            uri = FileProvider.getUriForFile(context, SHARED_LOCATION, file);
        }
        return uri;
    }

    //7.0Uri适配共享位置
    static String SHARED_LOCATION = "com.juying.mjreader.fileprovider";

}