package com.juying.mjreader.network.util

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
/**
 * @author Nimyears
 */
object Md5Util {
    fun md5(input: String): String {
        try {
            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray())

            val result = StringBuilder()
            for (byte in digest) {
                result.append(String.format("%02x", byte))
            }
            return result.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }

    fun md5(file: File): String? {
        var fileInputStream: FileInputStream? = null
        return try {
            val md5 = MessageDigest.getInstance("MD5")
            fileInputStream = FileInputStream(file)
            val buffer = ByteArray(8192)
            var length: Int
            while (fileInputStream.read(buffer).also { length = it } != -1) {
                md5.update(buffer, 0, length)
            }
            val md5Bytes = md5.digest()
            val hexValue = StringBuffer()
            for (i in md5Bytes.indices) {
                val va = md5Bytes[i].toInt() and 0xFF
                if (va < 16) {
                    hexValue.append("0")
                }
                hexValue.append(Integer.toHexString(va))
            }
            hexValue.toString()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            null
        } finally {
            fileInputStream?.close()
        }
    }
}