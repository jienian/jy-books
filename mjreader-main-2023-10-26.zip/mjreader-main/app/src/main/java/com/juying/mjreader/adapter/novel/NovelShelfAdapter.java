package com.juying.mjreader.adapter.novel;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.NovelBean;
import com.juying.mjreader.fragment.NovelFragment;

import java.util.ArrayList;
import java.util.List;

public class NovelShelfAdapter extends RecyclerView.Adapter<NovelShelfAdapter.ViewHolder> {
    private boolean isVertical;
    private NovelFragment novelFragment;
    private Context context;
    private NovelBean novelBean;

    private List<BookBean> bookBeanList;

    List<Integer> showPosition = new ArrayList<>();
    private int itmeType = 0;

    public NovelShelfAdapter(Context context, NovelFragment novelFragment, List<BookBean> bookBeanList, boolean showMode) {
        this.context = context;
        this.novelFragment = novelFragment;
        this.bookBeanList = bookBeanList;
        this.isVertical = showMode;
    }


    public void setList(List<BookBean> novelBeanList) {
        this.bookBeanList = novelBeanList;
        notifyDataSetChanged();
    }

    public void setVertical(boolean vertical) {
        isVertical = vertical;
    }


    /*用于缓存视图,提高性能*/
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = null;
        if (itmeType == 0) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_novel_shelf_s, null, false);
        } else if (itmeType == 1) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_novel_shelf_h, parent, false);
        }
        NovelShelfAdapter.ViewHolder viewHolder = new NovelShelfAdapter.ViewHolder(view);
        return viewHolder;
    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull NovelShelfAdapter.ViewHolder viewHolder, int position) {

        BookBean bookBean = bookBeanList.get(showPosition.get(position));
        String fileName = bookBean.getFileName();
        viewHolder.tvNovel1.setText(fileName);

        setTVN2(viewHolder, bookBean);
        setNCB(viewHolder, bookBean);

        if (bookBean.isDirectory() && bookBean.getBookBeanList().size() == 0) {
            //空目录
            viewHolder.flNovel.setVisibility(View.INVISIBLE);
        } else {
            //非空目录或文件
            viewHolder.flNovel.setVisibility(View.VISIBLE);
            setVisibility(viewHolder, bookBean);
        }
        viewHolder.itemView.setTag(showPosition.get(position));

/*        viewHolder.itemView.setOnClickListener(v -> {
//                BookBean bookBean = (BookBean) v.getTag();
            if (bookBean.isEdit()) {
                viewHolder.cb.setChecked(!viewHolder.cb.isChecked());
                bookBean.setChecked(viewHolder.cb.isChecked());
                novelFragment.upCheckedNum();
            } else {
                novelFragment.clickBook(bookBean, position);
            }

        });*/


    }


    private void setNCB(ViewHolder viewHolder, BookBean bookBean) {
        if (bookBean.isEdit()) {
            viewHolder.cb.setVisibility(View.VISIBLE);
        } else {
            viewHolder.cb.setVisibility(View.GONE);
        }
        viewHolder.cb.setChecked(bookBean.isChecked());
    }

    @SuppressLint("SetTextI18n")
    private void setTVN2(ViewHolder viewHolder, BookBean bookBean) {
        if (bookBean.isImputProcess()) {
            viewHolder.tvNovel2.setText("导入中");
            return;
        }
        if (bookBean.getReadPosition() == -1 && !bookBean.isDirectory()) {
            viewHolder.tvNovel2.setText("未读");
        } else if (bookBean.getReadPosition() != -1 && !bookBean.isDirectory()) {
            viewHolder.tvNovel2.setText("已读" + bookBean.getReadPosition() + "%");
        } else {
            List<BookBean> list = bookBean.getBookBeanList();
            if (list == null || list.size() == 0) {
                viewHolder.tvNovel2.setText("共0本");
            } else {
                viewHolder.tvNovel2.setText("共" + list.size() + "本");
            }
        }

        // viewHolder.tvNovel1.setText(bookBean.getFileName());
    }

    private void setVisibility(NovelShelfAdapter.ViewHolder viewHolder, BookBean bookBean) {
        double maxSize = bookBean.getMaxSize();
        double imputSchedule = bookBean.getImputSchedule();
        if (maxSize > imputSchedule) {
            //还没导完
            //   viewHolder.tvProgress.setVisibility(View.VISIBLE);
            viewHolder.ivNovel1.setVisibility(View.GONE);
            viewHolder.rlNovel.setVisibility(View.GONE);
            int progress = (int) ((imputSchedule / maxSize) * 100);
            Log.d("TAG", "setVisibility: 进度百分比值：" + progress);
            //    viewHolder.tvProgress.setText("导入进度\n" + progress + "%");
            //   viewHolder.pbNovel.setProgress(progress);
        } else {
            //导完了
            if (bookBean.isDirectory()) {
                List<BookBean> child = bookBean.getBookBeanList();
                viewHolder.ivNovel1.setVisibility(View.GONE);
                //     viewHolder.tvProgress.setVisibility(View.GONE);
                if (child == null || child.size() == 0) {
                    viewHolder.rlNovel.setVisibility(View.GONE);
                } else {
                    viewHolder.rlNovel.setVisibility(View.VISIBLE);
                    for (int i = 0; i < child.size(); i++) {
                        if (i == 0) {
                            setImage(viewHolder.ivNovel1, child.get(i).getFileType());
                            viewHolder.ivNovel2.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel3.setVisibility(View.INVISIBLE);
                            viewHolder.ivNovel4.setVisibility(View.INVISIBLE);
                            viewHolder.ivNovel5.setVisibility(View.INVISIBLE);
                        } else if (i == 1) {
                            setImage(viewHolder.ivNovel2, child.get(i).getFileType());
                            viewHolder.ivNovel2.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel3.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel4.setVisibility(View.INVISIBLE);
                            viewHolder.ivNovel5.setVisibility(View.INVISIBLE);
                        } else if (i == 2) {
                            setImage(viewHolder.ivNovel3, child.get(i).getFileType());
                            viewHolder.ivNovel2.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel3.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel4.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel5.setVisibility(View.INVISIBLE);
                        } else if (i == 3) {
                            setImage(viewHolder.ivNovel4, child.get(i).getFileType());
                            viewHolder.ivNovel2.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel3.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel4.setVisibility(View.VISIBLE);
                            viewHolder.ivNovel5.setVisibility(View.VISIBLE);
                        } else {
                            break;
                        }
                    }
                }
            } else {
                setImage(viewHolder.ivNovel1, bookBean.getFileType());
                viewHolder.rlNovel.setVisibility(View.GONE);
                //       viewHolder.tvProgress.setVisibility(View.GONE);
                viewHolder.ivNovel1.setVisibility(View.VISIBLE);
            }
        }

    }

    /* 输入文件名，用于判断设置图像标志*/
    private void setImage(ImageView iv, String fileType) {
        int image = -1;
        if (fileType.contains("txt")) {
            image = R.drawable.txt;
        } else if (fileType.contains("pdf")) {
            image = R.drawable.pdf;
        } else if (fileType.contains("gif")) {
            image = R.drawable.icon_epub;
        }
        if (image != -1) {
            iv.setImageResource(image);
        }
    }


    /*用于设置显示模式*/
    public void upSettingMode(boolean showMode) {
        this.isVertical = showMode;
        if (isVertical) {
            itmeType = 0;
        } else {
            itmeType = 1;
        }
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivNovel1;
        private final ImageView ivNovel2;
        private final ImageView ivNovel3;
        private final ImageView ivNovel4;
        private final ImageView ivNovel5;
        private final TextView tvNovel1;
        private final TextView tvNovel2;
        private final RelativeLayout rlNovel;
        // private final ProgressBar pbNovel;
        private final FrameLayout flNovel;
        private final CheckBox cb;
        //     private final TextView tvProgress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivNovel1 = itemView.findViewById(R.id.iv1);
            ivNovel2 = itemView.findViewById(R.id.iv2);
            ivNovel3 = itemView.findViewById(R.id.iv3);
            ivNovel4 = itemView.findViewById(R.id.iv4);
            ivNovel5 = itemView.findViewById(R.id.iv5);
            tvNovel1 = itemView.findViewById(R.id.tv1);
            tvNovel2 = itemView.findViewById(R.id.tv2);
            rlNovel = itemView.findViewById(R.id.rl);
            // pbNovel = itemView.findViewById(R.id.pb);
            flNovel = itemView.findViewById(R.id.fl);
            cb = itemView.findViewById(R.id.cb);
            //      tvProgress = itemView.findViewById(R.id.tv_progress);

        /*    itemView.setOnClickListener(v -> {
                BookBean bookBean = (BookBean) v.getTag();
                if (bookBean != null) {
                    if (bookBean.isDirectory()) {
                        Toast.makeText(context, "点击目录进入", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "选择文件开始读书", Toast.LENGTH_SHORT).show();
                    }
                }
            });*/
            itemView.setOnClickListener(v -> {
//                BookBean bookBean = (BookBean) v.getTag();
                int position = (int) v.getTag();
                BookBean bookBean = bookBeanList.get(position);
                if (bookBean != null) {
                    if (bookBean.isEdit()) {
                        cb.setChecked(!cb.isChecked());
                        bookBean.setChecked(cb.isChecked());
                        novelFragment.upCheckedNum();
                    } else {
                        novelFragment.clickBook(bookBeanList, position);
                    }

                }
            });

            cb.setOnClickListener(v -> {

                int position = (int) itemView.getTag();
                BookBean bookBean = bookBeanList.get(position);

                bookBean.setChecked(cb.isChecked());
//                comicBean.getComicBookBean().getBookBeanList().get(bookBean.getListPosition()).setChecked(cb.isChecked());
                novelFragment.upCheckedNum();
            });


        }
    }

    /*书籍列表的大小，计算总共小说书的数量，*/
    @Override
    public int getItemCount() {

        return bookBeanList == null ? 0 : getsize();
    }

    private int getsize() {
        int size = 0;
        showPosition = new ArrayList<>();
        for (int i = 0; i < bookBeanList.size(); i++) {
            BookBean bean = bookBeanList.get(i);
            if (bean.isFrontShow()) {
                showPosition.add(i);
                size++;
            }
        }
        return size;
    }


    public void setData(List<BookBean> bookBeanList) {
        this.bookBeanList = bookBeanList;
    }


    public interface OnItemClickListener {
        void onItemClick(BookBean bookBean, int position);
    }


    private OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setBookReadingPosition(int position, int readingPosition) {
        BookBean bookBean = bookBeanList.get(position);
        bookBean.setReadPosition(readingPosition);
        bookBeanList.remove(position);
        bookBeanList.add(position, bookBean);
        notifyItemChanged(position);
    }


    @Override
    public int getItemViewType(int position) {
        return itmeType;
    }


}
