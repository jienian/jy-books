package com.juying.mjreader.model;

import static com.juying.mjreader.utils.IOUtils.close;

import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import com.juying.mjreader.data.entities.Novel;
import com.juying.mjreader.data.entities.NovelChapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Author Nimyears
 * PDF解析
 */

public class PdfFile {

    private Novel novel;
    private static PdfFile pFile = null;

    // pdf分页尺寸
    public static final int PAGE_SIZE = 10;

    private PdfFile(Novel novel) {
        this.novel = novel;
    }

    public static synchronized PdfFile getPFile(Novel novel) {
        if (pFile == null || !pFile.novel.getNovelUrl().equals(novel.getNovelUrl())) {
            pFile = new PdfFile(novel);
            return pFile;
        }
        pFile.novel = novel;
        return pFile;
    }

    public synchronized void upNovelInfo() {
        // TODO: Implement this method
    }

    public synchronized ArrayList<NovelChapter> getChapterList() {
        // TODO: Implement this method
        return null;
    }

    public synchronized String getContent(NovelChapter chapter) {
        // TODO: Implement this method
        return null;
    }

    public synchronized InputStream getImage(String href) {
        // TODO: Implement this method
        return null;
    }

    public static class Companion implements BaseLocalNovelParse {

        @Override
        public synchronized void upNovelInfo(Novel novel) {
            PdfFile.getPFile(novel).upNovelInfo();
        }


        @Override
        public synchronized ArrayList<NovelChapter> getChapterList(Novel novel) {
            return PdfFile.getPFile(novel).getChapterList();
        }

        @Override
        public synchronized String getContent(Novel novel, NovelChapter chapter) {
            return PdfFile.getPFile(novel).getContent(chapter);
        }

        @Override
        public synchronized InputStream getImage(Novel novel, String href) {
            return PdfFile.getPFile(novel).getImage(href);
        }
    }
    /**
     * 持有引用，避免被回收
     */
/*
    private ParcelFileDescriptor fileDescriptor = null;
    private PdfRenderer pdfRenderer = null;

    public PdfRenderer getPdfRenderer() {
        if (pdfRenderer != null && fileDescriptor != null) {
            return pdfRenderer;
        }
        pdfRenderer = readPdf();
        return pdfRenderer;
    }

    {*/




    /**
     * 读取PDF文件
     *
     * 该方法用于读取PDF文件。
     * 首先，它获取PDF文件的URI。
     * 如果URI是Content Scheme类型，则使用ContentResolver打开文件。
     * 否则，使用ParcelFileDescriptor打开文件。
     * 最后，它返回PdfRenderer对象。
     * @return
     */

  /*  private PdfRenderer readPdf() {
        // 获取PDF文件的URI
        Uri uri = novel.getLocalUri();

        // 如果URI是Content Scheme类型，则使用ContentResolver打开文件
        if (uri.isContentScheme()) {
            fileDescriptor = appCtx.contentResolver.openFileDescriptor(uri, "r")
                    .map(PdfRenderer::new)
                    .orElse(null);
        } else {
            // 否则，使用ParcelFileDescriptor打开文件
            fileDescriptor =
                    ParcelFileDescriptor.open(File(uri.path!!), ParcelFileDescriptor.MODE_READ_ONLY)
                .map(PdfRenderer::new)
                    .orElse(null);
        }

        // 返回PdfRenderer对象
        return pdfRenderer;
    }*/

    /**
     * 关闭pdf文件
     *
     */
/*
    private void closePdf() {
        // 关闭PdfRenderer对象
        pdfRenderer?.close();

        // 关闭ParcelFileDescriptor对象
        fileDescriptor?.close();
    }
*/


    /**
     * 渲染PDF页面
     * 根据index打开pdf页面,并渲染到Bitmap
     *
     * @param renderer
     * @param index
     * @return
     */



}
