

package com.juying.mjreader.model;

import android.net.Uri;
import android.util.Pair;

import com.juying.mjreader.data.entities.Novel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;

public class LocalNovel {


    /**
     * 导入本地文件
     */
/*    public Novel importFile(Uri uri) {
        // Assuming uri points to a file
        File file = new File(uri.getPath());
        // 如果文件不存在或文件长度为0，直接返回null
        if (!file.exists() || file.length() == 0L) {
            return null;
        }
        String bookUrl = uri.toString();
        String fileName = file.getName();
        long updateTime = file.lastModified();

        Pair<String, String> nameAuthor = analyzeNameAuthor(fileName);
        Novel novel = new Novel();
        novel.setBookUrl(bookUrl);
        novel.setName(nameAuthor.first);
        novel.setAuthor(nameAuthor.second);
        novel.setOriginName(fileName);
        novel.setCoverUrl(getCoverPath(bookUrl));
        novel.setLatestChapterTime(updateTime);
        novel.setOrder(novel.getMinOrder() - 1);

        // 根据书的类型解析和更新书的信息
      //  if (novel.isEpub()) EpubFile.upBookInfo(novel);
        if (novel.isPdf()) PdfFile.upBookInfo(novel);

        return novel;
    }*/


    // Assuming you have these methods elsewhere
    private Pair<String, String> analyzeNameAuthor(String fileName) {
        // Implement this method based on your requirements
        return new Pair<>("Name from filename", "Author from filename");
    }

    private String getCoverPath(String bookUrl) {
        // Implement this method based on your requirements
        return "path to cover image";
    }

}


