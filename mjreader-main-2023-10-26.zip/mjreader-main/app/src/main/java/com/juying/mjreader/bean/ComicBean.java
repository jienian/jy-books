package com.juying.mjreader.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * @Author Ycc
 * @Date 10:34
 */
public class ComicBean implements Parcelable {

    private BookBean comicBookBean;

    private ComicSettingBean comicSettingBean;

    public BookBean getComicBookBean() {
        return comicBookBean;
    }

    public void setComicBookBean(BookBean comicBookBean) {
        this.comicBookBean = comicBookBean;
    }

    public ComicSettingBean getComicSettingBean() {
        return comicSettingBean;
    }

    public void setComicSettingBean(ComicSettingBean comicSettingBean) {
        this.comicSettingBean = comicSettingBean;
    }



    public ComicBean() {
    }

    public ComicBean(BookBean comicBookBean, ComicSettingBean comicSettingBean) {
        this.comicBookBean = comicBookBean;
        this.comicSettingBean = comicSettingBean;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.comicBookBean, flags);
        dest.writeParcelable(this.comicSettingBean, flags);
    }

    public void readFromParcel(Parcel source) {
        this.comicBookBean = source.readParcelable(BookBean.class.getClassLoader());
        this.comicSettingBean = source.readParcelable(ComicSettingBean.class.getClassLoader());
    }

    protected ComicBean(Parcel in) {
        this.comicBookBean = in.readParcelable(BookBean.class.getClassLoader());
        this.comicSettingBean = in.readParcelable(ComicSettingBean.class.getClassLoader());
    }

    public static final Parcelable.Creator<ComicBean> CREATOR = new Parcelable.Creator<ComicBean>() {
        @Override
        public ComicBean createFromParcel(Parcel source) {
            return new ComicBean(source);
        }

        @Override
        public ComicBean[] newArray(int size) {
            return new ComicBean[size];
        }
    };
}
