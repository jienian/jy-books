package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicBean;
import com.juying.mjreader.fragment.ComicFragment;
import com.juying.mjreader.utils.config.Abstract;
import com.juying.mjreader.utils.config.Constant;

import java.util.ArrayList;
import java.util.List;


public class BookShelfAdapter extends RecyclerView.Adapter<BookShelfAdapter.ViewHolder> {

    private boolean isVertical;
    private ComicFragment comicFragment;
    //    private ComicBean comicBean;
    private List<BookBean> bookBeanList;
    List<Integer> showPosition = new ArrayList<>();

    private int itmeType = 0;


    //    public BookShelfAdapter(ComicFragment comicFragment, ComicBean comicBean) {
//        this.comicFragment = comicFragment;
//        this.comicBean = comicBean;
//    }
    public BookShelfAdapter(ComicFragment comicFragment, List<BookBean> bookBeanList, boolean showMode) {
        this.comicFragment = comicFragment;
        this.bookBeanList = bookBeanList;
        this.isVertical = showMode;
    }


    public void setVertical(boolean vertical) {
        isVertical = vertical;
    }

    @NonNull
    @Override
    public BookShelfAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = null;
        if (itmeType == 0) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itme_book_shelf_s, null, false);
        } else if (itmeType == 1) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itme_book_shelf_h, parent, false);
        }
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull BookShelfAdapter.ViewHolder viewHolder, int position) {
        BookBean bookBean = bookBeanList.get(showPosition.get(position));
//        bookBean = showListBookBean.get(showPosition.get(position));
        String fileName = bookBean.getFileName();
        viewHolder.tv1.setText(fileName);
        setTV2(viewHolder, bookBean);
        setCB(viewHolder, bookBean);
        if (bookBean.isDirectory() && bookBean.getBookBeanList().size() == 0) {
            //空目录
            viewHolder.fl.setVisibility(View.INVISIBLE);
        } else {
            //非空目录或文件
            viewHolder.fl.setVisibility(View.VISIBLE);
            setVisibility(viewHolder, bookBean);
        }
        viewHolder.itemView.setTag(showPosition.get(position));
    }

    private void setCB(ViewHolder viewHolder, BookBean bookBean) {
        if (bookBean.isEdit()) {
            viewHolder.cb.setVisibility(View.VISIBLE);
        } else {
            viewHolder.cb.setVisibility(View.GONE);
        }
        viewHolder.cb.setChecked(bookBean.isChecked());

    }

    @SuppressLint("SetTextI18n")
    private void setTV2(ViewHolder viewHolder, BookBean bookBean) {
        if (bookBean.isImputProcess()) {
            viewHolder.tv2.setText("导入中");
            return;
        }
        //如果不是PDF同时不是目录，就不显示
//        if (!bookBean.getFileType().contains("pdf")&&!bookBean.isDirectory()) {
//            viewHolder.tv2.setVisibility(View.GONE);
//            return;
//        }else {
//            viewHolder.tv2.setVisibility(View.VISIBLE);
//        }

        if (bookBean.getReadPosition() == 0 && !bookBean.isDirectory()) {
            viewHolder.tv2.setText("未读");
        } else if (bookBean.getReadPosition() != 0 && !bookBean.isDirectory()) {
            viewHolder.tv2.setText("已读" + bookBean.getReadPosition() + "%");
        } else {
            List<BookBean> list = bookBean.getBookBeanList();
            if (list == null || list.size() == 0) {
                viewHolder.tv2.setText("共0本");
            } else {
                viewHolder.tv2.setText("共" + list.size() + "本");
            }
        }
    }


    private void setVisibility(BookShelfAdapter.ViewHolder viewHolder, BookBean bookBean) {
        double maxSize = bookBean.getMaxSize();
        double imputSchedule = bookBean.getImputSchedule();
        if (maxSize > imputSchedule) {
            //还没导完
            viewHolder.tvProgress.setVisibility(View.VISIBLE);
            viewHolder.iv1.setVisibility(View.GONE);
            viewHolder.rl.setVisibility(View.GONE);
            int progress = (int) ((imputSchedule / maxSize) * 100);
            Log.d("TAG", "setVisibility: 进度百分比值：" + progress);
            viewHolder.tvProgress.setText("导入进度\n" + progress + "%");
        } else {
            //导完了
            if (bookBean.isDirectory()) {
                List<BookBean> child = bookBean.getBookBeanList();
                viewHolder.iv1.setVisibility(View.GONE);
                viewHolder.tvProgress.setVisibility(View.GONE);
                if (child == null || child.size() == 0) {
                    viewHolder.rl.setVisibility(View.GONE);
                } else {
                    viewHolder.rl.setVisibility(View.VISIBLE);
                    for (int i = 0; i < child.size(); i++) {
                        if (i == 0) {
                            setImage(viewHolder.iv2, Abstract.getFileCover(child.get(i).getFileType()));
                            viewHolder.iv2.setVisibility(View.VISIBLE);
                            viewHolder.iv3.setVisibility(View.INVISIBLE);
                            viewHolder.iv4.setVisibility(View.INVISIBLE);
                            viewHolder.iv5.setVisibility(View.INVISIBLE);
                        } else if (i == 1) {
                            setImage(viewHolder.iv3, Abstract.getFileCover(child.get(i).getFileType()));
                            viewHolder.iv2.setVisibility(View.VISIBLE);
                            viewHolder.iv3.setVisibility(View.VISIBLE);
                            viewHolder.iv4.setVisibility(View.INVISIBLE);
                            viewHolder.iv5.setVisibility(View.INVISIBLE);
                        } else if (i == 2) {
                            setImage(viewHolder.iv4, Abstract.getFileCover(child.get(i).getFileType()));
                            viewHolder.iv2.setVisibility(View.VISIBLE);
                            viewHolder.iv3.setVisibility(View.VISIBLE);
                            viewHolder.iv4.setVisibility(View.VISIBLE);
                            viewHolder.iv5.setVisibility(View.INVISIBLE);
                        } else if (i == 3) {
                            setImage(viewHolder.iv5, Abstract.getFileCover(child.get(i).getFileType()));
                            viewHolder.iv2.setVisibility(View.VISIBLE);
                            viewHolder.iv3.setVisibility(View.VISIBLE);
                            viewHolder.iv4.setVisibility(View.VISIBLE);
                            viewHolder.iv5.setVisibility(View.VISIBLE);
                        } else {
                            break;
                        }
                    }
                }
            } else {
                setImage(viewHolder.iv1, Abstract.getFileCover(bookBean.getFileType()));
                viewHolder.rl.setVisibility(View.GONE);
                viewHolder.tvProgress.setVisibility(View.GONE);
                viewHolder.iv1.setVisibility(View.VISIBLE);
            }
        }

    }

//    private void setImage(ImageView iv, String fileType) {
//        int image = -1;
//        if (fileType.contains("pdf")) {
//            image = R.mipmap.ic_launcher;
//        } else if (fileType.contains("png")) {
//            image = R.drawable.set;
//        } else if (fileType.contains("jpeg") || fileType.contains("jpg")) {
//            image = R.drawable.icon_epub;
//        } else if (fileType.contains("webp")) {
//            image = R.drawable.wifi;
//        } else if (fileType.contains("gif")) {
//            image = R.drawable.icon_epub;
//        }
//        if (image != -1) {
//            iv.setImageResource(image);
//        }
//    }

    private void setImage(ImageView iv, int resID) {
        if (resID != -1) {
            iv.setImageResource(resID);
        }
    }
//    @Override
//    public int getItemCount() {
//        int size;
//        if (comicBean == null || comicBean.getComicBookBean() == null ||comicBean.getComicBookBean().getBookBeanList()==null|| (size = comicBean.getComicBookBean().getBookBeanList().size()) == 0) {
//            return 0;
//        }
//        return size;
//    }


    @Override
    public int getItemCount() {

        return bookBeanList == null ? 0 : getsize();
    }


    private int getsize() {
        showPosition = new ArrayList<>();


        //在分组编辑弹窗临时加的根目录Bean，这里做最后一道保险，不显示，防止在还没有删除临时Bean的情况下，执行了生命周期onRushow更新UI,把这个临时Bean给显示出来了
//        if (bookBeanList.size()>0&& bookBeanList.get(0).getFileName().equals(Constant.ROOT_NAME)) {
//            bookBeanList.get(0).setFrontShow(false);
//        }



        for (int i = 0; i < bookBeanList.size(); i++) {
            BookBean bean = bookBeanList.get(i);
            if (bean.isFrontShow()) {
                showPosition.add(i);
            }
        }

        return showPosition.size();
    }


    public void setData(List<BookBean> bookBeanList) {
        this.bookBeanList = bookBeanList;
    }

    public void upSettingMode(boolean showMode) {
        this.isVertical = showMode;
        if (isVertical) {
            itmeType = 0;
        } else {
            itmeType = 1;
        }
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView iv1;
        private final ImageView iv2;
        private final ImageView iv3;
        private final ImageView iv4;
        private final ImageView iv5;
        private final RelativeLayout rl;
        private final TextView tv1;
        private final TextView tv2;
        //        private final ProgressBar pb;
        private final FrameLayout fl;
        private final CheckBox cb;
        private final TextView tvProgress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv1 = itemView.findViewById(R.id.iv1);
            iv2 = itemView.findViewById(R.id.iv2);
            iv3 = itemView.findViewById(R.id.iv3);
            iv4 = itemView.findViewById(R.id.iv4);
            iv5 = itemView.findViewById(R.id.iv5);
            tv1 = itemView.findViewById(R.id.tv1);
            tv2 = itemView.findViewById(R.id.tv2);
            rl = itemView.findViewById(R.id.rl);
//            pb = itemView.findViewById(R.id.pb);
            fl = itemView.findViewById(R.id.fl);
            cb = itemView.findViewById(R.id.cb);
            tvProgress = itemView.findViewById(R.id.tv_progress);


            itemView.setOnClickListener(v -> {
//                BookBean bookBean = (BookBean) v.getTag();
                int position = (int) v.getTag();
                BookBean bookBean = bookBeanList.get(position);
                if (bookBean != null) {
                    if (bookBean.isEdit()) {
                        cb.setChecked(!cb.isChecked());
                        bookBean.setChecked(cb.isChecked());
                        comicFragment.upCheckedNum();
                    } else {
                        comicFragment.clickBook(bookBeanList, position);
                    }

                }
            });

            cb.setOnClickListener(v -> {

                int position = (int) itemView.getTag();
                BookBean bookBean = bookBeanList.get(position);

                bookBean.setChecked(cb.isChecked());
//                comicBean.getComicBookBean().getBookBeanList().get(bookBean.getListPosition()).setChecked(cb.isChecked());
                comicFragment.upCheckedNum();
            });


        }
    }

    @Override
    public int getItemViewType(int position) {
        return itmeType;
    }


//    private  void setType(int type){
//        this.type=type;
//    }
}
