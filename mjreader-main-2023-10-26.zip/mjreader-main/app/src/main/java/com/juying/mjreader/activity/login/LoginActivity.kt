package com.juying.mjreader.activity.login

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.juying.mjreader.BaseActivity
import com.juying.mjreader.activity.login.views.LoginFragment
import com.juying.mjreader.activity.login.views.RegisterFragment
import com.juying.mjreader.databinding.ActivityLoginBinding

/**
 * @author: Nimyears
 *
 */

class LoginActivity : BaseActivity(), View.OnClickListener {

    private val TAG = "LoginActivity"

    private lateinit  var binding: ActivityLoginBinding
    override fun onCreate(saveInstanceState: Bundle?) {
        super.onCreate(saveInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initTabView()
        initViewPager()
    }
    private fun initTabView() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("登录"))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("注册"))

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab != null) {
                    binding.viewPager.currentItem = tab.position
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {

            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }
        })
    }

    private fun initViewPager() {
        val fragments = mutableListOf<Fragment>(LoginFragment(), RegisterFragment())
        binding.viewPager.adapter = ViewPagerAdapter(supportFragmentManager, fragments)
        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                val tabToSelect = binding.tabLayout.getTabAt(position)
                tabToSelect?.select()
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })


    }

    override fun onClick(v: View) {


    }
    override fun onPointerCaptureChanged(hasCapture: Boolean) {
        super.onPointerCaptureChanged(hasCapture)
    }


}
