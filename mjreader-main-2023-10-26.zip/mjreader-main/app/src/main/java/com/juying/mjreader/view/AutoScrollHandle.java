package com.juying.mjreader.view;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Instrumentation;
import android.content.Context;
import android.media.metrics.Event;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;

import androidx.annotation.NonNull;

import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;

/**
 * @Author Ycc
 * @Date 13:42
 */
public class AutoScrollHandle extends DefaultScrollHandle {
    public AutoScrollHandle(Context context) {
        super(context);
    }

    public AutoScrollHandle(Context context, boolean inverted) {
        super(context, inverted);
    }

    private static final int delayTime = 50;
    //自动滚动速度，默认15 标准
    int speed = 15;
    private boolean running = false; //标示是否正在自动轮询
    private boolean canRun = true;//标示是否可以自动轮询,可在不需要的是否置false


    private final Runnable mTask = new Runnable() {
        @Override
        public void run() {
            if (running && canRun) {
//                if (canScrollVertically(-1)) {
//                    //如果到底了，就自动停止,并通知外层
//                    stopPlay();
//                    if (rvListener != null) {
//                        rvListener.moveBottomComplete();
//                    }
//                } else {




//                ValueAnimator animation = ValueAnimator.ofFloat(0, speed);
//                AnimationManager.YAnimation yAnimation = new AnimationManager.YAnimation();

//                animation.setInterpolator(new DecelerateInterpolator());
//                animation.addUpdateListener(yAnimation);
//                animation.addListener(yAnimation);
//                animation.setDuration(delayTime);
//                animation.start();



//                ObjectAnimator.ofFloat(this, "translationY",  500).setDuration(2000).start();
//                ObjectAnimator objectAnimatorX = ObjectAnimator.ofFloat(AutoScrollHandle.this, "translationY", 500);
//                objectAnimatorX.setDuration();
//                objectAnimatorX.start();
//                MotionEvent.PointerCoords xxx = new MotionEvent.PointerCoords();


//                case MotionEvent.ACTION_DOWN:
//                case MotionEvent.ACTION_POINTER_DOWN:


// 可以不用在 Activity 中增加任何处理，各 Activity 都可以响应
//                Instrumentation inst = new Instrumentation();
//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        inst.sendPointerSync(MotionEvent.obtain(SystemClock.uptimeMillis(),SystemClock.uptimeMillis(),
//                                MotionEvent.ACTION_DOWN, getX(), getY(), 0));
//                        inst.sendPointerSync(MotionEvent.obtain(SystemClock.uptimeMillis(),SystemClock.uptimeMillis(),
//                                MotionEvent.ACTION_UP, getX(), getY(), 0));
//
//                    }
//                }).start();
                float xxx = getX();
                float xxxY = getY();
//                simulateClick(AutoScrollHandle.this,xxx,xxxY);
                setMouseClick((int)xxx, (int) xxxY+5);

                postDelayed(mTask, 500);

//                page = determineValidPageNumberFrom(getCurrentPage());
//                float offset = page == 0 ? 0 : -pdfFile.getPageOffset(page, zoom);

//                moveTo(getCurrentXOffset(),getCurrentYOffset()-speed);

//                performPageSnap();
//               scrollTo(0, speed+=speed);
//                scrollBy(0, (int) getCurrentYOffset());
//                }


            }
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopPlay();
    }

    public void stopPlay() {
        running = false;
        removeCallbacks(mTask);
    }

    public void startPlay() {
        canRun = true;
        running = true;
        removeCallbacks(mTask);
        // 这里没调用Handler，view里面自带postDelayed
        postDelayed(mTask, delayTime);
    }

//    @Override
//    public boolean onTouchEvent(MotionEvent e) {
//        return false;
//    }



    /**
     * 设置速度
     * @param type 1=慢 2=较慢 3=标准 4=较快 5=快
     */
    public void setSpeed(int type) {
        if (type == 1) {
            speed = 5;
        } else if (type == 2) {
            speed = 10;
        } else if (type == 3) {
            speed = 15;
        } else if (type == 4) {
            speed = 20;
        } else if (type == 5) {
            speed = 25;
        }
    }




    private interface RvListener {
        //移动到底了
        void moveBottomComplete();
    }




    private void simulateClick(View view, float x, float y) {
        long downTime = SystemClock.uptimeMillis();
        final MotionEvent downEvent = MotionEvent.obtain(downTime, downTime,MotionEvent.ACTION_DOWN, x, y, 0);
        downTime += 1000;
        final MotionEvent upEvent = MotionEvent.obtain(downTime, downTime,MotionEvent.ACTION_UP, x, y, 0);
        view.onTouchEvent(downEvent);
        view.onTouchEvent(upEvent);
        downEvent.recycle();
        upEvent.recycle();
    }

    public void setMouseClick(int x, int y){
        MotionEvent evenDownt = MotionEvent.obtain(System.currentTimeMillis(),
                System.currentTimeMillis() + 100, MotionEvent.ACTION_DOWN, x, y, 0);
        dispatchTouchEvent(evenDownt);
        MotionEvent eventUp = MotionEvent.obtain(System.currentTimeMillis(),
                System.currentTimeMillis() + 100, MotionEvent.ACTION_UP, x, y, 0);
        dispatchTouchEvent(eventUp);
        evenDownt.recycle();
        eventUp.recycle();
    }
}
