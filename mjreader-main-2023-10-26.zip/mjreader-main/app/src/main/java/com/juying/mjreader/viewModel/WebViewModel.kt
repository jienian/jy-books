package com.juying.mjreader.viewModel

import androidx.lifecycle.ViewModel

/**
 *   @Author Ycc
 *   @Date  16:18
 */
class WebViewModel:ViewModel() {

}