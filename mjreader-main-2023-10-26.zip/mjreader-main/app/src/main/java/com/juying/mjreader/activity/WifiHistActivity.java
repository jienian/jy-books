package com.juying.mjreader.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.BaseActivity;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.adapter.BaseAdapter;
import com.juying.mjreader.bean.WifiHistBean;
import com.juying.mjreader.databinding.ActivityWifiHistBinding;
import com.juying.mjreader.databinding.ItmeWifiHistFrontBinding;
import com.juying.mjreader.fragment.WifiFragment;
import com.juying.mjreader.utils.DateUtil;
import com.juying.mjreader.utils.DialogUtils;
import com.juying.mjreader.utils.WifiFragmentMode;
import com.juying.mjreader.utils.sqlite.DBDao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 网络历史、收藏页
 * 点击某个界面，用 广播传给展示页
 */
public class WifiHistActivity extends BaseActivity {

    private ActivityWifiHistBinding vBinding;
    private WifiHistFrontAdapter wifiHistFrontAdapter1;
    private WifiHistFrontAdapter wifiHistFrontAdapter2;
    private List<WifiHistBean> listBeanHist;//历史记录
    private List<WifiHistBean> listBeanCollection;//收藏记录

    //当前展示listBean，0表示没有数据 1=收藏，2=历史
    private int currentShowList = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vBinding = ActivityWifiHistBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        initBean();
        iniUi();
        initListener();
    }


    private void initBean() {
        WifiHistBean wBean = new WifiHistBean();
        wBean.setUserID(MjApplication.getUserId());
        List<WifiHistBean> listBean = DBDao.getInstance().query(wBean,1);
        if (listBean != null && listBean.size() != 0) {
            log("查到数据：" + listBean);
            Collections.sort(listBean, (o1, o2) -> {
                // 按照时间戳降序，越大排越前面
                long age = o1.getSaveTime();
                long age2 = o2.getSaveTime();
                return (int) (age2 - age);
            });
            //开始分包
            listBeanHist = new ArrayList<>();
            listBeanCollection = new ArrayList<>();
            for (WifiHistBean bean : listBean) {
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // 指定日期格式
//                String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(bean.getSaveTime()));
                String date = DateUtil.timeToDate(bean.getSaveTime());
                int week = DateUtil.timeToWeek(bean.getSaveTime());
                String s = DateUtil.numberToChinese(week);
                date = date + "  周" + s;
                bean.setSaveDate(date);
                if (bean.isHist()) {
                    //深拷贝一份新的Bean  不然收藏和历史用同一个指引Bean  item会乱
                    listBeanHist.add(bean.clone());
                }
                if (bean.isCollection()) {
                    listBeanCollection.add(bean.clone());
                }
            }

        }
    }

    private void iniUi() {
        //默认先显示1
        setShow(true);
        if (listBeanCollection != null && listBeanCollection.size() > 0) {
            setRv(vBinding.rv1);
        }
    }

    private class WifiHistFrontAdapter extends BaseAdapter<WifiHistFrontAdapter.ViewHolder> {


        private final List<WifiHistBean> listBean;
        private final boolean isCollection;

        public WifiHistFrontAdapter(List<WifiHistBean> listBean, boolean isCollection) {
            this.listBean = listBean;
            this.isCollection = isCollection;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            @NonNull ItmeWifiHistFrontBinding vvBinding = ItmeWifiHistFrontBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new WifiHistFrontAdapter.ViewHolder(vvBinding);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            WifiHistBean bean = listBean.get(position);
            holder.vvBinding.tv1.setText(TextUtils.isEmpty(bean.getTitle()) ? "未知标题" : bean.getTitle());
            holder.vvBinding.tv2.setText(TextUtils.isEmpty(bean.getUrl()) ? "未知网址" : bean.getUrl());
            holder.vvBinding.getRoot().setTag(bean);
            if (bean.isEditState()) {
                holder.vvBinding.cb.setVisibility(View.VISIBLE);
            } else {
                holder.vvBinding.cb.setVisibility(View.GONE);
            }
            holder.vvBinding.cb.setChecked(bean.isEditSelectState());
            if (position == 0) {
                holder.vvBinding.tvTitle.setVisibility(View.VISIBLE);
            } else {
                WifiHistBean bean1 = listBean.get(Math.max(position - 1, 0));
                if (bean.getSaveDate().equals(bean1.getSaveDate())) {
                    holder.vvBinding.tvTitle.setVisibility(View.GONE);
                } else {
                    holder.vvBinding.tvTitle.setVisibility(View.VISIBLE);
                }
            }
            holder.vvBinding.tvTitle.setText(TextUtils.isEmpty(bean.getSaveDate()) ? "未知日期" : bean.getSaveDate());
            WifiFragmentMode.setImageView(holder.vvBinding.iv1, bean.getBrowserName());
        }


        @Override
        public int getItemCount() {
            return listBean.size();
        }

        @Override
        public long getItemId(int position) {
            return super.getItemId(position);
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            private final ItmeWifiHistFrontBinding vvBinding;

            public ViewHolder(@NonNull ItmeWifiHistFrontBinding viewBinding) {
                super(viewBinding.getRoot());
                this.vvBinding = viewBinding;
                vvBinding.getRoot().setOnClickListener(v -> {
                    log("vvBinding.getRoot().setOnClickListener");
                    setCb(vvBinding, false);
                });
                vvBinding.cb.setOnClickListener(v -> {
                    log("vvBinding.cb.setOnClickListener");
                    setCb(vvBinding, true);
                });
//                initChildUi();
            }


        }

    }


    private void setCb(ItmeWifiHistFrontBinding vvBinding, boolean isCbClick) {
        WifiHistBean wifiHistBean = (WifiHistBean) vvBinding.getRoot().getTag();
        if (wifiHistBean == null) {
            return;
        }

        if (!isCbClick) {
            if (wifiHistBean.isEditState()) {
                vvBinding.cb.setChecked(!vvBinding.cb.isChecked());
            } else {
                //跳转webview  销毁自己，然后传值
//                to("跳转webview,销毁自己，然后传值:" + wifiHistBean.getTitle(), true);
//                startActivity(new Intent(this, MainActivity.class).putExtra("url", wifiHistBean.getUrl()));
                WifiFragment.externalLoading(wifiHistBean.getUrl());
                finish();
                return;
            }
        }
        wifiHistBean.setEditSelectState(vvBinding.cb.isChecked());

    }

    private void setRv(RecyclerView rv) {
        if (rv == vBinding.rv1 && wifiHistFrontAdapter1 == null) {
            wifiHistFrontAdapter1 = new WifiHistFrontAdapter(listBeanCollection, true);
            wifiHistFrontAdapter1.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid
            rv.setLayoutManager(new LinearLayoutManager(this));
            rv.setAdapter(wifiHistFrontAdapter1);
        } else if (rv == vBinding.rv2 && wifiHistFrontAdapter2 == null) {
            wifiHistFrontAdapter2 = new WifiHistFrontAdapter(listBeanHist, false);
            rv.setLayoutManager(new LinearLayoutManager(this));
            wifiHistFrontAdapter2.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid
            rv.setAdapter(wifiHistFrontAdapter2);
        }
    }


//    private WifiHistFrontAdapter getAdapter(RecyclerView rv, WifiHistFrontAdapter adapter) {
//        if (adapter == null) {
//            if (rv == vBinding.rv1) {
//                return wifiHistFrontAdapter1 = new WifiHistFrontAdapter();
//            } else if (rv == vBinding.rv2) {
//                return wifiHistFrontAdapter2 = new WifiHistFrontAdapter();
//            }
//        }
//        return wifiHistFrontAdapter1 = new WifiHistFrontAdapter();
//    }


    private void initListener() {
        vBinding.rg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == vBinding.rb1.getId()) {
                vBinding.tv1.setText("清空所有收藏");
                allEdit(false);
                allSelect(false);
                upAdapter();
                //上面要在setShow之前  因为上面是依照currentShowList的值，它在下面才改的
                setShow(true);
                if (listBeanCollection != null && listBeanCollection.size() > 0) {
                    setRv(vBinding.rv1);
                }

            } else if (checkedId == vBinding.rb2.getId()) {
                vBinding.tv1.setText("清空所有历史");
                allEdit(false);
                allSelect(false);
                upAdapter();
                setShow(false);
                if (listBeanHist != null && listBeanHist.size() > 0) {
                    setRv(vBinding.rv2);
                }

            }
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    public void onClick(View view) {
        if (view == vBinding.tv1) {
            cleanUp(true);
        } else if (view == vBinding.tv2) {//编辑
            setButtom(2);
            allEdit(true);
            upAdapter();
        } else if (view == vBinding.tv3) {//全选
            allSelect(true);
            upAdapter();
        } else if (view == vBinding.tv4) {//删除
            cleanUp(false);
        } else if (view == vBinding.tv5) {//取消
            setButtom(1);
            allEdit(false);
            allSelect(false);
            upAdapter();
        } else if (view == vBinding.ivOff) {
            finish();
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private void upAdapter() {
        if (currentShowList == 1 && wifiHistFrontAdapter1 != null) {
            wifiHistFrontAdapter1.notifyDataSetChanged();
        } else if (currentShowList == 2 && wifiHistFrontAdapter2 != null) {
            wifiHistFrontAdapter2.notifyDataSetChanged();
        }
    }

    private void cleanUp(boolean isAll) {
        DialogUtils.delDialog(this, "清除", "您确定要清除所选内容吗？", isOk -> {
            if (isOk) {
                changeBean(isAll);
                if (currentShowList == 1 && listBeanCollection.size() == 0) {
                    setShow(true);
                } else if (currentShowList == 2 && listBeanHist.size() == 0) {
                    setShow(false);
                } else {
                    upAdapter();
                }
            }
        });
    }

    public void setShow(boolean isShowRv1) {
        if (isShowRv1) {
            vBinding.rv2.setVisibility(View.GONE);
            if (listBeanCollection == null || listBeanCollection.size() == 0) {
                vBinding.tvNoData.setVisibility(View.VISIBLE);
                vBinding.rv1.setVisibility(View.GONE);
                setButtom(3);
//                currentShowList = 0;
            } else {
                vBinding.tvNoData.setVisibility(View.GONE);
                vBinding.rv1.setVisibility(View.VISIBLE);
                setButtom(1);
            }
            currentShowList = 1;
        } else {
            vBinding.rv1.setVisibility(View.GONE);
            if (listBeanHist == null || listBeanHist.size() == 0) {
                vBinding.tvNoData.setVisibility(View.VISIBLE);
                vBinding.rv2.setVisibility(View.GONE);
                setButtom(3);
//                currentShowList = 0;
            } else {
                vBinding.tvNoData.setVisibility(View.GONE);
                vBinding.rv2.setVisibility(View.VISIBLE);
                setButtom(1);

            }
            currentShowList = 2;
        }
    }

    //下方视图的切换
    private void setButtom(int type) {
        if (type == 1) {
            vBinding.ll1.setVisibility(View.VISIBLE);
            vBinding.ll2.setVisibility(View.GONE);
        } else if (type == 2) {
            vBinding.ll1.setVisibility(View.GONE);
            vBinding.ll2.setVisibility(View.VISIBLE);
        } else {
            vBinding.ll1.setVisibility(View.GONE);
            vBinding.ll2.setVisibility(View.GONE);
        }
    }


    //全部选中
    private void allSelect(boolean isSelect) {
        if (currentShowList == 1 && listBeanCollection != null) {
            for (WifiHistBean bean : listBeanCollection) {
                bean.setEditSelectState(isSelect);
            }
        } else if (currentShowList == 2 && listBeanHist != null) {
            for (WifiHistBean bean : listBeanHist) {
                bean.setEditSelectState(isSelect);
            }
        }

    }

    //全部编辑状态
    private void allEdit(boolean isEdit) {
        if (currentShowList == 1 && listBeanCollection != null) {
            for (WifiHistBean bean : listBeanCollection) {
                bean.setEditState(isEdit);
            }
        } else if (currentShowList == 2 && listBeanHist != null) {
            for (WifiHistBean bean : listBeanHist) {
                bean.setEditState(isEdit);
            }
        }
    }

    /**
     * 改变收藏或者历史字段
     * 先改内存，再改SQL
     *
     * @param isAll 是否全部【如果不全部就拿选中状态的处理】
     */
    private void changeBean(boolean isAll) {
        List<WifiHistBean> list = null;
        if (currentShowList == 1) {
            list = listBeanCollection;
        } else if (currentShowList == 2) {
            list = listBeanHist;
        }
        if (list == null || list.size() == 0) {
            to("没有内容", false);
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            WifiHistBean bean = list.get(i);
            if (isAll) {
                bean.setEditSelectState(true);
            }
            if (bean.isEditSelectState()) {
                if (currentShowList == 1) {
                    bean.setCollection(false);
                } else if (currentShowList == 2) {
                    bean.setHist(false);
                }
                //删除SQL
                delSQL(bean);

                //删除内存
                list.remove(bean);
                i = i - 1;
            }
        }
    }



    /**
     * 删除url在SQL的数据（只有当收藏或者历史字段同时为0是才删除）
     * 同时不是收藏和历史，就删除，其他情况就修改SQL
     */
    private void delSQL(WifiHistBean bean) {
        if (!bean.isHist() && !bean.isCollection()) {
            DBDao.getInstance().delBean(bean);
        } else {
            DBDao.getInstance().upBean(bean,5);
        }
    }


}