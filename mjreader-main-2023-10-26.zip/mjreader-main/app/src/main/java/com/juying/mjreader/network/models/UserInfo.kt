package com.juying.mjreader.network.models

/**
 * @author Nimyears
 */
data class UserInfo(
    val userId: String = "",
    val nickname: String = "",
    val account: String = "",
    val sex: Int = 0,
    val age: Int = 0,
    val status: Int = 0,
    val phone: String = "",
    val email: String = "",
    val intro: String = "",
    val avatar: String = "",
    val deviceId: String = "",
    val lastDeviceId: String = "",
    val isFreeze: Int = 0
)
