package com.juying.mjreader.net;

/**
 * @Author Ycc
 * @Date 19:13
 */
public interface Regular {

    //net历史记录
    String READHISTORY = "READHISTORY";
}
