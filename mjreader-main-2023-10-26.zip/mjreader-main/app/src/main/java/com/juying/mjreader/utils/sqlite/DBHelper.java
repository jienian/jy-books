package com.juying.mjreader.utils.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * @Author Ycc
 * @Date 13:55
 * onCreate()是在数据库首次创建的时候调用，
 * onUpgrade()是在数据库版本号DB_VERSION升级的时候才会调用，这里如果想在数据中添加表，只能不断的升级数据库的版本号调用onUpgrade()
 */
public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "user.db";//数据库名称
    public static final int DB_VERSION = 1;//数据库版本

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DBDao.SQL_CREATE_TABLE);//建收藏表
        db.execSQL(FlagBDDao.SQL_CREATE_TABLE);//建标记表
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }




}
