package com.juying.mjreader;


import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.text.TextUtils;

import com.juying.mjreader.utils.CurrentActivityUtil;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.utils.exceptional.CrashManagerUtil;
import com.juying.mjreader.view.DialogMask;

import me.jessyan.autosize.AutoSizeConfig;
import me.jessyan.autosize.unit.Subunits;
import me.jingbin.smb.BySMB;

//import me.jessyan.autosize.AutoSizeConfig;
//import me.jessyan.autosize.unit.Subunits;

/**
 * @author juyingtech
 */
public class MjApplication extends Application {
    @SuppressLint("StaticFieldLeak")

    public static Context CONTEXT;
    private static long startTime = System.currentTimeMillis();

    public static String DEFAULT_USER_ID = "defaultUser";

    private static String userId;
    public static boolean isDebug;


    @Override
    public void onCreate() {
        super.onCreate();
        CONTEXT = getApplicationContext();
        //全局异常捕获
        CrashManagerUtil.getInstance(this).init();
        //对今日头条适配方案的自定义配置
        configUnits();
        syncIsDebug(this);
        BySMB.Companion.initProperty("5000", "10000");

        //将CurrentActivityUtil类作为Application的生命周期回调
        registerActivityLifecycleCallbacks(new CurrentActivityUtil());

    }




    public static String getUserId() {
        if (TextUtils.isEmpty(userId)) {
            return DEFAULT_USER_ID;
        } else {
            return userId;
        }
    }

    /**
     * 登录完成后设置
     *
     * @param userId
     */
    public static void setUserId(String userId) {
        MjApplication.userId = userId;
    }


    private void configUnits() {


        //注册今日头条适配方案，支持PT单位 TODO pt单位单独写一套资源
        AutoSizeConfig.getInstance()
                //是否让框架支持自定义 Fragment 的适配参数, 由于这个需求是比较少见的, 所以须要使用者手动开启
                //如果没有这个需求建议不开启
//                .setCustomFragment(true)
                //是否打印 AutoSize 的内部日志, 默认为 true, 如果您不想 AutoSize 打印日志, 则请设置为 false
                .setLog(false)
                //在全面屏或刘海屏幕设备中, 获取到的屏幕高度可能不包含状态栏高度, 所以在全面屏设备中不需要减去状态栏高度，所以可以 setUseDeviceSize(true)
                .setUseDeviceSize(true)
                .getUnitsManager()
                //AndroidAutoSize 默认开启对 sp 的支持, 调用 UnitsManager.setSupportSP(false); 可以关闭对 sp 的支持
                //如果关闭对 sp 的支持, 在布局时就应该使用副单位填写字体的尺寸
                //如果开启 sp, 对其他三方库控件影响不大, 也可以不关闭对 sp 的支持, 这里我就继续开启 sp, 请自行斟酌自己的项目是否需要关闭对 sp 的支持
//                .setSupportSP(false)
                .setSupportDP(false)//只使用MM
                .setSupportSubunits(Subunits.PT);

    }

    public static Context getContext() {
        return CONTEXT;
    }

    public static long getStartTime() {
        return startTime;
    }


    public static void syncIsDebug(Context context) {
        isDebug = context.getApplicationInfo() != null && (context.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

}
