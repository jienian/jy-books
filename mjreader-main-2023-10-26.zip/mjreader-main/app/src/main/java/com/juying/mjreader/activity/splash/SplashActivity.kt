package com.juying.mjreader.activity.splash

class SplashActivity {
}