package com.juying.mjreader.widget

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import com.juying.mjreader.R

/**
 * @author Nimyears
 */
class BackButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    init {
        val imageview = ImageView(context)
        imageview.setImageResource(R.drawable.back)
        addView(imageview)
///       LayoutInflater.from(context).inflate(R.drawable.back, this)
        rootView.setOnClickListener {
            if (context is Activity) {
                context.finish()
            }
        }
    }
}