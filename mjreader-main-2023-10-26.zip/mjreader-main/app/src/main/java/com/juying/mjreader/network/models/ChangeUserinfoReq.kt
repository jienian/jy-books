package com.juying.mjreader.network.models
/**
 * @author Nimyears
 */
data class ChangeUserinfoReq(val nickName: String, val avatarUrl: String, val sex: Int): BaseReq()
