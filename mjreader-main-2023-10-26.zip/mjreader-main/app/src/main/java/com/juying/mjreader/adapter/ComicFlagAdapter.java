package com.juying.mjreader.adapter;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;

import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeComicActivity;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.bean.FlagBean;
import com.juying.mjreader.bean.WifiHistBean;
import com.juying.mjreader.databinding.ItmeFlagBinding;
import com.juying.mjreader.utils.DialogUtils;
import com.juying.mjreader.utils.config.Abstract;
import com.juying.mjreader.utils.sqlite.FlagBDDao;
import com.juying.mjreader.view.DialogFlagDirectory;

import java.util.ArrayList;
import java.util.List;


public class ComicFlagAdapter extends BaseAdapter<ComicFlagAdapter.ViewHolder> {
    private final List<FlagBean> flagBeans;
    private final DialogFlagDirectory dialogFlagDirectory;
    private SeeComicActivity context;

    public ComicFlagAdapter(SeeComicActivity context, DialogFlagDirectory dialogFlagDirectory, List<FlagBean> flagBeans) {
        this.flagBeans = flagBeans;
        this.dialogFlagDirectory = dialogFlagDirectory;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itme_flag, null, false);
        return new ViewHolder(ItmeFlagBinding.inflate(LayoutInflater.from(parent.getContext())));
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        FlagBean flagBean = flagBeans.get(position);
        holder.viewBinding.getRoot().setTag(flagBean);
        holder.viewBinding.tvContent.setText(flagBean.getContent());
        if (position == 0) {
            holder.viewBinding.tvTitle.setVisibility(View.VISIBLE);
        } else {
            FlagBean bean1 = flagBeans.get(Math.max(position - 1, 0));
            if (flagBean.getFileName().equals(bean1.getFileName())) {
                holder.viewBinding.tvTitle.setVisibility(View.GONE);
            } else {
                holder.viewBinding.tvTitle.setVisibility(View.VISIBLE);
            }
        }
        holder.viewBinding.tvTitle.setText(flagBean.getFileName());
        holder.viewBinding.iv.setImageResource(Abstract.getFileCover(flagBean.getFileType()));
    }


    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
//        return position;
    }

    @Override
    public int getItemCount() {
        return flagBeans.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {


        private final ItmeFlagBinding viewBinding;

        public ViewHolder(@NonNull ItmeFlagBinding viewBinding) {
            super(viewBinding.getRoot());
            this.viewBinding = viewBinding;

//            tvTitle = itemView.findViewById(R.id.tv_title);
//            rv = itemView.findViewById(R.id.rv);
//            rv.setLayoutManager(new LinearLayoutManager(context));
//            ComicFlagChildAdapter adapter = new ComicFlagChildAdapter(context, comicSeeSumBean);
//            rv.setAdapter(adapter);
            viewBinding.getRoot().setOnClickListener(v -> {
                dialogFlagDirectory.dismiss();
                FlagBean flagBean = (FlagBean) v.getTag();
                context.clickFlag(flagBean);
            });
            viewBinding.getRoot().setOnLongClickListener(v -> {
                DialogUtils.longEnDialogView(context, new Runnable() {
                    @Override
                    public void run() {
//                        int position = context.queryPosition(flagBean);
                        //                context.LongClickFlag(flagBean);
                        FlagBean flagBean = (FlagBean) v.getTag();
                        //更新UI
                        flagBeans.remove(flagBean);
                        notifyItemRangeRemoved(getLayoutPosition(), 1);
                        dialogFlagDirectory.upFlagUi();//外层dialog
                        context.delFlag(flagBean);//最外层Activity
                        if (!TextUtils.isEmpty(flagBean.getFileType()) && flagBean.getFileType().contains("pdf")) {
                            //删除SQL
                            FlagBDDao.getInstance().delBean(flagBean, 1);
                        } else {
                            //rv删除SQL
                            FlagBDDao.getInstance().delBean(flagBean, 2);
                        }
                    }
                });
                return true;
            });
        }
    }


    private void viewShow(int type) {
        if (type == 1) {
//            viewHolder.iv.setVisibility(View.VISIBLE);
//            viewHolder.bt.setVisibility(View.GONE);
        } else if (type == 2) {
//            viewHolder.iv.setVisibility(View.GONE);
//            viewHolder.bt.setVisibility(View.VISIBLE);
        }
    }

}
