package com.juying.mjreader.view;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.juying.mjreader.R;
import com.juying.mjreader.adapter.MoveGroupingAdapter;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.fragment.ComicFragment;
import com.juying.mjreader.fragment.NovelFragment;

/**
 * @Author Ycc
 * @Date 15:34
 */
public class DialogGrouping extends Dialog {
    View view;
    private MoveGroupingAdapter moveGroupingAdapter;
    DialogGroupingListener listener;
    private ComicFragment context;



    public DialogGrouping(@NonNull ComicFragment context, int themeResId,BookBean currentShowBean, DialogGroupingListener listener) {
        super(context.getContext(), themeResId);
        this.context = context;
        this.listener = listener;
        //        final Dialog dialog = new Dialog(context);
        //2、设置布局
        view = View.inflate(context.getContext(), R.layout.dialog_grouping, null);
        setContentView(view);
        initRecyclerView(currentShowBean);
        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.7f);
        //设置弹出位置
        window.setGravity(Gravity.BOTTOM);

        //区域外点击不关闭dialog
//        setCanceledOnTouchOutside(false);

        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

//FLAG_WATCH_OUTSIDE_TOUCH作用：如果点击事件发生在window之外，就会收到一个特殊的MotionEvent，为ACTION_OUTSIDE
//        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);




        view.findViewById(R.id.iv_off).setOnClickListener(view1 -> {
            dismiss();
            cancel();
        });

        view.findViewById(R.id.iv_add).setOnClickListener(view12 -> {
            listener.onClickAdd();
        });
    }


    public void addUPRV(int position) {
        moveGroupingAdapter.notifyItemInserted(position);
    }




    public interface DialogGroupingListener {

        void onClickGroupingOK();

        void onClickAdd();
    }



    @SuppressLint("NotifyDataSetChanged")
    public void initRecyclerView(BookBean currentShowBean) {
        RecyclerView rv=findViewById(R.id.rv);
        moveGroupingAdapter = new MoveGroupingAdapter(context, currentShowBean, listener);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
//        ((SimpleItemAnimator) rv1.getItemAnimator()).setSupportsChangeAnimations(false);//禁止动画
        RecyclerView.ItemAnimator animator = rv.getItemAnimator();
        assert animator != null;
        animator.setChangeDuration(0);
        if (animator instanceof SimpleItemAnimator) {
            ((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);//禁止动画
        }
//        rv1.setHasFixedSize(true);//itme大小固定时，提到性能
//        rv1.setItemViewCacheSize(20);//
//        rv1.setPreserveFocusAfterLayout(true);//在布局变化后是否保持焦点
//        pageAdapter.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid
        rv.setLayoutManager(layoutManager);
//        linearSnapHelper = new LinearSnapHelper();//用作横向滑动时，不保持偏移量，可多页滑动连续滑动
//        PagerSnapHelper linearSnapHelper1 = new PagerSnapHelper();//用作横向滑动时，不保持偏移量，只能一页一页滑动
        rv.setAdapter(moveGroupingAdapter);
        moveGroupingAdapter.notifyDataSetChanged();
    }

}
