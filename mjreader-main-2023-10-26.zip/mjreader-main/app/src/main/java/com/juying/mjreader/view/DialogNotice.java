package com.juying.mjreader.view;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.annotation.NonNull;

import com.juying.mjreader.R;
import com.juying.mjreader.databinding.DialogFragmentUserAgreementBinding;

/**
 * @Author Ycc
 * @Date 17:15
 */
public class DialogNotice extends BaseDialog {
    public DialogFragmentUserAgreementBinding vBinding;
    private Context context;

    public DialogNotice(@NonNull Context context,InsideBean insideBean,View.OnClickListener onClickListener) {
        super(context, R.style.DialogTheme);
        this.context = context;
        vBinding = DialogFragmentUserAgreementBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        Window window = getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setDimAmount(0.5f);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);
        //区域外点击不关闭dialog
        setCanceledOnTouchOutside(false);
        if (onClickListener != null) {
            vBinding.tvStart.setOnClickListener(onClickListener);
            vBinding.tvCancel.setOnClickListener(onClickListener);
        }
        if(insideBean!=null){
            vBinding.tvTitle.setText(insideBean.title);
            vBinding.tvContent.setText(insideBean.content);
        }

    }


    public static class  InsideBean{
        String content;
        String title;

        public InsideBean( String title,String content) {
            this.content = content;
            this.title = title;
        }
    }
}
