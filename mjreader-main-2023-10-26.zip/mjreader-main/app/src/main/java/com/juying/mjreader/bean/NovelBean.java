package com.juying.mjreader.bean;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.io.Serializable;

/**
 * @Author Nimyears
 */
public class NovelBean implements Parcelable {

    private BookBean novelBookBean;
    private NovelSettingBean novelSettingBean;

    public NovelBean(BookBean novelBookBean, NovelSettingBean novelSettingBean) {
        this.novelBookBean = novelBookBean;
        this.novelSettingBean = novelSettingBean;

    }
    protected NovelBean(Parcel in) {
        this.novelBookBean = in.readParcelable(BookBean.class.getClassLoader());
        this.novelSettingBean = in.readParcelable(NovelSettingBean.class.getClassLoader());
    }

    /*    public BookBean getNovelBookBean() {
        return novelBookBean;
    }*/
    public NovelBean() {
}

    public static final Creator<NovelBean> CREATOR = new Creator<NovelBean>() {
        @Override
        public NovelBean createFromParcel(Parcel in) {
            return new NovelBean(in);
        }

        @Override
        public NovelBean[] newArray(int size) {
            return new NovelBean[size];
        }
    };




    public BookBean getNovelBookBean(){
        return novelBookBean;
    }


    public NovelSettingBean getNovelSettingBean() {
        return novelSettingBean;
    }


   public void setNovelBookBean(BookBean novelBookBean) {
       this.novelBookBean = novelBookBean;
   }


    public void setNovelSettingBean(NovelSettingBean novelSettingBean) {
        this.novelSettingBean = novelSettingBean;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeParcelable(novelSettingBean, flags);
    }
}
