package com.juying.mjreader.bean;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.juying.mjreader.utils.config.Constant;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 19:00
 * 书架上的书
 */
public class BookBean implements Parcelable {

    /**
     * 自身名称
     */
    private String fileName;
    /**
     * 父目录名称
     */
    private String fatherName;
    /**
     * 是否目录
     */
    private boolean isDirectory;

    /**
     * 导入进度(字节)
     */
    private long imputSchedule;
    /**
     * 总大小(字节)
     */
    private long maxSize;

    /**
     * 阅读进度【百分比，不大于100】
     */
    private int readPosition = -1;
    /**
     * 文件类型
     */
    private String fileType;

    /**
     * 现在文件路径
     */
    private String filePath;
    /**
     * 原Uri文件路径【】
     */
    private String originUriPath;
    /**
     * 存SP的文件路径 【带xml】
     */
    private String spFilePath;
    /**
     * 存SP的文件名【不带.xml】
     */
    private String spFileName;

    /**
     * 是否在导入状态中
     */
    private boolean isImputProcess;

    /**
     * 是否编辑状态
     */
    private boolean isEdit;

    /**
     * 是否编辑状态下被选中
     */
    private boolean isChecked;
    /**
     * 此目录Bean在整个Bean的第几位置【索引】
     */
    private int directoryPosition;

    /**
     * 是否编辑状态中
     */
    private boolean isEditProcess;
    /**
     * 章节
     */
    private List<String> sections;

    /**
     * 小说章节
     */
    private List<BookInfo> sections1;
    /**
     * 笔记
     */
    private List<Note> notes;

    /**
     * 上传修改/创建时间
     *
     * @return
     */
    private long lastModified;


    /**
     * 是否可展示在文件管理的前端，默认true【被搜索匹配】
     *
     * @return
     */
    private boolean isFrontShow = true;

    /**
     * 当前展示的子Bean在父bean的什么位置【索引】
     *
     * @return
     */
    private int showPosition = 0;


    /**
     * 用于存储，统一资源标识符
     */
    private Uri uri;


    /**
     * 漫画浏览需要用到的Bean
     */
    private ComicSeeBean comicSeeBean;

    /**
     * 漫画标签目录Bean
     */
    private TreeNodeData treeNodeData;

    /**
     * 是否是本地文件
     */
    private boolean isLocal = false;
    private NovelSeeBean novelSeeBean;

    /**
     * 转换成CollBookBean对象
     *
     * @return
     */
    public CollBookBean convertToCollBookBean() {
        if (TextUtils.isEmpty(filePath)) {
            //非本地导入
            return null;
        }
        File file = new File(filePath);
        if (!file.exists()) return null;
        //
        CollBookBean collBook = new CollBookBean();
        collBook.set_id(file.getAbsolutePath());
        collBook.setTitle(file.getName().replace(".txt", ""));
        collBook.setAuthor("");
        collBook.setShortIntro("无");
        collBook.setCover(file.getAbsolutePath());
        collBook.setLocal(true);
        collBook.setLastChapter("开始阅读");
        //    collBook.setBookChapters();
        //按需补全
        // collBook.setUpdated(StringUtils.dateConvert(file.lastModified(), Constant.FORMAT_BOOK_DATE));
        // collBook.setLastRead(StringUtils.
        //       dateConvert(System.currentTimeMillis(), Constant.FORMAT_BOOK_DATE));

        return collBook;
    }

    /**
     * 该Bean源头是否是网络
     */
    public boolean isFromWifi() {
        if (!TextUtils.isEmpty(originUriPath) && (originUriPath.startsWith("http://") || originUriPath.startsWith("https://"))) {
            return true;
        }
        return false;
    }

    public boolean isLocal() {
        return isLocal;
    }

    public void setLocal(boolean local) {
        isLocal = local;
    }

    public boolean getIsLocal() {
        return this.isLocal;
    }

    public void setIsLocal(boolean isLocal) {
        this.isLocal = isLocal;
    }


    public TreeNodeData getTreeNodeData() {
        return treeNodeData;
    }

    public void setTreeNodeData(TreeNodeData treeNodeData) {
        this.treeNodeData = treeNodeData;
    }

    public ComicSeeBean getComicSeeBean() {
        return comicSeeBean;
    }

    public void setComicSeeBean(ComicSeeBean comicSeeBean) {
        this.comicSeeBean = comicSeeBean;
    }





    public NovelSeeBean getNovelSeeBean() {
        return novelSeeBean;
    }

    public void setNovelSeeBean(NovelSeeBean novelSeeBean) {
        this.novelSeeBean = novelSeeBean;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }


    public BookBean getShowChildBean() {
        return getBookBeanList().get(showPosition);
    }


    public int getShowPosition() {
        return showPosition;
    }

    public void setShowPosition(int showPosition) {
        this.showPosition = showPosition;
    }

    public boolean isFrontShow() {
        return isFrontShow;
    }

    public void setFrontShow(boolean frontShow) {
        isFrontShow = frontShow;
    }

    public long getLastModified() {
        return lastModified;
    }

    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }


    public boolean isEditProcess() {
        return isEditProcess;
    }

    public void setEditProcess(boolean editProcess) {
        isEditProcess = editProcess;
    }

    public boolean isEdit() {
        return isEdit;
    }

    public void setEdit(boolean edit) {
        isEdit = edit;
    }

    public boolean isImputProcess() {
        return isImputProcess;
    }

    public void setImputProcess(boolean imputProcess) {
        isImputProcess = imputProcess;
    }

    public String getSpFileName() {
        return spFileName;
    }

    private void setSpFileName(String spFileName) {
        this.spFileName = spFileName;
    }

    public String getSpFilePath() {
        return spFilePath;
    }


    public void setSpFilePath(String spFilePath) {
        this.spFilePath = spFilePath;
        //注意，这里意味着，新建Bean时，要保证设置isDirectory属性先于设置此属性
        if (isDirectory) {
            this.spFileName = spFilePath.substring(spFilePath.lastIndexOf("/") + 1, spFilePath.length());
        } else {
            this.spFileName = spFilePath.substring(spFilePath.lastIndexOf("/") + 1, spFilePath.lastIndexOf("."));
        }

    }

    public String getOriginUriPath() {
        return originUriPath;
    }

    public void setOriginUriPath(String originUriPath) {
        this.originUriPath = originUriPath;
    }

    public int getDirectoryPosition() {
        return directoryPosition;
    }

    public void setDirectoryPosition(int directoryPosition) {
        this.directoryPosition = directoryPosition;
    }

    //    /**
//     * 子文件数量
//     */
//    private int childFileNum;


    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
        if (!TextUtils.isEmpty(originUriPath) && originUriPath.startsWith("http://") || filePath.startsWith("https://")) {
            //网络
            this.fatherName = Constant.ROOT_NAME;
        } else {
            //本地
            this.fileName = filePath.substring(filePath.lastIndexOf("/") + 1, filePath.length());
            int endIndex = filePath.lastIndexOf("/");
            //倒数第二个"/"的位置
            int startIndex = filePath.lastIndexOf("/", endIndex - 1);
            this.fatherName = filePath.substring(startIndex + 1, endIndex);
        }
    }


    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }


    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    private List<BookBean> bookBeanList = new ArrayList<>();

    public List<BookBean> getBookBeanList() {
        return bookBeanList;
    }

    public int getReadPosition() {
        return readPosition;
    }

    public void setReadPosition(int readPosition) {
        this.readPosition = readPosition;
    }

    public void setBookBeanList(List<BookBean> bookBeanList) {
        this.bookBeanList = bookBeanList;
    }


    public BookBean(String filePath, String fileName, String fatherName, boolean isDirectory, long imputSchedule, long maxSize, int readPosition, String fileType, List<BookBean> bookBeanList) {
        this.isDirectory = isDirectory;
        this.filePath = filePath;
        this.fileName = fileName;
        this.fatherName = fatherName;
        this.imputSchedule = imputSchedule;
        this.maxSize = maxSize;
        this.readPosition = readPosition;
        this.fileType = fileType;
        this.bookBeanList = bookBeanList;

    }


    public BookBean() {
    }

    public boolean isChecked() {
        return isChecked;
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    public void setDirectory(boolean directory) {
        isDirectory = directory;
    }

    public long getImputSchedule() {
        return imputSchedule;
    }

    public void setImputSchedule(long imputSchedule) {
        this.imputSchedule = imputSchedule;
    }

    public long getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(long maxSize) {
        this.maxSize = maxSize;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public List<String> getSections() {
        return sections;
    }

    public void setSections(List<String> sections) {
        this.sections = sections;
    }

    public List<Note> getNotes() {
        return notes;
    }

    public void setNotes(List<Note> notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "BookBean{" +
                "fileName='" + fileName + '\'' +
                ", fatherName='" + fatherName + '\'' +
                ", isDirectory=" + isDirectory +
                ", imputSchedule=" + imputSchedule +
                ", maxSize=" + maxSize +
                ", readPosition=" + readPosition +
                ", fileType='" + fileType + '\'' +
                ", filePath='" + filePath + '\'' +
                ", originUriPath='" + originUriPath + '\'' +
                ", spFilePath='" + spFilePath + '\'' +
                ", spFileName='" + spFileName + '\'' +
                ", isImputProcess=" + isImputProcess +
                ", isEdit=" + isEdit +
                ", isChecked=" + isChecked +
                ", directoryPosition=" + directoryPosition +
                ", isEditProcess=" + isEditProcess +
                ", sections=" + sections +
                ", notes=" + notes +
                ", lastModified=" + lastModified +
                ", isFrontShow=" + isFrontShow +
                ", showPosition=" + showPosition +
                ", bookBeanList=" + bookBeanList +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.fileName);
        dest.writeString(this.fatherName);
        dest.writeByte(this.isDirectory ? (byte) 1 : (byte) 0);
        dest.writeLong(this.imputSchedule);
        dest.writeLong(this.maxSize);
        dest.writeInt(this.readPosition);
        dest.writeString(this.fileType);
        dest.writeString(this.filePath);
        dest.writeString(this.originUriPath);
        dest.writeString(this.spFilePath);
        dest.writeString(this.spFileName);
        dest.writeByte(this.isImputProcess ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEdit ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isChecked ? (byte) 1 : (byte) 0);
        dest.writeInt(this.directoryPosition);
        dest.writeByte(this.isEditProcess ? (byte) 1 : (byte) 0);
        dest.writeStringList(this.sections);
        dest.writeTypedList(this.notes);
        dest.writeLong(this.lastModified);
        dest.writeByte(this.isFrontShow ? (byte) 1 : (byte) 0);
        dest.writeInt(this.showPosition);
        dest.writeList(this.bookBeanList);
        dest.writeByte(this.isLocal ? (byte) 1 : (byte) 0);

        dest.writeParcelable(uri, flags);
    }

    public void readFromParcel(Parcel source) {
        this.fileName = source.readString();
        this.fatherName = source.readString();
        this.isDirectory = source.readByte() != 0;
        this.imputSchedule = source.readLong();
        this.maxSize = source.readLong();
        this.readPosition = source.readInt();
        this.fileType = source.readString();
        this.filePath = source.readString();
        this.originUriPath = source.readString();
        this.spFilePath = source.readString();
        this.spFileName = source.readString();
        this.isImputProcess = source.readByte() != 0;
        this.isEdit = source.readByte() != 0;
        this.isChecked = source.readByte() != 0;
        this.directoryPosition = source.readInt();
        this.isEditProcess = source.readByte() != 0;
        this.sections = source.createStringArrayList();
        this.notes = source.createTypedArrayList(Note.CREATOR);
        this.lastModified = source.readLong();
        this.isFrontShow = source.readByte() != 0;
        this.showPosition = source.readInt();
        this.bookBeanList = new ArrayList<BookBean>();

        uri = source.readParcelable(Uri.class.getClassLoader());

        source.readList(this.bookBeanList, BookBean.class.getClassLoader());
    }

    public List<BookInfo> getSections1() {
        return sections1;
    }

    public void setSections1(List<BookInfo> sections1) {
        this.sections1 = sections1;
    }

    protected BookBean(Parcel in) {
        this.fileName = in.readString();
        this.fatherName = in.readString();
        this.isDirectory = in.readByte() != 0;
        this.imputSchedule = in.readLong();
        this.maxSize = in.readLong();
        this.readPosition = in.readInt();
        this.fileType = in.readString();
        this.filePath = in.readString();
        this.originUriPath = in.readString();
        this.spFilePath = in.readString();
        this.spFileName = in.readString();
        this.isImputProcess = in.readByte() != 0;
        this.isEdit = in.readByte() != 0;
        this.isChecked = in.readByte() != 0;
        this.directoryPosition = in.readInt();
        this.isEditProcess = in.readByte() != 0;
        this.sections = in.createStringArrayList();
        this.notes = in.createTypedArrayList(Note.CREATOR);
        this.lastModified = in.readLong();
        this.isFrontShow = in.readByte() != 0;
        this.showPosition = in.readInt();
        this.bookBeanList = new ArrayList<BookBean>();
        in.readList(this.bookBeanList, BookBean.class.getClassLoader());
    }

    public static final Parcelable.Creator<BookBean> CREATOR = new Parcelable.Creator<BookBean>() {
        @Override
        public BookBean createFromParcel(Parcel source) {
            return new BookBean(source);
        }

        @Override
        public BookBean[] newArray(int size) {
            return new BookBean[size];
        }
    };
}
