package com.juying.mjreader.activity.login.views

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.databinding.DataBindingUtil.setContentView
import androidx.lifecycle.lifecycleScope
import com.juying.mjreader.databinding.FragmentLoginBinding
import com.juying.mjreader.databinding.FragmentRegisterBinding
import com.juying.mjreader.fragment.BaseFragment
import com.juying.mjreader.manager.UserManager
import com.juying.mjreader.utils.AppUtil
import com.juying.mjreader.widget.LoadingView
import com.juying.mjreader.widget.LoadingViewImpl
import kotlinx.coroutines.launch

/**
 *
 * @author Nimyears
 */

class LoginFragment : BaseFragment(), LoadingView by LoadingViewImpl() {
    private val TAG = "LoginFragment"
    private lateinit var binding: FragmentLoginBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View ? {
        binding = FragmentLoginBinding.inflate(inflater, container, false)
        initView()
        initListener()
        return binding.root
    }


    fun initView() {

        loadingView = binding.loadingWrap.loadingView
    }

     fun initListener() {

        binding.btLogin.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (!validate(username, password)) return@setOnClickListener

            if (loading) return@setOnClickListener
            showLoading()

            lifecycleScope.launch {
                val data = UserManager.login(username, password)

                data?.let {

                    val userId = data.userId

                    val intent = Intent("login_success")
                    intent.putExtra("user_id", userId)
                    intent.setPackage(requireActivity().packageName)
                    requireActivity().sendBroadcast(intent)

                    Toast.makeText(
                        requireContext(),
                        "欢迎${AppUtil.getAppName(requireContext())}",
                        Toast.LENGTH_SHORT
                    ).show()
                    requireActivity().setResult(Activity.RESULT_OK)
                    requireActivity().finish()
                }

                hideLoading()
            }
        }
    }

    private fun validate(username: String, password: String): Boolean {
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                requireContext(),
                "账号或密码不能为空!",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        return true
    }
}