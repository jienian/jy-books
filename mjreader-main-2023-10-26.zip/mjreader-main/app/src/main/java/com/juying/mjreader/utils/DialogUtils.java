package com.juying.mjreader.utils;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.juying.mjreader.R;

/**
 * @Author Ycc
 * @Date 14:08
 */
public class DialogUtils {
    public static Dialog windowDialogView(Context context, int layoutId, String title, String hint, WindowDialogListener listener) {
        //1、使用Dialog、设置style
        final Dialog dialog = new Dialog(context, R.style.DialogTheme);
        //2、设置布局
        View view = View.inflate(context, layoutId, null);
        dialog.setContentView(view);

        EditText et = view.findViewById(R.id.et_edit);
        et.setHint(hint);
        ((TextView) view.findViewById(R.id.tv_title)).setText(title);
        view.findViewById(R.id.tv_cancel).setOnClickListener(view1 -> {
            dialog.dismiss();
        });

        view.findViewById(R.id.tv_ok).setOnClickListener(view12 -> {
            String name = et.getText().toString();
            if (!TextUtils.isEmpty(name)) {
                String s = StringUtils.isContain(name);
                if (TextUtils.isEmpty(s)) {
                    dialog.dismiss();
                    listener.onOk(name);
                } else {
                    Toast.makeText(context, "不能包含特殊字符：" + s, Toast.LENGTH_SHORT).show();
                }
            }
        });
        setDialogInfo(dialog);
        setDialogSize(dialog);
        return dialog;
    }

    public static Dialog imputDialogView(Context context, String title, String hint, WindowDialogListener listener) {
        //1、使用Dialog、设置style
        final Dialog dialog = new Dialog(context, R.style.DialogTheme);
        //2、设置布局
        View view = View.inflate(context, R.layout.dialog_wifi_imput, null);
        dialog.setContentView(view);

        EditText et = view.findViewById(R.id.et_edit);
        et.setHint(hint);
        ((TextView) view.findViewById(R.id.tv_title)).setText(title);
        view.findViewById(R.id.tv_cancel).setOnClickListener(view1 -> {
            dialog.dismiss();
        });

        view.findViewById(R.id.tv_ok).setOnClickListener(view12 -> {
            String name = et.getText().toString();
            if (!TextUtils.isEmpty(name)) {
                dialog.dismiss();
                listener.onOk(name);
            }
        });
        setDialogInfo(dialog);
        setDialogSize(dialog);
        return dialog;
    }

    public interface WindowDialogListener {
        void onOk(String name);
    }

    public interface OkDialogListener {
        void onOk(boolean isOk);
    }

    @SuppressLint("SetTextI18n")
    public static Dialog delDialog(Context context, String title, String content, OkDialogListener listener) {
        //1、使用Dialog、设置style
        final Dialog dialog = new Dialog(context, R.style.DialogTheme);
//        final Dialog dialog = new Dialog(context);
        //2、设置布局
        View view = View.inflate(context, R.layout.dialog_del_ok, null);
        dialog.setContentView(view);
        ((TextView) view.findViewById(R.id.tv_title)).setText(title);
        ((TextView) view.findViewById(R.id.tv_content)).setText(content);
        dialog.findViewById(R.id.tv_cancel).setOnClickListener(view1 -> {
            dialog.dismiss();
            listener.onOk(false);
        });
        dialog.findViewById(R.id.tv_ok).setOnClickListener(view12 -> {
            dialog.dismiss();
            listener.onOk(true);
        });
        setDialogInfo(dialog);
        setDialogSize(dialog);
        return dialog;
    }


    private static void setDialogSize(Dialog dialog) {
        Display display = dialog.getWindow().getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int) (display.getWidth() * 0.8);
        dialog.getWindow().setAttributes(params);
    }

    private static Dialog setDialogInfo(Dialog dialog) {
        Window window = dialog.getWindow();
        //设置弹出位置
//        window.setGravity(Gravity.CENTER_VERTICAL);
        //设置弹出动画
//        window.setWindowAnimations(R.style.main_menu_animStyle);
        //设置对话框大小
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        //设置弹出位置
        window.setGravity(Gravity.CENTER);
        //区域外点击不关闭dialog
//        dialog.setCanceledOnTouchOutside(false);
        //区域外响应点击事件
//        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

//FLAG_WATCH_OUTSIDE_TOUCH作用：如果点击事件发生在window之外，就会收到一个特殊的MotionEvent，为ACTION_OUTSIDE
//        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);

        window.setDimAmount(0.5f);
        //区域外点击不关闭dialog
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();

        return dialog;
    }


    public static Dialog longEnDialogView(Context context, Runnable runnable) {
        //1、使用Dialog、设置style
        final Dialog dialog = new Dialog(context, R.style.DialogTheme);
        //2、设置布局
        View view = View.inflate(context, R.layout.dialog_long, null);
        dialog.setContentView(view);
        view.findViewById(R.id.tv_del).setOnClickListener(v -> {
            dialog.dismiss();
            runnable.run();
        });
        view.findViewById(R.id.tv_off).setOnClickListener(v -> {
            dialog.dismiss();
        });
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.BOTTOM);
        window.setDimAmount(0.7f);
        dialog.show();

//        setDialogSize(dialog);
        return dialog;
    }

}
