package com.juying.mjreader.network.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import androidx.core.app.ActivityCompat
import java.net.Inet4Address
import java.net.NetworkInterface
/**
 * @author Nimyears
 */
object NetworkUtils {

    private var networkType: String? = null
    fun getNetworkType(context: Context): String {
        if (networkType != null) return networkType!!

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val networkCapabilities = connectivityManager.activeNetwork ?: return "UnKnown"

        val activeNetwork =
            connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return "UnKnown"

        networkType = if (activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            "WIFI"
        } else if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_PHONE_STATE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            "mobile"
        } else {
            val telephonyManager =
                context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            when (telephonyManager.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_LTE -> "4G"
                TelephonyManager.NETWORK_TYPE_NR -> "5G"
                else -> "UnKnown"
            }
        }
        return networkType ?: "UnKnown"
    }

    private var localIp: String? = null
    fun getLocalIp(): String {
        if (localIp != null) return localIp!!
        try {
            val networkInterfaces = NetworkInterface.getNetworkInterfaces()
            while (networkInterfaces.hasMoreElements()) {
                val networkInterface = networkInterfaces.nextElement()
                val inetAddresses = networkInterface.inetAddresses
                while (inetAddresses.hasMoreElements()) {
                    val address = inetAddresses.nextElement()
                    if (!address.isLoopbackAddress
                        && address is Inet4Address
                    ) {
                        localIp = address.getHostAddress()
                    }
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return localIp ?: "0.0.0.0"
    }
}