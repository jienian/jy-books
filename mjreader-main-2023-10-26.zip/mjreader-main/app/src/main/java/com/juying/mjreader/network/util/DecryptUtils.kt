package com.juying.mjreader.network.util

import com.juying.mjreader.network.models.Safety
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
/**
 * @author Nimyears
 */
object DecryptUtils {
    private fun decryptDES(ciphertext: String, key: String): String {
        val keyBytes = key.toByteArray()
        val secretKey = SecretKeySpec(keyBytes, "des")
        val cipher = Cipher.getInstance("des/ECB/PKCS7Padding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey)
        val data = android.util.Base64.decode(ciphertext, android.util.Base64.DEFAULT)
        val buffer = cipher.doFinal(data)
        return String(buffer)
    }

    private fun decrypt3DES(ciphertext: String, key: String, iv: String): String {
        val keyBytes = key.toByteArray()
        val secretKey = SecretKeySpec(keyBytes, "desede")
        val secretIv = IvParameterSpec(iv.toByteArray())
        val cipher = Cipher.getInstance("desede/CBC/PKCS7Padding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, secretIv)
        val data = android.util.Base64.decode(ciphertext, android.util.Base64.DEFAULT)
        val buffer = cipher.doFinal(data)
        return String(buffer)
    }

    private fun getValueBySingleOrDouble(str:String, index: Int): String {
        val length = str.length
        var result = ""
        for (i in 1..length) {
            if ((i + index) % 2 == 0) {
                result += str[i - 1]
            }
        }
        return result
    }

    fun decryptResp(safety: Safety, safetyData: String): String? {
        val type = safety.type
        val token = safety.token
        when(type) {
            "14239" -> {
                val key = token[0]
                return decryptDES(safetyData, key)
            }
            "14339" -> {
                val key = token[0].substring(1).reversed()
                return decryptDES(safetyData, key)
            }
            "14439" -> {
                val key = getValueBySingleOrDouble(token[0], 1) +
                        getValueBySingleOrDouble(token[1], 2)
                return decryptDES(safetyData, key)
            }
            "15632" -> {
                val key = token[0].reversed()
                val iv = token[1].reversed()
                return decrypt3DES(safetyData, key, iv)
            }
        }
        return null
    }
}