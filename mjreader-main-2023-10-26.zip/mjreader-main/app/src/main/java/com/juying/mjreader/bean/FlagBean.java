package com.juying.mjreader.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.File;
import java.util.Objects;

/**
 * 阅读时的标记Bean，显示和存标记用到
 * 唯一 通过 filePath 、 pageNumber 、 offset 三者同时判断唯一性 目前暂时用不到offset
 *
 * @Author Ycc
 * @Date 17:58
 */
public class FlagBean implements Parcelable {

    //所属用户
    private String userId;

    //标记时间
    private long saveTime;
    //内容
    private String content;
    //文件路径【和外面唯一链接】
    private String filePath;
    //文件父路径
    private String fatherPath;
//    //文件封面 [目前就是文件类型]
    private String coverUrl;
    //文件类型
    private String fileType;
    //文件标题
    private String fileName;
    //本标记是文件的多少页【如果是图片,那么这里永远是0，如果是PDF这里就是正常页数】
    private int pageNumber;
    //离该页上方的偏移量百分比 最大100【一页非常大的情况下，如果有多个标记的时候的显示Ui位置， 暂时用不到，先这样设计字段】
    private int offset;


    public String getFatherPath() {
        return fatherPath;
    }

    public void setFatherPath(String fatherPath) {
        this.fatherPath = fatherPath;
    }

    public FlagBean(String userId, long saveTime, String content, String filePath, String fileType, String coverUrl, String fileName, int pageNumber, int offset) {
        this.userId=userId;
        this.saveTime = saveTime;
        this.content = content;
        this.filePath = filePath;
        this.fatherPath= Objects.requireNonNull(new File(filePath).getParentFile()).getAbsolutePath();
        this.coverUrl = coverUrl;
        this.fileType=fileType;
        this.fileName = fileName;
        this.pageNumber = pageNumber;
        this.offset = offset;
    }

    public FlagBean(){};

    public FlagBean(String filePath, int pageNumber) {
        this.filePath = filePath;
        this.fatherPath= Objects.requireNonNull(new File(filePath).getParentFile()).getAbsolutePath();
        this.pageNumber = pageNumber;
    }


    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public long getSaveTime() {
        return saveTime;
    }

    public void setSaveTime(long saveTime) {
        this.saveTime = saveTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
        this.fatherPath= Objects.requireNonNull(new File(filePath).getParentFile()).getAbsolutePath();
//        this.fatherPath= new File(filePath).getParentFile().getAbsolutePath();
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.userId);
        dest.writeLong(this.saveTime);
        dest.writeString(this.content);
        dest.writeString(this.filePath);
        dest.writeString(this.fatherPath);
        dest.writeString(this.coverUrl);
        dest.writeString(this.fileType);
        dest.writeString(this.fileName);
        dest.writeInt(this.pageNumber);
        dest.writeInt(this.offset);
    }

    public void readFromParcel(Parcel source) {
        this.userId = source.readString();
        this.saveTime = source.readLong();
        this.content = source.readString();
        this.filePath = source.readString();
        this.fatherPath = source.readString();
        this.coverUrl = source.readString();
        this.fileType = source.readString();
        this.fileName = source.readString();
        this.pageNumber = source.readInt();
        this.offset = source.readInt();
    }

    protected FlagBean(Parcel in) {
        this.userId = in.readString();
        this.saveTime = in.readLong();
        this.content = in.readString();
        this.filePath = in.readString();
        this.fatherPath = in.readString();
        this.coverUrl = in.readString();
        this.fileType = in.readString();
        this.fileName = in.readString();
        this.pageNumber = in.readInt();
        this.offset = in.readInt();
    }

    public static final Parcelable.Creator<FlagBean> CREATOR = new Parcelable.Creator<FlagBean>() {
        @Override
        public FlagBean createFromParcel(Parcel source) {
            return new FlagBean(source);
        }

        @Override
        public FlagBean[] newArray(int size) {
            return new FlagBean[size];
        }
    };
}
