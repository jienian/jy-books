package com.juying.mjreader.utils.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.juying.mjreader.MjApplication;
import com.juying.mjreader.bean.WifiHistBean;
import com.juying.mjreader.manager.UserManager;
import com.juying.mjreader.net.Client;
import com.juying.mjreader.net.NoReturnCall;
import com.juying.mjreader.net.Regular;
import com.juying.mjreader.net.bean.ReqRemoveDataBean;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ycc
 * @Date 14:00
 */
public class DBDao {
    public static String TABLE_NAME = "wifi_hist";//表名

    private static final String ID = "id";//id自增长

    private static final String dataID = "data_id";//id自增长,唯一 ID_时间戳
    //用户id
    private static final String userID = "user_id";
    //浏览时间戳
    private static final String saveTime = "save_time";
    //使用浏览器
    private static final String browserName = "browser_name";
    //标题
    private static final String title = "title";
    //url
    private static final String url = "url";
    //封面图url
    private static final String imageUrl = "image_url";
    //是否收藏
    private static final String isCollection = "isCollection";
    //是否历史
    private static final String isHist = "isHist";
    //是否有更新需要上传后端
    private static final String isUpdatePresent = "isUpdatePresent";

    private DBHelper dbHelper;

    /**
     * 创建表结构
     * ID 只自增，没哈用
     * dataID 数据唯一ID:由时间戳+ID构成；【不用ID唯一键的原因：假如没登录时本地产生一条数据ID为1，然后登录，远程的数据ID也为1，两条数据的内容可能完成不一样；但拉下来后会被合并，所以不具备数据唯一性】
     */
    public static final String SQL_CREATE_TABLE = "create table " + TABLE_NAME + "(" +
            ID + " integer," +//这个ID不为唯一键，只
            dataID + " text primary key," +//唯一键
            userID + " text," +
            saveTime + " long," +//时间戳
            browserName + " text," +
            title + " text," +
            url + " text," +
            imageUrl + " text," +
            isCollection + " integer," +//0为不收藏，1为收藏
            isHist + " integer," +//0为不历史，1为历史
            isUpdatePresent + " integer" +//0为沒有，1有
            ")";

    //    autoincrement
    //    UNIQUE
    private DBDao() {
        dbHelper = new DBHelper(MjApplication.getContext());
    }

    public static DBDao getInstance() {
        return InnerDB.instance;
    }


    private static class InnerDB {
        private static DBDao instance = new DBDao();
    }


//    public synchronized <T> void insertOrUp(T bean) {
//        WifiHistBean wifiHistBean = (WifiHistBean) bean;
//        List<WifiHistBean> list = queryUrl(wifiHistBean.getUrl());
//        if (list != null && list.size() > 0) {
//            upBeanAll(wifiHistBean);
//        } else {
//            insert(bean);
//        }
//    }

    //根据url更新单条数据的所有字段
//    private <T> void upBeanAll(T bean) {
//        WifiHistBean wifiHistBean = (WifiHistBean) bean;
//        dbHelper.getWritableDatabase()
//                .update(TABLE_NAME, getContentValues(wifiHistBean),
//                        url + "= ?", new String[]{wifiHistBean.getUrl()});
//    }


    /**
     * 数据库插入数据
     *
     * @param bean 实体类
     * @param <T>  T
     */
    public synchronized <T> void insert(T bean) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            if (bean instanceof WifiHistBean) {
//                upEemote((WifiHistBean) bean);//更新远程后台
                //更新SQL
                db.insert(TABLE_NAME, null, getContentValues(bean));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
    }

    /**
     * 插入：在插入时会判断是否存在相同的唯一键（UNIQUE key），如果存在则删除原有数据，再插入新数据
     *
     * @param bean
     * @param <T>
     */
    public synchronized <T> void replace(T bean) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            if (bean != null && bean instanceof WifiHistBean) {
//                upEemote((WifiHistBean) bean);//更新远程后台
                db.replace(TABLE_NAME, null, getContentValues(bean));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
    }

    private <T> ContentValues getContentValues(T bean) {
        WifiHistBean wifiHistBean = (WifiHistBean) bean;
        ContentValues cv = new ContentValues();
        cv.put(ID, wifiHistBean.getId());
        cv.put(userID, wifiHistBean.getUserID());
        cv.put(dataID, wifiHistBean.getDataId());
        cv.put(saveTime, wifiHistBean.getSaveTime());
        cv.put(browserName, wifiHistBean.getBrowserName());
        cv.put(title, wifiHistBean.getTitle());
        cv.put(url, wifiHistBean.getUrl());
        cv.put(imageUrl, wifiHistBean.getImageUrl());
        cv.put(isCollection, wifiHistBean.isCollection() ? 1 : 0);
        cv.put(isHist, wifiHistBean.isHist() ? 1 : 0);
        cv.put(isUpdatePresent, wifiHistBean.isUpdatePresent() ? 1 : 0);
        return cv;
    }


    private List<WifiHistBean> getListBean(Cursor cursor) {
        List<WifiHistBean> list = new ArrayList<>();
        Log.d("TAG", "查询SQL条数:" + cursor.getCount());
        while (cursor != null && cursor.moveToNext()) {
            WifiHistBean wifiHistBean = assemble(cursor);
            list.add(wifiHistBean);
        }
        return list;
    }


    /**
     * 查数据
     *
     * @param type 类型：
     *             1：userID
     *             2：userID+isUpdatePresent 是否上传
     *             3：userID+url
     *             <p>
     *             5：userID+是否收藏
     *             6：userID+isUpdatePresent 是否上传+是否收藏
     *             7：userID+url+是否收藏
     */
    public synchronized List<WifiHistBean> query(WifiHistBean wifiHistBean, int type) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<WifiHistBean> list = new ArrayList<>();
        Cursor cursor = null;
        try {
            Object[] objects = getSelection(wifiHistBean, type);
            cursor = db.query(TABLE_NAME, null, (String) objects[0], (String[]) objects[1], null, null, saveTime+" desc");//insertTime升序。desc是降序
            list = getListBean(cursor);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
        return list;
    }


    /**
     * 更新
     *
     * @param type 类型：
     *             1：根据：dataID——全部更新
     *             2：根据：userID和url——更新时间
     *             3：根据：userID和url——更新收藏状态
     *             4:根据：userID和url——更新历史状态
     *             5:根据：userID和url——同时更新收藏和历史状态
     *             6:根据：dataID——同时更新UserID和是否需要上传后台
     * @return List
     */
    public void upBean(WifiHistBean wifiHistBean, int type) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Object[] o = getUpCondition(wifiHistBean, type);
        String s = (String) ((Object[]) (o[1]))[0];
        String[] s1 = (String[]) ((Object[]) (o[1]))[1];
        db.update(TABLE_NAME, (ContentValues) o[0], s, s1);
    }


    private Object[] getUpCondition(WifiHistBean wifiHistBean, int type) {
        ContentValues cv = new ContentValues();
        Object[] selection = null;
        if (type == 1) {
            cv = getContentValues(wifiHistBean);
            selection = getSelection(wifiHistBean, 4);
        } else if (type == 2) {
            cv.put(saveTime, wifiHistBean.getSaveTime());
            selection = getSelection(wifiHistBean, 3);
        } else if (type == 3) {
            cv.put(isCollection, wifiHistBean.isCollection() ? 1 : 0);
            selection = getSelection(wifiHistBean, 3);
        } else if (type == 4) {
            cv.put(isHist, wifiHistBean.isHist() ? 1 : 0);
            selection = getSelection(wifiHistBean, 3);
        } else if (type == 5) {
            cv.put(isCollection, wifiHistBean.isCollection() ? 1 : 0);
            cv.put(isHist, wifiHistBean.isHist() ? 1 : 0);
            selection = getSelection(wifiHistBean, 3);
        } else if (type == 6) {
            cv.put(userID, wifiHistBean.getUserID());
            cv.put(isUpdatePresent, wifiHistBean.isUpdatePresent() ? 1 : 0);
            selection = getSelection(wifiHistBean, 4);
        }


        switch (type) {
            case 2:
            case 3:
            case 4:
            case 5:
                cv.put(isUpdatePresent, 1);
        }


        return new Object[]{cv, selection};
    }


    /**
     * 删除数据
     *
     * @param wifiHistBean
     * @return
     */
    public void delBean(WifiHistBean wifiHistBean) {
        delEemote(wifiHistBean);//先删远程
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_NAME, whereClause, new String[]{wifiHistBean.getUrl(), MjApplication.getUserId()});
    }

    String whereClause = url + " = ? and " + userID + "= ?";


    @SuppressLint("Range")
    private WifiHistBean assemble(Cursor cursor) {
        WifiHistBean wifiHistBean = new WifiHistBean();
        wifiHistBean.setId(cursor.getString(cursor.getColumnIndex(ID)));
        wifiHistBean.setUserID(cursor.getString(cursor.getColumnIndex(userID)));
        wifiHistBean.setDataId(cursor.getString(cursor.getColumnIndex(dataID)));
        wifiHistBean.setSaveTime(cursor.getLong(cursor.getColumnIndex(saveTime)));
        wifiHistBean.setBrowserName(cursor.getString(cursor.getColumnIndex(browserName)));
        wifiHistBean.setTitle(cursor.getString(cursor.getColumnIndex(title)));
        wifiHistBean.setUrl(cursor.getString(cursor.getColumnIndex(url)));
        wifiHistBean.setImageUrl(cursor.getString(cursor.getColumnIndex(imageUrl)));
        wifiHistBean.setCollection(cursor.getInt(cursor.getColumnIndex(isCollection)) == 1);
        wifiHistBean.setHist(cursor.getInt(cursor.getColumnIndex(isHist)) == 1);
        wifiHistBean.setUpdatePresent(cursor.getInt(cursor.getColumnIndex(isUpdatePresent)) == 1);
        return wifiHistBean;
    }


    //删除远程
    public static void delEemote(WifiHistBean bean) {
        if (!MjApplication.getUserId().equals(MjApplication.DEFAULT_USER_ID)) {
            Client.getNetApi().delUserData(new ReqRemoveDataBean(Regular.READHISTORY, UserManager.INSTANCE.createDataId(Regular.READHISTORY, bean.getUrl()), UserManager.INSTANCE.createTopUserId())).enqueue(new NoReturnCall());
        }
    }

    //增添/更改远程
    public static void upEemote(WifiHistBean bean) {
        if (!MjApplication.getUserId().equals(MjApplication.DEFAULT_USER_ID)) {
            Client.getNetApi().submitUserData(Client.getRsBean(Regular.READHISTORY, bean.getUrl(), bean)).enqueue(new NoReturnCall());
        }
    }


    String USERID = userID + FLAG;
    String ISUPDATEPRESENT = isUpdatePresent + FLAG;
    String URL = url + FLAG;
    String DATAID = dataID + FLAG;

    static final String FLAG = " = ?";

    /**
     * 查找依据约束
     *
     * @param wifiHistBean
     * @param type         类型：
     *                     1：userID
     *                     2：userID+isUpdatePresent 是否上传
     *                     3：userID+url
     *                     4：dataID
     *                     5：userID+是否收藏
     *                     6：userID+isUpdatePresent 是否上传+是否收藏
     *                     6：userID+url+ 是否收藏
     * @return
     */
    private Object[] getSelection(WifiHistBean wifiHistBean, int type) {
        String selection = null;
        String[] selectionArgs = null;
        switch (type) {
            case 1:
                selection = USERID;
                selectionArgs = new String[]{wifiHistBean.getUserID()};
                break;
            case 2:
                selection = USERID + " and " + ISUPDATEPRESENT;
                selectionArgs = new String[]{wifiHistBean.getUserID(), (wifiHistBean.isUpdatePresent() ? 1 : 0) + ""};
                break;
            case 3:
                selection = USERID + " and " + URL;
                selectionArgs = new String[]{wifiHistBean.getUserID(), wifiHistBean.getUrl()};
                break;
            case 4:
                selection = DATAID;
                selectionArgs = new String[]{wifiHistBean.getDataId()};
                break;
            case 5:
                selection = USERID + " and " + isCollection + FLAG;
                selectionArgs = new String[]{wifiHistBean.getDataId(), (wifiHistBean.isCollection() ? 1 : 0) + ""};
                break;
            case 6:
                selection = USERID + " and " + ISUPDATEPRESENT + " and " + isCollection + FLAG;
                selectionArgs = new String[]{wifiHistBean.getUserID(), (wifiHistBean.isUpdatePresent() ? 1 : 0) + "", (wifiHistBean.isCollection() ? 1 : 0) + ""};
                break;
            case 7:
                selection = USERID + " and " + URL + " and " + isCollection + FLAG;
                selectionArgs = new String[]{wifiHistBean.getUserID(), wifiHistBean.getUrl(), (wifiHistBean.isCollection() ? 1 : 0) + ""};
                break;
            default:
        }
        return new Object[]{selection, selectionArgs};
    }
}
