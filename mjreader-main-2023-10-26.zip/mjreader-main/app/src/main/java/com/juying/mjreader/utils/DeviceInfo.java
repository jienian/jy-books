package com.juying.mjreader.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;

import androidx.core.app.ActivityCompat;

public class DeviceInfo {
    private static DeviceInfo deviceInfo;
    private static Activity context;
    private static DisplayMetrics dm;

    /**
     * @param
     * @return
     */
    public static DeviceInfo getDeviceInfo(Activity application) {
        if (deviceInfo == null) {
            deviceInfo = new DeviceInfo();
            context = application;
            dm = new DisplayMetrics();
            context.getWindowManager().getDefaultDisplay().getMetrics(dm);
        }
        return deviceInfo;
    }










    public void iniWindow() {
        float density = dm.density; // 屏幕密度（像素比例：0.75/1.0/1.5/2.0）
        int ensityDPI = dm.densityDpi; // 屏幕密度（每寸像素：120/160/240/320）
        int screenWidthDip = dm.widthPixels; // 屏幕宽（dip，如：320dip）
        int screenHeightDip = dm.heightPixels; // 屏幕高（dip，如：533dip）
        int screenWidth = (int) (dm.widthPixels * density + 0.5f); // 屏幕宽（px，如：720px）
        int screenHeight = (int) (dm.heightPixels * density + 0.5f); // 屏幕高（px，如：1280px）
        LogUtil.i("iniWindow", "设备屏幕信息，密度比例=" + density + "；每寸密度=" + ensityDPI + "dpi;宽=" + screenWidthDip + "dpi；高=" + screenHeightDip + "dpi；宽=" + screenWidth + "px;高=" + screenHeight + "px");
    }

    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    /**
     * 获取屏幕高度 dpi
     */
    public double getWindowW() {
        return dm.widthPixels; // 屏幕宽（dip，如：320dip）
    }

    public double getWindowH() {
        return dm.heightPixels; // 屏幕高（dip，如：320dip）
    }

    public double getWindowWPX() {
        float density = dm.density; // 屏幕密度（像素比例：0.75/1.0/1.5/2.0）
        return dm.widthPixels * density + 0.5f; // 屏幕宽（px，如：720px）;
    }

    public double getWindowHPX() {
        float density = dm.density; // 屏幕密度（像素比例：0.75/1.0/1.5/2.0）
        return dm.heightPixels * density + 0.5f; // 屏幕高（px，如：1280px）; // 屏幕高（dip，如：320dip）
    }


    /**
     * 状态栏高
     *
     * @return
     */
    public double getStatusH() {
        float density = dm.density; // 屏幕密度（像素比例：0.75/1.0/1.5/2.0）
        context.getWindow().getDecorView().getWindowVisibleDisplayFrame(new Rect());

        return dm.heightPixels * density + 0.5f; // 屏幕高（px，如：1280px）; // 屏幕高（dip，如：320dip）

    }


    /**
     * 是否是平板
     * @return 是平板则返回true，反之返回false
     */
    public  boolean isPad() {
        boolean isPad = (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE;
        double x = Math.pow(dm.widthPixels / dm.xdpi, 2);
        double y = Math.pow(dm.heightPixels / dm.ydpi, 2);
        double screenInches = Math.sqrt(x + y); // 屏幕尺寸

        return isPad || screenInches >= 7.0;
    }


    /**
     * 获得当前设备ID
     * @param context
     * @return
     */
    public static String getAndroidId(Context context) {
        @SuppressLint("HardwareIds") String androidId = Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
        return androidId;
    }

    /**
     * 获取设备序列号 需要注意，有些设备上可能会获取不到序列号。
     * @return
     */
    public static String getSerialNumber() {
        String serialNumber = null;
        try {
            serialNumber = android.os.Build.class.getField("SERIAL").get(null).toString();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
        return serialNumber;
    }

    /**
     * IMIE获取设备唯一标识 即国际移动设备身份码，是全球唯一的标识码，主要用于识别手机设备
     * 需要注意，不是所有的设备都有IMIE。
     * @param context TODO 已验证 获取不到
     * @return
     */
    public static String getImei(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String imei = null;

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        imei = telephonyManager.getDeviceId();

        return imei;
    }



}
