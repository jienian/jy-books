package com.juying.mjreader.utils;

/**
 * @Author Ycc
 * @Date 17:22
 */
public interface EventBusMessage {
    int TYPE0 = 999;
    int TYPE1 = 998;
    int TYPE2 = 997;

}
