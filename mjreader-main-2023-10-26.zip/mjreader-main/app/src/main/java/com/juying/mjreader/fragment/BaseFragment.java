package com.juying.mjreader.fragment;

import androidx.fragment.app.Fragment;

import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.ToastUtils;


/**
 * @Author Ycc
 * @Date 14:55
 */
public class BaseFragment extends Fragment {
    protected String TAG = getClass().getSimpleName();

    public void to(String s, boolean isLog) {
        getActivity().runOnUiThread(() -> {
            ToastUtils.show(getContext(), s);
            if (isLog) {
                log(s);
            }
        });
    }

    protected void log(String s) {
        LogUtil.d(TAG, s);
    }

}
