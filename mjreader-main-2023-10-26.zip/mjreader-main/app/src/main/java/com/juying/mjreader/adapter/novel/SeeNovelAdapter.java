package com.juying.mjreader.adapter.novel;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeNovelActivity;
import com.juying.mjreader.bean.NovelSeeSumBean;

import java.util.ArrayList;

public class SeeNovelAdapter extends RecyclerView.Adapter<SeeNovelAdapter.ViewHolder> {

    private SeeNovelActivity context;
    private NovelSeeSumBean novelSeeSumBean;
    private ViewHolder viewHolder;
    private ArrayList<Integer> showPosition;

    ViewGroup.LayoutParams layoutParams1 = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    ViewGroup.LayoutParams layoutParams2 = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    public SeeNovelAdapter(SeeNovelActivity context, NovelSeeSumBean novelSeeSumBean){
        this.novelSeeSumBean = novelSeeSumBean;
        this.context = context;
    }
    @NonNull
    @Override
    public SeeNovelAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_novel_page, null, false);
/*
        int type = context.novelSettingBean
*/
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull SeeNovelAdapter.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }




    }
