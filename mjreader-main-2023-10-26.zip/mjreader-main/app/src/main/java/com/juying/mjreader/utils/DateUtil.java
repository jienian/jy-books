package com.juying.mjreader.utils;

import android.annotation.SuppressLint;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @Author Ycc
 * @Date 19:41
 */
public class DateUtil {

    /**
     * 时间戳转年月日
     *
     * @param time
     * @return
     */
    @SuppressLint("SimpleDateFormat")
    public static String timeToDate(long time) {
        return new SimpleDateFormat("yyyy年MM月dd日").format(new Date(time));
    }

    /**
     * 时间戳星期几
     *
     * @param time
     * @return
     */
    public static int timeToWeek(long time) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(time));
        int week = calendar.get(Calendar.DAY_OF_WEEK);
        //阿拉伯数字，根据需要看要不要转成中文大小
        return week;
    }


    /**
     * 数字转汉字
     * @return
     */
    public static String numberToChinese(int number) {
        String chineser = "";
        //阿拉伯数字，根据需要看要不要转成中文大小
        switch (number) {
            case 0:
                chineser = "零";
                break;
            case 1:
                chineser = "一";
                break;
            case 2:
                chineser = "二";
                break;
            case 3:
                chineser = "三";
                break;
            case 4:
                chineser = "四";
                break;
            case 5:
                chineser = "五";
                break;
            case 6:
                chineser = "六";
                break;
            case 7:
                chineser = "七";
                break;
            case 8:
                chineser = "八";
                break;
            case 9:
                chineser = "九";
                break;
            default:
        }
        return chineser;
    }
}
