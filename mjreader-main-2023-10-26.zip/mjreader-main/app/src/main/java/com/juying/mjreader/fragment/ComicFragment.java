package com.juying.mjreader.fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.juying.mjreader.MainActivity;
import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeComicActivity;
import com.juying.mjreader.adapter.BookShelfAdapter;
import com.juying.mjreader.bean.BookBean;
import com.juying.mjreader.bean.ComicBean;
import com.juying.mjreader.bean.ComicSeeBean;
import com.juying.mjreader.bean.ComicSeeSumBean;
import com.juying.mjreader.bean.ComicSettingBean;
import com.juying.mjreader.databinding.FragmentComicBinding;
import com.juying.mjreader.net.NetUtils;
import com.juying.mjreader.utils.ComicMode;
import com.juying.mjreader.utils.DialogUtils;
import com.juying.mjreader.utils.FilesUtils;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.view.DialogAdd;
import com.juying.mjreader.view.DialogBookInput;
import com.juying.mjreader.view.DialogGrouping;
import com.juying.mjreader.view.DialogGroupingEdit;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * @Author Ycc
 */
public class ComicFragment extends BaseFragment implements EasyPermissions.PermissionCallbacks {


    private FragmentComicBinding vBinding;
    private ActivityResultLauncher<Uri> result1;
    private ActivityResultLauncher<String[]> result2;
    // 线程池
    private ThreadPoolExecutor importBookExecutor;
    private ComicBean comicBean;
    private Handler myHandler;
    private BookShelfAdapter bookShelfAdapter;
    private DialogAdd dialog;
    private DialogGroupingEdit dialogGroupingEdit;
    private BookBean currentShowBean;

    private DialogGrouping dialogGrouping;
    private LinearLayoutManager layoutManager;
    private GridLayoutManager gridManager;
    private MainActivity mainActivity;
    /**
     * 当前显示类型
     */
    private int currentType;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity = (MainActivity) getActivity();
        //目录
        result1 = registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), result ->
                handleUri(getContext(), result, true, true, myHandler, 1)
        );
        //单文件       // new ActivityResultContracts.OpenMultipleDocuments() 多文件
        result2 = registerForActivityResult(new ActivityResultContracts.OpenDocument(), result ->
                handleUri(getContext(), result, true, false, myHandler, 1));
        initBean(Constant.BOOK_DIRECTORY, 1);
        //注册广播
        getContext().registerReceiver(mBatteryBroadcast, new IntentFilter("download_image_complete"));
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        vBinding = FragmentComicBinding.inflate(inflater, null, false);
        initListener();
        myHandler = new Handler(Looper.myLooper(), msg -> {
            switch (msg.what) {
                //导入进度
                case 1:
                    if (msg.obj != null) {
                        BookBean bookBean = (BookBean) msg.obj;
                        List<BookBean> bookBeanList = comicBean.getComicBookBean().getBookBeanList();
//                        if (fatherName.equals(Constant.ROOT_NAME)) {
                        //处理根目录的导入UI，子目录需要在 Adapter里点击更新
                        if (bookBeanList == null) {
                            bookBeanList = new ArrayList<>();
                            comicBean.getComicBookBean().setBookBeanList(bookBeanList);
                        }
                        if (bookBeanList.size() == 0) {
                            //没有数据，直接存根目录
                            bookBeanList.add(bookBean);
                            setVisibilityView(2);
                            upRV();

                        } else {
                            //有数据，判断是应该add还是set
                            int position = -1;
                            for (int i = 0; i < bookBeanList.size(); i++) {
                                if (bookBean.getFileName().equals(bookBeanList.get(i).getFileName())) {
                                    position = i;
                                    break;
                                }
                            }
                            if (position == -1) {
                                bookBeanList.add(0, bookBean);
//                                bookShelfAdapter.notifyItemInserted(0);
                                bookShelfAdapter.notifyDataSetChanged();//这里虽然加了1个数据，但是不能用notifyItemInserted  不然其他位置的点击事件就会错乱，因为其他位置没有更新数据
                            } else {
                                bookBeanList.set(position, bookBean);
                                bookShelfAdapter.notifyItemChanged(position);
                            }
                        }
                        currentShowBean = comicBean.getComicBookBean();
//                        } else {
//                            //子目录数据的更新
//                            for (int i = 0; i < bookBeanList.size(); i++) {
//                                if (bookBean.getFatherName().equals(bookBeanList.get(i).getFileName())) {
//                                    ..
//                                }
//                            }
//                        }

                        //更新position的UI

                    }
                    break;
                default:
            }
            return false;
        });
        initUI();
        return vBinding.getRoot();
    }


    private void initBean(String filePath, int flag) {
        BookBean bookBean = new BookBean();
        bookBean.setFilePath(filePath);
        comicBean = new ComicBean(bookBean, new ComicSettingBean());
        File file = new File(filePath);
        if (!file.exists()) {
            return;
        }
        File[] files = file.listFiles();
        if (files == null || files.length == 0) {
            //根目录为空
            return;
        }
        List<BookBean> listBean = new ArrayList<>();
        for (File childFile : files) {
//            查总大小
//            查上次读的进度
//            查文件类型
//            查原uri,做断点续传
            String fileType = "";
            ArrayList<BookBean> beanList = new ArrayList<>();
            long imputSize;
            if (!childFile.isDirectory()) {
                imputSize = childFile.length();
//                fileType = FilesUtils.getStringLast(childFile.getName());
                fileType = FilesUtils.getFileTypeFromURLConnection(childFile);
            } else {
                imputSize = 0;//这里用0而不要childFile.length,因为目录无论多少文件 获取的大小都是3488，就会造成输入size大于总size
                if (childFile.listFiles() != null && childFile.listFiles().length > 0) {
                    for (File f : childFile.listFiles()) {
                        BookBean childBookBean = new BookBean();
                        childBookBean.setDirectory(f.isDirectory());
//                        childBookBean.setFileType(FilesUtils.getStringLast(f.getName()));
                        childBookBean.setFileType(FilesUtils.getFileTypeFromURLConnection(f));
                        childBookBean.setFilePath(f.getAbsolutePath());
//                        childBookBean.setFileName(f.getName());
                        childBookBean.setImputSchedule(f.length());
//                        childBookBean.setFatherName(f.getParentFile().getName());
//                        childBookBean.setSpFileName(ComicMode.filePathToSpName(f.getAbsolutePath(), f.isDirectory()));
                        childBookBean.setSpFilePath(ComicMode.fileNameToSpPath(getContext(), f.getParentFile().getName() + ComicMode.FLAG + f.getName()));
                        childBookBean.setLastModified(f.lastModified());
                        ComicMode.takeSP(getContext(), childBookBean);
                        imputSize += f.length();
                        beanList.add(childBookBean);
                    }
                }
            }
            BookBean childBean = new BookBean(childFile.getAbsolutePath(), childFile.getName(), Constant.ROOT_NAME, childFile.isDirectory(), imputSize, 0, 0, fileType, beanList);
            childBean.setLastModified(childFile.lastModified());
            ComicMode.takeSP(getContext(), childBean);
            if (flag == 2) {
                childBean.setEdit(true);
            }
            listBean.add(childBean);
        }
        comicBean.getComicBookBean().setBookBeanList(listBean);
        dataSort();//按时间倒序排一下
        currentShowBean = comicBean.getComicBookBean();
    }


    private void setVisibilityView(int type) {
        if (type == 1) {
            vBinding.rvBookshelf.setVisibility(View.GONE);
            vBinding.llNoContent.setVisibility(View.VISIBLE);
        } else if (type == 2) {
            vBinding.rvBookshelf.setVisibility(View.VISIBLE);
            vBinding.llNoContent.setVisibility(View.GONE);
        }
    }

    private void initUI() {
        setRecyclerView();
        vBinding.cb1.setChecked(comicBean.getComicSettingBean().getComicSettingMode());
        if (isDataNull()) {
            setVisibilityView(1);
        } else {
            setVisibilityView(2);
        }
    }


    @SuppressLint("NotifyDataSetChanged")
    private void setRecyclerView() {
        boolean mode = comicBean.getComicSettingBean().getComicSettingMode();
        bookShelfAdapter = new BookShelfAdapter(this, comicBean.getComicBookBean().getBookBeanList(), mode);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
//        ((SimpleItemAnimator) rv1.getItemAnimator()).setSupportsChangeAnimations(false);//禁止动画
        RecyclerView.ItemAnimator animator = vBinding.rvBookshelf.getItemAnimator();
        assert animator != null;
        animator.setChangeDuration(0);
        if (animator instanceof SimpleItemAnimator) {
            ((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);//禁止动画
        }
//        rv1.setHasFixedSize(true);//itme大小固定时，提到性能
//        rv1.setItemViewCacheSize(20);//
//        rv1.setPreserveFocusAfterLayout(true);//在布局变化后是否保持焦点
//        pageAdapter.setHasStableIds(true);//提高缓存的复用率,重新Adapter getitemid
        vBinding.rvBookshelf.setLayoutManager(mode ? getGridLayoutManager() : getLinearLayoutManager());
        bookShelfAdapter.upSettingMode(mode);

//        linearSnapHelper = new LinearSnapHelper();//用作横向滑动时，不保持偏移量，可多页滑动连续滑动
//        PagerSnapHelper linearSnapHelper1 = new PagerSnapHelper();//用作横向滑动时，不保持偏移量，只能一页一页滑动
        vBinding.rvBookshelf.setAdapter(bookShelfAdapter);
        upRV();
    }

    private LinearLayoutManager getLinearLayoutManager() {
        if (layoutManager == null) {
            layoutManager = new LinearLayoutManager(getContext());
        }
        return layoutManager;
    }

    private GridLayoutManager getGridLayoutManager() {
        if (gridManager == null) {
            gridManager = new GridLayoutManager(getContext(), 3);
        }
        return gridManager;
    }


    private void initListener() {
        vBinding.actionDirectory.setOnClickListener(v -> {
            getPermission(1);
//            exeImpurt(1);
            vBinding.actionsMenu.collapse();
        });
        vBinding.actionPdf.setOnClickListener(v -> {
            getPermission(2);
//            exeImpurt(2);
            vBinding.actionsMenu.collapse();
        });
        vBinding.actionWifi.setOnClickListener(v -> {
            getPermission(3);
//            exeImpurt(3);
            vBinding.actionsMenu.collapse();
        });

        vBinding.famMenu.setOnFloatingActionsMenuUpdateListener(new FloatingActionsMenu.OnFloatingActionsMenuUpdateListener() {
            DialogBookInput dialogBookInput = new DialogBookInput(ComicFragment.this, null);

            @Override
            public void onMenuExpanded() {
                showView(dialogBookInput);
            }

            @Override
            public void onMenuCollapsed() {
                showView(dialogBookInput);
            }

            private void showView(DialogBookInput dialogBookInput) {
                if (dialogBookInput.isShowing()) {
                    dialogBookInput.dismiss();
                } else {
                    dialogBookInput.show();
                }
            }
        });


        vBinding.cb1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            buttonView.setText(isChecked ? "列表排列" : "宫格排列");
            comicBean.getComicSettingBean().setComicSettingMode(isChecked);
            comicBean.getComicSettingBean().upSP();
            vBinding.rvBookshelf.setLayoutManager(isChecked ? getGridLayoutManager() : getLinearLayoutManager());
            bookShelfAdapter.upSettingMode(isChecked);
        });

        vBinding.cb2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isDataNull()) {
                startBookEditMode();
            } else {
                Toast.makeText(getContext(), "暂无数据可编辑", Toast.LENGTH_SHORT).show();
            }
        });
        vBinding.butHunt.setOnClickListener(v -> {
            String query = vBinding.searchView.getQuery().toString();
            if (!TextUtils.isEmpty(query)) {
                ComicMode.huntBean(currentShowBean, query);
                upRV();
            }
        });


        vBinding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (!TextUtils.isEmpty(query)) {
                    ComicMode.huntBean(currentShowBean, query);
                    upRV();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText)) {
//                    to("恢复搜索前原貌", false);
                    ComicMode.huntBean(currentShowBean, newText);
                    upRV();
                }
                return false;
            }
        });
        vBinding.tvOff.setOnClickListener(v -> {
            jump();
        });
        vBinding.cbAll.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (currentShowBean != null && currentShowBean.getBookBeanList().size() > 0) {
                if (isChecked) {
                    vBinding.cbAll.setText("全不选");
                } else {
                    vBinding.cbAll.setText("全选");
                }
                allChecked(isChecked);
                upRV();
            }
        });
        vBinding.ivBack.setOnClickListener(v -> {
            jumpStatusSet();
        });
        vBinding.ivEdit.setOnClickListener(v -> {
            if (dialogGroupingEdit == null) {
                dialogGroupingEdit = new DialogGroupingEdit(getContext(), R.style.DialogTheme, new DialogGroupingEdit.DialogGroupingEditListener() {
                    @Override
                    public void onClickDel() {
                        DialogUtils.delDialog(getContext(), "解散分组", "您确定解散此分组吗？", isOk -> {
                            if (isOk) {
                                //删除物理数据，文件和sp
                                ComicMode.delSPandFile(currentShowBean, true);
                                //重新读取内存数据
                                initBean(Constant.BOOK_DIRECTORY, 1);
                                //更新UI
                                bookShelfAdapter.setData(comicBean.getComicBookBean().getBookBeanList());
                                upRV();
                                defaultBookMode();
                                //删的一个不剩的处理
                                if (isDataNull()) {
                                    vBinding.llNoContent.setVisibility(View.VISIBLE);
                                }
                            }
                        });
                    }

                    @Override
                    public void onClickEdit() {
                        //编辑某本书
                        allEdit(true);
                        upRV();
//                        viewSwitch();
                        topStatusSet(4);
                        //建一个临时bean作为移动至书架的选项
                        List<BookBean> list = comicBean.getComicBookBean().getBookBeanList();
                        if (list.size() == 0 || !list.get(0).getFileName().equals(Constant.ROOT_NAME)) {
                            BookBean zeroHourBean = new BookBean();
                            zeroHourBean.setFilePath(Constant.BOOK_DIRECTORY);
                            zeroHourBean.setDirectory(true);
                            comicBean.getComicBookBean().getBookBeanList().add(0, zeroHourBean);
                        }
                        toDialog();
                    }

                    @Override
                    public void onClickChangeName() {
                        DialogUtils.windowDialogView(getContext(), R.layout.dialog_new_group, "重命名分组", "请输入新名称", new DialogUtils.WindowDialogListener() {
                            @Override
                            public void onOk(String name) {
                                if (name.equals(currentShowBean.getFileName())) {
                                    to("名字相同", false);
                                    return;
                                }
                                ComicMode.renameFileAndSP(currentShowBean, name);
                                upTvTop(name);
//                                只改了目录，没改子文件
                            }
                        });
                    }
                });
            }
            dialogGroupingEdit.show();
        });
    }

    /**
     * 删除临时bean
     */
    private void delBean() {
        if (!isDataNull() && comicBean.getComicBookBean().getBookBeanList().get(0).getFileName().equals(Constant.ROOT_NAME)) {
            comicBean.getComicBookBean().getBookBeanList().remove(0);
        }
    }

    private void toDialog() {
        if (dialog == null) {
            dialog = new DialogAdd(getContext(), R.style.DialogTheme, new DialogAdd.DialogAddListener() {
                @Override
                public void onClickMove() {
                    if (checkedNum(currentShowBean.getBookBeanList()) == 0) {
                        to("未选择文件", false);
                        return;
                    }

                    log("新建DialogGrouping的数据组：" + comicBean.getComicBookBean().getFileName());
                    dialogGrouping = new DialogGrouping(ComicFragment.this, R.style.DialogTheme, comicBean.getComicBookBean(), new DialogGrouping.DialogGroupingListener() {
                        @Override
                        public void onClickGroupingOK() {
                            dialogGrouping.dismiss();
                            initBean(Constant.BOOK_DIRECTORY, 1);
                            bookShelfAdapter.setData(currentShowBean.getBookBeanList());
                            vBinding.cbAll.setChecked(false);
                            //回到默认模式
                            defaultBookMode();

                            //如果上面cb本来就是未选中状态，那么就不会触发，所以下面还是要更新一次
//                            upRV();
//                            upCheckedNum();
                        }

                        @Override
                        public void onClickAdd() {
                            //弹出增添Dialog
                            DialogUtils.windowDialogView(getContext(), R.layout.dialog_new_group, "新建分组", "请输入新分组名称", name -> {

                                if (FilesUtils.isExistFile(new File(Constant.BOOK_DIRECTORY), name)) {
                                    to("分组名已存在", false);
                                    return;
                                }
                                //先组装内存数据
                                BookBean bean = new BookBean();
                                bean.setDirectory(true);
//                                bean.setFatherName(Constant.ROOT_NAME);
//                                bean.setFileName(name);
                                bean.setEdit(true);
                                bean.setFilePath(Constant.BOOK_DIRECTORY + "/" + name);
                                bean.setLastModified(System.currentTimeMillis());
                                List<BookBean> listBean = comicBean.getComicBookBean().getBookBeanList();
                                int upPosition = -1;
                                if (listBean.size() > 0 && listBean.get(0).getFileName().equals(Constant.ROOT_NAME)) {
                                    upPosition = 1;
                                } else {
                                    upPosition = 0;
                                    bookShelfAdapter.notifyItemInserted(0);
                                }
                                //再物理存
                                ComicMode.saveFile(bean);
                                ComicMode.saveSP(getContext(), bean);

                                listBean.add(upPosition, bean);
                                //更新dialog的rv
                                dialogGrouping.addUPRV(upPosition);
                            });
                        }

                    });

                    dialogGrouping.show();
                }

                @Override
                public void onClickDel() {
                    int num = checkedNum(currentShowBean.getBookBeanList());
                    if (num == 0) {
                        to("未选择删除项", false);
                        return;
                    }
                    DialogUtils.delDialog(getContext(), "删除", "您确定要删除所选 " + num + " 项内容吗？", isOk -> {
                        if (isOk) {
                            //删除物理数据，文件和spl标记
                            boolean isSuccess = ComicMode.delSPandFile(currentShowBean, false);
                            if (!isSuccess) {
                                to("删除不成功", false);
                                return;
                            }
                            //删除内存
                            ComicMode.delMemory(currentShowBean);

                            if (currentShowBean.getFileName().equals(Constant.ROOT_NAME)) {
                                //根目录浏览下
                                if (currentShowBean.getBookBeanList().size() > 0) {
                                    upCheckedNum();
                                } else {
                                    //删完了
                                    defaultBookMode();
                                    vBinding.llNoContent.setVisibility(View.VISIBLE);
                                }
                            } else {
                                //分组浏览下
                                ComicMode.saveSP(getContext(), currentShowBean);
                                upCheckedNum();
                            }
                            upRV();


                        }
                    });
                }
            });
            dialog.setOnKeyListener((dialog, keyCode, event) -> {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
                    jump();
                    //拦截返回键
                    return true;
                } else {
                    return false;
                }
            });

        }

        dialog.show();
    }

    private void jump() {
        if (currentType == 4) {
            //删掉临时bean
            delBean();
            startGroupingEditMode(currentShowBean);
        } else {
            defaultBookMode();
        }
    }

    /**
     * 开启书架编辑模式
     */
    private void startBookEditMode() {
        topStatusSet(2);
        allEdit(true);
//        editingStatus(true);
        toDialog();

        upRV();

    }

    /**
     * 开启分组浏览模式
     */
    private void startGroupingEditMode(BookBean bookBean) {
        topStatusSet(3);
        vBinding.tvTop.setText(bookBean.getFileName());
        currentShowBean = bookBean;
        allEdit(false);
        bookShelfAdapter.setData(bookBean.getBookBeanList());
        upRV();
        if (dialog != null) {
            dialog.dismiss();
        }


//        editingStatus(true);
    }

    /**
     * 开启默认书架模式
     */
    private void defaultBookMode() {
        topStatusSet(1);
        allEdit(false);
//        editingStatus(false);
        upRV();
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    /**
     * 选中数量
     *
     * @param bookBeanList
     * @return
     */
    public int checkedNum(List<BookBean> bookBeanList) {
        int num = 0;
        for (BookBean bean : bookBeanList) {
            if (bean.isChecked()) {
                num++;
            }
        }
        return num;
    }

    /**
     * 顶部UI控制， 一共4种类型
     */
    private void topStatusSet(int type) {
        currentType = type;
        switch (type) {
            case 1:
                viewSwitch(type);
                mainActivity.navigationSwith(false);
                break;
            case 2:
                viewSwitch(type);
                vBinding.tvTop.setText("编辑书架");
                vBinding.llSelect.setVisibility(View.VISIBLE);
                vBinding.tvNum.setText(0 + "");
                mainActivity.navigationSwith(false);
                break;
            case 3:
                viewSwitch(type);
                vBinding.tvTop.setText("未命名分组");
                vBinding.llSelect.setVisibility(View.GONE);
                vBinding.tvNum.setText(0 + "");
                mainActivity.navigationSwith(true);
                break;
            case 4:
                viewSwitch(type);
                vBinding.llSelect.setVisibility(View.VISIBLE);
                vBinding.tvNum.setText(0 + "");
                mainActivity.navigationSwith(false);
                break;
            default:
        }
    }

    private void viewSwitch(int type) {
        if (type == 1) {
            vBinding.rlTop1.setVisibility(View.GONE);
            vBinding.rlSearch.setVisibility(View.VISIBLE);
            vBinding.llEdit1.setVisibility(View.VISIBLE);
            vBinding.actionsMenu.setVisibility(View.VISIBLE);
            vBinding.famMenu.setVisibility(View.VISIBLE);
        } else {
            vBinding.rlTop1.setVisibility(View.VISIBLE);
            vBinding.rlSearch.setVisibility(View.GONE);
            vBinding.llEdit1.setVisibility(View.GONE);
            vBinding.actionsMenu.setVisibility(View.GONE);
            vBinding.famMenu.setVisibility(View.GONE);
            if (type == 2 || type == 4) {
                vBinding.ivBack.setVisibility(View.GONE);
                vBinding.cbAll.setVisibility(View.VISIBLE);
                vBinding.ivEdit.setVisibility(View.GONE);
                vBinding.tvOff.setVisibility(View.VISIBLE);
            } else if (type == 3) {
                vBinding.ivBack.setVisibility(View.VISIBLE);
                vBinding.cbAll.setVisibility(View.GONE);
                vBinding.ivEdit.setVisibility(View.VISIBLE);
                vBinding.tvOff.setVisibility(View.GONE);
            }
        }
    }

    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
    private void allEdit(boolean isEdit) {
//        if (dataDetermine()) {
//            List<BookBean> listBean = comicBean.getComicBookBean().getBookBeanList();
        if (currentShowBean != null && currentShowBean.getBookBeanList() != null) {
            for (int i = 0; i < currentShowBean.getBookBeanList().size(); i++) {
                currentShowBean.getBookBeanList().get(i).setEdit(isEdit);
                if (!isEdit) {
                    currentShowBean.getBookBeanList().get(i).setChecked(false);
                }
            }
            if (!isEdit) {
                vBinding.tvNum.setText(0 + "");
                vBinding.cbAll.setChecked(false);
            }
        }

//        }
    }


    @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
    private void allChecked(boolean isChecked) {
//        if (dataDetermine()) {
//            List<BookBean> listBean = bookBean.getBookBeanList();
        for (int i = 0; i < currentShowBean.getBookBeanList().size(); i++) {
            currentShowBean.getBookBeanList().get(i).setChecked(isChecked);
        }

        if (isChecked) {
            vBinding.tvNum.setText(currentShowBean.getBookBeanList().size() + "");
        } else {
            vBinding.tvNum.setText(0 + "");
        }
//        }
    }

    /**
     * 处理Uri逻辑
     *
     * @param context
     * @param uri
     * @param isFirst     是否首次导入
     * @param isDirectory 是否是目录
     * @param handler
     * @param code        handler返回码
     */
    private void handleUri(Context context, Uri uri, boolean isFirst, boolean isDirectory, Handler handler, int code) {
        getThreadPoolExecutor().execute(() -> {
            try {
                if (uri == null) {
//                    to("无法获取文件", true);
                    return;
                }
                //如果是目录这里获取不到大小
                long uriSize = FilesUtils.getUriSize(context, uri);
                //TODO 由于Android版本差异，如果是目录，这里获取的一定是真实目录名称；但如果是文件，这里获取的name有可能是真名称也可能只是资源编号，所以在下方还需要再查一次
                String originFileName = new File(uri.getPath()).getName();

                if (!isDirectory) {
                    //如果是文件的话（目录不能用Cursor查），这里再通过cursor查一遍真实文件名和大小【这里是为了适配那种uri.getPath返回资源编号而不是真正文件名的Android版本】
                    Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
                    if (cursor != null) {
                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                        cursor.moveToFirst();
                        //文件名
                        originFileName = cursor.getString(nameIndex);
                        uriSize = cursor.getLong(sizeIndex);
                        cursor.close();
                    }
                }
                //如果是目录，这个类型就是null
                ContentResolver resolver = getContext().getContentResolver();
                String inputType = resolver.getType(uri);
                log("即将导入的Uri路径:" + uri.getPath() + ";Uri文件/目录名称：" + originFileName + ";大小：" + uriSize + ";类型：" + inputType);
                if (!FilesUtils.isSizeSufficient(uriSize)) {
                    //剩余空间，小于当前文件大小+阈值
                    to("设备内存不足", true);
                    return;
                }
                //允许导入空目录，但不许导入空文件
                if (uriSize == 0 && !isDirectory) {
                    to("空文件不支持导入", true);
                    return;
                }
                File directoryFile = new File(Constant.BOOK_DIRECTORY);
                if (!directoryFile.exists()) {
                    directoryFile.mkdirs();
                }
                if (FilesUtils.isExistFile(directoryFile, originFileName) && isFirst) {
                    to("同名文件已存在", true);
                    return;
                }
//        ComicMode.writeUri(getThreadPoolExecutor(), context, imputFatherBookBean, uri, new File(newFilePath), selectFileType, handler, code);

                BookBean imputFatherBookBean = new BookBean();
                imputFatherBookBean.setDirectory(isDirectory);
                String newFilePath = Constant.BOOK_DIRECTORY + "/" + originFileName;
                imputFatherBookBean.setFilePath(newFilePath);
                imputFatherBookBean.setFileType(inputType);
                imputFatherBookBean.setOriginUriPath(uri.toString());
                //如果是目录，这里的Size是0,需要在后面的步骤获取
                imputFatherBookBean.setMaxSize(uriSize);
                log("准备读取文件：" + uri.toString() + "；写入文件=" + newFilePath);
                File newFile = new File(newFilePath);
                if (isDirectory) {
                    //为目录的话直接新建，空的也行
                    if (!newFile.exists()) {
                        newFile.mkdirs();
                    }
                    imputFatherBookBean.setLastModified(System.currentTimeMillis());
                    imputFatherBookBean.setBookBeanList(new ArrayList<>());
                    /**sp存储根目录【每个文件都对应一个sp,为了UI初始化查询】
                     *创建了目录，通知更新一遍UI
                     *存目录sp,在这存是因为，这里才设置目录最大值
                     * 此时只是创建了空目录，先存一遍sp 同时更新UI
                     */
                    ComicMode.saveSP(context, imputFatherBookBean, true);
                    ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                    // 使用DocumentFile.fromTreeUri获取指定目录下的文件
                    DocumentFile documentFile = DocumentFile.fromTreeUri(context, uri);
                    if (documentFile == null) {
                        log("目录为空，导入终止");
                        return;
                    }
                    // 获取文件列表
                    DocumentFile[] listFiles = documentFile.listFiles();
                    if (listFiles.length == 0) {
                        log("目录为空，导入终止");
                        return;
                    }
                    //TODO 导子目录
                    imputFatherBookBean.setImputProcess(true);
                    //目录无法在前面流程获得真实大小，所以在这里获取
                    List<DocumentFile> supportFiltList = new ArrayList<>();
                    for (DocumentFile docFile : listFiles) {
                        support:
                        for (String supportType : Constant.SUPPORT_TYPE) {
                            if (!TextUtils.isEmpty(docFile.getType()) && docFile.getType().equals(supportType) && docFile.length() > 0) {
                                //是文件，且不是空文件，且是支持类型
                                uriSize += docFile.length();
                                supportFiltList.add(docFile);
                                break support;
                            }
                        }
                    }
                    imputFatherBookBean.setMaxSize(uriSize);
                    //更新了目录总大小，存一遍sp 同时更新UI
                    ComicMode.saveSP(context, imputFatherBookBean, true);
                    ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);

                    if (supportFiltList.size() == 0) {
                        to("该目录没有支持的文件", true);
                        imputFatherBookBean.setImputProcess(false);
                        ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                        return;
                    }
                    //导入支持文件
                    for (DocumentFile supportFile : supportFiltList) {
                        BookBean imputChildBookBean = new BookBean();
                        imputChildBookBean.setFileType(supportFile.getType());
                        imputChildBookBean.setMaxSize(supportFile.length());
                        imputChildBookBean.setDirectory(false);
                        //这里通过supportFile.getName()获取到的名称就是真实名称，不会像直接用uri那种获取的名称有可能是资源ID，所以这里不用担心适配问题
                        File childFile = new File(newFile.getAbsolutePath() + "/" + supportFile.getName());
                        imputChildBookBean.setOriginUriPath(supportFile.getUri().toString());
                        imputChildBookBean.setFilePath(childFile.getAbsolutePath());
//                        FilesUtils.uriWriteFile(context, childUri, childFile, imputFatherBookBean, imputChildBookBean, handler, code);
                        log("准备读取文件：" + supportFile.getUri().getPath() + "；写入文件=" + childFile.getAbsolutePath());
                        /**
                         *TODO 随着官方对Android版本不断完善，获取别人文件的真实Path会越来越难甚至后面会直接禁止获取
                         *      所以这里，就不走直接操作File的方案，用复制Uri流的方式，不去获取别人的Path,也能到达同样效果，并且一劳永逸解决适配问题
                         *            FileInputStream inputStream = new FileInputStream(uri.getPath());
                         *            long fileSize = inputStream.getChannel().size();
                         */
                        InputStream inputStream = resolver.openInputStream(supportFile.getUri());
                        if (!childFile.exists()) {
                            childFile.createNewFile();
                        }
                        FileOutputStream outputStream = new FileOutputStream(childFile);
                        imputFatherBookBean.getBookBeanList().add(imputChildBookBean);
                        ComicMode.saveSP(context, imputChildBookBean, true);
                        //本地文件一次可以多读点，32kb读
                        byte[] buffer = new byte[32 * 1024];
                        int read;
                        imputChildBookBean.setImputProcess(true);
                        while ((read = inputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, read);
                            imputChildBookBean.setImputSchedule(childFile.length());
                            imputFatherBookBean.setImputSchedule(imputFatherBookBean.getImputSchedule() + read);
                            imputChildBookBean.setLastModified(System.currentTimeMillis());
                            imputFatherBookBean.setLastModified(System.currentTimeMillis());
                            log(childFile.getName() + "总字节大小：" + supportFile.length() + "，导入进度：" + childFile.length());
                            ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                            if (Constant.INTERVAL_TIME > 0) {
                                Thread.sleep(Constant.INTERVAL_TIME);
                            }
                        }
                        imputChildBookBean.setImputProcess(false);
                        imputFatherBookBean.setImputProcess(false);
                        ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                        log("成功写入文件=" + childFile.getAbsolutePath() + ";线程:" + Thread.currentThread().getName());
                        outputStream.flush();
                        outputStream.close();
                        inputStream.close();
                    }
                    imputFatherBookBean.setImputProcess(false);
                    ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                } else {
//                    FilesUtils.writeStream(context, inputStream, inputStream.available(), new File(newFilePath), imputFatherBookBean, imputChildBookBean, handler, code);


                    InputStream inputStream = resolver.openInputStream(uri);
                    if (!newFile.exists()) {
                        newFile.createNewFile();
                    }
                    imputFatherBookBean.setLastModified(System.currentTimeMillis());
                    FileOutputStream outputStream = new FileOutputStream(newFile);
                    ComicMode.saveSP(context, imputFatherBookBean, true);
                    ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                    //本地文件一次可以多读点，32kb读
                    byte[] buffer = new byte[32 * 1024];
                    int read;
                    imputFatherBookBean.setImputProcess(true);
                    while ((read = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, read);
                        imputFatherBookBean.setLastModified(System.currentTimeMillis());
                        imputFatherBookBean.setImputSchedule(imputFatherBookBean.getImputSchedule() + read);
                        log(newFile.getName() + "总字节大小：" + imputFatherBookBean.getMaxSize() + "，导入进度：" + newFile.length());
                        ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                        if (Constant.INTERVAL_TIME > 0) {
                            Thread.sleep(Constant.INTERVAL_TIME);
                        }
                    }
                    imputFatherBookBean.setImputProcess(false);
                    ComicMode.sendAssembleMessage(handler, code, imputFatherBookBean);
                    log("成功写入文件=" + newFile.getAbsolutePath() + ";线程:" + Thread.currentThread().getName());
                    outputStream.flush();
                    outputStream.close();
                    inputStream.close();
                }
            } catch (Exception e) {
                to("导入失败", false);
                log("导入失败:" + e.getMessage());
            }
        });
    }


    public void exeImpurt(int type) {
        switch (type) {
            //目录
            case 1:
                result1.launch(null);
                break;
            //文件
            case 2:
                result2.launch(Constant.SUPPORT_TYPE);
                break;
            //网络
            case 3:
                //弹出增添Dialog
                DialogUtils.imputDialogView(getContext(), "链接导入", "请输入正确的文件网址", name -> {
                    wifiInput(name, 1, 0, 0);
                });
                break;
            default:
        }
    }

    public void wifiInput(String urlString, int clickType, long originMaxSize, long startIndex) {
        getThreadPoolExecutor().execute(() -> {
            try {
                if (!Patterns.WEB_URL.matcher(urlString).matches()) {
                    //正则表达式模式，以匹配 RFC 3987 国际化 URL
                    if (clickType == 1 || clickType == 3) {
                        to("网址不正确", false);
                    }
                    return;
                }
                if (clickType == 1 || clickType == 3) {
                    if (!NetUtils.isNetSystemUsable(getContext())) {
                        to("请检查网络", false);
                        return;
                    }
                }
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                //设置断点续传的开始位置
                connection.setRequestProperty("RANGE", "bytes=" + startIndex + "-");
                // 设置超时间为3秒
                connection.setConnectTimeout(3 * 1000);
                int code = connection.getResponseCode();
                log("网络返回code码：" + code);
                if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                    if (clickType == 1 || clickType == 3) {
                        to("访问错误", false);
                    }
                    return;
                }
                long contentLengthLong = connection.getContentLengthLong();
                long maxSize = originMaxSize;
                if (clickType == 1) {
                    maxSize = contentLengthLong;
                }
                log("即将下载模式：" + clickType + ";源文件总大小：" + maxSize + ";已下载:" + startIndex + ";本次需下载：" + (maxSize - startIndex));

                if (maxSize <= 0) {
                    if (clickType == 1) {
                        to("文件为空", false);
                    }
                    return;
                }
                if (!FilesUtils.isSizeSufficient(maxSize - startIndex)) {
                    to("设备空间不足", true);
                    return;
                }


                boolean isSupport = false;
                String contentType = connection.getContentType();
                log("即将导入文件类型：" + contentType);
                for (String fileType : Constant.SUPPORT_TYPE) {
                    if (fileType.equals(contentType)) {
                        isSupport = true;
                        break;
                    }
                }
                if (!isSupport) {
                    to("不支持该类型", true);
                    return;
                }

                File directoryFile = new File(Constant.BOOK_DIRECTORY);
                if (!directoryFile.exists()) {
                    directoryFile.mkdirs();
                }
                String fileName = FilesUtils.getUrlFileNameFromOrigin(connection);
                log("即将导入文件名称：" + fileName);
                if (clickType == 1) {
                    if (FilesUtils.isExistFile(directoryFile, fileName)) {
                        to("同名文件已存在", true);
                        return;
                    }
                }


                //组Bean
                BookBean imputBean = new BookBean();
                imputBean.setDirectory(false);
                imputBean.setOriginUriPath(urlString);
                imputBean.setFileName(fileName);
                imputBean.setFileType(contentType);
                imputBean.setMaxSize(maxSize);

                //建文件
                String newFilePath = Constant.BOOK_DIRECTORY + "/" + fileName;
                imputBean.setFilePath(newFilePath);
                File newFile = new File(newFilePath);
                if (!newFile.exists()) {
                    newFile.createNewFile();
                }
                imputBean.setImputSchedule(newFile.length());

                //存SP
//                String with = "";
//                if (fileName.contains(".")) {
//                    with = fileName.substring(0, fileName.lastIndexOf("."));
//                }
//                String spName = imputBean.getFatherName() + ComicMode.FLAG + with;
//                if (clickType == 1) {
//                    SharedPreferences.Editor editor = getContext().getSharedPreferences(spName, Context.MODE_PRIVATE).edit();
//                    editor.putLong("maxSize", imputBean.getMaxSize());
//                    editor.putString("originUriPath", imputBean.getOriginUriPath() == null ? "" : imputBean.getOriginUriPath());
//                    editor.putString("fileType", imputBean.getFileType() == null ? "" : imputBean.getFileType());
//                    editor.putInt("readPosition", imputBean.getReadPosition());
//                    editor.apply();
//                }
                if (clickType == 1) {
                    //第一次导入的时候才存
                    ComicMode.saveSP(getContext(), imputBean, true);
                } else {
                    //之后就单纯的初始化路径
                    imputBean.setSpFilePath(ComicMode.getSpFilePath(getContext(), imputBean.getFileName(), imputBean.getFatherName()));
                }
                InputStream inputStream = connection.getInputStream();
                //开始写文件
                FileOutputStream outputStream = new FileOutputStream(newFile, true);
                //32kb读
                byte[] buffer = new byte[32 * 1024];
                int read;
                while ((read = inputStream.read(buffer)) != -1) {
                    imputBean.setImputProcess(true);
                    outputStream.write(buffer, 0, read);
                    log(newFile.getName() + "总字节大小：" + maxSize + "，导入进度：" + newFile.length() + ";剩余：" + (maxSize - newFile.length()));
                    imputBean.setImputSchedule(imputBean.getImputSchedule() + read);
                    imputBean.setLastModified(System.currentTimeMillis());
                    //Message发送之后就无效了，所以需要每次新建
                    ComicMode.sendAssembleMessage(myHandler, 1, imputBean);
                    if (Constant.INTERVAL_TIME > 0) {
                        Thread.sleep(Constant.INTERVAL_TIME);
                    }
                }
                imputBean.setImputSchedule(maxSize);
                imputBean.setImputProcess(false);
                ComicMode.sendAssembleMessage(myHandler, 1, imputBean);
                //关流
                outputStream.flush();
                outputStream.close();
                inputStream.close();
            } catch (Exception e) {
//                                    throw new RuntimeException(e);
                to("导入失败", false);
                log("导入失败:" + e.getMessage());
            }
        });
    }

    private ThreadPoolExecutor getThreadPoolExecutor() {
        if (importBookExecutor == null) {
            /**
             *  1：核心线程数，线程池中始终存活的线程数。
             *
             * 2：最大线程数，线程池中允许的最大线程数，当线程池的任务队列满了之后可以创建的最大线程数。
             *
             * 3：最大线程数可以存活的时间，当线程中没有任务执行时，最大线程就会销毁一部分，最终保持核心线程数量的线程。
             *
             *  4：unit:单位是和参数 3 存活时间配合使用的，合在一起用于设定线程的存活时间 ，参数 keepAliveTime 的时间单位有以下 7 种可选：
             *
             * TimeUnit.DAYS：天
             * TimeUnit.HOURS：小时
             * TimeUnit.MINUTES：分
             * TimeUnit.SECONDS：秒
             * TimeUnit.MILLISECONDS：毫秒
             * TimeUnit.MICROSECONDS：微妙
             * TimeUnit.NANOSECONDS：纳秒
             * 参数 5：workQueue
             * 一个阻塞队列，用来存储线程池等待执行的任务，均为线程安全，它包含以下 7 种类型：
             *
             * ArrayBlockingQueue：一个由数组结构组成的有界阻塞队列。
             * LinkedBlockingQueue：一个由链表结构组成的有界阻塞队列。
             * SynchronousQueue：一个不存储元素的阻塞队列，即直接提交给线程不保持它们。
             * PriorityBlockingQueue：一个支持优先级排序的无界阻塞队列。
             * DelayQueue：一个使用优先级队列实现的无界阻塞队列，只有在延迟期满时才能从中提取元素。
             * LinkedTransferQueue：一个由链表结构组成的无界阻塞队列。与SynchronousQueue类似，还含有非阻塞方法。
             * LinkedBlockingDeque：一个由链表结构组成的双向阻塞队列。
             * 较常用的是 LinkedBlockingQueue 和 Synchronous，线程池的排队策略与 BlockingQueue 有关。
             *
             * 参数 6：threadFactory
             * 线程工厂，主要用来创建线程，默认为正常优先级、非守护线程。
             *
             * 参数 7：handler
             * 拒绝策略，拒绝处理任务时的策略，系统提供了 4 种可选：
             *
             * AbortPolicy：拒绝并抛出异常。
             * CallerRunsPolicy：使用当前调用的线程来执行此任务。
             * DiscardOldestPolicy：抛弃队列头部（最旧）的一个任务，并执行当前任务。
             * DiscardPolicy：忽略并抛弃当前任务。
             * 默认策略为 AbortPolicy。
             */
            importBookExecutor = new ThreadPoolExecutor(3, 10, 100, TimeUnit.SECONDS, new LinkedBlockingQueue<>(10), r -> {
                Thread thread = new Thread(r);
                //thread.setName("樱桃老丸子"+r.hashCode());
                thread.setPriority(Thread.MAX_PRIORITY);
                return thread;
            });
        }
        return importBookExecutor;
    }

    public void getPermission(int type) {
        String[] perms = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
//        String[] perms = {Manifest.permission.SYSTEM_ALERT_WINDOW};

        if (EasyPermissions.hasPermissions(getContext(), perms)) {
            // 已获取权限
            log("已存在权限");
            exeImpurt(type);
        } else {
            // 没有权限，现在去获取
            log("没有权限，去获取");
            EasyPermissions.requestPermissions(this, "申请内存权限", type, perms);
        }
    }


    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        // 一些权限被授予
        log("权限被允许");
        exeImpurt(requestCode);
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        // 一些权限被禁止
        to("未授予本应用权限", true);
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            //点了拒绝且不再提醒
            log("权限没有被允许，且点了永不提醒");
            new AppSettingsDialog.Builder(this).build().show();
            //弹出个对话框 可以自定义
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // 将返回结果转给EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }


    /**
     * 用户点击某个Book
     */
    public void clickBook(List<BookBean> bookBeanList, int position) {
        try {
            BookBean bookBean = bookBeanList.get(position);


            if (bookBean.isImputProcess()) {
                to("导入中，请稍后", true);
                return;
            }

            //如果是目录，先让进去
            if (bookBean.isDirectory()) {
                startGroupingEditMode(bookBean);
                return;
            }


            if (bookBean.getMaxSize() > bookBean.getImputSchedule()) {
                //还没传完
                String originPath = bookBean.getOriginUriPath();
                if (TextUtils.isEmpty(originPath)) {
                    log("没有源地址，无法断点续传");
                    return;
                }
                if (originPath.startsWith("http://") || originPath.startsWith("https://")) {
                    //网络文件,断点续传
                    if (!bookBean.isImputProcess()) {
                        wifiInput(originPath, 3, bookBean.getMaxSize(), bookBean.getImputSchedule());
                    }
                } else {
                    //本地 TODO 这里本地的重传先不做，Uri暂时无法还原
//                    Uri uri;
//                uri= Uri.fromFile(new File(originPath));
//                uri=FileProvider.getUriForFile(getContext(),new File(originPath));
//                    File imagePath = new File("/document/primary", "Download/"+bookBean.getFileName());
//                    uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", imagePath);
//                    Uri.Builder builder = new Uri.Builder();
//                    String xxxxx = bui.toString();
//                    builder.build();
//                  uri = Uri.parse(originPath);
//                    if (uri != null) {
//                        handleUri(getContext(), uri, false, bookBean.isDirectory(), myHandler, 1);
//                    } else {
//                        log("本地uri无法还原");
//                    }
                    to("已损坏，请删除后重新导入", true);
                }
            } else {
                if (bookBean.isDirectory()) {
                    startGroupingEditMode(bookBean);
                } else {
                    Intent intent = new Intent(getActivity(), SeeComicActivity.class);
                    currentShowBean.setShowPosition(position);
                    ComicSeeSumBean comicSeeSumBean;
                    ArrayList<ComicSeeBean> list = new ArrayList<>();
                    String fileType = bookBean.getFileType();
                    if (fileType.contains("pdf")) {
                        list.add(new ComicSeeBean(bookBean.getFilePath(), bookBean.getFileName(), fileType, true, bookBean.getReadPosition(), false));
                        comicSeeSumBean = new ComicSeeSumBean(0, true, list);
                    } else {
                        int comicSeePosition = 0;
                        int flag = 0;
                        for (int i = 0; i < currentShowBean.getBookBeanList().size(); i++) {
                            BookBean book = currentShowBean.getBookBeanList().get(i);
                            if (book.getMaxSize() > book.getImputSchedule() || book.isDirectory() || book.getFileType().contains("pdf")) {
                                //如果是未导入完成、目录、PDF就不传过去
                            } else {
                                if (position == i) {
                                    comicSeePosition = flag;
                                }
                                ComicSeeBean comicSeeBean = new ComicSeeBean(book.getFilePath(), book.getFileName(), book.getFileType(), position == i, bookBean.getReadPosition(), false);
                                list.add(comicSeeBean);
                                flag++;
                            }
                        }
                        comicSeeSumBean = new ComicSeeSumBean(comicSeePosition, false, list);
                    }
                    intent.putExtra("comicSeeSumBean", comicSeeSumBean);
                    intent.putExtra("settingBean", comicBean.getComicSettingBean());
                    getContext().startActivity(intent);
                }
            }

        } catch (Exception e) {
            log("点击错误：" + e.getMessage());
        }
    }


    public BookBean getCurrentShowBean() {
        return currentShowBean;
    }


    @SuppressLint("NotifyDataSetChanged")
    private void upRV() {
        bookShelfAdapter.notifyDataSetChanged();
    }

    private void upTvTop(String name) {
        vBinding.tvTop.setText(name);
    }

    private boolean isDataNull() {
        if (comicBean == null || comicBean.getComicBookBean() == null || comicBean.getComicBookBean().getBookBeanList() == null || comicBean.getComicBookBean().getBookBeanList().size() == 0) {
            return true;
        }
        return false;
    }


    /**
     * 更新选中数据量
     */
    @SuppressLint("SetTextI18n")
    public void upCheckedNum() {
        vBinding.tvNum.setText(checkedNum(currentShowBean.getBookBeanList()) + "");
    }


    @Override
    public void onResume() {
        super.onResume();
        log("onResume");
//        if (currentShowBean != null) {
        //TODO 不在这里获取数据和更新UI,会导致原板块一系列的错误
//            if (currentShowBean.getBookBeanList().size() > 0 && currentShowBean.getBookBeanList().get(0).getFileName().equals(Constant.ROOT_NAME)) {
        //如果是分组编辑界面，就不更新UI,主要是为了解决在编辑分组时临时增添的Bean没有删除带来的一系列Bug
//                initBean(currentShowBean.getFilePath(), 1);
//                initUI();
//            } else {
//                initBean(Constant.BOOK_DIRECTORY, 1);
//                initUI();
//            }
//        }
    }

    @Override
    public void onStart() {
        super.onStart();
        log("onStart");
    }

    /**
     * 书按创建/修改时间正序排【越新越前】
     */
    private void dataSort() {
        if (!isDataNull()) {
//            for (BookBean b : comicBean.getComicBookBean().getBookBeanList()) {
//                log("排序前：" + b.getLastModified());
//            }
            comicBean.getComicBookBean().getBookBeanList().sort(Comparator.comparing(BookBean::getLastModified).reversed());
//                        comicBean.getComicBookBean().getBookBeanList().stream().sorted(Comparator.comparing(BookBean::getLastModified).reversed()).collect(Collectors.toList());
//            for (BookBean b :comicBean.getComicBookBean().getBookBeanList()) {
//                log("排序后：" + b.getLastModified());
//            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getContext().unregisterReceiver(mBatteryBroadcast);
    }

    /**
     * 返回键监听
     *
     * @return 是否不在传递
     */
    public boolean onBackListener() {
        boolean isIntercept = false;
        if (currentType == 3) {
            isIntercept = true;
            jumpStatusSet();
        }
        return isIntercept;
    }

    /**
     * 重新获取全盘数据并跳到1浏览模式【默认浏览模式】
     */
    private void jumpStatusSet() {
        initBean(Constant.BOOK_DIRECTORY, 1);
        topStatusSet(1);
        bookShelfAdapter.setData(currentShowBean.getBookBeanList());
        upRV();
    }

    private BroadcastReceiver mBatteryBroadcast = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!intent.getPackage().equals(getContext().getPackageName())) {
                return;
            }
            log("收到广播Action：" + intent.getAction());
            if (intent.getAction().equals("download_image_complete")) {
                //下载图片完成后的广告
                jumpStatusSet();
            }
        }
    };
}