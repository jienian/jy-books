package com.juying.mjreader;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.RadioGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.github.gzuliyujiang.oaid.DeviceIdentifier;
import com.google.gson.Gson;
import com.juying.mjreader.activity.SimpleWebViewActivity;
import com.juying.mjreader.bean.LoadingBean;
import com.juying.mjreader.bean.WifiHistBean;
import com.juying.mjreader.databinding.ActivityMainBinding;
import com.juying.mjreader.fragment.ComicFragment;
import com.juying.mjreader.fragment.MyFragment2;
import com.juying.mjreader.fragment.NovelFragment;
import com.juying.mjreader.fragment.WifiFragment;
import com.juying.mjreader.manager.UserManager;
import com.juying.mjreader.net.Client;
import com.juying.mjreader.net.Regular;
import com.juying.mjreader.net.bean.DataBean;
import com.juying.mjreader.net.bean.RequestSubmitUserDataBean;
import com.juying.mjreader.net.bean.RequestUserDataBean;
import com.juying.mjreader.net.bean.RetBaseBean;
import com.juying.mjreader.network.models.UserInfo;
import com.juying.mjreader.utils.DeviceInfo;
import com.juying.mjreader.utils.EventBusMessage;
import com.juying.mjreader.utils.config.Constant;
import com.juying.mjreader.utils.sqlite.DBDao;
import com.juying.mjreader.view.DialogMask;
import com.juying.mjreader.view.DialogNotice;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * @author Ycc
 */
public class MainActivity extends BaseActivity {

    private ActivityMainBinding vBinding;
    private NovelFragment novelFragment;
    private ComicFragment comicFragment;
    private WifiFragment wifiFragment;
    //    private MyFragment myFragment;
    private MyFragment2 myFragment;
    DialogNotice dialogNotice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);

        log("onCreate");
        //ViewBinding使用
        vBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(vBinding.getRoot());
        //初始化全局遮罩
        initMask();
        DeviceInfo.getDeviceInfo(this).iniWindow();
        initView();
        vBinding.getRoot().post(this::protocolDetection);//协议检测
        DeviceIdentifier.register(this.getApplication());
        dataSynchronization();
    }

    /**
     * 本地数据同步
     * 1.如果有登录 就从远程拉数据到本地，
     * 2.广播实时接收登录结果，也是从远程拉数据到本地，
     * 3。定时器，每隔5分钟找本地没有上传的数据上传，上传成功后再更改本地userID
     * 【没有上传的依据是：SQL里的UserId是否是默认的，如果是默认的就是没有上传，上传后会同步更改，SQL里的UserID只会在上传后才会被修改】
     */
    private void dataSynchronization() {
        UserInfo userInfo = UserManager.INSTANCE.getUserInfo();
        if (userInfo != null && !TextUtils.isEmpty(userInfo.getUserId())) {
            MjApplication.setUserId(userInfo.getUserId());
            pullData(Regular.READHISTORY, UserManager.INSTANCE.createTopUserId());   // 先拉一遍远程数据到本地
        }

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!intent.getPackage().equals(getPackageName())) {
                    return;
                }
                String userId = intent.getStringExtra("user_id");
                log("接收到登录广播userId:" + userId);
                if (!TextUtils.isEmpty(userId)) {
                    MjApplication.setUserId(userId);//更新内存
                    pullData(Regular.READHISTORY, UserManager.INSTANCE.createTopUserId());
                }
            }
        }, new IntentFilter("login_success"));

        //开定时器，每5分钟把SQL里默认UserId的改成当前ID上传
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                log("同步数据,当前线程：" + Thread.currentThread().getId());
                UserInfo userInfo = UserManager.INSTANCE.getUserInfo();
                if (userInfo != null && !TextUtils.isEmpty(userInfo.getUserId())) {
                    MjApplication.setUserId(userInfo.getUserId());
                    uploadSQLite(userInfo.getUserId());//上传
                }
            }
        }, 50, 5 * 60 * 1000);//启动定时器 参数对应为 TimerTask 延迟时间 间隔时间
    }


    //把所有默认ID的收藏网页内容，从SQL查出来,更改后、上传后台
    private void uploadSQLite(String userId) {
        getExecutorService(2).execute(() -> {
                    WifiHistBean wBean = new WifiHistBean();
                    wBean.setUserID(userId);
                    wBean.setUpdatePresent(true);
                    DBDao db = DBDao.getInstance();

                    List<WifiHistBean> list = db.query(wBean, 6);//先查当前用户，有数据更新的
                    wBean.setUserID(MjApplication.DEFAULT_USER_ID);
                    list.addAll(db.query(wBean, 5));//再查默认用户

                    for (WifiHistBean wifiHistBean : list) {
                        wifiHistBean.setUserID(userId);
                        wifiHistBean.setUpdatePresent(false);
                        log("上传JSON:" + wifiHistBean);
                        RequestSubmitUserDataBean bean = Client.getRsBean(Regular.READHISTORY, wifiHistBean.getUrl(), wifiHistBean);
                        Client.getNetApi().submitUserData(bean).enqueue(new Callback<ResponseBody>() {
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                log("上传数据返回Code：" + response.code());
                                try {
                                    int code = response.code();
                                    if (code == 200) {
                                        DBDao.getInstance().upBean(wifiHistBean, 6);
                                        ResponseBody body = response.body();
                                        if (body != null && !TextUtils.isEmpty(body.string())) {
                                            String json = body.string();
                                            log("上传成功返回JSON：" + json);
                                        }
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                log("上传数据失败：" + t.getMessage());
                            }
                        });
                    }
                }
        );
    }


    //从远程拉对应数据
    private void pullData(String dataType, String topUserId) {
        RequestUserDataBean bean = new RequestUserDataBean(dataType, topUserId);
        getExecutorService(2).execute(() -> Client.getNetApi().getUserData(bean).enqueue(new Callback<RetBaseBean<List<DataBean>>>() {
                    @Override
                    public void onResponse(Call<RetBaseBean<List<DataBean>>> call, Response<RetBaseBean<List<DataBean>>> response) {
                        log("拉取远程返回Code：" + response.code());
                        int code = response.code();
                        if (code == 200) {
                            List<DataBean> dataBeans = response.body().getData();
                            log("服务器拉取数据总JSON：" + dataBeans);
                            if (dataBeans == null) {
                                return;//没有获取到远程数据
                            }
                            for (int i = 0; i < dataBeans.size(); i++) {
                                DataBean dataBean = dataBeans.get(i);
                                String content = dataBean.getContent();
                                WifiHistBean wifiHistBean = new Gson().fromJson(content, WifiHistBean.class);
//                                    DBDao.getInstance().insertOrUp(wifiHistBean); //同步SQL
                                DBDao.getInstance().replace(wifiHistBean);
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<RetBaseBean<List<DataBean>>> call, Throwable t) {
                        log("拉取远程失败：" + t.getMessage());
                    }
                })
        );
    }


    /**
     * 协议检测
     */
    private void protocolDetection() {
        if (!Constant.COMIC_SETTING_SP.getBoolean(Constant.IS_RECOGNIZE_SOFTWARE_PROTOCOLS, false)) {

            String content = getResources().getString(R.string.agreement_content);
            String privacyPolicy = getResources().getString(R.string.privacyPolicy);
            String serviceAgreement = getResources().getString(R.string.serviceAgreement);
            DialogNotice.InsideBean insideBean = new DialogNotice.InsideBean(getResources().getString(R.string.agreement_title), content);
            SpannableStringBuilder builder = new SpannableStringBuilder(content);
            int startIndex = content.lastIndexOf(privacyPolicy);
            int endIndex = startIndex + privacyPolicy.length();
            //设置文本点击事件
            builder.setSpan(new ClickSpannable(v1 -> {
                startActivity(new Intent(this, SimpleWebViewActivity.class).putExtra(SimpleWebViewActivity.LOADING_BEAN_KEY
                        , new LoadingBean(getString(R.string.privacyPolicy), getString(R.string.privacyPolicy_URL))));
            }), startIndex, endIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            //
            int startIndex1 = content.lastIndexOf(serviceAgreement);
            int endIndex1 = startIndex1 + serviceAgreement.length();
            //设置文本点击事件
            builder.setSpan(new ClickSpannable(v1 -> {
                startActivity(new Intent(this, SimpleWebViewActivity.class).putExtra(SimpleWebViewActivity.LOADING_BEAN_KEY
                        , new LoadingBean(getString(R.string.serviceAgreement), getString(R.string.serviceAgreement_URL))));
            }), startIndex1, endIndex1, Spannable.SPAN_INCLUSIVE_INCLUSIVE);

            //   改文本颜色，要在点击事件之后，不然会被覆盖
            builder.setSpan(new ForegroundColorSpan(getColor(R.color.spFFFE605F)), startIndex, endIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            builder.setSpan(new ForegroundColorSpan(Color.parseColor("#FFFE605F")), startIndex1, endIndex1, Spannable.SPAN_INCLUSIVE_INCLUSIVE);

            dialogNotice = new DialogNotice(this, insideBean, v -> {
                if (dialogNotice.vBinding.tvCancel == v) {
                    dialogNotice.dismiss();
                    finish();
                } else if (v == dialogNotice.vBinding.tvStart) {
                    Constant.COMIC_SETTING_SP.edit().putBoolean(Constant.IS_RECOGNIZE_SOFTWARE_PROTOCOLS, true).apply();
                    dialogNotice.dismiss();
                }
            });
            dialogNotice.setOnKeyListener((dialog, keyCode, event) -> true);//拦截物理返回键
            dialogNotice.vBinding.tvContent.setMovementMethod(LinkMovementMethod.getInstance());
            dialogNotice.vBinding.tvContent.setText(builder);
            dialogNotice.show();
        }
    }


    private class ClickSpannable extends ClickableSpan implements View.OnClickListener {

        private View.OnClickListener onClickListener;

        public ClickSpannable(View.OnClickListener onClickListener) {
            this.onClickListener = onClickListener;
        }

        @Override
        public void onClick(View widget) {
            onClickListener.onClick(widget);
        }
    }


    private void initView() {
        setHomePage();
        vBinding.rg.setOnCheckedChangeListener((RadioGroup group, int checkedId) -> {
            if (checkedId == R.id.rb_novel) {
                setHomePage();
            } else if (checkedId == R.id.rb_comic) {
                if (comicFragment == null) {
                    comicFragment = new ComicFragment();
                }
                switchFragment(comicFragment, novelFragment, wifiFragment, myFragment);
            } else if (checkedId == R.id.rb_wifi) {
                if (wifiFragment == null) {
                    wifiFragment = new WifiFragment();
                }
                switchFragment(wifiFragment, comicFragment, novelFragment, myFragment);
//                startActivity(new Intent(this, SeeImageActivity.class));
            } else if (checkedId == R.id.rb_my) {
                if (myFragment == null) {
//                    myFragment = new MyFragment();
                    myFragment = new MyFragment2();
                }
                switchFragment(myFragment, wifiFragment, comicFragment, novelFragment);
            }
        });

    }

    /**
     * Fragment切换
     *
     * @param showFragment  显示的
     * @param hideFragments 隐藏的
     */
    private void switchFragment(Fragment showFragment, Fragment... hideFragments) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.show(showFragment);
        if (!showFragment.isAdded()) {
            ft.add(R.id.frameLayout, showFragment);
        }
        for (Fragment fragment : hideFragments) {
            if (fragment != null && fragment.isAdded()) {
                ft.hide(fragment);
            }
        }
        ft.commit();
    }

    private void setHomePage() {
        if (novelFragment == null) {
            novelFragment = new NovelFragment();
        }
        switchFragment(novelFragment, wifiFragment, comicFragment, myFragment);
    }

    public void navigationSwith(boolean isHide) {
        if (isHide) {
            ObjectAnimator.ofFloat(vBinding.rg, "translationY", vBinding.rg.getHeight()).setDuration(350).start();
            vBinding.rg.setVisibility(View.GONE);
        } else {
            ObjectAnimator.ofFloat(vBinding.rg, "translationY", 0).setDuration(350).start();
            vBinding.rg.setVisibility(View.VISIBLE);

        }


    }

    public void doOnClick(View v) {
        myFragment.doOnClick(v);
    }

    private long time;

    @Override
    public void onBackPressed() {

        log("onBackPressed");
        boolean isIntercept = false;
        if (comicFragment != null && !comicFragment.isHidden()) {
            isIntercept = comicFragment.onBackListener();
        }

  /*      if(novelFragment != null && !novelFragment.isHidden()){
            isIntercept = novelFragment.onBackListener();
        }*/

        if (wifiFragment != null && !wifiFragment.isHidden() && WifiFragment.vBinding.webView.getVisibility() == View.VISIBLE) {
            if (WifiFragment.vBinding.webView.canGoBack()) {
                WifiFragment.vBinding.webView.goBack();
            } else {
                wifiFragment.clickHome();
            }
            isIntercept = true;
        }

        if (!isIntercept) {
            if (System.currentTimeMillis() - time < 700) {
                finish();
            } else {
                to("再按一次，退出软件", false);
            }
            time = System.currentTimeMillis();
        }
    }


    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        //关闭遮罩
        DialogMask.example(MjApplication.CONTEXT).dismiss();
        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(Message event) {
        if (event.what == EventBusMessage.TYPE0) {
            showMasking((boolean) event.obj);
        }
    }

    private DialogMask dialogMask;

    @SuppressLint("WrongConstant")
    private void showMasking(boolean isShowMasking) {
//        if (dialogMask == null) {
//            dialogMask=new DialogMask(MjApplication.CONTEXT);
//        }
//
//        if (isShowMasking) {
//            dialogMask.show();
//        }else {
//            dialogMask.dismiss();
//        }
//检查权限
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            if (!Settings.canDrawOverlays(MainActivity.this)) {
//                //启动Activity让用户授权
//                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
//                startActivity(intent);
//                return;
//            } else {
//                dialogMask = new AlertDialog.Builder(getApplicationContext())
//                        .create();
////                TextView tv = new TextView(this);
////                tv.setText("哈哈哈哈");
////                WindowManager.LayoutParams f = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
////                dialogMask.addContentView(tv,f);
//                dialogMask.setCanceledOnTouchOutside(false);
//                Window window = dialogMask.getWindow();
//                window.setDimAmount(0.2f);
//
//                //        //区域外响应点击事件
////        FLAG_NOT_TOUCH_MODAL作用：即使该window可获得焦点情况下，仍把该window之外的任何event发送到该window之后的其他window
//                window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
//                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
//
//
//
//
//                //检查版本，注意当type为TYPE_APPLICATION_OVERLAY时，铺满活动窗口，但在关键的系统窗口下面，如状态栏或IME
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    dialogMask.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
//                } else {
//                    dialogMask.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
//                }
//                dialogMask.show();
//            }
//        }


//        if (isShowMasking) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                String[] perms = {Manifest.permission.SYSTEM_ALERT_WINDOW};
//                if (EasyPermissions.hasPermissions(this, perms)) {
//                    // 已获取权限
//                    Log.d("TAG", "已获得窗体挂载权限 ");
//                    showDialog();
//                } else {
//                    // 没有权限，现在去获取
//                    Log.d("TAG", "没权限，去获取 ");
//                    EasyPermissions.requestPermissions(this, "申请内存权限", -9, perms);
//                }
//            } else {
//
//            }
//        } else {
//            if (dialogMask != null) {
//                dialogMask.dismiss();
//            }
//        }

    }



    private void initMask() {
        boolean checked = Constant.COMIC_SETTING_SP.getBoolean("isModeNight", false);
        if (checked) {
            DialogMask.example(MjApplication.CONTEXT).show();
        }
    }



}