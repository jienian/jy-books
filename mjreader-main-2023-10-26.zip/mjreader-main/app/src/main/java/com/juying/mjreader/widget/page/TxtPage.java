package com.juying.mjreader.widget.page;

import java.util.List;

/**
 * @Author Nimyears
 */

public class TxtPage {
    int position;
    String title;
    int titleLines; //当前 lines 中为 title 的行数。
    List<String> lines;
}
