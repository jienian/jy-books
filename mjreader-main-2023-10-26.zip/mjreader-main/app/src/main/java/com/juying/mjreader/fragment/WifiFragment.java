package com.juying.mjreader.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import com.juying.mjreader.MainActivity;
import com.juying.mjreader.MjApplication;
import com.juying.mjreader.R;
import com.juying.mjreader.activity.SeeImageActivity;
import com.juying.mjreader.activity.WifiHistActivity;
import com.juying.mjreader.adapter.WifiHomeAdapter;
import com.juying.mjreader.bean.ComicSettingBean;
import com.juying.mjreader.bean.WifiHistBean;
import com.juying.mjreader.databinding.FragmentWifiBinding;
import com.juying.mjreader.utils.AdBlocker;
import com.juying.mjreader.utils.LogUtil;
import com.juying.mjreader.utils.WebViewUtil;
import com.juying.mjreader.utils.WifiFragmentMode;
import com.juying.mjreader.utils.sqlite.DBDao;
import com.juying.mjreader.view.DialogEngine;
import com.juying.mjreader.view.DialogMove;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author Ycc
 */
public class WifiFragment extends BaseFragment {


    public static FragmentWifiBinding vBinding;
    private static Context context;
    private DialogEngine dialogEngine;
    private static DialogMove dialogMove;
    private ImageView imageView;
    public static ComicSettingBean comicSettingBean;
    private static String currentTitle;

    private static FragmentActivity mainActivity;

    private static WifiFragment wifiFragment;
    private WifiHomeAdapter adapter;
    //    private  static  WifiHistBean currentShowUrlBean;
    private static WifiHistBean currentShowWifiHistBean;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        log("onCreate");
        wifiFragment = this;
        mainActivity = getActivity();
        context = getContext();
        AdBlocker.init(getContext());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        log("onCreateView");
        vBinding = FragmentWifiBinding.inflate(inflater, null, false);
        initView();
        initData();
        initUI();
        initListener();
        return vBinding.getRoot();
    }

    private void initView() {
        Resources resources = vBinding.searchView.getContext().getResources();
        int imgId = resources.getIdentifier("android:id/search_mag_icon", null, null);//获取ImageView
        int editId = resources.getIdentifier("android:id/search_src_text", null, null);//获取Edit
        EditText txtSearch = vBinding.searchView.findViewById(editId);
        txtSearch.setTextColor(getContext().getColor(R.color.black));
        imageView = vBinding.searchView.findViewById(imgId);
    }

    private void initData() {
        comicSettingBean = new ComicSettingBean();
    }

    private List<WifiHomeAdapter.InsideBean> upFavoriteData() {
        WifiHistBean wBean = new WifiHistBean();
        wBean.setDataId(MjApplication.getUserId());
        wBean.setCollection(true);
        List<WifiHistBean> list = DBDao.getInstance().query(wBean, 5);
        List<WifiHomeAdapter.InsideBean> ib = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (i == 8) {
                ib.remove(7);
                ib.add(new WifiHomeAdapter.InsideBean("更多", R.mipmap.logo_transparent, ""));
                break;
            }
            WifiHistBean whb = list.get(i);

            int res = WifiFragmentMode.searchUrlToRes(whb.getUrl());
            if (res == -1) {
                res = WifiFragmentMode.getRes(comicSettingBean.getSearchEngine());
            }
            ib.add(new WifiHomeAdapter.InsideBean(whb.getTitle(), res, whb.getUrl()));
        }
        return ib;
    }

    @SuppressLint("NotifyDataSetChanged")
    private void upRv(List<WifiHomeAdapter.InsideBean> iBean) {
        if (adapter == null) {
            adapter = new WifiHomeAdapter(getContext(), iBean);
            vBinding.rv.setLayoutManager(new GridLayoutManager(getContext(), 4));
            vBinding.rv.setAdapter(adapter);
        } else {
            adapter.setData(iBean);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }


    public void clickHome() {
        //主页
        showHome(true);

        upRv(upFavoriteData());
        //清理全部缓存
//        vBinding.webView.clearFormData();
        vBinding.webView.clearHistory();
    }


    private void initListener() {
        vBinding.view1.setOnClickListener(v -> {
            if (dialogEngine == null) {
                dialogEngine = new DialogEngine((MainActivity) getContext(), R.style.DialogTheme, comicSettingBean.getSearchEngine(), query -> {
                    log("点击搜索引擎：" + query);
                    comicSettingBean.setSearchEngine(query);
                    WifiFragmentMode.setImageView(imageView, query);
                });
            }
            dialogEngine.show();
        });


        vBinding.iv1.setOnClickListener(v -> {
            if (vBinding.webView.canGoBack()) {
                isClickBack = true;
                vBinding.webView.goBack();
//                for (String s :WebViewUtil.noTedirectUrlList) {
//                    log("回退栈：" + s);
//                }
//                //获取历史列表
//                vBinding.webView.loadUrl(WebViewUtil.noTedirectUrlList.get(WebViewUtil.noTedirectUrlList.size() - 1 - 1));
//                WebViewUtil.noTedirectUrlList.remove(WebViewUtil.noTedirectUrlList.size() - 1);
            } else {
                clickHome();
            }
        });
        vBinding.iv2.setOnClickListener(v -> {
            if (vBinding.webView.getVisibility() == View.GONE) {
                return;
            }
            if (vBinding.webView.canGoForward()) {
                vBinding.webView.goForward();
            } else {
                to("没有更多页面啦！", false);
//                ((MainActivity) getActivity()).navigationSwith(true);
            }
        });
        vBinding.iv3.setOnClickListener(v -> {
            clickHome();
        });

        vBinding.iv4.setOnClickListener(v -> {
            if (vBinding.webView.getVisibility() == View.GONE) {
                return;
            }
            vBinding.webView.reload();//刷新
        });

        vBinding.iv5.setOnClickListener(v -> {
            //这里每次都要判断，因为数据不一样

            dialogMove = new DialogMove(this, R.style.DialogTheme, comicSettingBean.isBlockAd(), currentShowWifiHistBean != null && currentShowWifiHistBean.isCollection(), false, (type, isColl) -> {
                if (type == 1) {
                    startActivity(new Intent(getContext(), WifiHistActivity.class));
                } else if (type == 2) {
                    if (vBinding.webView.getVisibility() == View.GONE) {
                        to("未浏览网页", false);
                        return;
                    }
                    currentShowWifiHistBean.setCollection(!isColl);
                    DBDao.getInstance().upBean(currentShowWifiHistBean, 3);
                    dialogMove.initUi(comicSettingBean.isBlockAd(), currentShowWifiHistBean.isCollection(), false);
                } else if (type == 4) {
                    //看图模式
//                        startActivity(new Intent(getContext(), SeeImageActivity.class));
                    //获取
//                        WebViewUtil.addImageClickListner(getContext(), vBinding.webView);
                    if (vBinding.webView.getVisibility() == View.GONE) {
                        to("未浏览网页", false);
                        return;
                    }
                    vBinding.webView.evaluateJavascript("javascript:getImages()", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            if (value != null && !value.equals("") && !value.equals("null")) {
                                value = value.replace("\"", "");
                                String[] dataSource = value.split("---");
//                                    List<String> imageDataSource = Arrays.asList(dataSource);
                                Log.d("TAG", "已获取到图片, 总共 " + dataSource.length + " 张图片" + "\n图片地址：" + Arrays.toString(dataSource));
                                if (dataSource.length == 0) {
                                    to("主人,没有可观看的图片！", false);
                                } else {
                                    Intent intent = new Intent(getContext(), SeeImageActivity.class);
                                    intent.putExtra("images", dataSource);
                                    intent.putExtra("webView_title", currentTitle);
                                    startActivity(intent);
                                }
                            }
                        }
                    });
                } else if (type == 5) {
                    comicSettingBean.setBlockAd(isColl);
                }
            });
//            if (dialogMove == null) {}else {
//                if (vBinding.webView.getVisibility() == View.GONE) {
//                    dialogMove.initUi(false, false);
//                } else {
//                    dialogMove.initUi(currentShowWifiHistBean.isCollection(), false);
//                }
//            }
            dialogMove.show();
        });

        vBinding.cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (currentShowWifiHistBean == null) {
                return;
            }
            currentShowWifiHistBean.setCollection(isChecked);
            DBDao.getInstance().upBean(currentShowWifiHistBean, 3);
        });
        vBinding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (TextUtils.isEmpty(query)) {
                    return false;
                }
                String searchEngine = comicSettingBean.getSearchEngine();
                String url = WifiFragmentMode.searchEngineToSearchUrl(searchEngine) + query;
                showHome(false);
                initWebView(vBinding.webView, url, listener);

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText)) {
//                    to("恢复搜索前原貌", false);
                }
                return false;
            }
        });
    }


    private boolean isClickBack;

    public boolean isClickBack() {
        return isClickBack;
    }

    public void setClickBack(boolean clickBack) {
        isClickBack = clickBack;
    }

    private void initUI() {
        WifiFragmentMode.setImageView(imageView, comicSettingBean.getSearchEngine());
    }


    @Override
    public void onResume() {
        super.onResume();
        if (dialogMove != null) {
            dialogMove.showIv2(false);
        }
        upRv(upFavoriteData());
    }

    //控制ManActivity下方菜单显示
    public void showMenu(boolean isHide) {
//        ((MainActivity) getActivity()).navigationSwith(isHide);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //清理全部缓存
        vBinding.webView.clearFormData(); //清除当前WebView自动完成填充的表单数据(并不会清除WebView存储到本地的数据)
        vBinding.webView.clearHistory();//历史记录清空
        //清除整个应用中WebView网页访问留下的缓存
//        vBinding.webView.clearCache(true);
    }


    public static void externalLoading(String url) {
        if (vBinding != null) {
            showHome(false);
            if (dialogMove != null) {
                dialogMove.dismiss();
            }
            //加载过，直接加载
            initWebView(vBinding.webView, url, listener);
        }

    }

    private static WebViewUtil.WebViewListener listener = new WebViewUtil.WebViewListener() {
        @Override
        public void onReceivedTitle(WebView view, String title) {
            currentTitle = title;
        }

        @Override
        public void onPageFinished(WebView webView, String url) {
            currentTitle = webView.getTitle();
            //先组建一个新的
            currentShowWifiHistBean = new WifiHistBean(
                    System.currentTimeMillis() + "",
                    MjApplication.getUserId(), System.currentTimeMillis(),
                    comicSettingBean.getSearchEngine(), webView.getTitle(), url, "", false, true);
            //保存历史,先判断本用户的这个Url是否存在，存在就只更新时间，不存在就增添整个数据
            currentShowWifiHistBean = WebViewUtil.inputOrUp(currentShowWifiHistBean);
//            DBDao.getInstance().replace(currentShowWifiHistBean);
//            log("保存后数据：" + currentShowWifiHistBean.toString());

            upCurrent(currentShowWifiHistBean.isCollection());
        }
    };


    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(Message event) {
        // Do something
        if (event.obj instanceof WifiHomeAdapter.InsideBean) {
            WifiHomeAdapter.InsideBean bean = (WifiHomeAdapter.InsideBean) event.obj;
            if ("".equals(bean.getUrl()) && "更多".equals(bean.getTitle())) {
                startActivity(new Intent(getActivity(), WifiHistActivity.class));
            } else {
                initWebView(vBinding.webView, bean.getUrl(), listener);
                showHome(false);
            }
        }
    }

    public static void showHome(boolean show) {
        if (show) {
            vBinding.rlSearch.setVisibility(View.VISIBLE);
            vBinding.rl.setVisibility(View.GONE);
            vBinding.webView.setVisibility(View.GONE);
        } else {
            vBinding.rlSearch.setVisibility(View.GONE);
            vBinding.rl.setVisibility(View.VISIBLE);
            vBinding.webView.setVisibility(View.VISIBLE);
        }
    }


    /**
     * @param webView
     */
    @SuppressLint({"JavascriptInterface", "SetJavaScriptEnabled"})
    public static void initWebView(WebView webView, String url, WebViewUtil.WebViewListener listener) {
        if (webClient == null) {
            // 启用javascript
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);
            webSettings.setDefaultTextEncodingName("UTF-8");
//        contentWebView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);//加载html数据
            // 添加js交互接口类，并起别名 imageListner
//        webView.addJavascriptInterface(new JavascriptInterface2(context), "imageListener");
//        webSettings.setJavaScriptEnabled(true);//暂时不需要交互
//        webSettings.setDomStorageEnabled(true);// 打开本地存供JS调用至关重要
//        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);//设置缓存模式为默认
//        webSettings.AppCacheMaxSize(1024 * 1024 * 8);//实现8后经存
            webSettings.setAllowFileAccess(true);//文件访问
//        webSettings.setAppCacheEnabled(true);
//        String appCachePath = MjApplication.CONTEXT.getCacheDir().getAbsolutePath();
//        webSettings.setAppCachePath(appCachePath);
            webSettings.setDatabaseEnabled(true);
//        webSettings.setGeolocationEnabled(true);//定位
            webClient = new WebViewClient() {


                //DOM加载结束，图片可能不一定加载完全了
                @Override
                public void onPageFinished(WebView view, String url) {
                    Log.d("TAG", "onPageFinished,加载结束: " + url + ";标题:" + view.getTitle() + ";图标：" + view.getFavicon());
//                saveUrlInfo(view, "user", url, context.comicSettingBean.getSearchEngine(), false);//存浏览记录
                    listener.onPageFinished(view, url);
                    WebViewUtil.addImageClickListner(view);

                    Log.d("TAG", "onPageFinished: 零时url:" + loadedUrls.size());

//                        view.loadUrl(getJs1(currentUrl));//去父标签
//                    view.loadUrl(getJs(url));


//                    view.evaluateJavascript(getJs4(), new ValueCallback<String>() {
//                        @Override
//                        public void onReceiveValue(String value) {
//
//                        }
//                    });



//                    super.onPageFinished(view, url);
                }

                @SuppressLint("SetJavaScriptEnabled")
                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    Log.d("TAG", "onPageStarted执行: " + url);
                    super.onPageStarted(view, url, favicon);
                }

                //WebView发起的WEB请求因为网络原因失败时回调
                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    super.onReceivedError(view, request, error);
                    int errorCode = error.getErrorCode();
                    String errorMessage = error.getDescription().toString();
                    Log.i("TAG", "onReceivedError,加载错误:网络原因——errorCode : " + errorCode + " errorMessage : " + errorMessage);
                }

                //WebView发起的WEB请求收到服务器的错误消息时回调
                @Override
                public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                    Log.i("TAG", "onReceivedHttpError，加载错误:服务器返回错误消息——  errorCode : " + errorResponse.getStatusCode() + ";Encoding : " + errorResponse.getEncoding());
                }

                //解决重定向造成的 -10 errorMessage : net::ERR_UNKNOWN_URL_SCHEME 问题
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    String url = request.getUrl().toString();
                    WebView.HitTestResult hit = view.getHitTestResult();
                    //hit.getExtra()为null或者hit.getType() == 0都表示即将加载的URL会发生重定向，需要做拦截处理
                    if (TextUtils.isEmpty(hit.getExtra()) || hit.getType() == 0) {
                        //通过判断开头协议就可解决大部分重定向问题，有另外的需求可以在此判断下操作
//                    Log.e("重定向", "重定向: " + hit.getType() + " && EXTRA（）" + hit.getExtra() + "------");
//                    Log.e("重定向", "GetURL: " + view.getUrl() + "\n" + "getOriginalUrl()" + view.getOriginalUrl());
                        Log.d("重定向", "URL: " + url);
                    }
                    if (url.startsWith("http://") || url.startsWith("https://")) { //加载的url是http/https协议地址
//                        view.loadUrl(url);
                        return false; //返回false表示此url默认由系统处理,url未加载完成，会继续往下走
                    } else { //加载的url是自定义协议地址
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            @SuppressLint("WrongConstant") ActivityInfo activityInfo = intent.resolveActivityInfo(view.getContext().getPackageManager(), intent.getFlags());
                            if (activityInfo.exported) {
                                context.startActivity(intent);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return true;
                    }
                }


                @Override
                public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                    //每次访问网页，webview都会记录访问的地址，保存了一个堆栈中，也就是浏览历史记录。网页进行加载时，都会调用；
                    //网页加载过程中本方法只会调用一次，网页前进后退并不会回调这个函数。
//                Log.d("TAG", "doUpdateVisitedHistory;webView标题：" + view.getTitle() + "；webView图标：" + view.getFavicon() + ";是否是重新加载：" + isReload + ": 当前加载url:" + url);
//                WebBackForwardList xxxx = view.copyBackForwardList();
//                WebHistoryItem xxx = xxxx.getCurrentItem();
//                Log.d("TAG", "doUpdateVisitedHistory: 历史记录标题：" + xxx.getTitle() + ";图标：" + xxx.getFavicon() + ";url：" + xxx.getUrl() + ";源url：" + xxx.getOriginalUrl());
                    ;
//                        doUpdateVisitedHistory
                    super.doUpdateVisitedHistory(view, url, isReload);
                }

                private Map<String, Boolean> loadedUrls = new HashMap<>();

                @Nullable
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    if (!comicSettingBean.isBlockAd()) {
                        return super.shouldInterceptRequest(view, request);
                    }
                    //屏蔽广告
                    boolean ad;
                    String currentUrl = request.getUrl().toString();
                    LogUtil.d("TAG", "shouldInterceptRequest:" + currentUrl);
                    if (!loadedUrls.containsKey(currentUrl)) {
                        ad = AdBlocker.isAd(currentUrl);
                        loadedUrls.put(currentUrl, ad);
                    } else {
                        ad = loadedUrls.get(currentUrl);
                    }


                    if (ad) {
//                        view.loadUrl(getJs1(currentUrl));//去父标签
//                        view.loadUrl(getJs(currentUrl));



                    }

                    return ad ? AdBlocker.createEmptyResource() :
                            super.shouldInterceptRequest(view, request);
                }
            };
            webView.setWebViewClient(webClient);
            webView.setWebChromeClient(new WebChromeClient() {
                //WebView加载任意网络请求时回调，包括html、网络图片
                //此回调虽然在单次页面请求时不只被回调一次，但是需要对页面所有请求做监控时，是个好选择
                @Override
                public void onProgressChanged(WebView view, int newProgress) {
                    Log.d("TAG", "onProgressChanged加载进度: " + newProgress);
                    vBinding.webViewProgress.setProgress(newProgress);
                    if (newProgress == 100) {
                        vBinding.webViewProgress.setVisibility(View.INVISIBLE);
                        vBinding.cb.setEnabled(true);
                    } else {
                        vBinding.webViewProgress.setVisibility(View.VISIBLE);
                        vBinding.cb.setEnabled(false);
                    }
                }

                //在WebView载入<head></head>标签结束时回调
                @Override
                public void onReceivedTitle(WebView view, String title) {
                    Log.d("TAG", "onReceivedTitle，WebView载入<head></head>标签结束：标题: " + title);
                    listener.onReceivedTitle(view, title);
                }

//                @Override
//                public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
//                    //禁止弹窗
//                    return true;
//                }
//
//                @Override
//                public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
//                    //禁止弹窗
//                    return true;
//                }
//
//                @Override
//                public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
//                    //禁止弹窗
//                    return true;
//                }
            });
        }
        webView.loadUrl(url);
    }

    private static void upCurrent(boolean currentShowUrlIsColl) {
        vBinding.cb.setChecked(currentShowUrlIsColl);
    }


    private static WebViewClient webClient;


    //隐藏图片父元素js
    private static String getJs1(String url) {
        String js = "javascript: (function () {\n" +
                "    var aList = document.getElementsByTagName(\"img\");\n" +
                "    var parentList = [];\n" +
                "    for (var i = 0; i < aList.length; i++) {\n" +
                "        parentList = parentList.concat([aList[i].parentElement]);\n" +
                "    }\n" +
                "    for (var i = 0; i < aList.length; i++) {\n" +
                "        if (aList[i].getAttribute(\"src\").indexOf(\"" + url + "\") != -1) {\n" +
                "            parentList[i].style.display = \"none\";\n" +
                "        }\n" +
                "    }\n" +
                "})();";
        return js;
    }
    //隐藏a元素js
    private static String getJs(String url) {
        String js = "javascript: (function () {\n" +
                "    var aList = document.getElementsByTagName(\"a\");\n" +
                "    var parentList = [];\n" +
                "    for (var i = 0; i < aList.length; i++) {\n" +
                "        parentList = parentList.concat([aList[i].parentElement]);\n" +
                "    }\n" +
                "    for (var i = 0; i < aList.length; i++) {\n" +
                "        if (aList[i].getAttribute(\"href\").indexOf(\"" + url + "\") != -1) {\n" +
                "            parentList[i].style.display = \"none\";\n" +
                "        }\n" +
                "    }\n" +
                "})();";
        return js;
    }


    private static String getJs3() {

        String js = "javascript:(" +
                "    function() {" +
                "            var len = document.getElementsByClassName('Advertisement').length; " +
                "            for(var i = 0; i < len; i ++){" +
                "                document.getElementsByClassName('Advertisement')[i].style.display = 'none'" +
                "            }" +
                "        }" +
                ")()";
        return js;


    }


    private static String getJs4() {

        String js = "javascript:(" +
                "    function() {" +
                "            var len = document.getElementsByClassName('ggrank').length; " +
                "            for(var i = 0; i < len; i ++){" +
                "                document.getElementsByClassName('ggrank')[i].style.display = 'none'" +
                "            }" +
                "        }" +
                ")()";
        return js;


    }




}